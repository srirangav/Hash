#!
javac -cp "*;.;lsh.jar" @sources.list -encoding utf8 -d bin
