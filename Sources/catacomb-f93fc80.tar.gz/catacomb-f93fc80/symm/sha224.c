/* -*-c-*-
 *
 * Stub code for SHA-224
 */

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "sha224.h"

GHASH_DEF(SHA224, sha224)
HASH_TEST(SHA224, sha224)
