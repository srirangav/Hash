/* -*-c-*-
 *
 * The CAST-128 block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the CAST-128 block cipher --------------------------------*
 *
 * CAST, designed by Carlisle Adams and Stafford Tavares, is a method for
 * designing block ciphers, based around the concept of `bent functions'.  It
 * is described in the paper `Constructing Symmetric Ciphers using the CAST
 * Design Procedure' by Carlisle Adams.
 *
 * CAST-128, defined in RFC2144, is a particular instance of the CAST design
 * procedure, The cipher seems strong and fairly quick.  The design procedure
 * itself is patented, although the cipher CAST-128 is free to use.
 *
 * Although CAST ciphers are resistant to differential and linear
 * cryptanalysis, some instances have been broken by more advanced techniques
 * -- the CAST procedure does not guarantee a strong cipher.  However,
 * CAST-128 has so far resisted all attacks against it, and has now been
 * accepted by the Canadian government for protection of all `Designated'
 * material.
 */

#ifndef CATACOMB_CAST128_H
#define CATACOMB_CAST128_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

/*----- Magic numbers -----------------------------------------------------*/

#define CAST128_BLKSZ 8
#define CAST128_KEYSZ 16
#define CAST128_CLASS (N, B, 64)

extern const octet cast128_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct cast128_ctx {
  unsigned r;
  uint32 km[16];
  octet kr[16];
} cast128_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @cast128_init@ --- *
 *
 * Arguments:	@cast128_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a CAST-128 key buffer.  CAST-128 accepts
 *		128-bit keys or shorter.
 */

extern void cast128_init(cast128_ctx */*k*/,
			 const void */*buf*/, size_t /*sz*/);

/* --- @cast128_eblk@, @cast128_dblk@ --- *
 *
 * Arguments:	@const cast128_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void cast128_eblk(const cast128_ctx */*k*/,
			 const uint32 */*s*/, uint32 */*d*/);

extern void cast128_dblk(const cast128_ctx */*k*/,
			 const uint32 */*s*/, uint32 */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
