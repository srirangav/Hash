/* -*-c-*-
 *
 * Implementation of the SHA-256 hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the SHA-256 hash function --------------------------------*
 *
 * SHA-1 (Secure Hash Algorithm) was designed by the NSA, for use with the
 * Digital Signature Algorithm.  This is an evolution with a larger output
 * size, intended to provide security commensurate with 128-bit AES.  At the
 * time of writing, SHA-256 is very new, and can't be trusted too far.
 */

#ifndef CATACOMB_SHA256_H
#define CATACOMB_SHA256_H
#define CATACOMB_SHA224_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

/*----- Magic numbers -----------------------------------------------------*/

#define SHA256_BUFSZ 64
#define SHA256_HASHSZ 32
#define SHA256_STATESZ 32

#define SHA224_BUFSZ 64
#define SHA224_HASHSZ 28
#define SHA224_STATESZ 32

/*----- Data structures ---------------------------------------------------*/

typedef struct sha256_ctx {
  uint32 a, b, c, d, e, f, g, h;	/* Chaining variables */
  uint32 nl, nh;			/* Byte count so far */
  unsigned off;				/* Offset into buffer */
  octet buf[SHA256_BUFSZ];		/* Accumulation buffer */
} sha256_ctx, sha224_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @sha256_compress@, @sha224_compress@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		SHA-256 compression function.
 */

extern void sha256_compress(sha256_ctx */*ctx*/, const void */*sbuf*/);
#define sha224_compress sha256_compress

/* --- @sha256_init@, @sha224_init@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

extern void sha256_init(sha256_ctx */*ctx*/);
extern void sha224_init(sha256_ctx */*ctx*/);

/* --- @sha256_set@, @sha224_set@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

extern void sha256_set(sha256_ctx */*ctx*/, const void */*buf*/,
		       unsigned long /*count*/);
#define sha224_set sha256_set

/* --- @sha256_hash@, @sha224_hash@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

extern void sha256_hash(sha256_ctx */*ctx*/,
			const void */*buf*/, size_t /*sz*/);
#define sha224_hash sha256_hash

/* --- @sha256_done@, @sha224_done@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

extern void sha256_done(sha256_ctx */*ctx*/, void */*hash*/);
extern void sha224_done(sha256_ctx */*ctx*/, void */*hash*/);

/* --- @sha256_state@, @sha224_state@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @sha256_set@.
 */

extern unsigned long sha256_state(sha256_ctx */*ctx*/, void */*state*/);
#define sha224_state sha256_state

/*----- Generic hash interface --------------------------------------------*/

extern const gchash sha256;
extern const gchash sha224;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
