/* -*-c-*-
 *
 * The Noekeon block cipher
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>

#include <mLib/bits.h>

#include "blkc.h"
#include "gcipher.h"
#include "noekeon.h"

/*----- Global variables --------------------------------------------------*/

const octet noekeon_keysz[] = { KSZ_SET, NOEKEON_KEYSZ, 0 };

/*----- Magic constants ---------------------------------------------------*/

/* --- To generate the magic --- *
 *
 * perl -e'@@r=();$x=0x80;for(0..16){push(@@r,$x);$x<<=1;$x^=0x11b
 * if$x&0x100;};print join(", ",map{sprintf"0x%02x",$_}@@r),"\n";'
 */

static const octet rcon[17] = {
  0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a,
  0x2f, 0x5e, 0xbc, 0x63, 0xc6, 0x97, 0x35, 0x6a,
  0xd4
};

/*----- Main code ---------------------------------------------------------*/

/* --- @noekeon_init@--- *
 *
 * Arguments:	@noekeon_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Noekeon key buffer.  Noekeon accepts a 128-bit
 *		key.
 */

void noekeon_init(noekeon_ctx *k, const void *buf, size_t sz)
{
  const octet *p = buf;
  static const noekeon_ctx nullkey = { { 0, 0, 0, 0 } };

  KSZ_ASSERT(noekeon, sz);
  k->k[0] = LOAD32(p +	0);
  k->k[1] = LOAD32(p +	4);
  k->k[2] = LOAD32(p +	8);
  k->k[3] = LOAD32(p + 12);
  noekeon_eblk(&nullkey, k->k, k->k);
}

/* --- @noekeon_eblk@, @noekeon_dblk@ --- *
 *
 * Arguments:	@const noekeon_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

#define GAMMA(a, b, c, d) do {						\
  uint32 _x;								\
  b ^= ~(c | d); a ^= b & c;						\
  _x = d; d = a; a = _x;						\
  c ^= a ^ b ^ d;							\
  b ^= ~(c | d); a ^= b & c;						\
} while (0)

#define THETA(ka, kb, kc, kd, a, b, c, d) do {				\
  uint32 _x;								\
  _x = a ^ c; _x ^= ROR32(_x, 8) ^ ROL32(_x, 8); b ^= _x; d ^= _x;	\
  a ^= ka; b ^= kb; c ^= kc; d ^= kd;					\
  _x = b ^ d; _x ^= ROR32(_x, 8) ^ ROL32(_x, 8); a ^= _x; c ^= _x;	\
} while (0)

#define ITHETA(ka, kb, kc, kd, a, b, c, d) do {				\
  uint32 _x;								\
  _x = b ^ d; _x ^= ROR32(_x, 8) ^ ROL32(_x, 8); a ^= _x; c ^= _x;	\
  a ^= ka; b ^= kb; c ^= kc; d ^= kd;					\
  _x = a ^ c; _x ^= ROR32(_x, 8) ^ ROL32(_x, 8); b ^= _x; d ^= _x;	\
} while (0)

#define PI1(a, b, c, d) do {						\
  b = ROL32(b, 1); c = ROL32(c, 5); d = ROL32(d, 2);			\
} while (0)

#define PI2(a, b, c, d) do {						\
  b = ROR32(b, 1); c = ROR32(c, 5); d = ROR32(d, 2);			\
} while (0)

#define ROUND(r, ka, kb, kc, kd, a, b, c, d) do {			\
  a ^= *r++; THETA(ka, kb, kc, kd, a, b, c, d);				\
  PI1(a, b, c, d); GAMMA(a, b, c, d); PI2(a, b, c, d);			\
} while (0)

#define IROUND(r, ka, kb, kc, kd, a, b, c, d) do {			\
  ITHETA(ka, kb, kc, kd, a, b, c, d); a ^= *--r;			\
  PI1(a, b, c, d); GAMMA(a, b, c, d); PI2(a, b, c, d);			\
} while (0)

void noekeon_eblk(const noekeon_ctx *k, const uint32 *src, uint32 *dst)
{
  uint32 ka = k->k[0], kb = k->k[1], kc = k->k[2], kd = k->k[3];
  uint32 a = src[0], b = src[1], c = src[2], d = src[3];
  const octet *r = rcon;

  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);
  ROUND(r, ka, kb, kc, kd, a, b, c, d);

  a ^= *r++; THETA(ka, kb, kc, kd, a, b, c, d);

  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d;
}

void noekeon_dblk(const noekeon_ctx *k, const uint32 *src, uint32 *dst)
{
  uint32 ka = k->k[0], kb = k->k[1], kc = k->k[2], kd = k->k[3];
  uint32 a = src[0], b = src[1], c = src[2], d = src[3];
  const octet *r = rcon + sizeof(rcon);

  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);
  IROUND(r, ka, kb, kc, kd, a, b, c, d);

  ITHETA(ka, kb, kc, kd, a, b, c, d); a ^= *--r;

  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d;
}

BLKC_TEST(NOEKEON, noekeon)

/*----- That's all, folks -------------------------------------------------*/
