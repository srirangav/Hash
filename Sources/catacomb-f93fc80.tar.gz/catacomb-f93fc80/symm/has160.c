/* -*-c-*-
 *
 * The HAS160 message digest function
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "has160.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @has160_compress@ --- *
 *
 * Arguments:	@has160_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		HAS160 compression function.
 */

void has160_compress(has160_ctx *ctx, const void *sbuf)
{
  uint32 a, b, c, d, e;
  uint32 buf[16];

  /* --- Fetch the chaining variables --- */

  a = ctx->a;
  b = ctx->b;
  c = ctx->c;
  d = ctx->d;
  e = ctx->e;

  /* --- Fetch the buffer contents --- */

  {
    int i;
    const octet *p;

    for (i = 0, p = sbuf; i < 16; i++, p += 4)
      buf[i] = LOAD32_L(p);
  }

  /* --- Definitions for round functions --- */

#define F(x, y, z) (((x) & (y)) | (~(x) & (z)))
#define G(x, y, z) ((x) ^ (y) ^ (z))
#define H(x, y, z) ((y) ^ ((x) | ~(z)))

#define FF(f, a, b, c, d, e, x, s, ss, k) do {				\
  e += ROL32(a, s) + f(b, c, d) + (x) + k;				\
  b = ROL32(b, ss);							\
} while (0)

  /* --- The actual hashing --- *
   *
   * Hmm, this is more regular than most.  The macros are quite grim,
   * though.
   */

#define ROUND(f, ss, k,							\
     i0,  i1,  i2,  i3,	 i4,  i5,  i6,	i7,				\
     i8,  i9, i10, i11, i12, i13, i14, i15) do {			\
  FF(f, a, b, c, d, e, buf[ i8]^buf[ i9]^buf[i10]^buf[i11],  5, ss, k);	\
  FF(f, e, a, b, c, d,				  buf[ i0], 11, ss, k);	\
  FF(f, d, e, a, b, c,				  buf[ i1],  7, ss, k);	\
  FF(f, c, d, e, a, b,				  buf[ i2], 15, ss, k);	\
  FF(f, b, c, d, e, a,				  buf[ i3],  6, ss, k);	\
  FF(f, a, b, c, d, e, buf[i12]^buf[i13]^buf[i14]^buf[i15], 13, ss, k);	\
  FF(f, e, a, b, c, d,				  buf[ i4],  8, ss, k);	\
  FF(f, d, e, a, b, c,				  buf[ i5], 14, ss, k);	\
  FF(f, c, d, e, a, b,				  buf[ i6],  7, ss, k);	\
  FF(f, b, c, d, e, a,				  buf[ i7], 12, ss, k);	\
  FF(f, a, b, c, d, e, buf[ i0]^buf[ i1]^buf[ i2]^buf[ i3],  9, ss, k);	\
  FF(f, e, a, b, c, d,				  buf[ i8], 11, ss, k);	\
  FF(f, d, e, a, b, c,				  buf[ i9],  8, ss, k);	\
  FF(f, c, d, e, a, b,				  buf[i10], 15, ss, k);	\
  FF(f, b, c, d, e, a,				  buf[i11],  6, ss, k);	\
  FF(f, a, b, c, d, e, buf[ i4]^buf[ i5]^buf[ i6]^buf[ i7], 12, ss, k);	\
  FF(f, e, a, b, c, d,				  buf[i12],  9, ss, k);	\
  FF(f, d, e, a, b, c,				  buf[i13], 14, ss, k);	\
  FF(f, c, d, e, a, b,				  buf[i14],  5, ss, k);	\
  FF(f, b, c, d, e, a,				  buf[i15], 13, ss, k); \
} while (0)

  ROUND(F, 10, 0x00000000,
	 0,  1,	 2,  3,	 4,  5,	 6,  7,	 8,  9, 10, 11, 12, 13, 14, 15);
  ROUND(G, 17, 0x5a827999,
	 3,  6,	 9, 12, 15,  2,	 5,  8, 11, 14,	 1,  4,	 7, 10, 13,  0);
  ROUND(H, 25, 0x6ed9eba1,
	12,  5, 14,  7,	 0,  9,	 2, 11,	 4, 13,	 6, 15,	 8,  1, 10,  3);
  ROUND(G, 30, 0x8f1bbcdc,
	 7,  2, 13,  8,	 3, 14,	 9,  4, 15, 10,	 5,  0, 11,  6,	 1, 12);

  /* --- Update the chaining variables --- */

  ctx->a += a;
  ctx->b += b;
  ctx->c += c;
  ctx->d += d;
  ctx->e += e;
}

/* --- @has160_init@ --- *
 *
 * Arguments:	@has160_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void has160_init(has160_ctx *ctx)
{
  ctx->a = 0x67452301;
  ctx->b = 0xefcdab89;
  ctx->c = 0x98badcfe;
  ctx->d = 0x10325476;
  ctx->e = 0xc3d2e1f0;
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

/* --- @has160_set@ --- *
 *
 * Arguments:	@has160_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void has160_set(has160_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  ctx->a = LOAD32_L(p +	 0);
  ctx->b = LOAD32_L(p +	 4);
  ctx->c = LOAD32_L(p +	 8);
  ctx->d = LOAD32_L(p + 12);
  ctx->e = LOAD32_L(p + 16);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @has160_hash@ --- *
 *
 * Arguments:	@has160_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void has160_hash(has160_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(HAS160, has160, ctx, buf, sz);
}

/* --- @has160_done@ --- *
 *
 * Arguments:	@has160_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

void has160_done(has160_ctx *ctx, void *hash)
{
  octet *p = hash;
  HASH_MD5STRENGTH(HAS160, has160, ctx);
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
  STORE32_L(p + 16, ctx->e);
}

/* --- @has160_state@ --- *
 *
 * Arguments:	@has160_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @has160_set@.
 */

unsigned long has160_state(has160_ctx *ctx, void *state)
{
  octet *p = state;
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
  STORE32_L(p + 16, ctx->e);
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(HAS160, has160)

/* --- Test code --- */

HASH_TEST(HAS160, has160)

/*----- That's all, folks -------------------------------------------------*/
