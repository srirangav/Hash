/* -*-c-*-
 *
 * The Tiger hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash-def.h"
#include "hash.h"
#include "tiger.h"
#include "tiger-base.h"

/*----- S-boxes -----------------------------------------------------------*/

extern const kludge64 tiger_s[4][256];

/*----- Main code ---------------------------------------------------------*/

/* --- @tiger_compress@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		Tiger compression function.
 */

void tiger_compress(tiger_ctx *ctx, const void *sbuf)
{
  kludge64 x[8];
  int i;
  const octet *p;
  for (i = 0, p = sbuf; i < 8; i++, p += 8)
    LOAD64_L_(x[i], p);
  TIGER_CORE(ctx->a, ctx->b, ctx->c, x);
}

/* --- @tiger_init@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void tiger_init(tiger_ctx *ctx)
{
  SET64(ctx->a, 0x01234567, 0x89abcdef);
  SET64(ctx->b, 0xfedcba98, 0x76543210);
  SET64(ctx->c, 0xf096a5b4, 0xc3b2e187);
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

/* --- @tiger_set@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void tiger_set(tiger_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  LOAD64_L_(ctx->a, p +	 0);
  LOAD64_L_(ctx->b, p +	 8);
  LOAD64_L_(ctx->c, p + 16);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @tiger_hash@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void tiger_hash(tiger_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(TIGER, tiger, ctx, buf, sz);
}

/* --- @tiger_done@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

void tiger_done(tiger_ctx *ctx, void *hash)
{
  octet *p = hash;
  HASH_PAD(TIGER, tiger, ctx, 0x01u, 0, 8);
  STORE32_L(ctx->buf + TIGER_BUFSZ - 8, ctx->nl << 3);
  STORE32_L(ctx->buf + TIGER_BUFSZ - 4, (ctx->nl >> 29) | (ctx->nh << 3));
  tiger_compress(ctx, ctx->buf);
  STORE64_L_(p +  0, ctx->a);
  STORE64_L_(p +  8, ctx->b);
  STORE64_L_(p + 16, ctx->c);
}

/* --- @tiger_state@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @tiger_set@.
 */

unsigned long tiger_state(tiger_ctx *ctx, void *state)
{
  octet *p = state;
  STORE64_L_(p +  0, ctx->a);
  STORE64_L_(p +  8, ctx->b);
  STORE64_L_(p + 16, ctx->c);
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(TIGER, tiger)

/* --- Test code --- */

HASH_TEST(TIGER, tiger)

/*----- That's all, folks -------------------------------------------------*/
