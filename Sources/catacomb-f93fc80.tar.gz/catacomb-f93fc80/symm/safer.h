/* -*-c-*-
 *
 * The SAFER block cipher
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the SAFER block cipher -----------------------------------*
 *
 * SAFER was designed by James Massey (who also worked on IDEA) for Cylink.
 * It's free -- patents or other silliness.  The original key schedule had
 * some weaknesses, and a new one (the SK version) was added.  SAFER has a
 * variable number of rounds.  The standard interface uses the recommended
 * number for the given key schedule algorithm and key size.
 *
 * SAFER got a bad press in Schneier's book `Applied Cryptography'.  I think
 * this is undeserved.  SAFER is a well-designed cipher which mostly looks
 * pretty solid.
 */

#ifndef CATACOMB_SAFER_H
#define CATACOMB_SAFER_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define SAFER_BLKSZ 8
#define SAFER_KEYSZ 8
#define SAFER_CLASS (N, B, 64)

#define SAFERSK_BLKSZ SAFER_BLKSZ
#define SAFERSK_KEYSZ 16
#define SAFERSK_CLASS SAFER_CLASS

#define SAFER_MAXROUNDS 12

extern const octet safer_keysz[];
#define safersk_keysz safer_keysz

/*----- Data structures ---------------------------------------------------*/

typedef struct safer_ctx {
  octet k[8 * (2 * SAFER_MAXROUNDS + 1)];
  unsigned r;
} safer_ctx, safersk_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @safer_setup@ --- *
 *
 * Arguments:	@safer_ctx *k@ = pointer to context to initialize
 *		@unsigned r@ = number of rounds wanted
 *		@unsigned f@ = various other flags
 *		@const void *buf@ = pointer to key material
 *		@size_t sz@ = size of key material in bytes
 *
 * Returns:	---
 *
 * Use:		Initializes an SAFER expanded key, with lots of options
 *		controlling how to do it.
 */

#define SAFER_SK 1u

extern void safer_setup(safer_ctx */*k*/, unsigned /*r*/, unsigned /*f*/,
			const void */*buf*/, size_t /*sz*/);

/* --- @safer_init@, @safersk_init@ --- *
 *
 * Arguments:	@safer_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to key material
 *		@size_t sz@ = size of key material in bytes
 *
 * Returns:	---
 *
 * Use:		Initializes an SAFER expanded key.  A default number of
 *		rounds is chosen, based on the key length.
 */

extern void safer_init(safer_ctx */*k*/,
		       const void */*buf*/, size_t /*sz*/);
extern void safersk_init(safer_ctx */*k*/,
			 const void */*buf*/, size_t /*sz*/);

/* --- @safer_eblk@, @safer_dblk@ --- *
 *
 * Arguments:	@const safer_ctx *k@ = pointer to SAFER context
 *		@const uint32 s[2]@ = pointer to source block
 *		@const uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void safer_eblk(const safer_ctx */*k*/,
		       const uint32 */*s*/, uint32 */*dst*/);
extern void safer_dblk(const safer_ctx */*k*/,
		       const uint32 */*s*/, uint32 */*dst*/);

#define safersk_eblk safer_eblk
#define safersk_dblk safer_dblk

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
