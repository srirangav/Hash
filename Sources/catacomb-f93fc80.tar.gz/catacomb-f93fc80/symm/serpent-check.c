/* -*-c-*-
 *
 * Check the Serpent S-boxes
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/bits.h>

#include "serpent-sbox.h"

/*----- S-box tables ------------------------------------------------------*/

static const octet s[8][16] = {
  {  3,	 8, 15,	 1, 10,	 6,  5, 11, 14, 13,  4,	 2,  7,	 0,  9, 12 },
  { 15, 12,  2,	 7,  9,	 0,  5, 10,  1, 11, 14,	 8,  6, 13,  3,	 4 },
  {  8,	 6,  7,	 9,  3, 12, 10, 15, 13,	 1, 14,	 4,  0, 11,  5,	 2 },
  {  0, 15, 11,	 8, 12,	 9,  6,	 3, 13,	 1,  2,	 4, 10,	 7,  5, 14 },
  {  1, 15,  8,	 3, 12,	 0, 11,	 6,  2,	 5,  4, 10,  9, 14,  7, 13 },
  { 15,	 5,  2, 11,  4, 10,  9, 12,  0,	 3, 14,	 8, 13,	 6,  7,	 1 },
  {  7,	 2, 12,	 5,  8,	 4,  6, 11, 14,	 9,  1, 15, 13,	 3, 10,	 0 },
  {  1, 13, 15,	 0, 14,	 8,  2, 11,  7,	 4, 12, 10,  9,	 3,  5,	 6 }
};

/*----- Main code ---------------------------------------------------------*/

/* --- @check@ --- *
 *
 * Arguments:	@unsigned a, b, c, d@ = four bitslice output registers
 *		@const octet *p@ = pointer to S-box
 *
 * Returns:	Zero if OK, nonzero on failure.
 *
 * Use:		Checks that an S-box output is correct.
 */

static int check(unsigned a, unsigned b, unsigned c, unsigned d,
		 const octet *p)
{
  octet buf[16];
  octet *q = buf;
  unsigned i;

  for (i = 0; i < 16; i++) {
    *q++ = (a & 1) | ((b & 1) << 1) | ((c & 1) << 2) | ((d & 1) << 3);
    a >>= 1; b >>= 1; c >>= 1; d >>= 1;
  }
  return (memcmp(buf, p, sizeof(buf)));
}

#define CHECK(i) do {							\
  unsigned a = 0xaaaa, b = 0xcccc, c = 0xf0f0, d = 0xff00;		\
  S##i(a, b, c, d);							\
  if (check(a, b, c, d, s[i])) {					\
    fprintf(stderr, "failure in S%i\n", i);				\
    rc = EXIT_FAILURE;							\
  }									\
  IS##i(a, b, c, d);							\
  if (a != 0xaaaa || b != 0xcccc || c != 0xf0f0 || d != 0xff00) {	\
    fprintf(stderr, "failure in IS%i\n", i);				\
    rc = EXIT_FAILURE;							\
  }									\
} while (0)

int main(void)
{
  int rc = 0;
  CHECK(0); CHECK(1); CHECK(2); CHECK(3);
  CHECK(4); CHECK(5); CHECK(6); CHECK(7);
  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
