/* -*-c-*-
 *
 * The Extended Tiny Encryption Algorithm
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Tiny Encryption Algorithm ----------------------------*
 *
 * XTEA is an amazingly simple 64-round Feistel network.  It's tiny, fairly
 * quick and surprisingly strong.  It was invented by David Wheeler and Roger
 * Needham.  It's unpatented.  XTEA is a new version of TEA, by the same
 * designers, which fixes some weaknesses in TEA's key schedule.
 *
 * This implementation uses big-endian byte order, following SCAN.
 */

#ifndef CATACOMB_XTEA_H
#define CATACOMB_XTEA_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define XTEA_BLKSZ 8
#define XTEA_KEYSZ 16
#define XTEA_CLASS (N, B, 64)

extern const octet xtea_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct xtea_ctx {
  unsigned r;
  uint32 k[4];
} xtea_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @xtea_init@ --- *
 *
 * Arguments:	@xtea_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes an XTEA key buffer.  The key buffer may be up to
 *		16 bytes long.
 */

extern void xtea_init(xtea_ctx */*k*/, const void */*buf*/, size_t /*sz*/);

/* --- @xtea_eblk@, @xtea_dblk@ --- *
 *
 * Arguments:	@const xtea_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to xteatination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void xtea_eblk(const xtea_ctx */*k*/,
		      const uint32 */*s*/, uint32 */*d*/);
extern void xtea_dblk(const xtea_ctx */*k*/,
		      const uint32 */*s*/, uint32 */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
