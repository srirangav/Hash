/* -*-c-*-
 *
 * The Square block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>

#include <mLib/bits.h>
#include <mLib/macros.h>

#include "blkc.h"
#include "gcipher.h"
#include "paranoia.h"
#include "square.h"

/*----- Global variables --------------------------------------------------*/

const octet square_keysz[] = { KSZ_RANGE, SQUARE_KEYSZ, 4, 16, 4 };

/*----- Constant tables ---------------------------------------------------*/

extern const octet square_s[256], square_si[256];
extern const uint32 square_t[4][256], square_ti[4][256];
extern const uint32 square_u[4][256];
extern const octet square_rcon[32];

#define S square_s
#define SI square_si
#define T square_t
#define TI square_ti
#define U square_u
#define RCON square_rcon

/*----- Main code ---------------------------------------------------------*/

/* --- @square_init@ --- *
 *
 * Arguments:	@square_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Square context with a particular key.  Square
 *		keys must be a multiple of 32 bits long, and may be at most
 *		128 bits.
 */

void square_init(square_ctx *k, const void *buf, size_t sz)
{
  unsigned nk, nr, nw;
  unsigned i, j, jj;
  const octet *p;
  uint32 ww;
  uint32 kk[SQUARE_KWORDS];

  /* --- Sort out the key size --- */

  KSZ_ASSERT(square, sz);
  nk = sz / 4;

  /* --- Fetch the first key words out --- */

  p = buf;
  for (i = 0; i < nk; i++) {
    kk[i] = LOAD32_L(p);
    p += 4;
  }
  nr = 8;

  /* --- GCC complains about an out-of-bounds subscript here --- *
   *
   * This is impossible.  Thanks to @KSZ_ASSERT@, we know that @4 <= sz <=
   * 16@ and hence @1 <= i <= nk <= 4@; but @SQUARE_KWORDS == 36@.
   */

  ww = MUFFLE_WARNINGS_EXPR(GCC_WARNING("-Warray-bounds"), kk[i - 1]);

  /* --- Expand this material to fill the rest of the table --- */

  nw = (nr + 1) * 4;
  p = RCON;
  for (; i < nw; i++) {
    uint32 w = kk[i - nk];
    if (i % nk == 0) {
      ww = ROR32(ww, 8);
      w ^= ww ^ *p++;
    } else
      w ^= ww;
    kk[i] = ww = w;
  }

  /* --- Make the encryption and decryption keys --- */

  for (i = 0; i < nr * 4; i++) {
    uint32 w = kk[i];
    k->w[i] = (U[0][U8(w >>  0)] ^ U[1][U8(w >>	 8)] ^
	       U[2][U8(w >> 16)] ^ U[3][U8(w >> 24)]);
  }
  for (; i < nw; i++)
    k->w[i] = kk[i];

  jj = nw;
  for (i = 0; i < nr * 4; i += 4) {
    jj -= 4;
    for (j = 0; j < 4; j++)
      k->wi[i + j] = kk[jj + j];
  }
  for (j = 0; j < 4; j++)
    k->wi[i + j] = k->w[j];

  BURN(kk);
}

/* --- @square_eblk@, @square_dblk@ --- *
 *
 * Arguments:	@const square_ctx *k@ = pointer to Square context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

#define SUB(s, sh, a, b, c, d)						\
  (s[U8((a) >> sh)] <<	0 | s[U8((b) >> sh)] <<	 8 |			\
   s[U8((c) >> sh)] << 16 | s[U8((d) >> sh)] << 24)

#define MIX(t, sh, a, b, c, d)						\
  (t[0][U8((a) >> sh)] ^ t[1][U8((b) >> sh)] ^				\
   t[2][U8((c) >> sh)] ^ t[3][U8((d) >> sh)])

#define DO(what, t, aa, bb, cc, dd, a, b, c, d, w) do {			\
  aa = what(t,	0, a, b, c, d) ^ *w++;					\
  bb = what(t,	8, a, b, c, d) ^ *w++;					\
  cc = what(t, 16, a, b, c, d) ^ *w++;					\
  dd = what(t, 24, a, b, c, d) ^ *w++;					\
} while (0)

void square_eblk(const square_ctx *k, const uint32 *s, uint32 *dst)
{
  uint32 a = s[0], b = s[1], c = s[2], d = s[3];
  uint32 aa, bb, cc, dd;
  const uint32 *w = k->w;

  a ^= *w++; b ^= *w++; c ^= *w++; d ^= *w++;

  DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
  DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
  DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
  DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
  DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
  DO(MIX, T, a, b, c, d, aa, bb, cc, dd, w);
  DO(MIX, T, aa, bb, cc, dd, a, b, c, d, w);
  DO(SUB, S, a, b, c, d, aa, bb, cc, dd, w);

  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d;
}

void square_dblk(const square_ctx *k, const uint32 *s, uint32 *dst)
{
  uint32 a = s[0], b = s[1], c = s[2], d = s[3];
  uint32 aa, bb, cc, dd;
  const uint32 *w = k->wi;

  a ^= *w++; b ^= *w++; c ^= *w++; d ^= *w++;

  DO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
  DO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
  DO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
  DO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
  DO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
  DO(MIX, TI, a, b, c, d, aa, bb, cc, dd, w);
  DO(MIX, TI, aa, bb, cc, dd, a, b, c, d, w);
  DO(SUB, SI, a, b, c, d, aa, bb, cc, dd, w);

  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d;
}

BLKC_TEST(SQUARE, square)

/*----- That's all, folks -------------------------------------------------*/
