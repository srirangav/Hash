/* -*-c-*-
 *
 * Whirlpool hash function
 *
 * (c) 2005 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "whirlpool.h"

#if defined(HAVE_UINT64)
#  define USE64
#endif

/*----- Static variables --------------------------------------------------*/

extern const kludge64 whirlpool_c[10];

#ifdef USE64
extern const kludge64 whirlpool_t[8][256];
#else
extern const uint32 whirlpool_u[4][256], whirlpool_v[4][256];
#endif

/*----- Main code ---------------------------------------------------------*/

#define DUMP(k, v) do {							\
  int i;								\
  printf("\n");								\
  for (i = 0; i < 8; i++)						\
    printf("  %08x %08x	 :  %08x %08x\n",				\
	   HI64(k[i]), LO64(k[i]),					\
	   HI64(v[i]), LO64(v[i]));					\
} while (0)

#define OFFSET(i, n) (((i) + 16 - (n)) % 8)

#ifdef USE64

#define BYTE(x, j)							\
  U8((j) < 4 ?								\
    (LO64(x) >> ((j) * 8)) :						\
    (HI64(x) >> ((j) * 8 - 32)))

#define TT(v, i, j) whirlpool_t[j][BYTE(v[OFFSET(i, j)], j)]

#define XROW(vv, v, i) do {						\
  XOR64(vv[i], vv[i], TT(v, i, 1));					\
  XOR64(vv[i], vv[i], TT(v, i, 2));					\
  XOR64(vv[i], vv[i], TT(v, i, 3));					\
  XOR64(vv[i], vv[i], TT(v, i, 4));					\
  XOR64(vv[i], vv[i], TT(v, i, 5));					\
  XOR64(vv[i], vv[i], TT(v, i, 6));					\
  XOR64(vv[i], vv[i], TT(v, i, 7));					\
} while (0)

#define ROWZ(vv, v, i) do {						\
  vv[i] = TT(v, i, 0);							\
  XROW(vv, v, i);							\
} while (0)

#define ROWK(vv, v, i, k) do {						\
  vv[i] = k;								\
  XOR64(vv[i], vv[i], TT(v, i, 0));					\
  XROW(vv, v, i);							\
} while (0)

#else

#define BYTE(x, j) U8((x) >> (((j) & 3) * 8))

#define UUL(v, i, j) whirlpool_u[j & 3][BYTE(v[OFFSET(i, j)].lo, j)]
#define VVL(v, i, j) whirlpool_v[j & 3][BYTE(v[OFFSET(i, j)].lo, j)]
#define UUH(v, i, j) whirlpool_u[j & 3][BYTE(v[OFFSET(i, j)].hi, j)]
#define VVH(v, i, j) whirlpool_v[j & 3][BYTE(v[OFFSET(i, j)].hi, j)]

#define XROW(vv, v, i) do {						\
  vv[i].lo ^= UUL(v, i, 1); vv[i].hi ^= VVL(v, i, 1);			\
  vv[i].lo ^= UUL(v, i, 2); vv[i].hi ^= VVL(v, i, 2);			\
  vv[i].lo ^= UUL(v, i, 3); vv[i].hi ^= VVL(v, i, 3);			\
  vv[i].lo ^= VVH(v, i, 4); vv[i].hi ^= UUH(v, i, 4);			\
  vv[i].lo ^= VVH(v, i, 5); vv[i].hi ^= UUH(v, i, 5);			\
  vv[i].lo ^= VVH(v, i, 6); vv[i].hi ^= UUH(v, i, 6);			\
  vv[i].lo ^= VVH(v, i, 7); vv[i].hi ^= UUH(v, i, 7);			\
} while (0)

#define ROWZ(vv, v, i) do {						\
  vv[i].lo = UUL(v, i, 0);  vv[i].hi = VVL(v, i, 0);			\
  XROW(vv, v, i);							\
} while (0)

#define ROWK(vv, v, i, k) do {						\
  vv[i] = k;								\
  vv[i].lo ^= UUL(v, i, 0); vv[i].hi ^= VVL(v, i, 0);			\
  XROW(vv, v, i);							\
} while (0)

#endif

#define RHO(vv, v, kk, k) do {						\
  ROWK(kk, k, 0, *c++);	  ROWK(vv, v, 0, kk[0]);			\
  ROWZ(kk, k, 1);	  ROWK(vv, v, 1, kk[1]);			\
  ROWZ(kk, k, 2);	  ROWK(vv, v, 2, kk[2]);			\
  ROWZ(kk, k, 3);	  ROWK(vv, v, 3, kk[3]);			\
  ROWZ(kk, k, 4);	  ROWK(vv, v, 4, kk[4]);			\
  ROWZ(kk, k, 5);	  ROWK(vv, v, 5, kk[5]);			\
  ROWZ(kk, k, 6);	  ROWK(vv, v, 6, kk[6]);			\
  ROWZ(kk, k, 7);	  ROWK(vv, v, 7, kk[7]);			\
} while (0)

void whirlpool_compress(whirlpool_ctx *ctx, const void *sbuf)
{
  kludge64 m[8], k[8], kk[8], v[8], vv[8];
  const kludge64 *c = whirlpool_c;
  const octet *s = sbuf;
  int i;

  for (i = 0; i < 8; i++) {
    LOAD64_L_(m[i], &s[i * 8]);
    XOR64(v[i], m[i], ctx->s[i]);
  }

  RHO(vv, v, kk, ctx->s);
  RHO(v, vv, k, kk);
  RHO(vv, v, kk, k);
  RHO(v, vv, k, kk);
  RHO(vv, v, kk, k);
  RHO(v, vv, k, kk);
  RHO(vv, v, kk, k);
  RHO(v, vv, k, kk);
  RHO(vv, v, kk, k);
  RHO(v, vv, k, kk);

  for (i = 0; i < 8; i++) {
    XOR64(ctx->s[i], ctx->s[i], m[i]);
    XOR64(ctx->s[i], ctx->s[i], v[i]);
  }
}

/* --- @whirlpool_init@, @whirlpool256_init@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void whirlpool_init(whirlpool_ctx *ctx)
{
  int i;

  for (i = 0; i < 8; i++)
    SET64(ctx->s[i], 0, 0);
  ctx->off = 0;
  ctx->nh = ctx->nl = 0;
}

/* --- @whirlpool_set@, @whirlpool256_set@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void whirlpool_set(whirlpool_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  int i;

  for (i = 0; i < 8; i++) {
    LOAD64_L_(ctx->s[i], p);
    p += 8;
  }
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @whirlpool_hash@, @whirlpool256_hash@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void whirlpool_hash(whirlpool_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(WHIRLPOOL, whirlpool, ctx, buf, sz);
}

/* --- @whirlpool_done@, @whirlpool256_done@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

static void final(whirlpool_ctx *ctx)
{
  HASH_PAD(WHIRLPOOL, whirlpool, ctx, 0x80, 0, 32);
  memset(ctx->buf + WHIRLPOOL_BUFSZ - 32, 0, 24);
  STORE32(ctx->buf + WHIRLPOOL_BUFSZ -	8, (ctx->nl >> 29) | (ctx->nh << 3));
  STORE32(ctx->buf + WHIRLPOOL_BUFSZ -	4, ctx->nl << 3);
  whirlpool_compress(ctx, ctx->buf);
}

void whirlpool_done(whirlpool_ctx *ctx, void *hash)
{
  octet *p = hash;
  int i;

  final(ctx);
  for (i = 0; i < 8; i++) {
    STORE64_L_(p, ctx->s[i]);
    p += 8;
  }
}

void whirlpool256_done(whirlpool256_ctx *ctx, void *hash)
{
  octet *p = hash;
  int i;

  final(ctx);
  for (i = 0; i < 4; i++) {
    STORE64_L_(p, ctx->s[i]);
    p += 8;
  }
}

/* --- @whirlpool_state@, @whirlpool256_state@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @whirlpool_set@.
 */

unsigned long whirlpool_state(whirlpool_ctx *ctx, void *state)
{
  octet *p = state;
  int i;

  for (i = 0; i < 8; i++) {
    STORE64_L_(p, ctx->s[i]);
    p += 8;
  }
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(WHIRLPOOL, whirlpool)

/* --- Test code --- */

HASH_TEST(WHIRLPOOL, whirlpool)

/*----- That's all, folks -------------------------------------------------*/
