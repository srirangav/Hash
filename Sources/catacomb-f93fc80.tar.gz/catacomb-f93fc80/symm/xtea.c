/* -*-c-*-
 *
 * The Extended Tiny Encryption Algorithm
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "blkc.h"
#include "gcipher.h"
#include "paranoia.h"
#include "xtea.h"

/*----- Global variables --------------------------------------------------*/

const octet xtea_keysz[] = { KSZ_RANGE, XTEA_KEYSZ, 0, 16, 1 };

/*----- Main code ---------------------------------------------------------*/

/* --- @xtea_init@ --- *
 *
 * Arguments:	@xtea_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes an XTEA key buffer.  The key buffer must be 16
 *		bytes long.
 */

void xtea_init(xtea_ctx *k, const void *buf, size_t sz)
{
  octet kb[16];
  const octet *p;

  KSZ_ASSERT(xtea, sz);
  if (sz >= sizeof(kb))
    p = buf;
  else {
    memcpy(kb, buf, sz);
    memset(kb + sz, 0, sizeof(kb) - sz);
    p = kb;
  }

  k->k[0] = LOAD32(p +	0); k->k[1] = LOAD32(p +  4);
  k->k[2] = LOAD32(p +	8); k->k[3] = LOAD32(p + 12);
  k->r = 32;

  if (p == kb)
    BURN(kb);
}

/* --- @xtea_eblk@, @xtea_dblk@ --- *
 *
 * Arguments:	@const xtea_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to xteatination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

#define DELTA 0x9e3779b9

void xtea_eblk(const xtea_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 y = s[0], z = s[1];
  uint32 n = 0;
  unsigned i;

  for (i = 0; i < k->r; i++) {
    y = U32(y + ((((z << 4) ^ (z >> 5)) + z) ^ (n + k->k[n & 3])));
    n += DELTA;
    z = U32(z + ((((y << 4) ^ (y >> 5)) + y) ^ (n + k->k[(n >> 11) & 3])));
  }
  d[0] = y; d[1] = z;
}

void xtea_dblk(const xtea_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 y = s[0], z = s[1];
  uint32 n = DELTA * k->r;
  unsigned i;

  for (i = 0; i < k->r; i++) {
    z = U32(z - ((((y << 4) ^ (y >> 5)) + y) ^ (n + k->k[(n >> 11) & 3])));
    n -= DELTA;
    y = U32(y - ((((z << 4) ^ (z >> 5)) + z) ^ (n + k->k[n & 3])));
  }
  d[0] = y; d[1] = z;
}

BLKC_TEST(XTEA, xtea)

/*----- That's all, folks -------------------------------------------------*/
