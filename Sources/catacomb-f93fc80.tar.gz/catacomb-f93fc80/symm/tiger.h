/* -*-c-*-
 *
 * The Tiger hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Tiger hash function ----------------------------------*
 *
 * Tiger was designed by Eli Biham and Ross Anderson to be an efficient and
 * secure hash function which worked well on 64-bit processors.  This
 * implementation should work everywhere, but it'll be faster if real 64-bit
 * arithmetic is available.
 *
 * I don't know of any really good analysis of Tiger.
 */

#ifndef CATACOMB_TIGER_H
#define CATACOMB_TIGER_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

/*----- Magic numbers -----------------------------------------------------*/

#define TIGER_BUFSZ 64
#define TIGER_HASHSZ 24
#define TIGER_STATESZ 24

/*----- Data structures ---------------------------------------------------*/

typedef struct tiger_ctx {
  kludge64 a, b, c;			/* Chaining variables */
  uint32 nl, nh;			/* Byte count so far */
  unsigned off;				/* Offset into buffer */
  octet buf[TIGER_BUFSZ];		/* Accumulation buffer */
} tiger_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @tiger_compress@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		Tiger compression function.
 */

extern void tiger_compress(tiger_ctx */*ctx*/, const void */*sbuf*/);

/* --- @tiger_init@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

extern void tiger_init(tiger_ctx */*ctx*/);

/* --- @tiger_set@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

extern void tiger_set(tiger_ctx */*ctx*/, const void */*buf*/,
		    unsigned long /*count*/);

/* --- @tiger_hash@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

extern void tiger_hash(tiger_ctx */*ctx*/, const void */*buf*/, size_t /*sz*/);

/* --- @tiger_done@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

extern void tiger_done(tiger_ctx */*ctx*/, void */*hash*/);

/* --- @tiger_state@ --- *
 *
 * Arguments:	@tiger_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @tiger_set@.
 */

extern unsigned long tiger_state(tiger_ctx */*ctx*/, void */*state*/);

/*----- Generic hash interface --------------------------------------------*/

extern const gchash tiger;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
