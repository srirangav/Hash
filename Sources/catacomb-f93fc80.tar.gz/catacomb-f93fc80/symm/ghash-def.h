/* -*-c-*-
 *
 * Definitions for generic hash interface
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GHASH_DEF_H
#define CATACOMB_GHASH_DEF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>
#include <mLib/sub.h>

#ifndef CATACOMB_ARENA_H
#  include "arena.h"
#endif

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

#ifndef CATACOMB_PARANOIA_H
#  include "paranoia.h"
#endif

/*----- Generic hash function interface -----------------------------------*/

/* --- @GHASH_DEF@ --- *
 *
 * Arguments:	@PRE, pre@ = prefixes for hash function
 *
 * Use:		Defines the generic hash instance.
 */

#define GHASH_DEF(PRE, pre)						\
									\
static const ghash_ops gops;						\
									\
typedef struct gctx {							\
  ghash h;								\
  pre##_ctx c;								\
  octet buf[PRE##_HASHSZ];						\
} gctx;									\
									\
static ghash *ghinit(void)						\
{									\
  gctx *g = S_CREATE(gctx);						\
  g->h.ops = &gops;							\
  pre##_init(&g->c);							\
  return (&g->h);							\
}									\
									\
static void ghhash(ghash *h, const void *p, size_t sz)			\
{									\
  gctx *g = (gctx *)h;							\
  pre##_hash(&g->c, p, sz);						\
}									\
									\
static octet *ghdone(ghash *h, void *buf)				\
{									\
  gctx *g = (gctx *)h;							\
  if (!buf)								\
    buf = g->buf;							\
  pre##_done(&g->c, buf);						\
  return (buf);								\
}									\
									\
static void ghdestroy(ghash *h)						\
{									\
  gctx *g = (gctx *)h;							\
  BURN(*g);								\
  S_DESTROY(g);								\
}									\
									\
static ghash *ghcopy(ghash *h)						\
{									\
  gctx *g = (gctx *)h;							\
  gctx *gg = S_CREATE(gctx);						\
  memcpy(gg, g, sizeof(gctx));						\
  return (&gg->h);							\
}									\
									\
static const ghash_ops gops =						\
  { &pre, ghhash, ghdone, ghdestroy, ghcopy };				\
const gchash pre = { #pre, PRE##_HASHSZ, ghinit, PRE##_BUFSZ };

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
