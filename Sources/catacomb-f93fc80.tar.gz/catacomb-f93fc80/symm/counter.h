/* -*-c-*-
 *
 * Block cipher counter mode (or long cycle mode)
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_COUNTER_H
#define CATACOMB_COUNTER_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Macros ------------------------------------------------------------*/

/* --- @COUNTER_DECL@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for block cipher definitions
 *
 * Use:		Makes declarations for counter mode.
 */

#define COUNTER_DECL(PRE, pre)						\
									\
/* --- Counter mode context --- */					\
									\
typedef struct pre##_counterctx {					\
  pre##_ctx ctx;			/* Underlying cipher context */	\
  unsigned off;				/* Current offset in buffer */	\
  octet buf[PRE##_BLKSZ];		/* Output buffer */		\
  uint32 n[PRE##_BLKSZ / 4];		/* Counter */			\
} pre##_counterctx;							\
									\
/* --- @pre_countergetiv@ --- *						\
 *									\
 * Arguments:	@const pre_counterctx *ctx@ = pointer to counter	\
 *			context						\
 *		@void *iv@ = pointer to output data block		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Reads the currently set IV.  Reading and setting an IV	\
 *		is not transparent to the cipher.  It will add a `step'	\
 *		which must be matched by a similar operation during	\
 *		decryption.						\
 */									\
									\
extern void pre##_countergetiv(const pre##_counterctx */*ctx*/,		\
			       void */*iv*/);				\
									\
/* --- @pre_countersetiv@ --- *						\
 *									\
 * Arguments:	@pre_counterctx *ctx@ = pointer to counter context	\
 *		@cnost void *iv@ = pointer to IV to set			\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the IV to use for subsequent encryption.		\
 */									\
									\
extern void pre##_countersetiv(pre##_counterctx */*ctx*/,		\
			       const void */*iv*/);			\
									\
/* --- @pre_counterbdry@ --- *						\
 *									\
 * Arguments:	@pre_counterctx *ctx@ = pointer to counter context	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Inserts a boundary during encryption.  Successful	\
 *		decryption must place a similar boundary.		\
 */									\
									\
extern void pre##_counterbdry(pre##_counterctx */*ctx*/);		\
									\
/* --- @pre_countersetkey@ --- *					\
 *									\
 * Arguments:	@pre_counterctx *ctx@ = pointer to counter context	\
 *		@const pre_ctx *k@ = pointer to cipher context		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the counter context to use a different cipher key.	\
 */									\
									\
extern void pre##_countersetkey(pre##_counterctx */*ctx*/,		\
				const pre##_ctx */*k*/);		\
									\
/* --- @pre_counterinit@ --- *						\
 *									\
 * Arguments:	@pre_counterctx *ctx@ = pointer to cipher context	\
 *		@const void *key@ = pointer to the key buffer		\
 *		@size_t sz@ = size of the key				\
 *		@const void *iv@ = pointer to initialization vector	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes a counter context ready for use.  You	\
 *		should ensure that the IV chosen is unique: reusing an	\
 *		IV will compromise the security of the entire		\
 *		plaintext.  This is equivalent to calls to @pre_init@,	\
 *		@pre_countersetkey@ and @pre_countersetiv@.		\
 */									\
									\
extern void pre##_counterinit(pre##_counterctx */*ctx*/,		\
			      const void */*key*/, size_t /*sz*/,	\
			      const void */*iv*/);			\
									\
/* --- @pre_counterencrypt@ --- *					\
 *									\
 * Arguments:	@pre_counterctx *ctx@ = pointer to counter context	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Encrypts or decrypts a block with a block cipher in	\
 *		counter mode: encryption and decryption are the same in	\
 *		counter.  The destination may be null to just churn the	\
 *		feedback round for a bit.  The source may be null to	\
 *		use the cipher as a random data generator.		\
 */									\
									\
extern void pre##_counterencrypt(pre##_counterctx */*ctx*/,		\
				 const void */*src*/, void */*dest*/,	\
				 size_t /*sz*/);			\
									\
/* --- @pre_counterrand@ --- *						\
 *									\
 * Arguments:	@const void *k@ = pointer to key material		\
 *		@size_t sz@ = size of key material			\
 *									\
 * Returns:	Pointer to generic random number generator interface.	\
 *									\
 * Use:		Creates a random number interface wrapper around an	\
 *		counter-mode block cipher.				\
 */									\
									\
extern grand *pre##_counterrand(const void */*k*/, size_t /*sz*/);	\
									\
/* --- Generic cipher interface --- */					\
									\
extern const gccipher pre##_counter;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
