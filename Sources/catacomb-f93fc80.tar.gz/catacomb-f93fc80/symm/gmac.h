/* -*-c-*-
 *
 * Generic MAC function interface
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GMAC_H
#define CATACOMB_GMAC_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

/*----- Generic MAC function interface ------------------------------------*/

typedef struct gmac {
  const struct gmac_ops *ops;		/* Pointer to MAC operations */
} gmac;

typedef struct gmac_ops {
  const struct gcmac *c;		/* Pointer to MAC class */
  ghash *(*init)(gmac */*m*/);		/* Create keyed hash instance */
  void (*destroy)(gmac */*m*/);		/* Destroy MAC key block */
} gmac_ops;

typedef struct gcmac {
  const char *name;			/* Name of the MAC function */
  size_t hashsz;			/* Size of output hash */
  const octet *keysz;			/* Key size options */
  gmac *(*key)(const void */*k*/, size_t /*sz*/); /* Create key */
} gcmac;

#define GM_KEY(cm, k, ksz)	(cm)->key((k), (ksz))
#define GM_CLASS(km)		(km)->ops->c
#define GM_INIT(km)		(km)->ops->init((km))
#define GM_DESTROY(km)		(km)->ops->destroy((km))

/*----- Tables ------------------------------------------------------------*/

extern const gcmac *const gmactab[];

/* --- @gmac_byname@ --- *
 *
 * Arguments:	@const char *p@ = pointer to name string
 *
 * Returns:	The named cipher class, or null.
 */

extern const gcmac *gmac_byname(const char */*p*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
