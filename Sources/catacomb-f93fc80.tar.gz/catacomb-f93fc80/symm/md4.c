/* -*-c-*-
 *
 * The MD4 message digest function
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "md4.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @md4_compress@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		RIPEMD-160 compression function.
 */

void md4_compress(md4_ctx *ctx, const void *sbuf)
{
  uint32 a, b, c, d;
  uint32 buf[16];

  /* --- Fetch the chaining variables --- */

  a = ctx->a;
  b = ctx->b;
  c = ctx->c;
  d = ctx->d;

  /* --- Fetch the buffer contents --- */

  {
    int i;
    const octet *p;

    for (i = 0, p = sbuf; i < 16; i++, p += 4)
      buf[i] = LOAD32_L(p);
  }

  /* --- Definitions for round functions --- */

#define F(x, y, z) (((x) & (y)) | (~(x) & (z)))
#define G(x, y, z) (((x) & (y)) | ((x) & (z)) | ((y) & (z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))

#define T(w, x, y, z, i, r, k, f) do {					\
  uint32 _t = w + f(x, y, z) + buf[i] + k;				\
  w = ROL32(_t, r);							\
} while (0)

#define FF(w, x, y, z, i, r) T(w, x, y, z, i, r, 0x00000000, F)
#define GG(w, x, y, z, i, r) T(w, x, y, z, i, r, 0x5a827999, G)
#define HH(w, x, y, z, i, r) T(w, x, y, z, i, r, 0x6ed9eba1, H)

  /* --- The main compression function --- */

  FF(a, b, c, d,  0,  3);
  FF(d, a, b, c,  1,  7);
  FF(c, d, a, b,  2, 11);
  FF(b, c, d, a,  3, 19);
  FF(a, b, c, d,  4,  3);
  FF(d, a, b, c,  5,  7);
  FF(c, d, a, b,  6, 11);
  FF(b, c, d, a,  7, 19);
  FF(a, b, c, d,  8,  3);
  FF(d, a, b, c,  9,  7);
  FF(c, d, a, b, 10, 11);
  FF(b, c, d, a, 11, 19);
  FF(a, b, c, d, 12,  3);
  FF(d, a, b, c, 13,  7);
  FF(c, d, a, b, 14, 11);
  FF(b, c, d, a, 15, 19);

  GG(a, b, c, d,  0,  3);
  GG(d, a, b, c,  4,  5);
  GG(c, d, a, b,  8,  9);
  GG(b, c, d, a, 12, 13);
  GG(a, b, c, d,  1,  3);
  GG(d, a, b, c,  5,  5);
  GG(c, d, a, b,  9,  9);
  GG(b, c, d, a, 13, 13);
  GG(a, b, c, d,  2,  3);
  GG(d, a, b, c,  6,  5);
  GG(c, d, a, b, 10,  9);
  GG(b, c, d, a, 14, 13);
  GG(a, b, c, d,  3,  3);
  GG(d, a, b, c,  7,  5);
  GG(c, d, a, b, 11,  9);
  GG(b, c, d, a, 15, 13);

  HH(a, b, c, d,  0,  3);
  HH(d, a, b, c,  8,  9);
  HH(c, d, a, b,  4, 11);
  HH(b, c, d, a, 12, 15);
  HH(a, b, c, d,  2,  3);
  HH(d, a, b, c, 10,  9);
  HH(c, d, a, b,  6, 11);
  HH(b, c, d, a, 14, 15);
  HH(a, b, c, d,  1,  3);
  HH(d, a, b, c,  9,  9);
  HH(c, d, a, b,  5, 11);
  HH(b, c, d, a, 13, 15);
  HH(a, b, c, d,  3,  3);
  HH(d, a, b, c, 11,  9);
  HH(c, d, a, b,  7, 11);
  HH(b, c, d, a, 15, 15);

  /* --- Update the chaining variables --- */

  ctx->a += a;
  ctx->b += b;
  ctx->c += c;
  ctx->d += d;
}

/* --- @md4_init@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void md4_init(md4_ctx *ctx)
{
  ctx->a = 0x67452301;
  ctx->b = 0xefcdab89;
  ctx->c = 0x98badcfe;
  ctx->d = 0x10325476;
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

/* --- @md4_set@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void md4_set(md4_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  ctx->a = LOAD32_L(p +	 0);
  ctx->b = LOAD32_L(p +	 4);
  ctx->c = LOAD32_L(p +	 8);
  ctx->d = LOAD32_L(p + 12);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @md4_hash@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void md4_hash(md4_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(MD4, md4, ctx, buf, sz);
}

/* --- @md4_done@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

void md4_done(md4_ctx *ctx, void *hash)
{
  octet *p = hash;
  HASH_MD5STRENGTH(MD4, md4, ctx);
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
}

/* --- @md4_state@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @md4_set@.
 */

unsigned long md4_state(md4_ctx *ctx, void *state)
{
  octet *p = state;
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
  return (ctx->nl | ((ctx->nh >> 16) >> 16));
}

/* --- Generic interface --- */

GHASH_DEF(MD4, md4)

/* --- Test rig --- */

HASH_TEST(MD4, md4)

/*----- That's all, folks -------------------------------------------------*/
