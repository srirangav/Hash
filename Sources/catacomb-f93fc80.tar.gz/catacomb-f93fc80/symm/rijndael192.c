/* -*-c-*-
 *
 * The Rijndael block cipher, 192-bit version
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>

#include <mLib/bits.h>

#include "blkc.h"
#include "gcipher.h"
#include "rijndael.h"
#include "rijndael192.h"
#include "rijndael-base.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @rijndael192_init@ --- *
 *
 * Arguments:	@rijndael_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Rijndael context with a particular key.  This
 *		implementation of Rijndael doesn't impose any particular
 *		limits on the key size except that it must be multiple of 4
 *		bytes long.  256 bits seems sensible, though.
 */

void rijndael192_init(rijndael_ctx *k, const void *buf, size_t sz)
{
  rijndael_setup(k, RIJNDAEL192_BLKSZ / 4, buf, sz);
}

/* --- @rijndael192_eblk@, @rijndael192_dblk@ --- *
 *
 * Arguments:	@const rijndael_ctx *k@ = pointer to Rijndael context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

#define DO(what, t, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w) do {	\
  aa = what(t, a, b, c, d) ^ *w++;					\
  bb = what(t, b, c, d, e) ^ *w++;					\
  cc = what(t, c, d, e, f) ^ *w++;					\
  dd = what(t, d, e, f, a) ^ *w++;					\
  ee = what(t, e, f, a, b) ^ *w++;					\
  ff = what(t, f, a, b, c) ^ *w++;					\
} while (0)

#define UNDO(what, t, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w) do {	\
  aa = what(t, a, f, e, d) ^ *w++;					\
  bb = what(t, b, a, f, e) ^ *w++;					\
  cc = what(t, c, b, a, f) ^ *w++;					\
  dd = what(t, d, c, b, a) ^ *w++;					\
  ee = what(t, e, d, c, b) ^ *w++;					\
  ff = what(t, f, e, d, c) ^ *w++;					\
} while (0)

void rijndael192_eblk(const rijndael_ctx *k, const uint32 *s, uint32 *dst)
{
  uint32 a = s[0], b = s[1], c = s[2], d = s[3], e = s[4], f = s[5];
  uint32 aa, bb, cc, dd, ee, ff;
  const uint32 *w = k->w;

  a ^= *w++; b ^= *w++; c ^= *w++; d ^= *w++; e ^= *w++; f ^= *w++;
  aa = a; bb = b; cc = c; dd = d; ee = e; ff = f;

  switch (k->nr) {
    case 14:
      DO(MIX, T, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
    case 13:
      DO(MIX, T, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
    case 12:
    default:
      DO(MIX, T, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      DO(MIX, T, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      DO(MIX, T, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      DO(MIX, T, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      DO(MIX, T, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      DO(MIX, T, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      DO(MIX, T, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      DO(MIX, T, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      DO(MIX, T, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      DO(MIX, T, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      DO(MIX, T, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
  }
  DO(SUB, S, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);

  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d; dst[4] = e; dst[5] = f;
}

void rijndael192_dblk(const rijndael_ctx *k, const uint32 *s, uint32 *dst)
{
  uint32 a = s[0], b = s[1], c = s[2], d = s[3], e = s[4], f = s[5];
  uint32 aa, bb, cc, dd, ee, ff;
  const uint32 *w = k->wi;

  a ^= *w++; b ^= *w++; c ^= *w++; d ^= *w++; e ^= *w++; f ^= *w++;
  aa = a; bb = b; cc = c; dd = d; ee = e; ff = f;

  switch (k->nr) {
    case 14:
      UNDO(MIX, TI, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
    case 13:
      UNDO(MIX, TI, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
    case 12:
    default:
      UNDO(MIX, TI, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      UNDO(MIX, TI, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      UNDO(MIX, TI, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      UNDO(MIX, TI, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      UNDO(MIX, TI, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      UNDO(MIX, TI, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      UNDO(MIX, TI, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      UNDO(MIX, TI, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      UNDO(MIX, TI, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
      UNDO(MIX, TI, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);
      UNDO(MIX, TI, aa, bb, cc, dd, ee, ff, a, b, c, d, e, f, w);
  }
  UNDO(SUB, SI, a, b, c, d, e, f, aa, bb, cc, dd, ee, ff, w);

  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d; dst[4] = e; dst[5] = f;
}

BLKC_TEST(RIJNDAEL192, rijndael192)

/*----- That's all, folks -------------------------------------------------*/
