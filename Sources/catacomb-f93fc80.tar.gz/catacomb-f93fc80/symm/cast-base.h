/* -*-c-*-
 *
 * Basic macros and definitions for CAST-128 and CAST-256
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_CAST_BASE_H
#define CATACOMB_CAST_BASE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

/*----- Round functions ---------------------------------------------------*/

#define CAST_R_guts(km, kr, xx, yy, aop, bop, cop) do {			\
  uint32 i = km aop yy;							\
  unsigned _r = kr;							\
  i = ROL32(i, _r);							\
  xx ^= ((cast_s[0][U8(i >> 24)] bop					\
	  cast_s[1][U8(i >> 16)]) cop					\
	  cast_s[2][U8(i >>  8)]) aop					\
	  cast_s[3][U8(i >>  0)];					\
} while (0)

#define CAST_R1(km, kr, xx, yy) CAST_R_guts(km, kr, xx, yy, +, ^, -)
#define CAST_R2(km, kr, xx, yy) CAST_R_guts(km, kr, xx, yy, ^, -, +)
#define CAST_R3(km, kr, xx, yy) CAST_R_guts(km, kr, xx, yy, -, +, ^)

/*----- Global variables --------------------------------------------------*/

extern const uint32 cast_s[4][256], cast_sk[4][256];

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
