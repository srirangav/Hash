/* -*-c-*-
 *
 * Ciphertext feedback for block ciphers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_CFB_H
#define CATACOMB_CFB_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

/*----- Data structures ---------------------------------------------------*/

/* --- @CFB_DECL@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for the underlying block cipher
 *
 * Use:		Creates declarations for CFB mode.
 */

#define CFB_DECL(PRE, pre)						\
									\
/* --- Ciphertext feedback context --- */				\
									\
typedef struct pre##_cfbctx {						\
  pre##_ctx ctx;			/* Underlying cipher context */	\
  unsigned off;				/* Offset into @iv@ buffer */	\
  octet iv[PRE##_BLKSZ];		/* Previous ciphertext or IV */	\
} pre##_cfbctx;								\
									\
/* --- @pre_cfbgetiv@ --- *						\
 *									\
 * Arguments:	@const pre_cfbctx *ctx@ = pointer to CFB context block	\
 *		@void *iv@ = pointer to output data block		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Reads the currently set IV.  Reading and setting an IV	\
 *		is not transparent to the cipher.  It will add a `step'	\
 *		which must be matched by a similar operation during	\
 *		decryption.						\
 */									\
									\
extern void pre##_cfbgetiv(const pre##_cfbctx */*ctx*/,			\
			   void */*iv*/);				\
									\
/* --- @pre_cfbsetiv@ --- *						\
 *									\
 * Arguments:	@pre_cfbctx *ctx@ = pointer to CFB context block	\
 *		@cnost void *iv@ = pointer to IV to set			\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the IV to use for subsequent encryption.		\
 */									\
									\
extern void pre##_cfbsetiv(pre##_cfbctx */*ctx*/,			\
			   const void */*iv*/);				\
									\
/* --- @pre_cfbbdry@ --- *						\
 *									\
 * Arguments:	@pre_cfbctx *ctx@ = pointer to CFB context block	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Inserts a boundary during encryption.  Successful	\
 *		decryption must place a similar boundary.		\
 */									\
									\
extern void pre##_cfbbdry(pre##_cfbctx */*ctx*/);			\
									\
/* --- @pre_cfbsetkey@ --- *						\
 *									\
 * Arguments:	@pre_cfbctx *ctx@ = pointer to CFB context block	\
 *		@const pre_ctx *k@ = pointer to cipher context		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the CFB context to use a different cipher key.	\
 */									\
									\
extern void pre##_cfbsetkey(pre##_cfbctx */*ctx*/,			\
			    const pre##_ctx */*k*/);			\
									\
/* --- @pre_cfbinit@ --- *						\
 *									\
 * Arguments:	@pre_cfbctx *ctx@ = pointer to cipher context		\
 *		@const void *key@ = pointer to the key buffer		\
 *		@size_t sz@ = size of the key				\
 *		@const void *iv@ = pointer to initialization vector	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes a CFB context ready for use.  You should	\
 *		ensure that the IV chosen is unique: reusing an IV will	\
 *		compromise the security of at least the first block	\
 *		encrypted.  This is equivalent to calls to @pre_init@,	\
 *		@pre_cfbsetkey@ and @pre_cfbsetiv@.			\
 */									\
									\
extern void pre##_cfbinit(pre##_cfbctx */*ctx*/,			\
			  const void */*key*/, size_t /*sz*/,		\
			  const void */*iv*/);				\
									\
/* --- @pre_cfbencrypt@ --- *						\
 *									\
 * Arguments:	@pre_cfbctx *ctx@ = pointer to CFB context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Encrypts a block with a block cipher in CFB mode.  The	\
 *		input block may be arbitrary in size.  CFB mode is not	\
 *		sensitive to block boundaries.				\
 */									\
									\
extern void pre##_cfbencrypt(pre##_cfbctx */*ctx*/,			\
			     const void */*src*/, void */*dest*/,	\
			     size_t /*sz*/);				\
									\
/* --- @pre_cfbencrypt@ --- *						\
 *									\
 * Arguments:	@pre_cfbctx *ctx@ = pointer to CFB context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Decrypts a block with a block cipher in CFB mode.  The	\
 *		input block may be arbitrary in size.  CFB mode is not	\
 *		sensitive to block boundaries.				\
 */									\
									\
extern void pre##_cfbdecrypt(pre##_cfbctx */*ctx*/,			\
			     const void */*src*/, void */*dest*/,	\
			     size_t /*sz*/);				\
									\
/* --- Generic cipher interface --- */					\
									\
extern const gccipher pre##_cfb;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
