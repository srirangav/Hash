/* -*-c-*-
 *
 * Stub code for SAFER-SK
 */

#include "blkc.h"
#include "safersk.h"

typedef int uninteresting;
BLKC_TEST(SAFERSK, safersk)
