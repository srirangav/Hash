/* -*-c-*-
 *
 * The RC2 block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the RC2 block cipher -------------------------------------*
 *
 * RC2 was designed by Ron Rivest, and for a long time was a trade secret of
 * RSA Data Security Inc.  Like RC4, it leaked out, and has now been
 * described in RFC2268.  The RC2 key schedule is known to have some
 * weaknesses, although I'm not aware of any major results against the cipher
 * itself.  I'm also not aware of any legal problems with using the RC2
 * cipher.
 *
 * The oddest feature in the cipher is the key schedule.  It expands the
 * initial key material to 128 bytes, and then `brain-damages' it, according
 * to a supplied `effective key-bits' parameter, before expanding the
 * remaining key material back into the buffer.
 *
 * The key schedule allows second preimages to be computed trivially.
 */

#ifndef CATACOMB_RC2_H
#define CATACOMB_RC2_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define RC2_BLKSZ 8
#define RC2_KEYSZ 16
#define RC2_CLASS (N, L, 64)

extern const octet rc2_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct rc2_ctx {
  uint16 k[64];
} rc2_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @rc2_braindamage@ --- *
 *
 * Arguments:	@rc2_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to key material
 *		@size_t sz@ = size of key material in bytes
 *		@unsigned eb@ = desired effective key size, in bits
 *
 * Returns:	---
 *
 * Use:		Initializes an RC2 expanded key, and braindamages it to the
 *		requested effective key size.  This is here for compatibility
 *		reasons.  You should be using @rc2_init@ in normal code,
 *		which doesn't actually apply braindamage.
 */

extern void rc2_braindamage(rc2_ctx */*k*/, const void */*buf*/,
			    size_t /*sz*/, unsigned /*eb*/);

/* --- @rc2_init@ --- *
 *
 * Arguments:	@rc2_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to key material
 *		@size_t sz@ = size of key material in bytes
 *
 * Returns:	---
 *
 * Use:		Initializes an RC2 expanded key.  The effective key size is
 *		set to be equal to the real key size, in bits.
 */

extern void rc2_init(rc2_ctx */*k*/, const void */*buf*/, size_t /*sz*/);

/* --- @rc2_eblk@, @rc2_dblk@ --- *
 *
 * Arguments:	@const rc2_ctx *k@ = pointer to RC2 context
 *		@const uint32 s[2]@ = pointer to source block
 *		@const uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void rc2_eblk(const rc2_ctx */*k*/,
		     const uint32 */*s*/, uint32 */*dst*/);
extern void rc2_dblk(const rc2_ctx */*k*/,
		     const uint32 */*s*/, uint32 */*dst*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
