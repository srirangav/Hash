/* -*-c-*-
 *
 * Generic hash wrapper for CRC32
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/crc32.h>
#include <mLib/sub.h>

#include "arena.h"
#include "crc32.h"
#include "ghash.h"
#include "paranoia.h"

/*----- Main code ---------------------------------------------------------*/

typedef struct gctx {
  ghash h;
  uint32 c;
  octet buf[4];
} gctx;

static const ghash_ops gops;

static ghash *ghinit(void)
{
  gctx *g = S_CREATE(gctx);
  g->h.ops = &gops;
  g->c = 0;
  return (&g->h);
}

static void ghhash(ghash *h, const void *p, size_t sz)
{
  gctx *g = (gctx *)h;
  CRC32(g->c, g->c, p, sz);
}

static octet *ghdone(ghash *h, void *buf)
{
  gctx *g = (gctx *)h;
  if (!buf)
    buf = g->buf;
  STORE32(buf, g->c);
  return (buf);
}

static void ghdestroy(ghash *h)
{
  gctx *g = (gctx *)h;
  BURN(*g);
  S_DESTROY(g);
}

static ghash *ghcopy(ghash *h)
{
  gctx *g = (gctx *)h;
  gctx *gg = S_CREATE(gctx);
  memcpy(gg, g, sizeof(gctx));
  return (&gg->h);
}

static const ghash_ops gops = { &gcrc32, ghhash, ghdone, ghdestroy, ghcopy };
const gchash gcrc32 = { "crc32", 4, ghinit };

/*----- That's all, folks -------------------------------------------------*/
