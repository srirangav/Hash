/* -*-c-*-
 *
 * Implementation of the Whirlpool hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Whirlpool hash function ------------------------------*
 *
 * Whirlpool was designed by Paulo Barreto and Vincent Rijmen.  Its
 * compression function is based on similar ideas to Rijndael (also
 * codesigned by Rijmen).
 *
 * Whirlpool256 is simply Whirlpool with its final output truncated to 256
 * bits.  This is, I hope, about as good as a 256-bit hash function can get.
 * It isn't vulnerable to the Kelsey-Schneier generic second-preimage attack
 * against MD hash functions because of its larger internal state (see also
 * Lucks).
 */

#ifndef CATACOMB_WHIRLPOOL_H
#define CATACOMB_WHIRLPOOL_H
#define CATACOMB_WHIRLPOOL256_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

/*----- Magic numbers -----------------------------------------------------*/

#define WHIRLPOOL_BUFSZ 64
#define WHIRLPOOL_HASHSZ 64
#define WHIRLPOOL_STATESZ 64

#define WHIRLPOOL256_BUFSZ 64
#define WHIRLPOOL256_HASHSZ 32
#define WHIRLPOOL256_STATESZ 64

/*----- Data structures ---------------------------------------------------*/

typedef struct whirlpool_ctx {
  kludge64 s[8];			/* Chaining variables */
  uint32 nh, nl;			/* Byte count so far */
  unsigned off;				/* Offset into buffer */
  octet buf[WHIRLPOOL_BUFSZ];		/* Accumulation buffer */
} whirlpool_ctx, whirlpool256_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @whirlpool_compress@, @whirlpool256_compress@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		SHA-512 compression function.
 */

extern void whirlpool_compress(whirlpool_ctx */*ctx*/, const void */*sbuf*/);
#define whirlpool256_compress whirlpool_compress

/* --- @whirlpool_init@, @whirlpool256_init@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

extern void whirlpool_init(whirlpool_ctx */*ctx*/);
#define whirlpool256_init whirlpool_init

/* --- @whirlpool_set@, @whirlpool256_set@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

extern void whirlpool_set(whirlpool_ctx */*ctx*/, const void */*buf*/,
			  unsigned long /*count*/);
#define whirlpool256_set whirlpool_set

/* --- @whirlpool_hash@, @whirlpool256_hash@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

extern void whirlpool_hash(whirlpool_ctx */*ctx*/,
			   const void */*buf*/, size_t /*sz*/);
#define whirlpool256_hash whirlpool_hash

/* --- @whirlpool_done@, @whirlpool256_done@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

extern void whirlpool_done(whirlpool_ctx */*ctx*/, void */*hash*/);
extern void whirlpool256_done(whirlpool_ctx */*ctx*/, void */*hash*/);

/* --- @whirlpool_state@, @whirlpool256_state@ --- *
 *
 * Arguments:	@whirlpool_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @whirlpool_set@.
 */

extern unsigned long whirlpool_state(whirlpool_ctx */*ctx*/,
				     void */*state*/);
#define whirlpool256_state whirlpool_state

/*----- Generic hash interface --------------------------------------------*/

extern const gchash whirlpool;
extern const gchash whirlpool256;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
