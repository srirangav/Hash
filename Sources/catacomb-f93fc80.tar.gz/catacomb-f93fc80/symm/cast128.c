/* -*-c-*-
 *
 * The CAST-128 block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/bits.h>

#include "blkc.h"
#include "cast-base.h"
#include "cast128.h"
#include "gcipher.h"
#include "paranoia.h"

/*----- Global variables --------------------------------------------------*/

const octet cast128_keysz[] = { KSZ_RANGE, CAST128_KEYSZ, 0, 16, 1 };

/*----- Main code ---------------------------------------------------------*/

/* --- @cast128_init@ --- *
 *
 * Arguments:	@cast128_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a CAST-128 key buffer.  CAST-128 accepts
 *		128-bit keys or shorter.
 */

void cast128_init(cast128_ctx *k, const void *buf, size_t sz)
{
  const octet *p = buf;
  uint32 kk[4];
  unsigned i;
  uint32 a, b, c, d,  aa, bb, cc, dd;

  /* --- Fiddle with the key size a bit --- */

  KSZ_ASSERT(cast128, sz);

  if (sz > 10)
    k->r = 16;
  else
    k->r = 12;

  /* --- Read the key into the array --- */

  i = 0;
  b = 32; aa = 0;
  for (;;) {
    if (!sz)
      break;
    b -= 8;
    aa |= ((uint32)*p++ << b);
    sz--;
    if (b == 0) {
      kk[i++] = aa;
      if (i == 4)
	break;
      aa = 0;
      b = 32;
    }
  }

  for (; i < 4; i++) {
    kk[i] = aa;
    aa = 0;
  }

  /* --- Read the key words out --- */

  a = kk[0]; b = kk[1]; c = kk[2]; d = kk[3];

#define X_0123 a
#define X_4567 b
#define X_89ab c
#define X_cdef d

#define X_0 U8(X_0123 >> 24)
#define X_1 U8(X_0123 >> 16)
#define X_2 U8(X_0123 >>  8)
#define X_3 U8(X_0123 >>  0)
#define X_4 U8(X_4567 >> 24)
#define X_5 U8(X_4567 >> 16)
#define X_6 U8(X_4567 >>  8)
#define X_7 U8(X_4567 >>  0)
#define X_8 U8(X_89ab >> 24)
#define X_9 U8(X_89ab >> 16)
#define X_a U8(X_89ab >>  8)
#define X_b U8(X_89ab >>  0)
#define X_c U8(X_cdef >> 24)
#define X_d U8(X_cdef >> 16)
#define X_e U8(X_cdef >>  8)
#define X_f U8(X_cdef >>  0)

#define Z_0123 aa
#define Z_4567 bb
#define Z_89ab cc
#define Z_cdef dd

#define Z_0 U8(Z_0123 >> 24)
#define Z_1 U8(Z_0123 >> 16)
#define Z_2 U8(Z_0123 >>  8)
#define Z_3 U8(Z_0123 >>  0)
#define Z_4 U8(Z_4567 >> 24)
#define Z_5 U8(Z_4567 >> 16)
#define Z_6 U8(Z_4567 >>  8)
#define Z_7 U8(Z_4567 >>  0)
#define Z_8 U8(Z_89ab >> 24)
#define Z_9 U8(Z_89ab >> 16)
#define Z_a U8(Z_89ab >>  8)
#define Z_b U8(Z_89ab >>  0)
#define Z_c U8(Z_cdef >> 24)
#define Z_d U8(Z_cdef >> 16)
#define Z_e U8(Z_cdef >>  8)
#define Z_f U8(Z_cdef >>  0)

#define SK(w, x, y, z)							\
  cast_sk[0][w] ^ cast_sk[1][x] ^ cast_sk[2][y] ^ cast_sk[3][z]

  i = 0;
  Z_0123 = X_0123 ^ SK(X_d, X_f, X_c, X_e) ^ cast_sk[2][X_8];
  Z_4567 = X_89ab ^ SK(Z_0, Z_2, Z_1, Z_3) ^ cast_sk[3][X_a];
  Z_89ab = X_cdef ^ SK(Z_7, Z_6, Z_5, Z_4) ^ cast_sk[0][X_9];
  Z_cdef = X_4567 ^ SK(Z_a, Z_9, Z_b, Z_8) ^ cast_sk[1][X_b];
  k->km[i++] = SK(Z_8, Z_9, Z_7, Z_6) ^ cast_sk[0][Z_2];
  k->km[i++] = SK(Z_a, Z_b, Z_5, Z_4) ^ cast_sk[1][Z_6];
  k->km[i++] = SK(Z_c, Z_d, Z_3, Z_2) ^ cast_sk[2][Z_9];
  k->km[i++] = SK(Z_e, Z_f, Z_1, Z_0) ^ cast_sk[3][Z_c];
  X_0123 = Z_89ab ^ SK(Z_5, Z_7, Z_4, Z_6) ^ cast_sk[2][Z_0];
  X_4567 = Z_0123 ^ SK(X_0, X_2, X_1, X_3) ^ cast_sk[3][Z_2];
  X_89ab = Z_4567 ^ SK(X_7, X_6, X_5, X_4) ^ cast_sk[0][Z_1];
  X_cdef = Z_cdef ^ SK(X_a, X_9, X_b, X_8) ^ cast_sk[1][Z_3];
  k->km[i++] = SK(X_3, X_2, X_c, X_d) ^ cast_sk[0][X_8];
  k->km[i++] = SK(X_1, X_0, X_e, X_f) ^ cast_sk[1][X_d];
  k->km[i++] = SK(X_7, X_6, X_8, X_9) ^ cast_sk[2][X_3];
  k->km[i++] = SK(X_5, X_4, X_a, X_b) ^ cast_sk[3][X_7];
  Z_0123 = X_0123 ^ SK(X_d, X_f, X_c, X_e) ^ cast_sk[2][X_8];
  Z_4567 = X_89ab ^ SK(Z_0, Z_2, Z_1, Z_3) ^ cast_sk[3][X_a];
  Z_89ab = X_cdef ^ SK(Z_7, Z_6, Z_5, Z_4) ^ cast_sk[0][X_9];
  Z_cdef = X_4567 ^ SK(Z_a, Z_9, Z_b, Z_8) ^ cast_sk[1][X_b];
  k->km[i++] = SK(Z_3, Z_2, Z_c, Z_d) ^ cast_sk[0][Z_9];
  k->km[i++] = SK(Z_1, Z_0, Z_e, Z_f) ^ cast_sk[1][Z_c];
  k->km[i++] = SK(Z_7, Z_6, Z_8, Z_9) ^ cast_sk[2][Z_2];
  k->km[i++] = SK(Z_5, Z_4, Z_a, Z_b) ^ cast_sk[3][Z_6];
  X_0123 = Z_89ab ^ SK(Z_5, Z_7, Z_4, Z_6) ^ cast_sk[2][Z_0];
  X_4567 = Z_0123 ^ SK(X_0, X_2, X_1, X_3) ^ cast_sk[3][Z_2];
  X_89ab = Z_4567 ^ SK(X_7, X_6, X_5, X_4) ^ cast_sk[0][Z_1];
  X_cdef = Z_cdef ^ SK(X_a, X_9, X_b, X_8) ^ cast_sk[1][Z_3];
  k->km[i++] = SK(X_8, X_9, X_7, X_6) ^ cast_sk[0][X_3];
  k->km[i++] = SK(X_a, X_b, X_5, X_4) ^ cast_sk[1][X_7];
  k->km[i++] = SK(X_c, X_d, X_3, X_2) ^ cast_sk[2][X_8];
  k->km[i++] = SK(X_e, X_f, X_1, X_0) ^ cast_sk[3][X_d];

  i = 0;
  Z_0123 = X_0123 ^ SK(X_d, X_f, X_c, X_e) ^ cast_sk[2][X_8];
  Z_4567 = X_89ab ^ SK(Z_0, Z_2, Z_1, Z_3) ^ cast_sk[3][X_a];
  Z_89ab = X_cdef ^ SK(Z_7, Z_6, Z_5, Z_4) ^ cast_sk[0][X_9];
  Z_cdef = X_4567 ^ SK(Z_a, Z_9, Z_b, Z_8) ^ cast_sk[1][X_b];
  k->kr[i++] = (SK(Z_8, Z_9, Z_7, Z_6) ^ cast_sk[0][Z_2]) & 0x1f;
  k->kr[i++] = (SK(Z_a, Z_b, Z_5, Z_4) ^ cast_sk[1][Z_6]) & 0x1f;
  k->kr[i++] = (SK(Z_c, Z_d, Z_3, Z_2) ^ cast_sk[2][Z_9]) & 0x1f;
  k->kr[i++] = (SK(Z_e, Z_f, Z_1, Z_0) ^ cast_sk[3][Z_c]) & 0x1f;
  X_0123 = Z_89ab ^ SK(Z_5, Z_7, Z_4, Z_6) ^ cast_sk[2][Z_0];
  X_4567 = Z_0123 ^ SK(X_0, X_2, X_1, X_3) ^ cast_sk[3][Z_2];
  X_89ab = Z_4567 ^ SK(X_7, X_6, X_5, X_4) ^ cast_sk[0][Z_1];
  X_cdef = Z_cdef ^ SK(X_a, X_9, X_b, X_8) ^ cast_sk[1][Z_3];
  k->kr[i++] = (SK(X_3, X_2, X_c, X_d) ^ cast_sk[0][X_8]) & 0x1f;
  k->kr[i++] = (SK(X_1, X_0, X_e, X_f) ^ cast_sk[1][X_d]) & 0x1f;
  k->kr[i++] = (SK(X_7, X_6, X_8, X_9) ^ cast_sk[2][X_3]) & 0x1f;
  k->kr[i++] = (SK(X_5, X_4, X_a, X_b) ^ cast_sk[3][X_7]) & 0x1f;
  Z_0123 = X_0123 ^ SK(X_d, X_f, X_c, X_e) ^ cast_sk[2][X_8];
  Z_4567 = X_89ab ^ SK(Z_0, Z_2, Z_1, Z_3) ^ cast_sk[3][X_a];
  Z_89ab = X_cdef ^ SK(Z_7, Z_6, Z_5, Z_4) ^ cast_sk[0][X_9];
  Z_cdef = X_4567 ^ SK(Z_a, Z_9, Z_b, Z_8) ^ cast_sk[1][X_b];
  k->kr[i++] = (SK(Z_3, Z_2, Z_c, Z_d) ^ cast_sk[0][Z_9]) & 0x1f;
  k->kr[i++] = (SK(Z_1, Z_0, Z_e, Z_f) ^ cast_sk[1][Z_c]) & 0x1f;
  k->kr[i++] = (SK(Z_7, Z_6, Z_8, Z_9) ^ cast_sk[2][Z_2]) & 0x1f;
  k->kr[i++] = (SK(Z_5, Z_4, Z_a, Z_b) ^ cast_sk[3][Z_6]) & 0x1f;
  X_0123 = Z_89ab ^ SK(Z_5, Z_7, Z_4, Z_6) ^ cast_sk[2][Z_0];
  X_4567 = Z_0123 ^ SK(X_0, X_2, X_1, X_3) ^ cast_sk[3][Z_2];
  X_89ab = Z_4567 ^ SK(X_7, X_6, X_5, X_4) ^ cast_sk[0][Z_1];
  X_cdef = Z_cdef ^ SK(X_a, X_9, X_b, X_8) ^ cast_sk[1][Z_3];
  k->kr[i++] = (SK(X_8, X_9, X_7, X_6) ^ cast_sk[0][X_3]) & 0x1f;
  k->kr[i++] = (SK(X_a, X_b, X_5, X_4) ^ cast_sk[1][X_7]) & 0x1f;
  k->kr[i++] = (SK(X_c, X_d, X_3, X_2) ^ cast_sk[2][X_8]) & 0x1f;
  k->kr[i++] = (SK(X_e, X_f, X_1, X_0) ^ cast_sk[3][X_d]) & 0x1f;

  BURN(kk);
}

/* --- @cast128_eblk@, @cast128_dblk@ --- *
 *
 * Arguments:	@const cast128_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

void cast128_eblk(const cast128_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 a = s[0], b = s[1];
  const uint32 *km = k->km;
  const octet *kr = k->kr;

  switch (k->r) {
    default:
      CAST_R1(*km++, *kr++, a, b);
      CAST_R2(*km++, *kr++, b, a);
      CAST_R3(*km++, *kr++, a, b);
      CAST_R1(*km++, *kr++, b, a);
      CAST_R2(*km++, *kr++, a, b);
      CAST_R3(*km++, *kr++, b, a);
      CAST_R1(*km++, *kr++, a, b);
      CAST_R2(*km++, *kr++, b, a);
      CAST_R3(*km++, *kr++, a, b);
      CAST_R1(*km++, *kr++, b, a);
      CAST_R2(*km++, *kr++, a, b);
      CAST_R3(*km++, *kr++, b, a);
      if (k->r == 12)
	break;
      CAST_R1(*km++, *kr++, a, b);
      CAST_R2(*km++, *kr++, b, a);
      CAST_R3(*km++, *kr++, a, b);
      CAST_R1(*km++, *kr++, b, a);
      break;
  }

  d[0] = b; d[1] = a;
}

void cast128_dblk(const cast128_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 a = s[0], b = s[1];
  const uint32 *km = k->km + k->r;
  const octet *kr = k->kr + k->r;

  switch (k->r) {
    case 16:
    default:
      CAST_R1(*--km, *--kr, a, b);
      CAST_R3(*--km, *--kr, b, a);
      CAST_R2(*--km, *--kr, a, b);
      CAST_R1(*--km, *--kr, b, a);
    case 12:
      CAST_R3(*--km, *--kr, a, b);
      CAST_R2(*--km, *--kr, b, a);
      CAST_R1(*--km, *--kr, a, b);
      CAST_R3(*--km, *--kr, b, a);
      CAST_R2(*--km, *--kr, a, b);
      CAST_R1(*--km, *--kr, b, a);
      CAST_R3(*--km, *--kr, a, b);
      CAST_R2(*--km, *--kr, b, a);
      CAST_R1(*--km, *--kr, a, b);
      CAST_R3(*--km, *--kr, b, a);
      CAST_R2(*--km, *--kr, a, b);
      CAST_R1(*--km, *--kr, b, a);
      break;
  }

  d[0] = b; d[1] = a;
}

BLKC_TEST(CAST128, cast128)

/*----- That's all, folks -------------------------------------------------*/
