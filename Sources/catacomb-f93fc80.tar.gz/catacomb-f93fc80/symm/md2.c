/* -*-c-*-
 *
 * The MD2 message digest function
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "md2.h"

/*----- Tables ------------------------------------------------------------*/

extern const octet md2_s[256];

/*----- Main code ---------------------------------------------------------*/

/* --- @md2_compress@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		MD2 compression and checksum function.
 */

void md2_compress(md2_ctx *ctx, const void *sbuf)
{
  unsigned i;
  unsigned t;
  octet x[MD2_BUFSZ];
  octet y[MD2_BUFSZ];

  /* --- Handy macro for doing something lots of times --- */

#define DO(what, where) do {						\
  what(where,  0); what(where,	1); what(where,	 2); what(where,  3);	\
  what(where,  4); what(where,	5); what(where,	 6); what(where,  7);	\
  what(where,  8); what(where,	9); what(where, 10); what(where, 11);	\
  what(where, 12); what(where, 13); what(where, 14); what(where, 15);	\
} while (0)

  /* --- Do the hashing first to avoid corrupting the checksum --- */

  memcpy(x, sbuf, sizeof(x));
#define X(z, i) y[i] = z[i] ^ ctx->h[i]
  DO(X, x);
#undef X

  t = 0;
  for (i = 0; i < 18; i++) {
#define X(z, i) t = z[i] ^= md2_s[t];
    DO(X, ctx->h);
    DO(X, x);
    DO(X, y);
#undef X
    t = U8(t + i);
  }

  /* --- Now compute the checksum --- */

  t = ctx->c[MD2_BUFSZ - 1];
#define X(z, i) t = ctx->c[i] ^= md2_s[z[i] ^ t]
  DO(X, ((const octet *)sbuf));
#undef X

#undef DO
}

/* --- @md2_init@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void md2_init(md2_ctx *ctx)
{
  memset(ctx->c, 0, sizeof(ctx->c));
  memset(ctx->h, 0, sizeof(ctx->h));
  ctx->off = 0;
}

/* --- @md2_set@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void md2_set(md2_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  memcpy(ctx->h, p, MD2_BUFSZ);
  memcpy(ctx->c, p + MD2_BUFSZ, MD2_BUFSZ);
  ctx->off = 0;
}

/* --- @md2_hash@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void md2_hash(md2_ctx *ctx, const void *buf, size_t sz)
{
  const octet *bbuf = (octet *)buf;

  /* --- Code automatically expanded from @HASH_BUFFER@ and tidied --- */

  if (ctx->off + sz < MD2_BUFSZ) {
    memcpy(ctx->buf + ctx->off, bbuf, sz);
    ctx->off += sz;
  } else {
    if (ctx->off) {
      size_t s = MD2_BUFSZ - ctx->off;
      memcpy(ctx->buf + ctx->off, bbuf, s);
      md2_compress(ctx, ctx->buf);
      sz -= s;
      bbuf += s;
    }
    while (sz >= MD2_BUFSZ) {
      md2_compress(ctx, bbuf);
      sz -= MD2_BUFSZ; bbuf += MD2_BUFSZ;
    }
    if (sz)
      memcpy(ctx->buf, bbuf, sz);
    ctx->off = sz;
  }
}

/* --- @md2_done@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

void md2_done(md2_ctx *ctx, void *hash)
{
  unsigned pad = MD2_BUFSZ - ctx->off;
  unsigned i;
  for (i = ctx->off; i < MD2_BUFSZ; i++)
    ctx->buf[i] = pad;
  md2_compress(ctx, ctx->buf);
  md2_compress(ctx, ctx->c);
  memcpy(hash, ctx->h, MD2_BUFSZ);
}

/* --- @md2_state@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @md2_set@.
 */

unsigned long md2_state(md2_ctx *ctx, void *state)
{
  octet *p = state;
  memcpy(p, ctx->h, MD2_BUFSZ);
  memcpy(p + MD2_BUFSZ, ctx->c, MD2_BUFSZ);
  return (0);
}

/* --- Generic interface --- */

GHASH_DEF(MD2, md2)

/* --- Test code --- */

HASH_TEST(MD2, md2)

/*----- That's all, folks -------------------------------------------------*/
