/* -*-c-*-
 *
 * Ciphertext block chaining for block ciphers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_CBC_H
#define CATACOMB_CBC_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

/*----- Macros ------------------------------------------------------------*/

/* --- @CBC_DECL@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for the underlying block cipher
 *
 * Use:		Creates declarations for CBC stealing mode.
 */

#define CBC_DECL(PRE, pre)						\
									\
/* --- Cipher block chaining context --- */				\
									\
typedef struct pre##_cbcctx {						\
  pre##_ctx ctx;			/* Underlying cipher context */	\
  uint32 iv[PRE##_BLKSZ / 4];		/* Previous ciphertext or IV */	\
} pre##_cbcctx;								\
									\
/* --- @pre_cbcgetiv@ --- *						\
 *									\
 * Arguments:	@const pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@void *iv@ = pointer to output data block		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Reads the currently set IV.  Reading and setting an IV	\
 *		is transparent to the CBC encryption or decryption	\
 *		process.						\
 */									\
									\
extern void pre##_cbcgetiv(const pre##_cbcctx */*ctx*/,			\
			   void */*iv*/);				\
									\
/* --- @pre_cbcsetiv@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@cnost void *iv@ = pointer to IV to set			\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the IV to use for subsequent encryption.		\
 */									\
									\
extern void pre##_cbcsetiv(pre##_cbcctx */*ctx*/,			\
			   const void */*iv*/);				\
									\
/* --- @pre_cbcsetkey@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@const pre_ctx *k@ = pointer to cipher context		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the CBC context to use a different cipher key.	\
 */									\
									\
extern void pre##_cbcsetkey(pre##_cbcctx */*ctx*/,			\
			    const pre##_ctx */*k*/);			\
									\
/* --- @pre_cbcinit@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to cipher context		\
 *		@const void *key@ = pointer to the key buffer		\
 *		@size_t sz@ = size of the key				\
 *		@const void *iv@ = pointer to initialization vector	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes a CBC context ready for use.  The @iv@	\
 *		argument may be passed as a null pointer to set a zero	\
 *		IV.  Apart from that, this call is equivalent to calls	\
 *		to @pre_init@, @pre_cbcsetkey@ and @pre_cbcsetiv@.	\
 */									\
									\
extern void pre##_cbcinit(pre##_cbcctx */*ctx*/,			\
			  const void */*key*/, size_t /*sz*/,		\
			  const void */*iv*/);				\
									\
/* --- @pre_cbcencrypt@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Encrypts a block with a block cipher in CBC mode, with	\
 *		ciphertext stealing and other clever tricks.		\
 *		Essentially, data can be encrypted in arbitrary sized	\
 *		chunks, although decryption must use the same chunks.	\
 */									\
									\
extern void pre##_cbcencrypt(pre##_cbcctx */*ctx*/,			\
			     const void */*src*/, void */*dest*/,	\
			     size_t /*sz*/);				\
									\
/* --- @pre_cbcdecrypt@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Decrypts a block with a block cipher in CBC mode, with	\
 *		ciphertext stealing and other clever tricks.		\
 *		Essentially, data can be encrypted in arbitrary sized	\
 *		chunks, although decryption must use the same chunks.	\
 */									\
									\
extern void pre##_cbcdecrypt(pre##_cbcctx */*ctx*/,			\
			     const void */*src*/, void */*dest*/,	\
			     size_t /*sz*/);				\
									\
/* --- Generic cipher interface --- */					\
									\
extern const gccipher pre##_cbc;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
