/* -*-c-*-
 *
 * The Rijndael block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Rijndael block cipher --------------------------------*
 *
 * Invented by Joan Daemen and Vincent Rijmen, Rijndael is a fast, elegant
 * and relatively simple 128-bit block cipher.  It was chosen by NIST to be
 * the new Advanced Encryption Standard (AES) algorithm.
 *
 * Rijnadel appears to have a low security margin.  I recommend waiting
 * before using Rijndael for any sensitive applications.
 */

#ifndef CATACOMB_RIJNDAEL_H
#define CATACOMB_RIJNDAEL_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define RIJNDAEL_BLKSZ 16
#define RIJNDAEL_KEYSZ 32
#define RIJNDAEL_CLASS (N, B, 128)

extern const octet rijndael_keysz[];

/*----- Data structures ---------------------------------------------------*/

#define RIJNDAEL_MAXROUNDS 16
#define RIJNDAEL_KWORDS ((RIJNDAEL_MAXROUNDS + 1) * 8)

typedef struct rijndael_ctx {
  unsigned nr;
  uint32 w[RIJNDAEL_KWORDS];
  uint32 wi[RIJNDAEL_KWORDS];
} rijndael_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @rijndael_setup@ --- *
 *
 * Arguments:	@rijndael_ctx *k@ = pointer to context to initialize
 *		@unsigned nb@ = number of words in the block
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Low-level key-scheduling.  Don't call this directly.
 */

extern void rijndael_setup(rijndael_ctx */*k*/, unsigned /*nb*/,
			   const void */*buf*/, size_t /*sz*/);

/* --- @rijndael_init@ --- *
 *
 * Arguments:	@rijndael_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Rijndael context with a particular key.  This
 *		implementation of Rijndael doesn't impose any particular
 *		limits on the key size except that it must be multiple of 4
 *		bytes long.  256 bits seems sensible, though.
 */

extern void rijndael_init(rijndael_ctx */*k*/,
			  const void */*buf*/, size_t /*sz*/);

/* --- @rijndael_eblk@, @rijndael_dblk@ --- *
 *
 * Arguments:	@const rijndael_ctx *k@ = pointer to Rijndael context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void rijndael_eblk(const rijndael_ctx */*k*/,
			  const uint32 */*s*/, uint32 */*dst*/);
extern void rijndael_dblk(const rijndael_ctx */*k*/,
			  const uint32 */*s*/, uint32 */*dst*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
