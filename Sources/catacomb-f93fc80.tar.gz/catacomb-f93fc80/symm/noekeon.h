/* -*-c-*-
 *
 * The Noekeon block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Noekeon block cipher --------------------------------*
 *
 * A Nessie entry, by Joan Daemen, Michael Peeters, Gilles Van Assche and
 * Vincent Rijmen, two of whom were the designers of the AES winner
 * Rijndael.  It's a simple cipher, based on Serpent-style bit-slicing.
 * Speed is about middle-of-the-road -- about as fast as SAFER, faster than
 * MARS.
 */

#ifndef CATACOMB_NOEKEON_H
#define CATACOMB_NOEKEON_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define NOEKEON_BLKSZ 16
#define NOEKEON_KEYSZ 16
#define NOEKEON_CLASS (N, B, 128)

extern const octet noekeon_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct noekeon_ctx {
  uint32 k[4];
} noekeon_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @noekeon_init@ --- *
 *
 * Arguments:	@noekeon_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Noekeon context with a particular key.  This
 *		uses indirect keying.  The key must be 128 bits long.
 */

extern void noekeon_init(noekeon_ctx */*k*/,
			 const void */*buf*/, size_t /*sz*/);

/* --- @noekeon_eblk@, @noekeon_dblk@ --- *
 *
 * Arguments:	@const noekeon_ctx *k@ = pointer to Noekeon context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void noekeon_eblk(const noekeon_ctx */*k*/,
			 const uint32 */*s*/, uint32 */*dst*/);
extern void noekeon_dblk(const noekeon_ctx */*k*/,
			 const uint32 */*s*/, uint32 */*dst*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
