/* -*-c-*-
 *
 * Generic hash function interface
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GHASH_H
#define CATACOMB_GHASH_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Generic hash function interface -----------------------------------*/

typedef struct ghash {
  const struct ghash_ops *ops;		/* Pointer to hash operations */
} ghash;

typedef struct ghash_ops {
  const struct gchash *c;		/* Pointer to hash class */
  void (*hash)(ghash */*h*/, const void */*p*/, size_t /*sz*/); /* Hash */
  octet *(*done)(ghash */*h*/, void */*buf*/); /* Write result */
  void (*destroy)(ghash */*h*/);	/* Destroy hash block */
  ghash *(*copy)(ghash */*h*/);		/* Make a copy of the hash context */
} ghash_ops;

#define GH_INIT(ch)		(ch)->init()
#define GH_CLASS(h)		(h)->ops->c
#define GH_HASH(h, p, sz)	(h)->ops->hash((h), (p), (sz))
#define GH_DONE(h, buf)		(h)->ops->done((h), (buf))
#define GH_DESTROY(h)		(h)->ops->destroy((h))
#define GH_COPY(h)		(h)->ops->copy((h))

#define GH_HASHU_(h, n, W)  do {					\
  TY_U##W n_ = (n); octet b_[SZ_##W];					\
  STORE##W(b_, n_); GH_HASH((h), b_, SZ_##W);				\
} while (0)
#define GH_HASHU8(h, n)	 GH_HASHU_((h), (n), 8)
#define GH_HASHU16(h, n) GH_HASHU_((h), (n), 16)
#define GH_HASHU16_B(h, n) GH_HASHU_((h), (n), 16_B)
#define GH_HASHU16_L(h, n) GH_HASHU_((h), (n), 16_L)
#define GH_HASHU24(h, n) GH_HASHU_((h), (n), 24)
#define GH_HASHU24_B(h, n) GH_HASHU_((h), (n), 24_B)
#define GH_HASHU24_L(h, n) GH_HASHU_((h), (n), 24_L)
#define GH_HASHU32(h, n) GH_HASHU_((h), (n), 32)
#define GH_HASHU32_B(h, n) GH_HASHU_((h), (n), 32_B)
#define GH_HASHU32_L(h, n) GH_HASHU_((h), (n), 32_L)
#ifdef HAVE_UINT64
#  define GH_HASHU64(h, n) GH_HASHU_((h), (n), 64)
#  define GH_HASHU64_B(h, n) GH_HASHU_((h), (n), 64_B)
#  define GH_HASHU64_L(h, n) GH_HASHU_((h), (n), 64_L)
#endif

#define GH_HASHBUF_(h, p, sz, W) do {					\
  size_t sz_ = (sz); assert(sz_ <= MASK##W);				\
  GH_HASHU_(h, sz_, W); GH_HASH(h, (p), sz_);				\
} while (0)
#define GH_HASHBUF8(h, p, sz) GH_HASHBUF_((h), (p), (sz), 8)
#define GH_HASHBUF16(h, p, sz) GH_HASHBUF_((h), (p), (sz), 16)
#define GH_HASHBUF16_L(h, p, sz) GH_HASHBUF_((h), (p), (sz), 16_L)
#define GH_HASHBUF16_B(h, p, sz) GH_HASHBUF_((h), (p), (sz), 16_B)
#define GH_HASHBUF24(h, p, sz) GH_HASHBUF_((h), (p), (sz), 24)
#define GH_HASHBUF24_L(h, p, sz) GH_HASHBUF_((h), (p), (sz), 24_L)
#define GH_HASHBUF24_B(h, p, sz) GH_HASHBUF_((h), (p), (sz), 24_B)
#define GH_HASHBUF32(h, p, sz) GH_HASHBUF_((h), (p), (sz), 32)
#define GH_HASHBUF32_L(h, p, sz) GH_HASHBUF_((h), (p), (sz), 32_L)
#define GH_HASHBUF32_B(h, p, sz) GH_HASHBUF_((h), (p), (sz), 32_B)
#ifdef HAVE_UINT64
#  define GH_HASHBUF64(h, p, sz) GH_HASHBUF_((h), (p), (sz), 64)
#  define GH_HASHBUF64_L(h, p, sz) GH_HASHBUF_((h), (p), (sz), 64_L)
#  define GH_HASHBUF64_B(h, p, sz) GH_HASHBUF_((h), (p), (sz), 64_B)
#endif

#define GH_HASHSTR_(h, p, W) do {					\
  const char *p_ = (p); GH_HASHBUF_((h), p_, strlen(p_), W);		\
} while (0)
#define GH_HASHSTR8(h, p) GH_HASHSTR_((h), (p), 8)
#define GH_HASHSTR16(h, p) GH_HASHSTR_((h), (p), 16)
#define GH_HASHSTR16_L(h, p) GH_HASHSTR_((h), (p), 16_L)
#define GH_HASHSTR16_B(h, p) GH_HASHSTR_((h), (p), 16_B)
#define GH_HASHSTR24(h, p) GH_HASHSTR_((h), (p), 24)
#define GH_HASHSTR24_L(h, p) GH_HASHSTR_((h), (p), 24_L)
#define GH_HASHSTR24_B(h, p) GH_HASHSTR_((h), (p), 24_B)
#define GH_HASHSTR32(h, p) GH_HASHSTR_((h), (p), 32)
#define GH_HASHSTR32_L(h, p) GH_HASHSTR_((h), (p), 32_L)
#define GH_HASHSTR32_B(h, p) GH_HASHSTR_((h), (p), 32_B)
#ifdef HAVE_UINT64
#  define GH_HASHSTR64(h, p) GH_HASHSTR_((h), (p), 64)
#  define GH_HASHSTR64_L(h, p) GH_HASHSTR_((h), (p), 64_L)
#  define GH_HASHSTR64_B(h, p) GH_HASHSTR_((h), (p), 64_B)
#endif

#define GH_HASHSTRZ(h, p) do {						\
  const char *p_ = (p); GH_HASH((h), p_, strlen(p_) + 1);		\
} while (0)
#define GH_HASHSTR(h, p) do {						\
  const char *p_ = (p); GH_HASH((h), p_, strlen(p_));			\
} while (0)

typedef struct gchash {
  const char *name;			/* Name of the hash function */
  size_t hashsz;			/* Size of output hash */
  ghash *(*init)(void);			/* Create a new hash instance */
  size_t bufsz;				/* Buffer size, or zero */
} gchash;

/*----- Tables ------------------------------------------------------------*/

extern const gchash *const ghashtab[];

/* --- @ghash_byname@ --- *
 *
 * Arguments:	@const char *p@ = pointer to name string
 *
 * Returns:	The named cipher class, or null.
 */

extern const gchash *ghash_byname(const char */*p*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
