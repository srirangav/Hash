/* -*-c-*-
 *
 * Generate S-boxes for the Tiger hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include <stdio.h>
#include <stdlib.h>

#include "tiger-base.h"

/*----- Static variables --------------------------------------------------*/

static kludge64 tiger_s[4][256];

/*----- Main code ---------------------------------------------------------*/

/* --- The basic Tiger compression function --- */

static void tiger(kludge64 *x, kludge64 *ss)
{
  TIGER_CORE(ss[0], ss[1], ss[2], x);
}

/* --- The S-box generator --- */

void gen(const char *buf, unsigned passes)
{
  kludge64 x[8], ss[3];
  unsigned i, j, k, b;
  unsigned q, n;
  uint32 t;
  const char *p;

  for (i = 0; i < 256; i++) {
    for (j = 0; j < 4; j++) {
      uint32 z = 0x01010101 * i;
      SET64(tiger_s[j][i], z, z);
    }
  }

  SET64(ss[0], 0x01234567, 0x89abcdef);
  SET64(ss[1], 0xfedcba98, 0x76543210);
  SET64(ss[2], 0xf096a5b4, 0xc3b2e187);

  q = 2;
  for (i = 0; i < passes; i++) {
    for (j = 0; j < 256; j++) {
      for (k = 0; k < 4; k++) {
	q++;
	if (q == 3) {
	  q = 0;
	  for (p = buf, n = 0; n < 8; n++, p += 8)
	    LOAD64_L_(x[n], p);
	  tiger(x, ss);
	}
	for (b = 0; b < 32; b += 8) {
	  n = U8(LO64(ss[q]) >> b);
	  t = (LO64(tiger_s[k][j]) ^ LO64(tiger_s[k][n])) & (0xff << b);
	  SET64(tiger_s[k][j], HI64(tiger_s[k][j]), LO64(tiger_s[k][j]) ^ t);
	  SET64(tiger_s[k][n], HI64(tiger_s[k][n]), LO64(tiger_s[k][n]) ^ t);
	}
	for (b = 0; b < 32; b += 8) {
	  n = U8(HI64(ss[q]) >> b);
	  t = (HI64(tiger_s[k][j]) ^ HI64(tiger_s[k][n])) & (0xff << b);
	  SET64(tiger_s[k][j], HI64(tiger_s[k][j]) ^ t, LO64(tiger_s[k][j]));
	  SET64(tiger_s[k][n], HI64(tiger_s[k][n]) ^ t, LO64(tiger_s[k][n]));
	}
      }
    }
  }
}

int main(void)
{
  unsigned i, j;

  gen("Tiger - A Fast New Hash Function, by Ross Anderson and Eli Biham", 5);

  fputs("\
/* -*-c-*-\n\
 *\n\
 * S-boxes for Tiger [generated]\n\
 */\n\
\n\
#include <mLib/bits.h>\n\
\n\
const kludge64 tiger_s[4][256] = {\n\
  { ", stdout);

  for (i = 0; i < 4; i++) {
    for (j = 0; j < 256; j++) {
      printf("X64(%08lx, %08lx)",
	     (unsigned long)HI64(tiger_s[i][j]),
	     (unsigned long)LO64(tiger_s[i][j]));
      if (j == 255) {
	if (i == 3)
	  fputs(" }\n};\n", stdout);
	else
	  fputs(" },\n\n  { ", stdout);
      } else if (j % 2 == 1)
	fputs(",\n    ", stdout);
      else
	fputs(", ", stdout);
    }
  }

  if (fclose(stdout)) {
    fprintf(stderr, "error writing data\n");
    exit(EXIT_FAILURE);
  }

  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
