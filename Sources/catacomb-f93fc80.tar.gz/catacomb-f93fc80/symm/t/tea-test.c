#include <stdio.h>
#include <catacomb/fibrand.h>

/* --- Needham and Wheeler's original code --- *
 *
 * Almost.  I changed the types from long to unsigned long.
 */

void code(unsigned long* v, unsigned long* k)  {
unsigned long y=v[0],z=v[1], sum=0,   /* set up */
 delta=0x9e3779b9, n=32 ;	      /* a key schedule constant */
while (n-->0) {			      /* basic cycle start */
  sum += delta ;
    y += (z<<4)+k[0] ^ z+sum ^ (z>>5)+k[1] ;
    z += (y<<4)+k[2] ^ y+sum ^ (y>>5)+k[3] ;   /* end cycle */
	      }
v[0]=y ; v[1]=z ; }

int main(void)
{
  unsigned long k[4] = { 0x00112233, 0x44556677, 0x8899aabb, 0xccddeeff };
  unsigned long p[2] = { 0x01234567, 0x89abcdef };
  fibrand f;

  int i;

  printf("  %08lx%08lx%08lx%08lx %08lx%08lx ",
	 k[0], k[1], k[2], k[3], p[0], p[1]);
  code(p, k);
  printf("%08lx%08lx;\n", p[0], p[1]);

  fibrand_lcseed(&f, 0);
  for (i = 1; i < 64; i++) {
    k[0] = fibrand_step(&f);
    k[1] = fibrand_step(&f);
    k[2] = fibrand_step(&f);
    k[3] = fibrand_step(&f);
    p[0] = fibrand_step(&f);
    p[1] = fibrand_step(&f);
    printf("  %08lx%08lx%08lx%08lx %08lx%08lx ",
	   k[0], k[1], k[2], k[3], p[0], p[1]);
    code(p, k);
    printf("%08lx%08lx;\n", p[0], p[1]);
  }

  return (0);
}
