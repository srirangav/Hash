#include <stdio.h>
#include <catacomb/fibrand.h>

/* --- Needham and Wheeler's original code --- *
 *
 * Almost.  I changed the types from long to unsigned long.
 */

void tean(unsigned long * v, unsigned long * k, long N) {
unsigned long y=v[0], z=v[1], DELTA=0x9e3779b9 ;
if (N>0) {
       /* coding */
   unsigned long limit=DELTA*N, sum=0 ;
   while (sum!=limit)
     y+= (z<<4 ^ z>>5) + z ^ sum + k[sum&3],
     sum+=DELTA,
     z+= (y<<4 ^ y>>5) + y ^ sum + k[sum>>11 &3] ;
	 }
else {

	  /* decoding */
   unsigned long sum=DELTA*(-N) ;
   while (sum)
     z-= (y<<4 ^ y>>5) + y ^ sum + k[sum>>11 &3],
     sum-=DELTA,
     y-= (z<<4 ^ z>>5) + z ^ sum + k[sum&3];
      }
v[0]=y, v[1]=z ;
return ;
}

int main(void)
{
  unsigned long k[4] = { 0x00112233, 0x44556677, 0x8899aabb, 0xccddeeff };
  unsigned long p[2] = { 0x01234567, 0x89abcdef };
  fibrand f;

  int i;

  printf("  %08lx%08lx%08lx%08lx %08lx%08lx ",
	 k[0], k[1], k[2], k[3], p[0], p[1]);
  tean(p, k, 32);
  printf("%08lx%08lx;\n", p[0], p[1]);

  fibrand_lcseed(&f, 0);
  for (i = 1; i < 64; i++) {
    k[0] = fibrand_step(&f);
    k[1] = fibrand_step(&f);
    k[2] = fibrand_step(&f);
    k[3] = fibrand_step(&f);
    p[0] = fibrand_step(&f);
    p[1] = fibrand_step(&f);
    printf("  %08lx%08lx%08lx%08lx %08lx%08lx ",
	   k[0], k[1], k[2], k[3], p[0], p[1]);
    tean(p, k, 32);
    printf("%08lx%08lx;\n", p[0], p[1]);
  }

  return (0);
}
