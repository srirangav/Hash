/* -*-c-*-
 *
 * The RC2 block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>

#include <mLib/bits.h>

#include "blkc.h"
#include "gcipher.h"
#include "paranoia.h"
#include "rc2.h"

/*----- Global variables --------------------------------------------------*/

const octet rc2_keysz[] = { KSZ_RANGE, RC2_KEYSZ, 1, 128, 1 };

/*----- Important tables --------------------------------------------------*/

extern const octet rc2_pi[256];

/*----- Main code ---------------------------------------------------------*/

/* --- @rc2_braindamage@ --- *
 *
 * Arguments:	@rc2_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to key material
 *		@size_t sz@ = size of key material in bytes
 *		@unsigned eb@ = desired effective key size, in bits
 *
 * Returns:	---
 *
 * Use:		Initializes an RC2 expanded key, and braindamages it to the
 *		requested effective key size.  This is here for compatibility
 *		reasons.  You should be using @rc2_init@ in normal code,
 *		which doesn't actually apply braindamage.
 */

void rc2_braindamage(rc2_ctx *k, const void *buf, size_t sz, unsigned eb)
{
  unsigned t8;
  uint16 tm;
  unsigned i;
  uint16 *kk;
  octet l[128];

  KSZ_ASSERT(rc2, sz);

  /* --- Compute the braindamage parameters --- */

  t8 = (eb + 7) / 8;
  tm = 0xff & ((1 << (8 + eb - 8 * t8)) - 1);

  /* --- Copy and expand the initial key --- */

  if (sz > sizeof(l))
    sz = sizeof(l);
  memcpy(l, buf, sz);

  for (i = sz; i < sizeof(l); i++)
    l[i] = rc2_pi[U8(l[i - 1] + l[i - sz])];

  /* --- Braindamage the key --- */

  i = sizeof(l) - t8;
  l[i] = rc2_pi[l[i] & tm];
  while (i) {
    i--;
    l[i] = rc2_pi[U8(l[i + 1] ^ l[i + t8])];
  }

  /* --- Write it to the key block --- */

  kk = k->k;
  for (i = 0; i < sizeof(l); i += 2)
    *kk++ = LOAD16_L(l + i);
  BURN(l);
}

/* --- @rc2_init@ --- *
 *
 * Arguments:	@rc2_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to key material
 *		@size_t sz@ = size of key material in bytes
 *
 * Returns:	---
 *
 * Use:		Initializes an RC2 expanded key.  The effective key size is
 *		set to be equal to the real key size, in bits.
 */

void rc2_init(rc2_ctx *k, const void *buf, size_t sz)
{
  rc2_braindamage(k, buf, sz, sz * 8);
}

/*----- Encryption and decryption -----------------------------------------*/

#define MIX(a, b, c, d, r, kk) do {					\
  a += *kk++ + (d & c) + (~d & b);					\
  a = ROL16(a, r);							\
} while (0)

#define MASH(a, d, k) do {						\
  a += k[d & 63];							\
} while (0)

#define UNMIX(a, b, c, d, r, kk) do {					\
  a = ROR16(a, r);							\
  a -= *--kk + (d & c) + (~d & b);					\
} while (0)

#define UNMASH(a, d, k) do {						\
  a -= k[d & 63];							\
} while (0)

/* --- @rc2_eblk@, @rc2_dblk@ --- *
 *
 * Arguments:	@const rc2_ctx *k@ = pointer to RC2 context
 *		@const uint32 s[2]@ = pointer to source block
 *		@const uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

void rc2_eblk(const rc2_ctx *k, const uint32 *s, uint32 *dst)
{
  uint16 a = U16(s[0] >>  0), b = U16(s[0] >> 16);
  uint16 c = U16(s[1] >>  0), d = U16(s[1] >> 16);
  const uint16 *kk = k->k;

  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MASH(a, d, k->k); MASH(b, a, k->k);
  MASH(c, b, k->k); MASH(d, c, k->k);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MASH(a, d, k->k); MASH(b, a, k->k);
  MASH(c, b, k->k); MASH(d, c, k->k);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);
  MIX(a, b, c, d, 1, kk); MIX(b, c, d, a, 2, kk);
  MIX(c, d, a, b, 3, kk); MIX(d, a, b, c, 5, kk);

  dst[0] = a | (b << 16); dst[1] = c | (d << 16);
}

void rc2_dblk(const rc2_ctx *k, const uint32 *s, uint32 *dst)
{
  uint16 a = U16(s[0] >>  0), b = U16(s[0] >> 16);
  uint16 c = U16(s[1] >>  0), d = U16(s[1] >> 16);
  const uint16 *kk = k->k + 64;

  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMASH(d, c, k->k); UNMASH(c, b, k->k);
  UNMASH(b, a, k->k); UNMASH(a, d, k->k);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMASH(d, c, k->k); UNMASH(c, b, k->k);
  UNMASH(b, a, k->k); UNMASH(a, d, k->k);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);
  UNMIX(d, a, b, c, 5, kk); UNMIX(c, d, a, b, 3, kk);
  UNMIX(b, c, d, a, 2, kk); UNMIX(a, b, c, d, 1, kk);

  dst[0] = a | (b << 16); dst[1] = c | (d << 16);
}

/*----- Custom test rig ---------------------------------------------------*
 *
 * I need to test the braindamage feature.
 */

#ifdef TEST_RIG

#include <mLib/quis.h>
#include <mLib/testrig.h>

static int verify(dstr *v)
{
  rc2_ctx k;
  uint32 p[RC2_BLKSZ / 4];
  uint32 c[RC2_BLKSZ / 4];
  uint32 d[RC2_BLKSZ / 4];
  dstr b = DSTR_INIT;
  unsigned bd = *(unsigned *)v[1].buf;
  int ok = 1;

  /* --- Initialize the key buffer --- */

  dstr_ensure(&b, RC2_BLKSZ);
  b.len = RC2_BLKSZ;
  rc2_braindamage(&k, v[0].buf, v[0].len, bd);
  BLKC_LOAD(RC2, p, v[2].buf);
  BLKC_LOAD(RC2, c, v[3].buf);

  /* --- Test encryption --- */

  BLKC_MOVE(RC2, d, p);
  rc2_eblk(&k, d, d);
  BLKC_STORE(RC2, b.buf, d);
  if (memcmp(b.buf, v[3].buf, RC2_BLKSZ)) {
    ok = 0;
    printf("\nfail encryption:"
	   "\n\tkey	   = ");
    type_hex.dump(&v[0], stdout);
    printf("\n\tbraindamage= %u", bd);
    printf("\n\tplaintext  = "); type_hex.dump(&v[2], stdout);
    printf("\n\texpected   = "); type_hex.dump(&v[3], stdout);
    printf("\n\tcalculated = "); type_hex.dump(&b, stdout);
    putchar('\n');
  }

  /* --- Test decryption --- */

  BLKC_MOVE(RC2, d, c);
  rc2_dblk(&k, d, d);
  BLKC_STORE(RC2, b.buf, d);
  if (memcmp(b.buf, v[2].buf, RC2_BLKSZ)) {
    ok = 0;
    printf("\nfail decryption:"
	   "\n\tkey	   = ");
    type_hex.dump(&v[0], stdout);
    printf("\n\tbraindamage= %u", bd);
    printf("\n\tciphertext = "); type_hex.dump(&v[3], stdout);
    printf("\n\texpected   = "); type_hex.dump(&v[2], stdout);
    printf("\n\tcalculated = "); type_hex.dump(&b, stdout);
    putchar('\n');
  }

  /* --- Return --- */

  return (ok);
}

static test_chunk defs[] = {
  { "rc2", verify, { &type_hex, &type_int, &type_hex, &type_hex, 0 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  test_run(argc, argv, defs, SRCDIR"/t/rc2");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
