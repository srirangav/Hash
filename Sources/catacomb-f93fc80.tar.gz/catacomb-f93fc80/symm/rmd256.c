/* -*-c-*-
 *
 * The RIPEMD-256 message digest function
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "rmd256.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @rmd256_compress@ --- *
 *
 * Arguments:	@rmd256_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		RIPEMD-256 compression function.
 */

void rmd256_compress(rmd256_ctx *ctx, const void *sbuf)
{
  uint32 a, b, c, d;
  uint32 A, B, C, D;
  uint32 buf[16];

  /* --- Fetch the chaining variables --- */

  a = ctx->a;
  b = ctx->b;
  c = ctx->c;
  d = ctx->d;
  A = ctx->A;
  B = ctx->B;
  C = ctx->C;
  D = ctx->D;

  /* --- Fetch the buffer contents --- */

  {
    int i;
    const octet *p;

    for (i = 0, p = sbuf; i < 16; i++, p += 4)
      buf[i] = LOAD32_L(p);
  }

  /* --- Definitions for round functions --- */

#define F(x, y, z) ((x) ^ (y) ^ (z))
#define G(x, y, z) (((x) & (y)) | (~(x) & (z)))
#define H(x, y, z) (((x) | ~(y)) ^ (z))
#define I(x, y, z) (((x) & (z)) | ((y) & ~(z)))

#define T(w, x, y, z, i, r, f, k) do {					\
  uint32 _t = w + f(x, y, z) + buf[i] + k;				\
  w = ROL32(_t, r);							\
} while (0)

#define F1(w, x, y, z, i, r) T(w, x, y, z, i, r, F, 0x00000000)
#define G1(w, x, y, z, i, r) T(w, x, y, z, i, r, G, 0x5a827999)
#define H1(w, x, y, z, i, r) T(w, x, y, z, i, r, H, 0x6ed9eba1)
#define I1(w, x, y, z, i, r) T(w, x, y, z, i, r, I, 0x8f1bbcdc)

#define F2(w, x, y, z, i, r) T(w, x, y, z, i, r, I, 0x50a28be6)
#define G2(w, x, y, z, i, r) T(w, x, y, z, i, r, H, 0x5c4dd124)
#define H2(w, x, y, z, i, r) T(w, x, y, z, i, r, G, 0x6d703ef3)
#define I2(w, x, y, z, i, r) T(w, x, y, z, i, r, F, 0x00000000)

  /* --- We must do both sides together --- */

  F1(a, b, c, d,  0, 11);
  F1(d, a, b, c,  1, 14);
  F1(c, d, a, b,  2, 15);
  F1(b, c, d, a,  3, 12);
  F1(a, b, c, d,  4,  5);
  F1(d, a, b, c,  5,  8);
  F1(c, d, a, b,  6,  7);
  F1(b, c, d, a,  7,  9);
  F1(a, b, c, d,  8, 11);
  F1(d, a, b, c,  9, 13);
  F1(c, d, a, b, 10, 14);
  F1(b, c, d, a, 11, 15);
  F1(a, b, c, d, 12,  6);
  F1(d, a, b, c, 13,  7);
  F1(c, d, a, b, 14,  9);
  F1(b, c, d, a, 15,  8);

  F2(A, B, C, D,  5,  8);
  F2(D, A, B, C, 14,  9);
  F2(C, D, A, B,  7,  9);
  F2(B, C, D, A,  0, 11);
  F2(A, B, C, D,  9, 13);
  F2(D, A, B, C,  2, 15);
  F2(C, D, A, B, 11, 15);
  F2(B, C, D, A,  4,  5);
  F2(A, B, C, D, 13,  7);
  F2(D, A, B, C,  6,  7);
  F2(C, D, A, B, 15,  8);
  F2(B, C, D, A,  8, 11);
  F2(A, B, C, D,  1, 14);
  F2(D, A, B, C, 10, 14);
  F2(C, D, A, B,  3, 12);
  F2(B, C, D, A, 12,  6);

  G1(A, b, c, d,  7,  7);
  G1(d, A, b, c,  4,  6);
  G1(c, d, A, b, 13,  8);
  G1(b, c, d, A,  1, 13);
  G1(A, b, c, d, 10, 11);
  G1(d, A, b, c,  6,  9);
  G1(c, d, A, b, 15,  7);
  G1(b, c, d, A,  3, 15);
  G1(A, b, c, d, 12,  7);
  G1(d, A, b, c,  0, 12);
  G1(c, d, A, b,  9, 15);
  G1(b, c, d, A,  5,  9);
  G1(A, b, c, d,  2, 11);
  G1(d, A, b, c, 14,  7);
  G1(c, d, A, b, 11, 13);
  G1(b, c, d, A,  8, 12);

  G2(a, B, C, D,  6,  9);
  G2(D, a, B, C, 11, 13);
  G2(C, D, a, B,  3, 15);
  G2(B, C, D, a,  7,  7);
  G2(a, B, C, D,  0, 12);
  G2(D, a, B, C, 13,  8);
  G2(C, D, a, B,  5,  9);
  G2(B, C, D, a, 10, 11);
  G2(a, B, C, D, 14,  7);
  G2(D, a, B, C, 15,  7);
  G2(C, D, a, B,  8, 12);
  G2(B, C, D, a, 12,  7);
  G2(a, B, C, D,  4,  6);
  G2(D, a, B, C,  9, 15);
  G2(C, D, a, B,  1, 13);
  G2(B, C, D, a,  2, 11);

  H1(A, B, c, d,  3, 11);
  H1(d, A, B, c, 10, 13);
  H1(c, d, A, B, 14,  6);
  H1(B, c, d, A,  4,  7);
  H1(A, B, c, d,  9, 14);
  H1(d, A, B, c, 15,  9);
  H1(c, d, A, B,  8, 13);
  H1(B, c, d, A,  1, 15);
  H1(A, B, c, d,  2, 14);
  H1(d, A, B, c,  7,  8);
  H1(c, d, A, B,  0, 13);
  H1(B, c, d, A,  6,  6);
  H1(A, B, c, d, 13,  5);
  H1(d, A, B, c, 11, 12);
  H1(c, d, A, B,  5,  7);
  H1(B, c, d, A, 12,  5);

  H2(a, b, C, D, 15,  9);
  H2(D, a, b, C,  5,  7);
  H2(C, D, a, b,  1, 15);
  H2(b, C, D, a,  3, 11);
  H2(a, b, C, D,  7,  8);
  H2(D, a, b, C, 14,  6);
  H2(C, D, a, b,  6,  6);
  H2(b, C, D, a,  9, 14);
  H2(a, b, C, D, 11, 12);
  H2(D, a, b, C,  8, 13);
  H2(C, D, a, b, 12,  5);
  H2(b, C, D, a,  2, 14);
  H2(a, b, C, D, 10, 13);
  H2(D, a, b, C,  0, 13);
  H2(C, D, a, b,  4,  7);
  H2(b, C, D, a, 13,  5);

  I1(A, B, C, d,  1, 11);
  I1(d, A, B, C,  9, 12);
  I1(C, d, A, B, 11, 14);
  I1(B, C, d, A, 10, 15);
  I1(A, B, C, d,  0, 14);
  I1(d, A, B, C,  8, 15);
  I1(C, d, A, B, 12,  9);
  I1(B, C, d, A,  4,  8);
  I1(A, B, C, d, 13,  9);
  I1(d, A, B, C,  3, 14);
  I1(C, d, A, B,  7,  5);
  I1(B, C, d, A, 15,  6);
  I1(A, B, C, d, 14,  8);
  I1(d, A, B, C,  5,  6);
  I1(C, d, A, B,  6,  5);
  I1(B, C, d, A,  2, 12);

  I2(a, b, c, D,  8, 15);
  I2(D, a, b, c,  6,  5);
  I2(c, D, a, b,  4,  8);
  I2(b, c, D, a,  1, 11);
  I2(a, b, c, D,  3, 14);
  I2(D, a, b, c, 11, 14);
  I2(c, D, a, b, 15,  6);
  I2(b, c, D, a,  0, 14);
  I2(a, b, c, D,  5,  6);
  I2(D, a, b, c, 12,  9);
  I2(c, D, a, b,  2, 12);
  I2(b, c, D, a, 13,  9);
  I2(a, b, c, D,  9, 12);
  I2(D, a, b, c,  7,  5);
  I2(c, D, a, b, 10, 15);
  I2(b, c, D, a, 14,  8);

  /* --- Recombine the two halves --- */

  ctx->a += A;
  ctx->b += B;
  ctx->c += C;
  ctx->d += D;
  ctx->A += a;
  ctx->B += b;
  ctx->C += c;
  ctx->D += d;
}

/* --- @rmd256_init@ --- *
 *
 * Arguments:	@rmd256_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void rmd256_init(rmd256_ctx *ctx)
{
  ctx->a = 0x67452301;
  ctx->b = 0xefcdab89;
  ctx->c = 0x98badcfe;
  ctx->d = 0x10325476;
  ctx->A = 0x76543210;
  ctx->B = 0xfedcba98;
  ctx->C = 0x89abcdef;
  ctx->D = 0x01234567;
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

/* --- @rmd256_set@ --- *
 *
 * Arguments:	@rmd256_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void rmd256_set(rmd256_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  ctx->a = LOAD32_L(p +	 0);
  ctx->b = LOAD32_L(p +	 4);
  ctx->c = LOAD32_L(p +	 8);
  ctx->d = LOAD32_L(p + 12);
  ctx->A = LOAD32_L(p + 16);
  ctx->B = LOAD32_L(p + 20);
  ctx->C = LOAD32_L(p + 24);
  ctx->D = LOAD32_L(p + 28);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @rmd256_hash@ --- *
 *
 * Arguments:	@rmd256_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void rmd256_hash(rmd256_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(RMD256, rmd256, ctx, buf, sz);
}

/* --- @rmd256_done@ --- *
 *
 * Arguments:	@rmd256_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

void rmd256_done(rmd256_ctx *ctx, void *hash)
{
  octet *p = hash;
  HASH_MD5STRENGTH(RMD256, rmd256, ctx);
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
  STORE32_L(p + 16, ctx->A);
  STORE32_L(p + 20, ctx->B);
  STORE32_L(p + 24, ctx->C);
  STORE32_L(p + 28, ctx->D);
}

/* --- @rmd256_state@ --- *
 *
 * Arguments:	@rmd256_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @rmd256_set@.
 */

unsigned long rmd256_state(rmd256_ctx *ctx, void *state)
{
  octet *p = state;
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
  STORE32_L(p + 16, ctx->A);
  STORE32_L(p + 20, ctx->B);
  STORE32_L(p + 24, ctx->C);
  STORE32_L(p + 28, ctx->D);
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(RMD256, rmd256)

/* --- Test code --- */

HASH_TEST(RMD256, rmd256)

/*----- That's all, folks -------------------------------------------------*/
