/* -*-c-*-
 *
 * Output feedback for block ciphers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_OFB_H
#define CATACOMB_OFB_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Macros ------------------------------------------------------------*/

/* --- @OFB_DECL@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for block cipher definitions
 *
 * Use:		Makes declarations for output feedback mode.
 */

#define OFB_DECL(PRE, pre)						\
									\
/* --- Output feedback context --- */					\
									\
typedef struct pre##_ofbctx {						\
  pre##_ctx ctx;			/* Underlying cipher context */	\
  unsigned off;				/* Current offset in buffer */	\
  octet iv[PRE##_BLKSZ];		/* Output buffer and IV */	\
} pre##_ofbctx;								\
									\
/* --- @pre_ofbgetiv@ --- *						\
 *									\
 * Arguments:	@const pre_ofbctx *ctx@ = pointer to OFB context block	\
 *		@void *iv@ = pointer to output data block		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Reads the currently set IV.  Reading and setting an IV	\
 *		is not transparent to the cipher.  It will add a `step'	\
 *		which must be matched by a similar operation during	\
 *		decryption.						\
 */									\
									\
extern void pre##_ofbgetiv(const pre##_ofbctx */*ctx*/,			\
			   void */*iv*/);				\
									\
/* --- @pre_ofbsetiv@ --- *						\
 *									\
 * Arguments:	@pre_ofbctx *ctx@ = pointer to OFB context block	\
 *		@cnost void *iv@ = pointer to IV to set			\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the IV to use for subsequent encryption.		\
 */									\
									\
extern void pre##_ofbsetiv(pre##_ofbctx */*ctx*/,			\
			   const void */*iv*/);				\
									\
/* --- @pre_ofbbdry@ --- *						\
 *									\
 * Arguments:	@pre_ofbctx *ctx@ = pointer to OFB context block	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Inserts a boundary during encryption.  Successful	\
 *		decryption must place a similar boundary.		\
 */									\
									\
extern void pre##_ofbbdry(pre##_ofbctx */*ctx*/);			\
									\
/* --- @pre_ofbsetkey@ --- *						\
 *									\
 * Arguments:	@pre_ofbctx *ctx@ = pointer to OFB context block	\
 *		@const pre_ctx *k@ = pointer to cipher context		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the OFB context to use a different cipher key.	\
 */									\
									\
extern void pre##_ofbsetkey(pre##_ofbctx */*ctx*/,			\
			    const pre##_ctx */*k*/);			\
									\
/* --- @pre_ofbinit@ --- *						\
 *									\
 * Arguments:	@pre_ofbctx *ctx@ = pointer to cipher context		\
 *		@const void *key@ = pointer to the key buffer		\
 *		@size_t sz@ = size of the key				\
 *		@const void *iv@ = pointer to initialization vector	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes a OFB context ready for use.  You should	\
 *		ensure that the IV chosen is unique: reusing an IV will	\
 *		compromise the security of the entire plaintext.  This	\
 *		is equivalent to calls to @pre_init@, @pre_ofbsetkey@	\
 *		and @pre_ofbsetiv@.					\
 */									\
									\
extern void pre##_ofbinit(pre##_ofbctx */*ctx*/,			\
			  const void */*key*/, size_t /*sz*/,		\
			  const void */*iv*/);				\
									\
/* --- @pre_ofbencrypt@ --- *						\
 *									\
 * Arguments:	@pre_ofbctx *ctx@ = pointer to OFB context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Encrypts or decrypts a block with a block cipher in OFB	\
 *		mode: encryption and decryption are the same in OFB.	\
 *		The destination may be null to just churn the feedback	\
 *		round for a bit.  The source may be null to use the	\
 *		cipher as a random data generator.			\
 */									\
									\
extern void pre##_ofbencrypt(pre##_ofbctx */*ctx*/,			\
			     const void */*src*/, void */*dest*/,	\
			     size_t /*sz*/);				\
									\
/* --- @pre_ofbrand@ --- *						\
 *									\
 * Arguments:	@const void *k@ = pointer to key material		\
 *		@size_t sz@ = size of key material			\
 *									\
 * Returns:	Pointer to generic random number generator interface.	\
 *									\
 * Use:		Creates a random number interface wrapper around an	\
 *		OFB-mode block cipher.					\
 */									\
									\
extern grand *pre##_ofbrand(const void */*k*/, size_t /*sz*/);		\
									\
/* --- Generic cipher interface --- */					\
									\
extern const gccipher pre##_ofb;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
