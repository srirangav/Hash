/* -*-c-*-
 *
 * Common features for DES implementation
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_DES_BASE_H
#define CATACOMB_DES_BASE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

/*----- External data -----------------------------------------------------*/

extern const uint32 des_sp[8][64];

/*----- Macros ------------------------------------------------------------*/

/* --- @DES_ROUND@ --- *
 *
 * This is the basic DES round function.  The inputs are the two subkey
 * halves, and the left and right block halves.  Note that the block halves
 * are rotated left one place at this point.  This wraps what's meant to be
 * the top bit around to the bottom, so I get a clear run at the S-boxes.
 */

#define DES_ROUND(ka, kb, x, y) do {					\
  uint32 _t = (y) ^ (ka);						\
  (x) ^= des_sp[7][(_t >>  0) & 0x3f] ^					\
	 des_sp[5][(_t >>  8) & 0x3f] ^					\
	 des_sp[3][(_t >> 16) & 0x3f] ^					\
	 des_sp[1][(_t >> 24) & 0x3f];					\
  _t = ROR32((y), 4) ^ (kb);						\
  (x) ^= des_sp[6][(_t >>  0) & 0x3f] ^					\
	 des_sp[4][(_t >>  8) & 0x3f] ^					\
	 des_sp[2][(_t >> 16) & 0x3f] ^					\
	 des_sp[0][(_t >> 24) & 0x3f];					\
} while (0)

/* --- @DES_IP@, @DES_IPINV@ --- *
 *
 * The cryptographically useless initial and final permutations.  The initial
 * permutation also rotates the two block halves left by one place.  This is
 * undone by the inverse permutation at the end.
 */

#define DES_IP(x, y) do {						\
  uint32 _t;								\
  _t = (y ^ (x >> 4)) & 0x0f0f0f0f; y ^= _t; x ^= _t << 4;		\
  _t = (x ^ (x >> 18)) & 0x00003333; x ^= _t; x ^= _t << 18;		\
  _t = (y ^ (y >> 18)) & 0x00003333; y ^= _t; y ^= _t << 18;		\
  _t = (x ^ (x >> 9)) & 0x00550055; x ^= _t; x ^= _t << 9;		\
  _t = (y ^ (y >> 9)) & 0x00550055; y ^= _t; y ^= _t << 9;		\
  _t = (x ^ (x >> 24)) & 0x000000ff; x ^= _t; x ^= _t << 24;		\
  _t = (y ^ (y >> 24)) & 0x000000ff; y ^= _t; y ^= _t << 24;		\
  _t = (y ^ (x >> 16)) & 0x0000ffff; y ^= _t; x ^= _t << 16;		\
  x = ROL32(x, 1); y = ROL32(y, 1);					\
} while (0)

#define DES_IPINV(x, y) do {						\
  uint32 _t;								\
  x = ROR32(x, 1); y = ROR32(y, 1);					\
  _t = (y ^ (x >> 16)) & 0x0000ffff; y ^= _t; x ^= _t << 16;		\
  _t = (x ^ (x >> 24)) & 0x000000ff; x ^= _t; x ^= _t << 24;		\
  _t = (y ^ (y >> 24)) & 0x000000ff; y ^= _t; y ^= _t << 24;		\
  _t = (y ^ (x >> 4)) & 0x0f0f0f0f; y ^= _t; x ^= _t << 4;		\
  _t = (x ^ (x >> 18)) & 0x00003333; x ^= _t; x ^= _t << 18;		\
  _t = (y ^ (y >> 18)) & 0x00003333; y ^= _t; y ^= _t << 18;		\
  _t = (x ^ (x >> 9)) & 0x00550055; x ^= _t; x ^= _t << 9;		\
  _t = (y ^ (y >> 9)) & 0x00550055; y ^= _t; y ^= _t << 9;		\
} while (0)

/* --- @DES_EBLK@, @DES_DBLK@ --- *
 *
 * Whole block encryption and decryption.
 */

#define DES_EBLK(k, a, b, c, d) do {					\
  const uint32 *_k = (k);						\
  uint32 _x = (a), _y = (b);						\
  DES_ROUND(_k[0], _k[1], _x, _y); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _y, _x); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _x, _y); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _y, _x); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _x, _y); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _y, _x); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _x, _y); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _y, _x); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _x, _y); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _y, _x); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _x, _y); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _y, _x); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _x, _y); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _y, _x); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _x, _y); _k += 2;				\
  DES_ROUND(_k[0], _k[1], _y, _x); _k += 2;				\
  (c) = _y;								\
  (d) = _x;								\
} while (0)

#define DES_DBLK(k, a, b, c, d) do {					\
  const uint32 *_k = (k) + 32;						\
  uint32 _x = (a), _y = (b);						\
  _k -= 2; DES_ROUND(_k[0], _k[1], _x, _y);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _y, _x);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _x, _y);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _y, _x);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _x, _y);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _y, _x);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _x, _y);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _y, _x);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _x, _y);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _y, _x);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _x, _y);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _y, _x);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _x, _y);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _y, _x);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _x, _y);				\
  _k -= 2; DES_ROUND(_k[0], _k[1], _y, _x);				\
  (c) = _y;								\
  (d) = _x;								\
} while (0)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
