/* -*-c-*-
 *
 * The DESX algorithm
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on DESX -----------------------------------------------------*
 *
 * DESX was designed by Ron Rivest in 1986 as a simple and cheap way to
 * strengthen DES against exhaustive search.  It also increases the
 * difficulty of differential and linear attacks.
 */

#ifndef CATACOMB_DESX_H
#define CATACOMB_DESX_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

#ifndef CATACOMB_DES_H
#  include "des.h"
#endif

/*----- Magical numbers ---------------------------------------------------*/

#define DESX_BLKSZ 8
#define DESX_KEYSZ 23
#define DESX_CLASS (N, B, 64)

extern const octet desx_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct desx_ctx {
  des_ctx k;
  uint32 prea, preb;
  uint32 posta, postb;
} desx_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @desx_init@ --- *
 *
 * Arguments:	@desx_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a DESX key buffer.  The key buffer contains, in
 *		order, an optional 8-byte pre-whitening key, a single-DES key
 *		(either 7 or 8 bytes), and an optional 8-byte port-whitening
 *		key.  If no whitening keys are specified, the algorithm
 *		becomes the same as single-DES.
 */

extern void desx_init(desx_ctx */*k*/, const void */*buf*/, size_t /*sz*/);

/* --- @desx_eblk@, @desx_dblk@ --- *
 *
 * Arguments:	@const desx_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void desx_eblk(const desx_ctx */*k*/,
		      const uint32 */*s*/, uint32 */*d*/);
extern void desx_dblk(const desx_ctx */*k*/,
		      const uint32 */*s*/, uint32 */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
