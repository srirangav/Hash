/* -*-c-*-
 *
 * Implementation of the IDEA cipher
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the IDEA block cipher ------------------------------------*
 *
 * IDEA was invented by James Massey and Xuejia Lai.  The fundamental idea
 * underlying the cipher is combining incompatible group operations.  The
 * algorithm's main claim to fame is that it is the symmetric cipher in PGP
 * version 2.
 *
 * The IDEA algorithm is allegedly patented by Ascom Tech A.G., even in the
 * UK and Europe.  Ascom are willing to grant licences for use in software
 * which forbids commercial use, but this is not compatible with Free
 * Software Foundation ideology.  The author recommends against the use of
 * the IDEA cipher entirely.  Blowfish is conceptually simpler, appears more
 * concervative, offers a larger keyspace, runs faster, and is in the public
 * domain.
 */

#ifndef CATACOMB_IDEA_H
#define CATACOMB_IDEA_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define IDEA_BLKSZ 8
#define IDEA_KEYSZ 16
#define IDEA_CLASS (N, B, 64)

extern const octet idea_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct idea_ctx {
  uint16 e[52];
  uint16 d[52];
} idea_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @idea_init@ --- *
 *
 * Arguments:	@idea_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes an IDEA key buffer.  The buffer must be exactly
 *		16 bytes in size, because IDEA is only defined with a key
 *		size of 128 bits.
 */

extern void idea_init(idea_ctx */*k*/, const void */*buf*/, size_t /*sz*/);

/* --- @idea_eblk@, @idea_dblk@ --- *
 *
 * Arguments:	@const idea_ctx *k@ = pointer to a key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void idea_eblk(const idea_ctx */*k*/,
		      const uint32 */*s*/, uint32 */*d*/);
extern void idea_dblk(const idea_ctx */*k*/,
		      const uint32 */*s*/, uint32 */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
