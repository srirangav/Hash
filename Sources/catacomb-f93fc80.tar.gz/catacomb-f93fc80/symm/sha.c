/* -*-c-*-
 *
 * Implementation of the SHA-1 hash function
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "sha.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @sha_compress@ --- *
 *
 * Arguments:	@sha_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		SHA-1 compression function.
 */

void sha_compress(sha_ctx *ctx, const void *sbuf)
{
  uint32 a, b, c, d, e;
  uint32 buf[80];

  /* --- Fetch the chaining variables --- */

  a = ctx->a;
  b = ctx->b;
  c = ctx->c;
  d = ctx->d;
  e = ctx->e;

  /* --- Fetch and expand the buffer contents --- */

  {
    int i;
    const octet *p;

    for (i = 0, p = sbuf; i < 16; i++, p += 4)
      buf[i] = LOAD32(p);
    for (i = 16; i < 80; i++) {
      uint32 x = buf[i - 3] ^ buf[i - 8] ^ buf[i - 14] ^ buf[i - 16];
      buf[i] = ROL32(x, 1);
    }
  }

  /* --- Definitions for round functions --- */

#define F(x, y, z) (((x) & (y)) | (~(x) & (z)))
#define G(x, y, z) ((x) ^ (y) ^ (z))
#define H(x, y, z) (((x) & (y)) | ((x) & (z)) | ((y) & (z)))

#define T(v, w, x, y, z, i, f, k) do {					\
  z = ROL32(v, 5) + f(w, x, y) + z + buf[i] + k;			\
  w = ROR32(w, 2);							\
} while (0)

#define FF(v, w, x, y, z, i) T(v, w, x, y, z, i, F, 0x5a827999)
#define GG(v, w, x, y, z, i) T(v, w, x, y, z, i, G, 0x6ed9eba1)
#define HH(v, w, x, y, z, i) T(v, w, x, y, z, i, H, 0x8f1bbcdc)
#define II(v, w, x, y, z, i) T(v, w, x, y, z, i, G, 0xca62c1d6)

  /* --- The main compression function --- */

  FF(a, b, c, d, e,  0);
  FF(e, a, b, c, d,  1);
  FF(d, e, a, b, c,  2);
  FF(c, d, e, a, b,  3);
  FF(b, c, d, e, a,  4);
  FF(a, b, c, d, e,  5);
  FF(e, a, b, c, d,  6);
  FF(d, e, a, b, c,  7);
  FF(c, d, e, a, b,  8);
  FF(b, c, d, e, a,  9);
  FF(a, b, c, d, e, 10);
  FF(e, a, b, c, d, 11);
  FF(d, e, a, b, c, 12);
  FF(c, d, e, a, b, 13);
  FF(b, c, d, e, a, 14);
  FF(a, b, c, d, e, 15);
  FF(e, a, b, c, d, 16);
  FF(d, e, a, b, c, 17);
  FF(c, d, e, a, b, 18);
  FF(b, c, d, e, a, 19);

  GG(a, b, c, d, e, 20);
  GG(e, a, b, c, d, 21);
  GG(d, e, a, b, c, 22);
  GG(c, d, e, a, b, 23);
  GG(b, c, d, e, a, 24);
  GG(a, b, c, d, e, 25);
  GG(e, a, b, c, d, 26);
  GG(d, e, a, b, c, 27);
  GG(c, d, e, a, b, 28);
  GG(b, c, d, e, a, 29);
  GG(a, b, c, d, e, 30);
  GG(e, a, b, c, d, 31);
  GG(d, e, a, b, c, 32);
  GG(c, d, e, a, b, 33);
  GG(b, c, d, e, a, 34);
  GG(a, b, c, d, e, 35);
  GG(e, a, b, c, d, 36);
  GG(d, e, a, b, c, 37);
  GG(c, d, e, a, b, 38);
  GG(b, c, d, e, a, 39);

  HH(a, b, c, d, e, 40);
  HH(e, a, b, c, d, 41);
  HH(d, e, a, b, c, 42);
  HH(c, d, e, a, b, 43);
  HH(b, c, d, e, a, 44);
  HH(a, b, c, d, e, 45);
  HH(e, a, b, c, d, 46);
  HH(d, e, a, b, c, 47);
  HH(c, d, e, a, b, 48);
  HH(b, c, d, e, a, 49);
  HH(a, b, c, d, e, 50);
  HH(e, a, b, c, d, 51);
  HH(d, e, a, b, c, 52);
  HH(c, d, e, a, b, 53);
  HH(b, c, d, e, a, 54);
  HH(a, b, c, d, e, 55);
  HH(e, a, b, c, d, 56);
  HH(d, e, a, b, c, 57);
  HH(c, d, e, a, b, 58);
  HH(b, c, d, e, a, 59);

  II(a, b, c, d, e, 60);
  II(e, a, b, c, d, 61);
  II(d, e, a, b, c, 62);
  II(c, d, e, a, b, 63);
  II(b, c, d, e, a, 64);
  II(a, b, c, d, e, 65);
  II(e, a, b, c, d, 66);
  II(d, e, a, b, c, 67);
  II(c, d, e, a, b, 68);
  II(b, c, d, e, a, 69);
  II(a, b, c, d, e, 70);
  II(e, a, b, c, d, 71);
  II(d, e, a, b, c, 72);
  II(c, d, e, a, b, 73);
  II(b, c, d, e, a, 74);
  II(a, b, c, d, e, 75);
  II(e, a, b, c, d, 76);
  II(d, e, a, b, c, 77);
  II(c, d, e, a, b, 78);
  II(b, c, d, e, a, 79);

  /* --- Update the chaining variables --- */

  ctx->a += a;
  ctx->b += b;
  ctx->c += c;
  ctx->d += d;
  ctx->e += e;
}

/* --- @sha_init@ --- *
 *
 * Arguments:	@sha_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void sha_init(sha_ctx *ctx)
{
  ctx->a = 0x67452301;
  ctx->b = 0xefcdab89;
  ctx->c = 0x98badcfe;
  ctx->d = 0x10325476;
  ctx->e = 0xc3d2e1f0;
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

/* --- @sha_set@ --- *
 *
 * Arguments:	@sha_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void sha_set(sha_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  ctx->a = LOAD32(p +  0);
  ctx->b = LOAD32(p +  4);
  ctx->c = LOAD32(p +  8);
  ctx->d = LOAD32(p + 12);
  ctx->e = LOAD32(p + 16);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @sha_hash@ --- *
 *
 * Arguments:	@sha_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void sha_hash(sha_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(SHA, sha, ctx, buf, sz);
}

/* --- @sha_done@ --- *
 *
 * Arguments:	@sha_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

void sha_done(sha_ctx *ctx, void *hash)
{
  octet *p = hash;
  HASH_PAD(SHA, sha, ctx, 0x80, 0, 8);
  STORE32(ctx->buf + SHA_BUFSZ - 8, (ctx->nl >> 29) | (ctx->nh << 3));
  STORE32(ctx->buf + SHA_BUFSZ - 4, ctx->nl << 3);
  sha_compress(ctx, ctx->buf);
  STORE32(p +  0, ctx->a);
  STORE32(p +  4, ctx->b);
  STORE32(p +  8, ctx->c);
  STORE32(p + 12, ctx->d);
  STORE32(p + 16, ctx->e);
}

/* --- @sha_state@ --- *
 *
 * Arguments:	@sha_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @sha_set@.
 */

unsigned long sha_state(sha_ctx *ctx, void *state)
{
  octet *p = state;
  STORE32(p +  0, ctx->a);
  STORE32(p +  4, ctx->b);
  STORE32(p +  8, ctx->c);
  STORE32(p + 12, ctx->d);
  STORE32(p + 16, ctx->e);
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(SHA, sha)

/* --- Test code --- */

HASH_TEST(SHA, sha)

/*----- That's all, folks -------------------------------------------------*/
