/* -*-c-*-
 *
 * Implementation of the SHA-256 hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "sha256.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @sha256_compress@, @sha224_compress@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		SHA-256 compression function.
 */

void sha256_compress(sha256_ctx *ctx, const void *sbuf)
{
  uint32 a, b, c, d, e, f, g, h;
  uint32 buf[64];

  /* --- Fetch the chaining variables --- */

  a = ctx->a;
  b = ctx->b;
  c = ctx->c;
  d = ctx->d;
  e = ctx->e;
  f = ctx->f;
  g = ctx->g;
  h = ctx->h;

  /* --- Definitions for round functions --- */

#define CH(x, y, z) (((x) & (y)) | (~(x) & (z)))
#define MAJ(x, y, z) (((x) & (y)) | ((x) & (z)) | ((y) & (z)))

#define S0(x) (ROR32((x),  2) ^ ROR32((x), 13) ^ ROR32((x), 22))
#define S1(x) (ROR32((x),  6) ^ ROR32((x), 11) ^ ROR32((x), 25))
#define s0(x) (ROR32((x),  7) ^ ROR32((x), 18) ^ LSR32((x),  3))
#define s1(x) (ROR32((x), 17) ^ ROR32((x), 19) ^ LSR32((x), 10))

#define T(a, b, c, d, e, f, g, h, i, k) do {				\
  uint32 t1 = h + S1(e) + CH(e, f, g) + k + buf[i];			\
  uint32 t2 = S0(a) + MAJ(a, b, c);					\
  d += t1; h = t1 + t2;							\
} while (0)

  /* --- Fetch and expand the buffer contents --- */

  {
    int i;
    const octet *p;

    for (i = 0, p = sbuf; i < 16; i++, p += 4)
      buf[i] = LOAD32(p);
    for (i = 16; i < 64; i++)
      buf[i] = s1(buf[i - 2]) + buf[i - 7] + s0(buf[i - 15]) + buf[i - 16];
  }

  /* --- The main compression function --- */

  T(a, b, c, d, e, f, g, h,  0, 0x428a2f98);
  T(h, a, b, c, d, e, f, g,  1, 0x71374491);
  T(g, h, a, b, c, d, e, f,  2, 0xb5c0fbcf);
  T(f, g, h, a, b, c, d, e,  3, 0xe9b5dba5);
  T(e, f, g, h, a, b, c, d,  4, 0x3956c25b);
  T(d, e, f, g, h, a, b, c,  5, 0x59f111f1);
  T(c, d, e, f, g, h, a, b,  6, 0x923f82a4);
  T(b, c, d, e, f, g, h, a,  7, 0xab1c5ed5);
  T(a, b, c, d, e, f, g, h,  8, 0xd807aa98);
  T(h, a, b, c, d, e, f, g,  9, 0x12835b01);
  T(g, h, a, b, c, d, e, f, 10, 0x243185be);
  T(f, g, h, a, b, c, d, e, 11, 0x550c7dc3);
  T(e, f, g, h, a, b, c, d, 12, 0x72be5d74);
  T(d, e, f, g, h, a, b, c, 13, 0x80deb1fe);
  T(c, d, e, f, g, h, a, b, 14, 0x9bdc06a7);
  T(b, c, d, e, f, g, h, a, 15, 0xc19bf174);
  T(a, b, c, d, e, f, g, h, 16, 0xe49b69c1);
  T(h, a, b, c, d, e, f, g, 17, 0xefbe4786);
  T(g, h, a, b, c, d, e, f, 18, 0x0fc19dc6);
  T(f, g, h, a, b, c, d, e, 19, 0x240ca1cc);
  T(e, f, g, h, a, b, c, d, 20, 0x2de92c6f);
  T(d, e, f, g, h, a, b, c, 21, 0x4a7484aa);
  T(c, d, e, f, g, h, a, b, 22, 0x5cb0a9dc);
  T(b, c, d, e, f, g, h, a, 23, 0x76f988da);
  T(a, b, c, d, e, f, g, h, 24, 0x983e5152);
  T(h, a, b, c, d, e, f, g, 25, 0xa831c66d);
  T(g, h, a, b, c, d, e, f, 26, 0xb00327c8);
  T(f, g, h, a, b, c, d, e, 27, 0xbf597fc7);
  T(e, f, g, h, a, b, c, d, 28, 0xc6e00bf3);
  T(d, e, f, g, h, a, b, c, 29, 0xd5a79147);
  T(c, d, e, f, g, h, a, b, 30, 0x06ca6351);
  T(b, c, d, e, f, g, h, a, 31, 0x14292967);
  T(a, b, c, d, e, f, g, h, 32, 0x27b70a85);
  T(h, a, b, c, d, e, f, g, 33, 0x2e1b2138);
  T(g, h, a, b, c, d, e, f, 34, 0x4d2c6dfc);
  T(f, g, h, a, b, c, d, e, 35, 0x53380d13);
  T(e, f, g, h, a, b, c, d, 36, 0x650a7354);
  T(d, e, f, g, h, a, b, c, 37, 0x766a0abb);
  T(c, d, e, f, g, h, a, b, 38, 0x81c2c92e);
  T(b, c, d, e, f, g, h, a, 39, 0x92722c85);
  T(a, b, c, d, e, f, g, h, 40, 0xa2bfe8a1);
  T(h, a, b, c, d, e, f, g, 41, 0xa81a664b);
  T(g, h, a, b, c, d, e, f, 42, 0xc24b8b70);
  T(f, g, h, a, b, c, d, e, 43, 0xc76c51a3);
  T(e, f, g, h, a, b, c, d, 44, 0xd192e819);
  T(d, e, f, g, h, a, b, c, 45, 0xd6990624);
  T(c, d, e, f, g, h, a, b, 46, 0xf40e3585);
  T(b, c, d, e, f, g, h, a, 47, 0x106aa070);
  T(a, b, c, d, e, f, g, h, 48, 0x19a4c116);
  T(h, a, b, c, d, e, f, g, 49, 0x1e376c08);
  T(g, h, a, b, c, d, e, f, 50, 0x2748774c);
  T(f, g, h, a, b, c, d, e, 51, 0x34b0bcb5);
  T(e, f, g, h, a, b, c, d, 52, 0x391c0cb3);
  T(d, e, f, g, h, a, b, c, 53, 0x4ed8aa4a);
  T(c, d, e, f, g, h, a, b, 54, 0x5b9cca4f);
  T(b, c, d, e, f, g, h, a, 55, 0x682e6ff3);
  T(a, b, c, d, e, f, g, h, 56, 0x748f82ee);
  T(h, a, b, c, d, e, f, g, 57, 0x78a5636f);
  T(g, h, a, b, c, d, e, f, 58, 0x84c87814);
  T(f, g, h, a, b, c, d, e, 59, 0x8cc70208);
  T(e, f, g, h, a, b, c, d, 60, 0x90befffa);
  T(d, e, f, g, h, a, b, c, 61, 0xa4506ceb);
  T(c, d, e, f, g, h, a, b, 62, 0xbef9a3f7);
  T(b, c, d, e, f, g, h, a, 63, 0xc67178f2);

  /* --- Update the chaining variables --- */

  ctx->a += a;
  ctx->b += b;
  ctx->c += c;
  ctx->d += d;
  ctx->e += e;
  ctx->f += f;
  ctx->g += g;
  ctx->h += h;
}

/* --- @sha256_init@, @sha224_init@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void sha256_init(sha256_ctx *ctx)
{
  ctx->a = 0x6a09e667;
  ctx->b = 0xbb67ae85;
  ctx->c = 0x3c6ef372;
  ctx->d = 0xa54ff53a;
  ctx->e = 0x510e527f;
  ctx->f = 0x9b05688c;
  ctx->g = 0x1f83d9ab;
  ctx->h = 0x5be0cd19;
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

void sha224_init(sha256_ctx *ctx)
{
  ctx->a = 0xc1059ed8;
  ctx->b = 0x367cd507;
  ctx->c = 0x3070dd17;
  ctx->d = 0xf70e5939;
  ctx->e = 0xffc00b31;
  ctx->f = 0x68581511;
  ctx->g = 0x64f98fa7;
  ctx->h = 0xbefa4fa4;
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

/* --- @sha256_set@, @sha224_set@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void sha256_set(sha256_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  ctx->a = LOAD32(p +  0);
  ctx->b = LOAD32(p +  4);
  ctx->c = LOAD32(p +  8);
  ctx->d = LOAD32(p + 12);
  ctx->e = LOAD32(p + 16);
  ctx->f = LOAD32(p + 20);
  ctx->g = LOAD32(p + 24);
  ctx->h = LOAD32(p + 28);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @sha256_hash@, @sha224_hash@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void sha256_hash(sha256_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(SHA256, sha256, ctx, buf, sz);
}

/* --- @sha256_done, @sha224_done@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

static void final(sha256_ctx *ctx)
{
  HASH_PAD(SHA256, sha256, ctx, 0x80, 0, 8);
  STORE32(ctx->buf + SHA256_BUFSZ - 8, (ctx->nl >> 29) | (ctx->nh << 3));
  STORE32(ctx->buf + SHA256_BUFSZ - 4, ctx->nl << 3);
  sha256_compress(ctx, ctx->buf);
}

void sha256_done(sha256_ctx *ctx, void *hash)
{
  octet *p = hash;
  final(ctx);
  STORE32(p +  0, ctx->a);
  STORE32(p +  4, ctx->b);
  STORE32(p +  8, ctx->c);
  STORE32(p + 12, ctx->d);
  STORE32(p + 16, ctx->e);
  STORE32(p + 20, ctx->f);
  STORE32(p + 24, ctx->g);
  STORE32(p + 28, ctx->h);
}

void sha224_done(sha224_ctx *ctx, void *hash)
{
  octet *p = hash;
  final(ctx);
  STORE32(p +  0, ctx->a);
  STORE32(p +  4, ctx->b);
  STORE32(p +  8, ctx->c);
  STORE32(p + 12, ctx->d);
  STORE32(p + 16, ctx->e);
  STORE32(p + 20, ctx->f);
  STORE32(p + 24, ctx->g);
}

/* --- @sha256_state@, @sha224_state@ --- *
 *
 * Arguments:	@sha256_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @sha256_set@.
 */

unsigned long sha256_state(sha256_ctx *ctx, void *state)
{
  octet *p = state;
  STORE32(p +  0, ctx->a);
  STORE32(p +  4, ctx->b);
  STORE32(p +  8, ctx->c);
  STORE32(p + 12, ctx->d);
  STORE32(p + 16, ctx->e);
  STORE32(p + 20, ctx->f);
  STORE32(p + 24, ctx->g);
  STORE32(p + 28, ctx->h);
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(SHA256, sha256)

/* --- Test code --- */

HASH_TEST(SHA256, sha256)

/*----- That's all, folks -------------------------------------------------*/
