/* -*-c-*-
 *
 * Implementation of the SHA-512 hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "sha512.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @sha512_compress@, @sha384_compress@ --- *
 *
 * Arguments:	@sha512_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		SHA-512 compression function.
 */

void sha512_compress(sha512_ctx *ctx, const void *sbuf)
{
  kludge64 a, b, c, d, e, f, g, h;
  kludge64 buf[80];
  int i;

  static const kludge64 K[80] = {
    X64(428a2f98, d728ae22), X64(71374491, 23ef65cd),
    X64(b5c0fbcf, ec4d3b2f), X64(e9b5dba5, 8189dbbc),
    X64(3956c25b, f348b538), X64(59f111f1, b605d019),
    X64(923f82a4, af194f9b), X64(ab1c5ed5, da6d8118),
    X64(d807aa98, a3030242), X64(12835b01, 45706fbe),
    X64(243185be, 4ee4b28c), X64(550c7dc3, d5ffb4e2),
    X64(72be5d74, f27b896f), X64(80deb1fe, 3b1696b1),
    X64(9bdc06a7, 25c71235), X64(c19bf174, cf692694),
    X64(e49b69c1, 9ef14ad2), X64(efbe4786, 384f25e3),
    X64(0fc19dc6, 8b8cd5b5), X64(240ca1cc, 77ac9c65),
    X64(2de92c6f, 592b0275), X64(4a7484aa, 6ea6e483),
    X64(5cb0a9dc, bd41fbd4), X64(76f988da, 831153b5),
    X64(983e5152, ee66dfab), X64(a831c66d, 2db43210),
    X64(b00327c8, 98fb213f), X64(bf597fc7, beef0ee4),
    X64(c6e00bf3, 3da88fc2), X64(d5a79147, 930aa725),
    X64(06ca6351, e003826f), X64(14292967, 0a0e6e70),
    X64(27b70a85, 46d22ffc), X64(2e1b2138, 5c26c926),
    X64(4d2c6dfc, 5ac42aed), X64(53380d13, 9d95b3df),
    X64(650a7354, 8baf63de), X64(766a0abb, 3c77b2a8),
    X64(81c2c92e, 47edaee6), X64(92722c85, 1482353b),
    X64(a2bfe8a1, 4cf10364), X64(a81a664b, bc423001),
    X64(c24b8b70, d0f89791), X64(c76c51a3, 0654be30),
    X64(d192e819, d6ef5218), X64(d6990624, 5565a910),
    X64(f40e3585, 5771202a), X64(106aa070, 32bbd1b8),
    X64(19a4c116, b8d2d0c8), X64(1e376c08, 5141ab53),
    X64(2748774c, df8eeb99), X64(34b0bcb5, e19b48a8),
    X64(391c0cb3, c5c95a63), X64(4ed8aa4a, e3418acb),
    X64(5b9cca4f, 7763e373), X64(682e6ff3, d6b2b8a3),
    X64(748f82ee, 5defb2fc), X64(78a5636f, 43172f60),
    X64(84c87814, a1f0ab72), X64(8cc70208, 1a6439ec),
    X64(90befffa, 23631e28), X64(a4506ceb, de82bde9),
    X64(bef9a3f7, b2c67915), X64(c67178f2, e372532b),
    X64(ca273ece, ea26619c), X64(d186b8c7, 21c0c207),
    X64(eada7dd6, cde0eb1e), X64(f57d4f7f, ee6ed178),
    X64(06f067aa, 72176fba), X64(0a637dc5, a2c898a6),
    X64(113f9804, bef90dae), X64(1b710b35, 131c471b),
    X64(28db77f5, 23047d84), X64(32caab7b, 40c72493),
    X64(3c9ebe0a, 15c9bebc), X64(431d67c4, 9c100d4c),
    X64(4cc5d4be, cb3e42b6), X64(597f299c, fc657e2a),
    X64(5fcb6fab, 3ad6faec), X64(6c44198c, 4a475817)
  };

  /* --- Fetch the chaining variables --- */

  a = ctx->a;
  b = ctx->b;
  c = ctx->c;
  d = ctx->d;
  e = ctx->e;
  f = ctx->f;
  g = ctx->g;
  h = ctx->h;

  /* --- Definitions for round functions --- */

#define CH(d, x, y, z) do {						\
  kludge64 _x; AND64((d), (x), (y)); CPL64(_x, (x));			\
  AND64(_x, _x, (z)); OR64((d), (d), _x);				\
} while (0)

#define MAJ(d, x, y, z) do {						\
  kludge64 _x; AND64((d), (x), (y)); AND64(_x, (x), (z));		\
  OR64((d), (d), _x); AND64(_x, (y), (z)); OR64((d), (d), _x);		\
} while (0)

#define SIGMA(d, x, i, j, k, last, what) do {				\
  kludge64 _x; ROR64_((d), (x), (i)); ROR64_(_x, (x), (j));		\
  XOR64((d), (d), _x); last##64_(_x, (x), (k)); XOR64((d), (d), _x);	\
} while (0)

#define S0(d, x) SIGMA(d, x, 28, 34, 39, ROR, S0);
#define S1(d, x) SIGMA(d, x, 14, 18, 41, ROR, S1);
#define s0(d, x) SIGMA(d, x,  1,  8,  7, LSR, s0);
#define s1(d, x) SIGMA(d, x, 19, 61,  6, LSR, s1);

#define T(a, b, c, d, e, f, g, h, i) do {				\
  kludge64 t1, t2, x;							\
  ADD64(t1, buf[i], K[i]); ADD64(t1, t1, h);				\
  S1(x, e); ADD64(t1, t1, x); CH(x, e, f, g); ADD64(t1, t1, x);		\
  S0(t2, a); MAJ(x, a, b, c); ADD64(t2, t2, x);				\
  ADD64(d, d, t1); ADD64(h, t1, t2);					\
} while (0)

  /* --- Fetch and expand the buffer contents --- */

  {
    const octet *p;

    for (i = 0, p = sbuf; i < 16; i++, p += 8)
      LOAD64_(buf[i], p);
    for (i = 16; i < 80; i++) {
      kludge64 x;
      buf[i] = buf[i - 7]; s1(x, buf[i - 2]); ADD64(buf[i], buf[i], x);
      s0(x, buf[i - 15]); ADD64(buf[i], buf[i], x);
      ADD64(buf[i], buf[i], buf[i - 16]);
    }
  }

  /* --- The main compression function --- */

  for (i = 0; i < 80; i += 8) {
    T(a, b, c, d, e, f, g, h, i + 0);
    T(h, a, b, c, d, e, f, g, i + 1);
    T(g, h, a, b, c, d, e, f, i + 2);
    T(f, g, h, a, b, c, d, e, i + 3);
    T(e, f, g, h, a, b, c, d, i + 4);
    T(d, e, f, g, h, a, b, c, i + 5);
    T(c, d, e, f, g, h, a, b, i + 6);
    T(b, c, d, e, f, g, h, a, i + 7);
  }

  /* --- Update the chaining variables --- */

  ADD64(ctx->a, ctx->a, a);
  ADD64(ctx->b, ctx->b, b);
  ADD64(ctx->c, ctx->c, c);
  ADD64(ctx->d, ctx->d, d);
  ADD64(ctx->e, ctx->e, e);
  ADD64(ctx->f, ctx->f, f);
  ADD64(ctx->g, ctx->g, g);
  ADD64(ctx->h, ctx->h, h);
}

/* --- @sha512_init@, @sha384_init@ --- *
 *
 * Arguments:	@sha512_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void sha512_init(sha512_ctx *ctx)
{
  SET64(ctx->a,	0x6a09e667, 0xf3bcc908);
  SET64(ctx->b,	0xbb67ae85, 0x84caa73b);
  SET64(ctx->c,	0x3c6ef372, 0xfe94f82b);
  SET64(ctx->d,	0xa54ff53a, 0x5f1d36f1);
  SET64(ctx->e,	0x510e527f, 0xade682d1);
  SET64(ctx->f,	0x9b05688c, 0x2b3e6c1f);
  SET64(ctx->g,	0x1f83d9ab, 0xfb41bd6b);
  SET64(ctx->h,	0x5be0cd19, 0x137e2179);
  ctx->off = 0;
  ctx->nh = ctx->nl = 0;
}

void sha384_init(sha512_ctx *ctx)
{
  SET64(ctx->a,	0xcbbb9d5d, 0xc1059ed8);
  SET64(ctx->b,	0x629a292a, 0x367cd507);
  SET64(ctx->c,	0x9159015a, 0x3070dd17);
  SET64(ctx->d,	0x152fecd8, 0xf70e5939);
  SET64(ctx->e,	0x67332667, 0xffc00b31);
  SET64(ctx->f,	0x8eb44a87, 0x68581511);
  SET64(ctx->g,	0xdb0c2e0d, 0x64f98fa7);
  SET64(ctx->h,	0x47b5481d, 0xbefa4fa4);
  ctx->off = 0;
  ctx->nh = ctx->nl = 0;
}

/* --- @sha512_set@, @sha384_set@ --- *
 *
 * Arguments:	@sha512_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void sha512_set(sha512_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  LOAD64_(ctx->a, p +  0);
  LOAD64_(ctx->b, p +  8);
  LOAD64_(ctx->c, p + 16);
  LOAD64_(ctx->d, p + 24);
  LOAD64_(ctx->e, p + 32);
  LOAD64_(ctx->f, p + 40);
  LOAD64_(ctx->g, p + 48);
  LOAD64_(ctx->h, p + 56);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @sha512_hash@, @sha384_hash@ --- *
 *
 * Arguments:	@sha512_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void sha512_hash(sha512_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(SHA512, sha512, ctx, buf, sz);
}

/* --- @sha512_done@, @sha384_done@ --- *
 *
 * Arguments:	@sha512_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

static void final(sha512_ctx *ctx)
{
  HASH_PAD(SHA512, sha512, ctx, 0x80, 0, 16);
  memset(ctx->buf + SHA512_BUFSZ - 16, 0, 8);
  STORE32(ctx->buf + SHA512_BUFSZ -  8, (ctx->nl >> 29) | (ctx->nh << 3));
  STORE32(ctx->buf + SHA512_BUFSZ -  4, ctx->nl << 3);
  sha512_compress(ctx, ctx->buf);
}

void sha512_done(sha512_ctx *ctx, void *hash)
{
  octet *p = hash;
  final(ctx);
  STORE64_(p +	0, ctx->a);
  STORE64_(p +	8, ctx->b);
  STORE64_(p + 16, ctx->c);
  STORE64_(p + 24, ctx->d);
  STORE64_(p + 32, ctx->e);
  STORE64_(p + 40, ctx->f);
  STORE64_(p + 48, ctx->g);
  STORE64_(p + 56, ctx->h);
}

void sha384_done(sha384_ctx *ctx, void *hash)
{
  octet *p = hash;
  final(ctx);
  STORE64_(p +	0, ctx->a);
  STORE64_(p +	8, ctx->b);
  STORE64_(p + 16, ctx->c);
  STORE64_(p + 24, ctx->d);
  STORE64_(p + 32, ctx->e);
  STORE64_(p + 40, ctx->f);
}

/* --- @sha512_state@, @sha384_state@ --- *
 *
 * Arguments:	@sha512_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @sha512_set@.
 */

unsigned long sha512_state(sha512_ctx *ctx, void *state)
{
  octet *p = state;
  STORE64_(p +	0, ctx->a);
  STORE64_(p +	8, ctx->b);
  STORE64_(p + 16, ctx->c);
  STORE64_(p + 24, ctx->d);
  STORE64_(p + 32, ctx->e);
  STORE64_(p + 40, ctx->f);
  STORE64_(p + 48, ctx->g);
  STORE64_(p + 56, ctx->h);
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(SHA512, sha512)

/* --- Test code --- */

HASH_TEST(SHA512, sha512)

/*----- That's all, folks -------------------------------------------------*/
