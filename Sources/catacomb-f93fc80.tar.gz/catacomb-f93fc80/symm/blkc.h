/* -*-c-*-
 *
 * Common definitions for block ciphers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_BLKC_H
#define CATACOMB_BLKC_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <assert.h>

#include <mLib/bits.h>

/*----- Theory of operation -----------------------------------------------*
 *
 * A block cipher has associated with it a triple, called PRE_CLASS, of the
 * form `(TYPE, ENDIAN, BITS)', where TYPE is either `N' (representing an
 * implemented bit size) or `X' (representing an unimplemented bit size,
 * causing loops to be compiled rather than unrolled code), ENDIAN is `B'
 * (big) or `L' (little), and BITS is the block size of the cipher in bits.
 */

/*----- Data movement macros ----------------------------------------------*/

/*
 * `The C preprocessor.  You will never find a more wretched hive of bogus
 * hackery.  We must be cautious.'
 */

/* --- General dispatch macros --- */

#define BLKC_DOGLUE(x, y) x ## y
#define BLKC_GLUE(x, y) BLKC_DOGLUE(x, y)
#define BLKC_APPLY(f, x) f x
#define BLKC_FIRST(x, y, z) x
#define BLKC_SECOND(x, y, z) y
#define BLKC_THIRD(x, y, z) z
#define BLKC_TYPE(PRE) BLKC_APPLY(BLKC_FIRST, PRE##_CLASS)
#define BLKC_ENDIAN(PRE) BLKC_APPLY(BLKC_SECOND, PRE##_CLASS)
#define BLKC_BITS(PRE) BLKC_APPLY(BLKC_THIRD, PRE##_CLASS)

#define BLKC_STORE_E(PRE) BLKC_GLUE(STORE32_, BLKC_ENDIAN(PRE))
#define BLKC_LOAD_E(PRE) BLKC_GLUE(LOAD32_, BLKC_ENDIAN(PRE))

/* --- Interface macros --- */

#define BLKC_STORE(PRE, b, w)						\
  BLKC_GLUE(BLKC_STORE_, BLKC_TYPE(PRE))				\
    (PRE, b, w, BLKC_STORE_E(PRE), BLKC_BITS(PRE))

#define BLKC_XSTORE(PRE, b, w, wx)					\
  BLKC_GLUE(BLKC_XSTORE_, BLKC_TYPE(PRE))				\
    (PRE, b, w, wx, BLKC_STORE_E(PRE), BLKC_BITS(PRE))

#define BLKC_LOAD(PRE, w, b)						\
  BLKC_GLUE(BLKC_LOAD_, BLKC_TYPE(PRE))					\
    (PRE, w, b, BLKC_LOAD_E(PRE), BLKC_BITS(PRE))

#define BLKC_XLOAD(PRE, w, b)						\
  BLKC_GLUE(BLKC_XLOAD_, BLKC_TYPE(PRE))				\
    (PRE, w, b, BLKC_LOAD_E(PRE), BLKC_BITS(PRE))

#define BLKC_MOVE(PRE, w, wx)						\
  BLKC_GLUE(BLKC_MOVE_, BLKC_TYPE(PRE))					\
    (PRE, w, wx, BLKC_BITS(PRE))

#define BLKC_XMOVE(PRE, w, wx)						\
  BLKC_GLUE(BLKC_XMOVE_, BLKC_TYPE(PRE))				\
    (PRE, w, wx, BLKC_BITS(PRE))

#define BLKC_STEP(PRE, w)						\
  BLKC_GLUE(BLKC_STEP_X_, BLKC_ENDIAN(PRE))				\
    (PRE, w)

#define BLKC_ZERO(PRE, w)						\
  BLKC_GLUE(BLKC_ZERO_, BLKC_TYPE(PRE))					\
    (PRE, w, BLKC_BITS(PRE))

#define BLKC_SET(PRE, w, x)						\
  BLKC_GLUE(BLKC_SET_X_, BLKC_ENDIAN(PRE))				\
    (PRE, w, x)

#define BLKC_SHOW(PRE, tag, w) do {					\
  fputs(tag ": ", stdout);						\
  BLKC_SKEL_X(PRE, BLKC_W(w);, printf("%08x ", *_w++););		\
  fputc('\n', stdout);							\
} while (0)

/* --- General implementation skeleton --- */

#define BLKC_SKEL(PRE, decl, guts) do {					\
  decl									\
  guts									\
} while (0)

#define BLKC_P(p) register octet *_p = (octet *)(p)
#define BLKC_W(w) register uint32 *_w = (w)
#define BLKC_WX(wx) register uint32 *_wx = (wx)

/* --- Implementation for unusual block sizes --- */

#define BLKC_SKEL_X(PRE, decl, guts)					\
  BLKC_SKEL(PRE, unsigned _i; decl,					\
	    for (_i = 0; _i < PRE##_BLKSZ / 4; _i++) {			\
	      guts							\
	    })

#define BLKC_STORE_X(PRE, b, w, op, n)					\
  BLKC_SKEL_X(PRE, BLKC_P(b); const BLKC_W(w);,				\
	      op(_p, *_w); _p += 4; _w++; )

#define BLKC_XSTORE_X(PRE, b, w, wx, op, n)				\
  BLKC_SKEL_X(PRE, BLKC_P(b); const BLKC_W(w); const BLKC_WX(wx);,	\
	      op(_p, *_w ^ *_wx); _p += 4; _w++; _wx++; )

#define BLKC_LOAD_X(PRE, w, b, op, n)					\
  BLKC_SKEL_X(PRE, const BLKC_P(b); BLKC_W(w);,				\
	      *_w = op(_p); _p += 4; _w++; )

#define BLKC_XLOAD_X(PRE, w, b, op, n)					\
  BLKC_SKEL_X(PRE, const BLKC_P(b); BLKC_W(w);,				\
	      *_w ^= op(_p); _p += 4; _w++; )

#define BLKC_MOVE_X(PRE, w, wx, n)					\
  BLKC_SKEL_X(PRE, BLKC_W(w); const BLKC_WX(wx);,			\
	      *_w = *_wx; _w++; _wx++; )				\

#define BLKC_XMOVE_X(PRE, w, wx, n)					\
  BLKC_SKEL_X(PRE, BLKC_W(w); const BLKC_WX(wx);,			\
	      *_w ^= *_wx; _w++; _wx++; )				\

#define BLKC_ZERO_X(PRE, w, n)						\
  BLKC_SKEL_X(PRE, BLKC_W(w);, *_w++ = 0;)

#define BLKC_STEP_X_B(PRE, w) do {					\
  unsigned _i = PRE##_BLKSZ / 4; BLKC_W(w); uint32 _x = 0;		\
  while (_i && !_x) { _i--; _w[_i] = _x = U32(_w[_i] + 1); }		\
} while (0)

#define BLKC_STEP_X_L(PRE, w) do {					\
  unsigned _i = 0; BLKC_W(w); uint32 _x = 0;				\
  while (_i < PRE##_BLKSZ / 4 && !_x)					\
    { _w[_i] = _x = U32(_w[_i] + 1); _i++; }				\
} while (0)

#define BLKC_SET_X_B(PRE, w, x) do {					\
  unsigned _i; BLKC_W(w); unsigned long _x = x;				\
  for (_i = 0; _i < PRE##_BLKSZ / 4; _i++) {				\
    *_w++ = U32(_x);							\
    _x = ((_x & ~MASK32) >> 16) >> 16;					\
  }									\
} while (0)

#define BLKC_SET_X_L(PRE, w, x) do {					\
  unsigned _i; BLKC_W(w); unsigned long _x = x;	_w += PRE##_BLKSZ / 4;	\
  for (_i = 0; _i < PRE##_BLKSZ / 4; _i++) {				\
    *--_w = U32(_x);							\
    _x = ((_x & ~MASK32) >> 16) >> 16;					\
  }									\
} while (0)

/* --- Implementation for known block sizes --- */

#define BLKC_SKEL_64(PRE, decl, op, guts)				\
  BLKC_SKEL(PRE, decl, guts(op, 0); guts(op, 1);)

#define BLKC_SKEL_96(PRE, decl, op, guts)				\
  BLKC_SKEL(PRE, decl, guts(op, 0); guts(op, 1); guts(op, 2);)

#define BLKC_SKEL_128(PRE, decl, op, guts)				\
  BLKC_SKEL(PRE, decl, guts(op, 0); guts(op, 1); guts(op, 2); guts(op, 3);)

#define BLKC_SKEL_192(PRE, decl, op, guts)				\
  BLKC_SKEL(PRE, decl,							\
	    guts(op, 0); guts(op, 1); guts(op, 2); guts(op, 3);		\
	    guts(op, 4); guts(op, 5);)

#define BLKC_SKEL_256(PRE, decl, op, guts)				\
  BLKC_SKEL(PRE, decl,							\
	    guts(op, 0); guts(op, 1); guts(op, 2); guts(op, 3);		\
	    guts(op, 4); guts(op, 5); guts(op, 6); guts(op, 7);)

#define BLKC_STORE_GUTS(op, i) op(_p + 4 * i, _w[i])
#define BLKC_XSTORE_GUTS(op, i) op(_p + 4 * i, _w[i] ^ _wx[i])
#define BLKC_LOAD_GUTS(op, i) _w[i] = op(_p + 4 * i)
#define BLKC_XLOAD_GUTS(op, i) _w[i] ^= op(_p + 4 * i)
#define BLKC_MOVE_GUTS(op, i) _w[i] = _wx[i]
#define BLKC_XMOVE_GUTS(op, i) _w[i] ^= _wx[i]
#define BLKC_ZERO_GUTS(op, i) _w[i] = 0

#define BLKC_STORE_N(PRE, b, w, op, n)					\
  BLKC_GLUE(BLKC_SKEL_, n)						\
    (PRE, BLKC_P(b); const BLKC_W(w);, op, BLKC_STORE_GUTS)

#define BLKC_XSTORE_N(PRE, b, w, wx, op, n)				\
  BLKC_GLUE(BLKC_SKEL_, n)						\
    (PRE, BLKC_P(b); const BLKC_W(w); const BLKC_WX(wx);,		\
     op, BLKC_XSTORE_GUTS)

#define BLKC_LOAD_N(PRE, w, b, op, n)					\
  BLKC_GLUE(BLKC_SKEL_, n)						\
    (PRE, const BLKC_P(b); BLKC_W(w);, op, BLKC_LOAD_GUTS)

#define BLKC_XLOAD_N(PRE, w, b, op, n)					\
  BLKC_GLUE(BLKC_SKEL_, n)						\
    (PRE, const BLKC_P(b); BLKC_W(w);, op, BLKC_XLOAD_GUTS)

#define BLKC_MOVE_N(PRE, w, wx, n)					\
  BLKC_GLUE(BLKC_SKEL_, n)						\
    (PRE, BLKC_W(w); const BLKC_WX(wx);, op, BLKC_MOVE_GUTS)

#define BLKC_ZERO_N(PRE, w, n)						\
  BLKC_GLUE(BLKC_SKEL_, n)						\
    (PRE, BLKC_W(w); , op, BLKC_ZERO_GUTS)

#define BLKC_XMOVE_N(PRE, w, wx, n)					\
  BLKC_GLUE(BLKC_SKEL_, n)						\
    (PRE, BLKC_W(w); const BLKC_WX(wx);, op, BLKC_XMOVE_GUTS)

/*----- Test rig for block ciphers ----------------------------------------*/

/* --- @BLKC_TEST@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for cipher-specific definitions
 *
 * Use:		Standard test rig for block ciphers.
 */

#ifdef TEST_RIG

#include <string.h>

#include <mLib/quis.h>
#include <mLib/testrig.h>

#define BLKC_VERIFY(PRE, pre)						\
									\
static int pre##_verify(dstr *v)					\
{									\
  pre##_ctx k;								\
  uint32 p[PRE##_BLKSZ / 4];						\
  uint32 c[PRE##_BLKSZ / 4];						\
  uint32 d[PRE##_BLKSZ / 4];						\
  dstr b = DSTR_INIT;							\
  int ok = 1;								\
									\
  /* --- Initialize the key buffer --- */				\
									\
  dstr_ensure(&b, PRE##_BLKSZ);						\
  b.len = PRE##_BLKSZ;							\
  pre##_init(&k, v[0].buf, v[0].len);					\
  BLKC_LOAD(PRE, p, v[1].buf);						\
  BLKC_LOAD(PRE, c, v[2].buf);						\
									\
  /* --- Test encryption --- */						\
									\
  BLKC_MOVE(PRE, d, p);							\
  pre##_eblk(&k, d, d);							\
  BLKC_STORE(PRE, b.buf, d);						\
  if (memcmp(b.buf, v[2].buf, PRE##_BLKSZ)) {				\
    ok = 0;								\
    printf("\nfail encryption:"						\
	   "\n\tkey	   = ");					\
    type_hex.dump(&v[0], stdout);					\
    printf("\n\tplaintext  = "); type_hex.dump(&v[1], stdout);		\
    printf("\n\texpected   = "); type_hex.dump(&v[2], stdout);		\
    printf("\n\tcalculated = "); type_hex.dump(&b, stdout);		\
    putchar('\n');							\
  }									\
									\
  /* --- Test decryption --- */						\
									\
  BLKC_MOVE(PRE, d, c);							\
  pre##_dblk(&k, d, d);							\
  BLKC_STORE(PRE, b.buf, d);						\
  if (memcmp(b.buf, v[1].buf, PRE##_BLKSZ)) {				\
    ok = 0;								\
    printf("\nfail decryption:"						\
	   "\n\tkey	   = ");					\
    type_hex.dump(&v[0], stdout);					\
    printf("\n\tciphertext = "); type_hex.dump(&v[2], stdout);		\
    printf("\n\texpected   = "); type_hex.dump(&v[1], stdout);		\
    printf("\n\tcalculated = "); type_hex.dump(&b, stdout);		\
    putchar('\n');							\
  }									\
									\
  /* --- Return --- */							\
									\
  return (ok);								\
}

#define BLKC_TEST(PRE, pre)						\
									\
BLKC_VERIFY(PRE, pre)							\
									\
static const test_chunk defs[] = {					\
  { #pre, pre##_verify, { &type_hex, &type_hex, &type_hex, 0 } },	\
  { 0, 0, { 0 } }							\
};									\
									\
int main(int argc, char *argv[])					\
{									\
  test_run(argc, argv, defs, SRCDIR"/t/" #pre);				\
  return (0);								\
}

#else
#  define BLKC_VERIFY(PRE, pre)
#  define BLKC_TEST(PRE, pre)
#endif

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
