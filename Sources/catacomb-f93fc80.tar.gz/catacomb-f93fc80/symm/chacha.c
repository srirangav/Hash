/* -*-c-*-
 *
 * ChaCha stream cipher
 *
 * (c) 2015 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdarg.h>

#include <mLib/bits.h>

#include "arena.h"
#include "chacha.h"
#include "chacha-core.h"
#include "gcipher.h"
#include "grand.h"
#include "keysz.h"
#include "paranoia.h"

/*----- Global variables --------------------------------------------------*/

const octet chacha_keysz[] = { KSZ_SET, 32, 16, 10, 0 };

/*----- The ChaCha core function and utilities ----------------------------*/

/* --- @core@ --- *
 *
 * Arguments:	@unsigned r@ = number of rounds
 *		@const chacha_matrix src@ = input matrix
 *		@chacha_matrix dest@ = where to put the output
 *
 * Returns:	---
 *
 *
 * Use:		Apply the ChaCha/r core function to @src@, writing the
 *		result to @dest@.  This consists of @r@ rounds followed by
 *		the feedforward step.
 */

static void core(unsigned r, const chacha_matrix src, chacha_matrix dest)
  { CHACHA_nR(dest, src, r); CHACHA_FFWD(dest, src); }

/* --- @populate@ --- *
 *
 * Arguments:	@chacha_matrix a@ = a matrix to fill in
 *		@const void *key@ = pointer to key material
 *		@size_t ksz@ = size of key
 *
 * Returns:	---
 *
 * Use:		Fills in a ChaCha matrix from the key, setting the
 *		appropriate constants according to the key length.  The nonce
 *		and position words are left uninitialized.
 */

static void populate(chacha_matrix a, const void *key, size_t ksz)
{
  const octet *k = key;

  KSZ_ASSERT(chacha, ksz);

  a[ 4] = LOAD32_L(k +  0);
  a[ 5] = LOAD32_L(k +  4);
  if (ksz == 10) {
    a[ 6] = LOAD16_L(k +  8);
    a[ 7] = 0;
  } else {
    a[ 6] = LOAD32_L(k +  8);
    a[ 7] = LOAD32_L(k + 12);
  }
  if (ksz <= 16) {
    a[ 8] = a[ 4];
    a[ 9] = a[ 5];
    a[10] = a[ 6];
    a[11] = a[ 7];
    a[ 0] = CHACHA_A128;
    a[ 1] = CHACHA_B128;
    a[ 2] = ksz == 10 ? CHACHA_C80 : CHACHA_C128;
    a[ 3] = CHACHA_D128;
  } else {
    a[ 8] = LOAD32_L(k + 16);
    a[ 9] = LOAD32_L(k + 20);
    a[10] = LOAD32_L(k + 24);
    a[11] = LOAD32_L(k + 28);
    a[ 0] = CHACHA_A256;
    a[ 1] = CHACHA_B256;
    a[ 2] = CHACHA_C256;
    a[ 3] = CHACHA_D256;
  }
}

/*----- ChaCha implementation ---------------------------------------------*/

/* --- @chacha_init@ --- *
 *
 * Arguments:	@chacha_ctx *ctx@ = context to fill in
 *		@const void *key@ = pointer to key material
 *		@size_t ksz@ = size of key (either 32 or 16)
 *		@const void *nonce@ = initial nonce, or null
 *
 * Returns:	---
 *
 * Use:		Initializes a ChaCha context ready for use.
 */

void chacha_init(chacha_ctx *ctx, const void *key, size_t ksz,
		  const void *nonce)
{
  static const octet zerononce[CHACHA_NONCESZ];

  populate(ctx->a, key, ksz);
  chacha_setnonce(ctx, nonce ? nonce : zerononce);
}

/* --- @chacha_setnonce@ --- *
 *
 * Arguments:	@chacha_ctx *ctx@ = pointer to context
 *		@const void *nonce@ = the nonce (@CHACHA_NONCESZ@ bytes)
 *
 * Returns:	---
 *
 * Use:		Set a new nonce in the context @ctx@, e.g., for processing a
 *		different message.  The stream position is reset to zero (see
 *		@chacha_seek@ etc.).
 */

void chacha_setnonce(chacha_ctx *ctx, const void *nonce)
{
  const octet *n = nonce;

  ctx->a[14] = LOAD32_L(n + 0);
  ctx->a[15] = LOAD32_L(n + 4);
  chacha_seek(ctx, 0);
}

/* --- @chacha_seek@, @chacha_seeku64@ --- *
 *
 * Arguments:	@chacha_ctx *ctx@ = pointer to context
 *		@unsigned long i@, @kludge64 i@ = new position to set
 *
 * Returns:	---
 *
 * Use:		Sets a new stream position, in units of Chacha output
 *		blocks, which are @CHACHA_OUTSZ@ bytes each.  Byte
 *		granularity can be achieved by calling @chachaR_encrypt@
 *		appropriately.
 */

void chacha_seek(chacha_ctx *ctx, unsigned long i)
  { kludge64 ii; ASSIGN64(ii, i); chacha_seeku64(ctx, ii); }

void chacha_seeku64(chacha_ctx *ctx, kludge64 i)
{
  ctx->a[12] = LO64(i); ctx->a[13] = HI64(i);
  ctx->bufi = CHACHA_OUTSZ;
}

/* --- @chacha_tell@, @chacha_tellu64@ --- *
 *
 * Arguments:	@chacha_ctx *ctx@ = pointer to context
 *
 * Returns:	The current position in the output stream, in blocks,
 *		rounding upwards.
 */

unsigned long chacha_tell(chacha_ctx *ctx)
  { kludge64 i = chacha_tellu64(ctx); return (GET64(unsigned long, i)); }

kludge64 chacha_tellu64(chacha_ctx *ctx)
  { kludge64 i; SET64(i, ctx->a[9], ctx->a[8]); return (i); }

/* --- @chacha{,12,8}_encrypt@ --- *
 *
 * Arguments:	@chacha_ctx *ctx@ = pointer to context
 *		@const void *src@ = source buffer (or null)
 *		@void *dest@ = destination buffer (or null)
 *		@size_t sz@ = size of the buffers
 *
 * Returns:	---
 *
 * Use:		Encrypts or decrypts @sz@ bytes of data from @src@ to @dest@.
 *		ChaCha works by XORing plaintext with a keystream, so
 *		encryption and decryption are the same operation.  If @dest@
 *		is null then ignore @src@ and skip @sz@ bytes of the
 *		keystream.  If @src@ is null, then just write the keystream
 *		to @dest@.
 */

#define CHACHA_ENCRYPT(r, ctx, src, dest, sz)				\
  chacha##r##_encrypt(ctx, src, dest, sz)
#define DEFENCRYPT(r)							\
  void CHACHA_ENCRYPT(r, chacha_ctx *ctx, const void *src,		\
		      void *dest, size_t sz)				\
  {									\
    chacha_matrix b;							\
    const octet *s = src;						\
    octet *d = dest;							\
    size_t n;								\
    kludge64 pos, delta;						\
									\
    SALSA20_OUTBUF(ctx, d, s, sz);					\
    if (!sz) return;							\
									\
    if (!dest) {							\
      n = sz/CHACHA_OUTSZ;						\
      pos = chacha_tellu64(ctx);					\
      ASSIGN64(delta, n);						\
      ADD64(pos, pos, delta);						\
      chacha_seeku64(ctx, pos);						\
      sz = sz%CHACHA_OUTSZ;						\
    } else if (!src) {							\
      while (sz >= CHACHA_OUTSZ) {					\
	core(r, ctx->a, b);						\
	CHACHA_STEP(ctx->a);						\
	SALSA20_GENFULL(b, d);						\
	sz -= CHACHA_OUTSZ;						\
      }									\
    } else {								\
      while (sz >= CHACHA_OUTSZ) {					\
	core(r, ctx->a, b);						\
	CHACHA_STEP(ctx->a);						\
	SALSA20_MIXFULL(b, d, s);					\
	sz -= CHACHA_OUTSZ;						\
      }									\
    }									\
									\
    if (sz) {								\
      core(r, ctx->a, b);						\
      CHACHA_STEP(ctx->a);						\
      SALSA20_PREPBUF(ctx, b);						\
      SALSA20_OUTBUF(ctx, d, s, sz);					\
      assert(!sz);							\
    }									\
  }
CHACHA_VARS(DEFENCRYPT)

/*----- HChaCha implementation --------------------------------------------*/

#define HCHACHA_RAW(r, ctx, src, dest) hchacha##r##_raw(ctx, src, dest)
#define HCHACHA_PRF(r, ctx, src, dest) hchacha##r##_prf(ctx, src, dest)

/* --- @hchacha{20,12,8}_prf@ --- *
 *
 * Arguments:	@chacha_ctx *ctx@ = pointer to context
 *		@const void *src@ = the input (@HCHACHA_INSZ@ bytes)
 *		@void *dest@ = the output (@HCHACHA_OUTSZ@ bytes)
 *
 * Returns:	---
 *
 * Use:		Apply the HChacha/r pseudorandom function to @src@, writing
 *		the result to @out@.
 */

#define DEFHCHACHA(r)							\
  static void HCHACHA_RAW(r, chacha_matrix k,				\
			  const uint32 *src, uint32 *dest)		\
  {									\
    chacha_matrix a;							\
    int i;								\
									\
    /* --- HChaCha, computed from full ChaCha --- *			\
     *									\
     * The security proof makes use of the fact that HChaCha (i.e.,	\
     * without the final feedforward step) can be computed from full	\
     * ChaCha using only knowledge of the non-secret input.  I don't	\
     * want to compromise the performance of the main function by	\
     * making the feedforward step separate, but this operation is less	\
     * speed critical, so we do it the harder way.			\
     */									\
									\
    for (i = 0; i < 4; i++) k[12 + i] = src[i];				\
    core(r, k, a);							\
    for (i = 0; i < 8; i++) dest[i] = a[(i + 4)^4] - k[(i + 4)^4];	\
  }									\
									\
  void HCHACHA_PRF(r, chacha_ctx *ctx, const void *src, void *dest)	\
  {									\
    const octet *s = src;						\
    octet *d = dest;							\
    uint32 in[4], out[8];						\
    int i;								\
									\
    for (i = 0; i < 4; i++) in[i] = LOAD32_L(s + 4*i);			\
    HCHACHA_RAW(r, ctx->a, in, out);					\
    for (i = 0; i < 8; i++) STORE32_L(d + 4*i, out[i]);			\
  }
CHACHA_VARS(DEFHCHACHA)

/*----- XChaCha implementation -------------------------------------------*/

/* --- Some convenient macros for naming functions --- *
 *
 * Because the crypto core is involved in XChaCha/r's per-nonce setup, we
 * need to take an interest in the number of rounds in most of the various
 * functions, and it will probably help if we distinguish the context
 * structures for the various versions.
 */

#define XCHACHA_CTX(r) xchacha##r##_ctx
#define XCHACHA_INIT(r, ctx, k, ksz, n) xchacha##r##_init(ctx, k, ksz, n)
#define XCHACHA_SETNONCE(r, ctx, n) xchacha##r##_setnonce(ctx, n)
#define XCHACHA_SEEK(r, ctx, i) xchacha##r##_seek(ctx, i)
#define XCHACHA_SEEKU64(r, ctx, i) xchacha##r##_seeku64(ctx, i)
#define XCHACHA_TELL(r, ctx) xchacha##r##_tell(ctx)
#define XCHACHA_TELLU64(r, ctx) xchacha##r##_tellu64(ctx)
#define XCHACHA_ENCRYPT(r, ctx, src, dest, sz)				\
  xchacha##r##_encrypt(ctx, src, dest, sz)

/* --- @xchacha{20,12,8}_init@ --- *
 *
 * Arguments:	@xchachaR_ctx *ctx@ = the context to fill in
 *		@const void *key@ = pointer to key material
 *		@size_t ksz@ = size of key (either 32 or 16)
 *		@const void *nonce@ = initial nonce, or null
 *
 * Returns:	---
 *
 * Use:		Initializes an XChaCha/r context ready for use.
 *
 *		There is a different function for each number of rounds,
 *		unlike for plain ChaCha.
 */

#define DEFXINIT(r)							\
  void XCHACHA_INIT(r, XCHACHA_CTX(r) *ctx,				\
		    const void *key, size_t ksz, const void *nonce)	\
  {									\
    static const octet zerononce[XCHACHA_NONCESZ];			\
									\
    populate(ctx->k, key, ksz);						\
    ctx->s.a[ 0] = CHACHA_A256;						\
    ctx->s.a[ 1] = CHACHA_B256;						\
    ctx->s.a[ 2] = CHACHA_C256;						\
    ctx->s.a[ 3] = CHACHA_D256;						\
    XCHACHA_SETNONCE(r, ctx, nonce ? nonce : zerononce);		\
  }
CHACHA_VARS(DEFXINIT)

/* --- @xchacha{20,12,8}_setnonce@ --- *
 *
 * Arguments:	@xchachaR_ctx *ctx@ = pointer to context
 *		@const void *nonce@ = the nonce (@XCHACHA_NONCESZ@ bytes)
 *
 * Returns:	---
 *
 * Use:		Set a new nonce in the context @ctx@, e.g., for processing a
 *		different message.  The stream position is reset to zero (see
 *		@chacha_seek@ etc.).
 *
 *		There is a different function for each number of rounds,
 *		unlike for plain ChaCha.
 */

#define DEFXNONCE(r)							\
  void XCHACHA_SETNONCE(r, XCHACHA_CTX(r) *ctx, const void *nonce)	\
  {									\
    const octet *n = nonce;						\
    uint32 in[4];							\
    int i;								\
									\
    for (i = 0; i < 4; i++) in[i] = LOAD32_L(n + 4*i);			\
    HCHACHA_RAW(r, ctx->k, in, ctx->s.a + 4);				\
    chacha_setnonce(&ctx->s, n + 16);					\
  }
CHACHA_VARS(DEFXNONCE)

/* --- @xchacha{20,12,8}_seek@, @xchacha{20,12,8}_seeku64@ --- *
 *
 * Arguments:	@xchachaR_ctx *ctx@ = pointer to context
 *		@unsigned long i@, @kludge64 i@ = new position to set
 *
 * Returns:	---
 *
 * Use:		Sets a new stream position, in units of ChaCha output
 *		blocks, which are @XCHACHA_OUTSZ@ bytes each.  Byte
 *		granularity can be achieved by calling @xchachaR_encrypt@
 *		appropriately.
 *
 *		There is a different function for each number of rounds,
 *		unlike for plain ChaCha, because the context structures are
 *		different.
 */

/* --- @xchacha{20,12,8}_tell@, @xchacha{20,12,8}_tellu64@ --- *
 *
 * Arguments:	@chacha_ctx *ctx@ = pointer to context
 *
 * Returns:	The current position in the output stream, in blocks,
 *		rounding upwards.
 *
 *		There is a different function for each number of rounds,
 *		unlike for plain ChaCha, because the context structures are
 *		different.
 */

/* --- @xchacha{,12,8}_encrypt@ --- *
 *
 * Arguments:	@xchachaR_ctx *ctx@ = pointer to context
 *		@const void *src@ = source buffer (or null)
 *		@void *dest@ = destination buffer (or null)
 *		@size_t sz@ = size of the buffers
 *
 * Returns:	---
 *
 * Use:		Encrypts or decrypts @sz@ bytes of data from @src@ to @dest@.
 *		XChaCha works by XORing plaintext with a keystream, so
 *		encryption and decryption are the same operation.  If @dest@
 *		is null then ignore @src@ and skip @sz@ bytes of the
 *		keystream.  If @src@ is null, then just write the keystream
 *		to @dest@.
 */

#define DEFXPASSTHRU(r)							\
  void XCHACHA_SEEK(r, XCHACHA_CTX(r) *ctx, unsigned long i)		\
    { chacha_seek(&ctx->s, i); }					\
  void XCHACHA_SEEKU64(r, XCHACHA_CTX(r) *ctx, kludge64 i)		\
    { chacha_seeku64(&ctx->s, i); }					\
  unsigned long XCHACHA_TELL(r, XCHACHA_CTX(r) *ctx)			\
    { return chacha_tell(&ctx->s); }					\
  kludge64 XCHACHA_TELLU64(r, XCHACHA_CTX(r) *ctx)			\
    { return chacha_tellu64(&ctx->s); }					\
  void XCHACHA_ENCRYPT(r, XCHACHA_CTX(r) *ctx,				\
			const void *src, void *dest, size_t sz)		\
    { CHACHA_ENCRYPT(r, &ctx->s, src, dest, sz); }
CHACHA_VARS(DEFXPASSTHRU)

/*----- Generic cipher interface ------------------------------------------*/

typedef struct gctx { gcipher c; chacha_ctx ctx; } gctx;

static void gsetiv(gcipher *c, const void *iv)
  { gctx *g = (gctx *)c; chacha_setnonce(&g->ctx, iv); }

static void gdestroy(gcipher *c)
  { gctx *g = (gctx *)c; BURN(*g); S_DESTROY(g); }

#define DEFGCIPHER(r)							\
									\
  static const gcipher_ops gops_##r;					\
									\
  static gcipher *ginit_##r(const void *k, size_t sz)			\
  {									\
    gctx *g = S_CREATE(gctx);						\
    g->c.ops = &gops_##r;						\
    chacha_init(&g->ctx, k, sz, 0);					\
    return (&g->c);							\
  }									\
									\
  static void gencrypt_##r(gcipher *c, const void *s,			\
			   void *t, size_t sz)				\
    { gctx *g = (gctx *)c; CHACHA_ENCRYPT(r, &g->ctx, s, t, sz); }	\
									\
  static const gcipher_ops gops_##r = {					\
    &chacha##r,								\
    gencrypt_##r, gencrypt_##r, gdestroy, gsetiv, 0			\
  };									\
									\
  const gccipher chacha##r = {						\
    "chacha" #r, chacha_keysz,						\
    CHACHA_NONCESZ, ginit_##r						\
  };

CHACHA_VARS(DEFGCIPHER)

#define DEFGXCIPHER(r)							\
									\
  typedef struct { gcipher c; XCHACHA_CTX(r) ctx; } gxctx_##r;		\
									\
  static void gxsetiv_##r(gcipher *c, const void *iv)			\
    { gxctx_##r *g = (gxctx_##r *)c; XCHACHA_SETNONCE(r, &g->ctx, iv); } \
									\
  static void gxdestroy_##r(gcipher *c)					\
    { gxctx_##r *g = (gxctx_##r *)c; BURN(*g); S_DESTROY(g); }		\
									\
  static const gcipher_ops gxops_##r;					\
									\
  static gcipher *gxinit_##r(const void *k, size_t sz)			\
  {									\
    gxctx_##r *g = S_CREATE(gxctx_##r);					\
    g->c.ops = &gxops_##r;						\
    XCHACHA_INIT(r, &g->ctx, k, sz, 0);					\
    return (&g->c);							\
  }									\
									\
  static void gxencrypt_##r(gcipher *c, const void *s,			\
			    void *t, size_t sz)				\
  {									\
    gxctx_##r *g = (gxctx_##r *)c;					\
    XCHACHA_ENCRYPT(r, &g->ctx, s, t, sz);				\
  }									\
									\
  static const gcipher_ops gxops_##r = {				\
    &xchacha##r,							\
    gxencrypt_##r, gxencrypt_##r, gxdestroy_##r, gxsetiv_##r, 0		\
  };									\
									\
  const gccipher xchacha##r = {						\
    "xchacha" #r, chacha_keysz,						\
    CHACHA_NONCESZ, gxinit_##r						\
  };

CHACHA_VARS(DEFGXCIPHER)

/*----- Generic random number generator interface -------------------------*/

typedef struct grops {
  size_t noncesz;
  void (*seek)(void *, kludge64);
  kludge64 (*tell)(void *);
  void (*setnonce)(void *, const void *);
  void (*generate)(void *, void *, size_t);
} grops;

typedef struct grbasectx {
  grand r;
  const grops *ops;
} grbasectx;

static int grmisc(grand *r, unsigned op, ...)
{
  octet buf[XCHACHA_NONCESZ];
  grbasectx *g = (grbasectx *)r;
  grand *rr;
  const octet *p;
  size_t sz;
  uint32 i;
  unsigned long ul;
  kludge64 pos;
  va_list ap;
  int rc = 0;

  va_start(ap, op);

  switch (op) {
    case GRAND_CHECK:
      switch (va_arg(ap, unsigned)) {
	case GRAND_CHECK:
	case GRAND_SEEDINT:
	case GRAND_SEEDUINT32:
	case GRAND_SEEDBLOCK:
	case GRAND_SEEDRAND:
	case CHACHA_SEEK:
	case CHACHA_SEEKU64:
	case CHACHA_TELL:
	case CHACHA_TELLU64:
	  rc = 1;
	  break;
	default:
	  rc = 0;
	  break;
      }
      break;

    case GRAND_SEEDINT:
      i = va_arg(ap, unsigned); STORE32_L(buf, i);
      memset(buf + 4, 0, g->ops->noncesz - 4);
      g->ops->setnonce(g, buf);
      break;
    case GRAND_SEEDUINT32:
      i = va_arg(ap, uint32); STORE32_L(buf, i);
      memset(buf + 4, 0, g->ops->noncesz - 4);
      g->ops->setnonce(g, buf);
      break;
    case GRAND_SEEDBLOCK:
      p = va_arg(ap, const void *);
      sz = va_arg(ap, size_t);
      if (sz < g->ops->noncesz) {
	memcpy(buf, p, sz);
	memset(buf + sz, 0, g->ops->noncesz - sz);
	p = buf;
      }
      g->ops->setnonce(g, p);
      break;
    case GRAND_SEEDRAND:
      rr = va_arg(ap, grand *);
      rr->ops->fill(rr, buf, g->ops->noncesz);
      g->ops->setnonce(g, buf);
      break;
    case CHACHA_SEEK:
      ul = va_arg(ap, unsigned long); ASSIGN64(pos, ul);
      g->ops->seek(g, pos);
      break;
    case CHACHA_SEEKU64:
      pos = va_arg(ap, kludge64);
      g->ops->seek(g, pos);
      break;
    case CHACHA_TELL:
      pos = g->ops->tell(g);
      *va_arg(ap, unsigned long *) = GET64(unsigned long, pos);
      break;
    case CHACHA_TELLU64:
      *va_arg(ap, kludge64 *) = g->ops->tell(g);
      break;
    default:
      GRAND_BADOP;
      break;
  }

  return (rc);
}

static octet grbyte(grand *r)
{
  grbasectx *g = (grbasectx *)r;
  octet o;
  g->ops->generate(g, &o, 1);
  return (o);
}

static uint32 grword(grand *r)
{
  grbasectx *g = (grbasectx *)r;
  octet b[4];
  g->ops->generate(g, b, sizeof(b));
  return (LOAD32_L(b));
}

static void grfill(grand *r, void *p, size_t sz)
{
  grbasectx *g = (grbasectx *)r;
  g->ops->generate(r, p, sz);
}

typedef struct grctx {
  grbasectx r;
  chacha_ctx ctx;
} grctx;

static void gr_seek(void *r, kludge64 pos)
  { grctx *g = r; chacha_seeku64(&g->ctx, pos); }

static kludge64 gr_tell(void *r)
  { grctx *g = r; return (chacha_tellu64(&g->ctx)); }

static void gr_setnonce(void *r, const void *n)
  { grctx *g = r; chacha_setnonce(&g->ctx, n); }

static void grdestroy(grand *r)
  { grctx *g = (grctx *)r; BURN(*g); S_DESTROY(g); }

#define DEFGRAND(rr)							\
									\
  static void gr_generate_##rr(void *r, void *b, size_t sz)		\
    { grctx *g = r; CHACHA_ENCRYPT(rr, &g->ctx, 0, b, sz); }		\
									\
  static const grops grops_##rr =					\
    { CHACHA_NONCESZ, gr_seek, gr_tell,					\
      gr_setnonce, gr_generate_##rr };					\
									\
  static const grand_ops grops_rand_##rr = {				\
    "chacha" #rr, GRAND_CRYPTO, 0,					\
    grmisc, grdestroy, grword,						\
    grbyte, grword, grand_range, grfill					\
  };									\
									\
  grand *chacha##rr##_rand(const void *k, size_t ksz, const void *n)	\
  {									\
    grctx *g = S_CREATE(g);						\
    g->r.r.ops = &grops_rand_##rr;					\
    g->r.ops = &grops_##rr;						\
    chacha_init(&g->ctx, k, ksz, n);					\
    return (&g->r.r);							\
  }
CHACHA_VARS(DEFGRAND)

#define DEFXGRAND(rr)							\
									\
  typedef struct grxctx_##rr {						\
    grbasectx r;							\
    XCHACHA_CTX(rr) ctx;						\
  } grxctx_##rr;							\
									\
  static void grx_seek_##rr(void *r, kludge64 pos)			\
    { grxctx_##rr *g = r; XCHACHA_SEEKU64(rr, &g->ctx, pos); }		\
									\
  static kludge64 grx_tell_##rr(void *r)				\
    { grxctx_##rr *g = r; return (XCHACHA_TELLU64(rr, &g->ctx)); }	\
									\
  static void grx_setnonce_##rr(void *r, const void *n)			\
    { grxctx_##rr *g = r; XCHACHA_SETNONCE(rr, &g->ctx, n); }		\
									\
  static void grxdestroy_##rr(grand *r)					\
    { grxctx_##rr *g = (grxctx_##rr *)r; BURN(*g); S_DESTROY(g); }	\
									\
  static void grx_generate_##rr(void *r, void *b, size_t sz)		\
    { grxctx_##rr *g = r; XCHACHA_ENCRYPT(rr, &g->ctx, 0, b, sz); }	\
									\
  static const grops grxops_##rr =					\
    { XCHACHA_NONCESZ, grx_seek_##rr, grx_tell_##rr,			\
      grx_setnonce_##rr, grx_generate_##rr };				\
									\
  static const grand_ops grxops_rand_##rr = {				\
    "xchacha" #rr, GRAND_CRYPTO, 0,					\
    grmisc, grxdestroy_##rr, grword,					\
    grbyte, grword, grand_range, grfill					\
  };									\
									\
  grand *xchacha##rr##_rand(const void *k, size_t ksz, const void *n)	\
  {									\
    grxctx_##rr *g = S_CREATE(g);					\
    g->r.r.ops = &grxops_rand_##rr;					\
    g->r.ops = &grxops_##rr;						\
    XCHACHA_INIT(rr, &g->ctx, k, ksz, n);				\
    return (&g->r.r);							\
  }
CHACHA_VARS(DEFXGRAND)

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#include <stdio.h>
#include <string.h>

#include <mLib/quis.h>
#include <mLib/testrig.h>

#define DEFVCORE(r)							\
  static int v_core_##r(dstr *v)					\
  {									\
    chacha_matrix a, b;							\
    dstr d = DSTR_INIT;							\
    int i, n;								\
    int ok = 1;								\
									\
    DENSURE(&d, CHACHA_OUTSZ); d.len = CHACHA_OUTSZ;			\
    n = *(int *)v[0].buf;						\
    for (i = 0; i < CHACHA_OUTSZ/4; i++)				\
      a[i] = LOAD32_L(v[1].buf + 4*i);					\
    for (i = 0; i < n; i++) {						\
      core(r, a, b);							\
      memcpy(a, b, sizeof(a));						\
    }									\
    for (i = 0; i < CHACHA_OUTSZ/4; i++) STORE32_L(d.buf + 4*i, a[i]);	\
									\
    if (d.len != v[2].len || memcmp(d.buf, v[2].buf, v[2].len) != 0) {	\
      ok = 0;								\
      printf("\nfail core:"						\
	     "\n\titerations = %d"					\
	     "\n\tin	   = ", n);					\
      type_hex.dump(&v[1], stdout);					\
      printf("\n\texpected   = ");					\
      type_hex.dump(&v[2], stdout);					\
      printf("\n\tcalculated = ");					\
      type_hex.dump(&d, stdout);					\
      putchar('\n');							\
    }									\
									\
    dstr_destroy(&d);							\
    return (ok);							\
  }
CHACHA_VARS(DEFVCORE)

#define CHACHA_CTX(r) chacha_ctx
#define CHACHA_INIT(r, ctx, k, ksz, n) chacha_init(ctx, k, ksz, n)
#define CHACHA_SEEKU64(r, ctx, i) chacha_seeku64(ctx, i)
#define XCHACHA_SEEKU64(r, ctx, i) xchacha##r##_seeku64(ctx, i)

#define DEFxVENC(base, BASE, r)						\
  static int v_encrypt_##base##_##r(dstr *v)				\
  {									\
    BASE##_CTX(r) ctx;							\
    dstr d = DSTR_INIT;							\
    kludge64 pos;							\
    const octet *p, *p0;						\
    octet *q;								\
    size_t sz, sz0, step;						\
    unsigned long skip;							\
    int ok = 1;								\
									\
    if (v[4].len) { p0 = (const octet *)v[4].buf; sz0 = v[4].len; }	\
    else { p0 = 0; sz0 = v[5].len; }					\
    DENSURE(&d, sz0); d.len = sz0;					\
    skip = *(unsigned long *)v[3].buf;					\
									\
    step = 0;								\
    while (step < sz0 + skip) {						\
      step = step ? 3*step + 4 : 1;					\
      if (step > sz0 + skip) step = sz0 + skip;				\
      BASE##_INIT(r, &ctx, v[0].buf, v[0].len, v[1].buf);		\
      if (v[2].len) {							\
	LOAD64_(pos, v[2].buf);						\
	BASE##_SEEKU64(r, &ctx, pos);					\
      }									\
									\
      for (sz = skip; sz >= step; sz -= step)				\
	BASE##_ENCRYPT(r, &ctx, 0, 0, step);				\
      if (sz) BASE##_ENCRYPT(r, &ctx, 0, 0, sz);			\
      for (p = p0, q = (octet *)d.buf, sz = sz0;			\
	   sz >= step;							\
	   sz -= step, q += step) {					\
	BASE##_ENCRYPT(r, &ctx, p, q, step);				\
	if (p) p += step;						\
      }									\
      if (sz) BASE##_ENCRYPT(r, &ctx, p, q, sz);			\
									\
      if (d.len != v[5].len || memcmp(d.buf, v[5].buf, v[5].len) != 0) { \
	ok = 0;								\
	printf("\nfail encrypt:"					\
	       "\n\tstep	   = %lu"				\
	       "\n\tkey	   = ", (unsigned long)step);			\
	type_hex.dump(&v[0], stdout);					\
	printf("\n\tnonce	   = ");				\
	type_hex.dump(&v[1], stdout);					\
	printf("\n\tposition   = ");					\
	type_hex.dump(&v[2], stdout);					\
	printf("\n\tskip	   = %lu", skip);			\
	printf("\n\tmessage    = ");					\
	type_hex.dump(&v[4], stdout);					\
	printf("\n\texpected   = ");					\
	type_hex.dump(&v[5], stdout);					\
	printf("\n\tcalculated = ");					\
	type_hex.dump(&d, stdout);					\
	putchar('\n');							\
      }									\
    }									\
									\
    dstr_destroy(&d);							\
    return (ok);							\
  }
#define DEFVENC(r) DEFxVENC(chacha, CHACHA, r)
#define DEFXVENC(r) DEFxVENC(xchacha, XCHACHA, r)
CHACHA_VARS(DEFVENC)
CHACHA_VARS(DEFXVENC)

static test_chunk defs[] = {
#define DEFxTAB(base, r)						\
  { #base #r, v_encrypt_##base##_##r,					\
    { &type_hex, &type_hex, &type_hex, &type_ulong,			\
      &type_hex, &type_hex, 0 } },
#define DEFTAB(r)							\
  { "chacha" #r "-core", v_core_##r,					\
    { &type_int, &type_hex, &type_hex, 0 } },				\
  DEFxTAB(chacha, r)
#define DEFXTAB(r) DEFxTAB(xchacha, r)
CHACHA_VARS(DEFTAB)
CHACHA_VARS(DEFXTAB)
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  test_run(argc, argv, defs, SRCDIR"/t/chacha");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
