/* -*-c-*-
 *
 * Definitions for the MGF-1 mask generator
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MGF_DEF_H
#define CATACOMB_MGF_DEF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/bits.h>
#include <mLib/sub.h>

#ifndef CATACOMB_ARENA_H
#  include "arena.h"
#endif

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

#ifndef CATACOMB_PARANOIA_H
#  include "paranoia.h"
#endif

/*----- Macros ------------------------------------------------------------*/

#define MGF_DEF(PRE, pre)						\
									\
/* --- Useful constants --- */						\
									\
const octet pre##_mgfkeysz[] = { KSZ_ANY, PRE##_HASHSZ };		\
									\
/* --- @pre_mgfkeybegin@, @pre_mgfkeyadd@ --- *				\
 *									\
 * Arguments:	@pre_mgfctx *k@ = pointer to context to initialize	\
 *		@const void *p@ = pointer to data to contribute		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		A multi-step keying procedure for initializing an MGF	\
 *		context.  The data is contributed to a hashing context	\
 *		which is then used for mask generation.  If you only	\
 *		have a fixed buffer, you can save a lot of effort by	\
 *		simply calling @pre_mgfinit@.				\
 */									\
									\
void pre##_mgfkeybegin(pre##_mgfctx *k)					\
{									\
  k->c = 0;								\
  k->bsz = 0;								\
  pre##_init(&k->k);							\
}									\
									\
void pre##_mgfkeyadd(pre##_mgfctx *k, const void *p, size_t sz)		\
{									\
  pre##_hash(&k->k, p, sz);						\
}									\
									\
/* ---- @pre_mgfinit@ --- *						\
 *									\
 * Arguments:	@pre_mgfctx *k@ = pointer to context to initialize	\
 *		@const void *p@ = pointer to data to contribute		\
 *		@size_t sz@ = size of data to contribute		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		A simpler interface to initialization if all of your	\
 *		keying material is in one place.			\
 */									\
									\
void pre##_mgfinit(pre##_mgfctx *k, const void *p, size_t sz)		\
{									\
  k->c = 0;								\
  k->bsz = 0;								\
  pre##_init(&k->k);							\
  pre##_hash(&k->k, p, sz);						\
}									\
									\
/* --- @pre_mgfencrypt@ --- *						\
 *									\
 * Arguments:	@pre_mgfctx *k@ = pointer to masking context		\
 *		@const void *s@ = pointer to source buffer		\
 *		@void *d@ = pointer to destination buffer		\
 *		@size_t sz@ = size of buffers				\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Outputs pseudorandom data, or masks an input buffer.	\
 *									\
 *		If @s@ is nonzero, the source material is exclusive-	\
 *		orred with the generated mask.  If @d@ is zero, the	\
 *		generator is simply spun around for a while, which	\
 *		isn't very useful.					\
 */									\
									\
void pre##_mgfencrypt(pre##_mgfctx *k, const void *s,			\
		      void *d, size_t sz)				\
{									\
  const octet *ss = s;							\
  octet *dd = d;							\
									\
  /* --- Empty the buffer if there's anything there --- */		\
									\
  if (k->bsz) {								\
    const octet *p = k->buf + PRE##_HASHSZ - k->bsz;			\
    size_t n = sz > k->bsz ? k->bsz : sz;				\
    sz -= n;								\
    k->bsz -= n;							\
    if (dd) {								\
      if (!ss) {							\
	memcpy(dd, p, n);						\
	dd += n;							\
      } else {								\
	while (n) {							\
	  *dd++ = *ss++ ^ *p++;						\
	  n--;								\
	}								\
      }									\
    }									\
  }									\
									\
  /* --- While necessary, generate some more mask --- */		\
									\
  while (sz) {								\
    pre##_ctx c = k->k;		/* Not quick! */			\
    size_t n;								\
									\
    STORE32(k->buf, k->c);						\
    k->c++;								\
    pre##_hash(&c, k->buf, 4);						\
    pre##_done(&c, k->buf);						\
    n = sz > PRE##_HASHSZ ? PRE##_HASHSZ : sz;				\
    k->bsz = PRE##_HASHSZ - n;						\
    sz -= n;								\
    if (dd) {								\
      const octet *p = k->buf;						\
      if (!ss) {							\
	memcpy(dd, p, n);						\
	dd += n;							\
      } else {								\
	while (n) {							\
	  *dd++ = *ss++ ^ *p++;						\
	  n--;								\
	}								\
      }									\
    }									\
  }									\
}									\
									\
/* --- @pre_mgfsetindex@ --- *						\
 *									\
 * Arguments:	@pre_mgfctx *k@ = pointer to masking context		\
 *		@uint32 *c@ = new index to set				\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets a new index.  This may be used to step around the	\
 *		output stream in a rather crude way.			\
 */									\
									\
void pre##_mgfsetindex(pre##_mgfctx *k, uint32 c)			\
{									\
  k->c = c;								\
  k->bsz = 0;								\
}									\
									\
/* --- Generic cipher interface --- */					\
									\
static const gcipher_ops gops;						\
									\
typedef struct gctx {							\
  gcipher c;								\
  pre##_mgfctx k;							\
} gctx;									\
									\
static gcipher *ginit(const void *k, size_t sz)				\
{									\
  gctx *g = S_CREATE(gctx);						\
  g->c.ops = &gops;							\
  pre##_mgfinit(&g->k, k, sz);						\
  return (&g->c);							\
}									\
									\
static void gencrypt(gcipher *c, const void *s, void *t, size_t sz)	\
{									\
  gctx *g = (gctx *)c;							\
  pre##_mgfencrypt(&g->k, s, t, sz);					\
}									\
									\
static void gdestroy(gcipher *c)					\
{									\
  gctx *g = (gctx *)c;							\
  BURN(*g);								\
  S_DESTROY(g);								\
}									\
									\
static const gcipher_ops gops = {					\
  &pre##_mgf,								\
  gencrypt, gencrypt, gdestroy, 0, 0					\
};									\
									\
const gccipher pre##_mgf = {						\
  #pre "-mgf", pre##_mgfkeysz, 0,					\
  ginit									\
};									\
									\
/* --- Generic random number generator interface --- */			\
									\
typedef struct grctx {							\
  grand r;								\
  pre##_mgfctx k;							\
} grctx;								\
									\
static void grdestroy(grand *r)						\
{									\
  grctx *g = (grctx *)r;						\
  BURN(*g);								\
  S_DESTROY(g);								\
}									\
									\
static int grmisc(grand *r, unsigned op, ...)				\
{									\
  grctx *g = (grctx *)r;						\
  va_list ap;								\
  int rc = 0;								\
  va_start(ap, op);							\
									\
  switch (op) {								\
    case GRAND_CHECK:							\
      switch (va_arg(ap, unsigned)) {					\
	case GRAND_CHECK:						\
	case GRAND_SEEDINT:						\
	case GRAND_SEEDUINT32:						\
	case GRAND_SEEDBLOCK:						\
	case GRAND_SEEDRAND:						\
	  rc = 1;							\
	  break;							\
	default:							\
	  rc = 0;							\
	  break;							\
      }									\
      break;								\
    case GRAND_SEEDINT:							\
      pre##_mgfsetindex(&g->k, va_arg(ap, unsigned));			\
      break;								\
    case GRAND_SEEDUINT32:						\
      pre##_mgfsetindex(&g->k, va_arg(ap, uint32));			\
      break;								\
    case GRAND_SEEDBLOCK: {						\
      const void *p = va_arg(ap, const void *);				\
      size_t sz = va_arg(ap, size_t);					\
      pre##_hash(&g->k.k, p, sz);					\
    } break;								\
    case GRAND_SEEDRAND: {						\
      octet buf[PRE##_BUFSZ];						\
      grand *rr = va_arg(ap, grand *);					\
      rr->ops->fill(rr, buf, sizeof(buf));				\
      pre##_hash(&g->k.k, buf, sizeof(buf));				\
    } break;								\
    default:								\
      GRAND_BADOP;							\
      break;								\
  }									\
									\
  va_end(ap);								\
  return (rc);								\
}									\
									\
static octet grbyte(grand *r)						\
{									\
  grctx *g = (grctx *)r;						\
  octet o;								\
  pre##_mgfencrypt(&g->k, 0, &o, 1);					\
  return (o);								\
}									\
									\
static uint32 grword(grand *r)						\
{									\
  grctx *g = (grctx *)r;						\
  octet b[4];								\
  pre##_mgfencrypt(&g->k, 0, b, sizeof(b));				\
  return (LOAD32(b));							\
}									\
									\
static void grfill(grand *r, void *p, size_t sz)			\
{									\
  grctx *g = (grctx *)r;						\
  pre##_mgfencrypt(&g->k, 0, p, sz);					\
}									\
									\
static const grand_ops grops = {					\
  #pre "-mgf",								\
  GRAND_CRYPTO, 0,							\
  grmisc, grdestroy,							\
  grword, grbyte, grword, grand_range, grfill				\
};									\
									\
/* --- @pre_mgfrand@ --- *						\
 *									\
 * Arguments:	@const void *k@ = pointer to key material		\
 *		@size_t sz@ = size of key material			\
 *									\
 * Returns:	Pointer to a generic random number generator instance.	\
 *									\
 * Use:		Creates a random number interface wrapper around an	\
 *		MGF-1-mode hash function.				\
 */									\
									\
extern grand *pre##_mgfrand(const void *k, size_t sz)			\
{									\
  grctx *g = S_CREATE(grctx);						\
  g->r.ops = &grops;							\
  pre##_mgfinit(&g->k, k, sz);						\
  return (&g->r);							\
}									\
									\
MGF_TEST(PRE, pre)

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#include <stdio.h>

#include "daftstory.h"

/* --- @MGF_TEST@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for block cipher definitions
 *
 * Use:		Standard test rig for MGF functions.
 */

#define MGF_TEST(PRE, pre)						\
									\
/* --- Initial plaintext for the test --- */				\
									\
static const octet text[] = TEXT;					\
									\
/* --- Key and IV to use --- */						\
									\
static const octet key[] = KEY;						\
									\
/* --- Buffers for encryption and decryption output --- */		\
									\
static octet ct[sizeof(text)];						\
static octet pt[sizeof(text)];						\
									\
static void hexdump(const octet *p, size_t sz)				\
{									\
  const octet *q = p + sz;						\
  for (sz = 0; p < q; p++, sz++) {					\
    printf("%02x", *p);							\
    if ((sz + 1) % PRE##_HASHSZ == 0)					\
      putchar(':');							\
  }									\
}									\
									\
int main(void)								\
{									\
  size_t sz = 0, rest;							\
  pre##_mgfctx ctx;							\
  int status = 0;							\
  int done = 0;								\
									\
  size_t keysz = strlen((const char *)key);				\
									\
  fputs(#pre "-mgf: ", stdout);						\
									\
  pre##_mgfinit(&ctx, key, keysz);					\
									\
  while (sz <= sizeof(text)) {						\
    rest = sizeof(text) - sz;						\
    memcpy(ct, text, sizeof(text));					\
    pre##_mgfsetindex(&ctx, 0);						\
    pre##_mgfencrypt(&ctx, ct, ct, sz);					\
    pre##_mgfencrypt(&ctx, ct + sz, ct + sz, rest);			\
    memcpy(pt, ct, sizeof(text));					\
    pre##_mgfsetindex(&ctx, 0);						\
    pre##_mgfencrypt(&ctx, pt, pt, rest);				\
    pre##_mgfencrypt(&ctx, pt + rest, pt + rest, sz);			\
    if (memcmp(pt, text, sizeof(text)) == 0) {				\
      done++;								\
      if (sizeof(text) < 40 || done % 8 == 0)				\
	fputc('.', stdout);						\
      if (done % 480 == 0)						\
	fputs("\n\t", stdout);						\
      fflush(stdout);							\
    } else {								\
      printf("\nError (sz = %lu)\n", (unsigned long)sz);		\
      status = 1;							\
      printf("\tplaintext      = "); hexdump(text, sz);			\
	printf(", "); hexdump(text + sz, rest);				\
	fputc('\n', stdout);						\
      printf("\tciphertext     = "); hexdump(ct, sz);			\
	printf(", "); hexdump(ct + sz, rest);				\
	fputc('\n', stdout);						\
      printf("\trecovered text = "); hexdump(pt, sz);			\
	printf(", "); hexdump(pt + sz, rest);				\
	fputc('\n', stdout);						\
      fputc('\n', stdout);						\
    }									\
    if (sz < 63)							\
      sz++;								\
    else								\
      sz += 9;								\
  }									\
									\
  fputs(status ? " failed\n" : " ok\n", stdout);			\
  return (status);							\
}

#else
#  define MGF_TEST(PRE, pre)
#endif

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
