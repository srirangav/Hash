/* -*-c-*-
 *
 * Internal header for Rijndael implementation
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_RIJNDAEL_BASE_H
#define CATACOMB_RIJNDAEL_BASE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

/*----- Constant tables ---------------------------------------------------*/

extern const octet rijndael_s[256];
extern const octet rijndael_si[256];
extern const uint32 rijndael_t[4][256];
extern const uint32 rijndael_ti[4][256];
extern const uint32 rijndael_u[4][256];
extern const octet rijndael_rcon[];

#define S rijndael_s
#define SI rijndael_si
#define T rijndael_t
#define TI rijndael_ti
#define U rijndael_u
#define RCON rijndael_rcon

/*----- Handy macros ------------------------------------------------------*/

#define SUB(s, a, b, c, d)						\
  (s[U8((a) >> 24)] << 24 | s[U8((b) >> 16)] << 16 |			\
   s[U8((c) >>	8)] <<	8 | s[U8((d) >>	 0)] <<	 0)

#define MIX(t, a, b, c, d)						\
   (t[0][U8((a) >> 24)] ^ t[1][U8((b) >> 16)] ^				\
    t[2][U8((c) >>  8)] ^ t[3][U8((d) >>  0)])

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
