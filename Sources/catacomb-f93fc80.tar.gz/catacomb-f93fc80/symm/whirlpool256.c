/* -*-c-*-
 *
 * Stub code for Whirlpool-256
 */

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "whirlpool256.h"

GHASH_DEF(WHIRLPOOL256, whirlpool256)
HASH_TEST(WHIRLPOOL256, whirlpool256)
