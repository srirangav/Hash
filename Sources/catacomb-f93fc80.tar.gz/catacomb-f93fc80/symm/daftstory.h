/* -*-c-*-
 *
 * Daft story for use in test encryptions
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_DAFTSTORY_H
#define CATACOMB_DAFTSTORY_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Macros ------------------------------------------------------------*/

/* --- Don't ask --- */

#ifdef SMALL_TEST
#  define TEXT "A small piece of text for testing encryption."
#else
#  define STORY "\
Once upon a time there were a beautiful princess, a slightly nutty wizard,\n\
and a watermelon.  Now, the watermelon had decided that it probably wasn't\n\
going to get very far with the princess unless it did something pretty\n\
drastic.  So it asked the wizard to turn it into a handsome prince.\n\
\n\
At least, this is the way that the wizard viewed the situation.  He might\n\
have just hallucinated it all; those mushrooms had looked ever so nice.\n\
\n\
Back to the point.  The watermelon had expressed its desire not to be a\n\
watermelon any more.  And the wizard was probably tripping something quite\n\
powerful.  He hunted around a bit for his staff, and mumbled something\n\
that film directors would think of as sounding appropriately arcane and\n\
mystical (but was, in fact, just the ingredients list for an ancient\n\
remedy for athlete's foot) and *pop*.  Cooked watermelon.  Yuk.\n\
\n\
Later in the year, the princess tripped over the hem of her dress, fell\n\
down a spiral staircase, and died.  The king ordered dressmakers to attach\n\
safety warnings to long dresses.\n\
\n\
And the wizard?	 Who cares?\n\
"
#  define TEXT STORY STORY
#endif

#define KEY "Penguins rule OK, rhubarb cauliflower"
#define IV "EdgewareCatacomb, parsley, sage, rosemary and thyme"

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
