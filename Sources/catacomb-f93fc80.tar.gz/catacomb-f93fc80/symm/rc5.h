/* -*-c-*-
 *
 * The RC5-32/12 block cipher
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the RC5 block cipher -------------------------------------*
 *
 * RC5 was designed by Ron Rivest as a test vehicle for the use of data-
 * dependent rotations in cryptographic transformations.  The algorithm is
 * covered by a patent held by RSA Security Inc. (US Patent# 5,724,428).
 * It's vulnerable to some clever differential attacks, which can break it in
 * about %$2^{44}$% chosen plaintexts.  I don't recommend the use of this
 * cipher.
 */

#ifndef CATACOMB_RC5_H
#define CATACOMB_RC5_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

/*----- Magic numbers -----------------------------------------------------*/

#define RC5_ROUNDS 12
#define RC5_KEYSZ 10
#define RC5_BLKSZ 8
#define RC5_CLASS (N, L, 64)

extern const octet rc5_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct rc5_ctx {
  uint32 s[2 * (RC5_ROUNDS + 1)];
} rc5_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @rc5_init@ --- *
 *
 * Arguments:	@rc5_ctx *k@ = pointer to a key block
 *		@const void *sbuf@ = pointer to key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes an RC5 key block.
 */

extern void rc5_init(rc5_ctx */*k*/, const void */*sbuf*/, size_t /*sz*/);

/* --- @rc5_eblk@, @rc5_dblk@ --- *
 *
 * Arguments:	@const rc5_ctx *k@ = pointer to RC5 context block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 *d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low level block encryption and decryption.
 */

extern void rc5_eblk(const rc5_ctx */*k*/,
		     const uint32 */*s*/, uint32 */*d*/);
extern void rc5_dblk(const rc5_ctx */*k*/,
		     const uint32 */*s*/, uint32 */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
