/* -*-c-*-
 *
 * The MARS block cipher
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>

#include <mLib/bits.h>

#include "blkc.h"
#include "gcipher.h"
#include "mars.h"
#include "paranoia.h"

/*----- Global variables --------------------------------------------------*/

const octet mars_keysz[] = { KSZ_RANGE, MARS_KEYSZ, 0, 56, 4 };

/*----- Useful tables -----------------------------------------------------*/

extern const uint32 mars_s[512];
#define s0 (mars_s +   0)
#define s1 (mars_s + 256)
#define bb (mars_s + 265)

/*----- Main code ---------------------------------------------------------*/

/* --- @mars_init@ --- *
 *
 * Arguments:	@mars_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a MARS key buffer.  MARS accepts key sizes
 *		between 128 and 448 bits which are a multiple of 32 bits.
 */

void mars_init(mars_ctx *k, const void *buf, size_t sz)
{
  uint32 t[15];
  uint32 *kk = k->k;
  const octet *p;
  unsigned i, j, ii;

  KSZ_ASSERT(mars, sz);

  /* --- Copy the key into the temporary buffer --- */

  p = buf;
  for (i = 0; i < sz/4; i++) {
    t[i] = LOAD32_L(p);
    p += 4;
  }
  t[i++] = sz/4;
  for (; i < 15; i++)
    t[i] = 0;

  /* --- Now spit out the actual key material --- */

  for (j = 0; j < 4; j++) {
    uint32 x;

    /* --- Do the linear mixing stage --- */

    for (i = 0; i < 15; i++) {
      x = t[(i + 8)%15] ^ t[(i + 13)%15];
      t[i] ^= ROL32(x, 3) ^ ((i << 2) | j);
    }

    /* --- Now do the Feistel stirring stage --- */

    x = t[14];
    for (ii = 0; ii < 4; ii++) {
      for (i = 0; i < 15; i++) {
	x = t[i] + mars_s[x & 511u];
	t[i] = x = ROL32(x, 9);
      }
    }

    /* --- And spit out the key material --- */

    for (i = 0; i < 10; i++)
      *kk++ = t[(4 * i)%15];
  }

  /* --- Finally, fix up the multiplicative entries --- */

  for (i = 5; i < 37; i += 2) {
    uint32 w, m, x;
    j = k->k[i] & 3u;
    w = k->k[i] | 3u;

    /* --- Compute the magic mask value --- */

    m = 0;
    for (ii = 0; ii <= 22; ii++) {
      x = w >> ii;
      if ((x & 0x3ff) == 0x3ff || (x & 0x3ff) == 0)
	m |= 0x3ff << ii;
    }
    m &= ~(((w ^ (w << 1)) | (w ^ (w >> 1))) | 0x80000003);

    /* --- Add in the bias entry to fix up the key --- */

    x = ROL32(bb[j], k->k[i - 1]);
    k->k[i] = w ^ (x & m);
  }
}

/* --- @mars_eblk@, @mars_dblk@ --- *
 *
 * Arguments:	@const mars_ctx *k@ = pointer to key block
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

#define KADD(k, a, b, c, d)  a += *k++, b += *k++, c += *k++, d += *k++
#define KSUB(k, a, b, c, d)  a -= *k++, b -= *k++, c -= *k++, d -= *k++
#define IKADD(k, a, b, c, d) d += *--k, c += *--k, b += *--k, a += *--k
#define IKSUB(k, a, b, c, d) d -= *--k, c -= *--k, b -= *--k, a -= *--k

#define MIX(a, b, c, d) do {						\
  b ^= s0[(a >>	 0) & 0xff];						\
  b += s1[(a >>	 8) & 0xff];						\
  c += s0[(a >> 16) & 0xff];						\
  d ^= s1[(a >> 24) & 0xff];						\
  a = ROL32(a, 8);							\
} while (0)

#define IMIX(a, b, c, d) do {						\
  a = ROR32(a, 8);							\
  d ^= s1[(a >> 24) & 0xff];						\
  c -= s0[(a >> 16) & 0xff];						\
  b -= s1[(a >>	 8) & 0xff];						\
  b ^= s0[(a >>	 0) & 0xff];						\
} while (0)

#define E(x, y, z, k, a) do {						\
  uint32 kx = *k++, ky = *k++;						\
  y = a + kx;								\
  a = ROL32(a, 13); z = a * ky; z = ROL32(z, 5);			\
  x = mars_s[y & 511u] ^ z; y = ROL32(y, z);				\
  z = ROL32(z, 5); x ^= z; x = ROL32(x, z);				\
} while (0)

#define IE(x, y, z, k, a) do {						\
  uint32 ky = *--k, kx = *--k;						\
  z = a * ky;								\
  a = ROR32(a, 13); y = a + kx; z = ROL32(z, 5);			\
  x = mars_s[y & 511u] ^ z; y = ROL32(y, z);				\
  z = ROL32(z, 5); x ^= z; x = ROL32(x, z);				\
} while (0)

#define ROUND(k, a, b, c, d) do {					\
  uint32 x, y, z;							\
  E(x, y, z, k, a);							\
  b += x; c += y; d ^= z;						\
} while (0)

#define IROUND(k, a, b, c, d) do {					\
  uint32 x, y, z;							\
  IE(x, y, z, k, a);							\
  b -= x; c -= y; d ^= z;						\
} while (0)

void mars_eblk(const mars_ctx *k, const uint32 *src, uint32 *dst)
{
  uint32 a, b, c, d;
  const uint32 *kk = k->k;

  a = src[0], b = src[1], c = src[2], d = src[3];
  KADD(kk, a, b, c, d);

  MIX(a, b, c, d); a += d; MIX(b, c, d, a); b += c;
  MIX(c, d, a, b); MIX(d, a, b, c);
  MIX(a, b, c, d); a += d; MIX(b, c, d, a); b += c;
  MIX(c, d, a, b); MIX(d, a, b, c);

  ROUND(kk, a, b, c, d); ROUND(kk, b, c, d, a);
  ROUND(kk, c, d, a, b); ROUND(kk, d, a, b, c);
  ROUND(kk, a, b, c, d); ROUND(kk, b, c, d, a);
  ROUND(kk, c, d, a, b); ROUND(kk, d, a, b, c);

  ROUND(kk, a, d, c, b); ROUND(kk, b, a, d, c);
  ROUND(kk, c, b, a, d); ROUND(kk, d, c, b, a);
  ROUND(kk, a, d, c, b); ROUND(kk, b, a, d, c);
  ROUND(kk, c, b, a, d); ROUND(kk, d, c, b, a);

  IMIX(a, d, c, b); IMIX(b, a, d, c);
  c -= b; IMIX(c, b, a, d); d -= a; IMIX(d, c, b, a);
  IMIX(a, d, c, b); IMIX(b, a, d, c);
  c -= b; IMIX(c, b, a, d); d -= a; IMIX(d, c, b, a);

  KSUB(kk, a, b, c, d);
  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d;
}

void mars_dblk(const mars_ctx *k, const uint32 *src, uint32 *dst)
{
  uint32 a, b, c, d;
  const uint32 *kk = k->k + 40;

  a = src[0], b = src[1], c = src[2], d = src[3];
  IKADD(kk, a, b, c, d);

  MIX(d, c, b, a); d += a; MIX(c, b, a, d); c += b;
  MIX(b, a, d, c); MIX(a, d, c, b);
  MIX(d, c, b, a); d += a; MIX(c, b, a, d); c += b;
  MIX(b, a, d, c); MIX(a, d, c, b);

  IROUND(kk, d, c, b, a); IROUND(kk, c, b, a, d);
  IROUND(kk, b, a, d, c); IROUND(kk, a, d, c, b);
  IROUND(kk, d, c, b, a); IROUND(kk, c, b, a, d);
  IROUND(kk, b, a, d, c); IROUND(kk, a, d, c, b);

  IROUND(kk, d, a, b, c); IROUND(kk, c, d, a, b);
  IROUND(kk, b, c, d, a); IROUND(kk, a, b, c, d);
  IROUND(kk, d, a, b, c); IROUND(kk, c, d, a, b);
  IROUND(kk, b, c, d, a); IROUND(kk, a, b, c, d);

  IMIX(d, a, b, c); IMIX(c, d, a, b);
  b -= c; IMIX(b, c, d, a); a -= d; IMIX(a, b, c, d);
  IMIX(d, a, b, c); IMIX(c, d, a, b);
  b -= c; IMIX(b, c, d, a); a -= d; IMIX(a, b, c, d);

  IKSUB(kk, a, b, c, d);
  dst[0] = a; dst[1] = b; dst[2] = c; dst[3] = d;
}

BLKC_TEST(MARS, mars)

/*----- That's all, folks -------------------------------------------------*/
