/* -*-c-*-
 *
 * Common definitions for the Tiger hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_TIGER_BASE_H
#define CATACOMB_TIGER_BASE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

/*----- Macros provided ---------------------------------------------------*/

/* --- The guts of a single round --- */

#define TIGER_ROUND(a, b, c, x, n, op) do {				\
  kludge64 _t;								\
  XOR64(c, c, x);							\
  _t =		tiger_s[0][U8(LO64(c) >>  0)];				\
  XOR64(_t, _t, tiger_s[1][U8(LO64(c) >> 16)]);				\
  XOR64(_t, _t, tiger_s[2][U8(HI64(c) >>  0)]);				\
  XOR64(_t, _t, tiger_s[3][U8(HI64(c) >> 16)]);				\
  SUB64(a, a, _t);							\
  _t =		tiger_s[3][U8(LO64(c) >>  8)];				\
  XOR64(_t, _t, tiger_s[2][U8(LO64(c) >> 24)]);				\
  XOR64(_t, _t, tiger_s[1][U8(HI64(c) >>  8)]);				\
  XOR64(_t, _t, tiger_s[0][U8(HI64(c) >> 24)]);				\
  ADD64(b, b, _t);							\
  LSL64_(_t, b, n);							\
  op##64(b, _t, b);							\
} while (0)

/* --- One pass over the buffer --- */

#define TIGER_PASS(a, b, c, x, n, op) do {				\
  TIGER_ROUND(a, b, c, x[0], n, op);					\
  TIGER_ROUND(b, c, a, x[1], n, op);					\
  TIGER_ROUND(c, a, b, x[2], n, op);					\
  TIGER_ROUND(a, b, c, x[3], n, op);					\
  TIGER_ROUND(b, c, a, x[4], n, op);					\
  TIGER_ROUND(c, a, b, x[5], n, op);					\
  TIGER_ROUND(a, b, c, x[6], n, op);					\
  TIGER_ROUND(b, c, a, x[7], n, op);					\
} while (0)

/* --- A step in the `key schedule' --- */

#define TIGER_KSTEP(a, b, c, d, op, n) do {				\
  kludge64 _u;								\
  XOR64(b, b, a);							\
  ADD64(c, c, b);							\
  CPL64(_u, b); op##64_(_u, _u, n); XOR64(_u, _u, c); SUB64(d, d, _u);	\
} while (0)

/* --- The `key schedule' -- mangle the buffer --- */

#define TIGER_KSCHED(x) do {						\
  kludge64 _t;								\
									\
  SET64(_t, 0xa5a5a5a5, 0xa5a5a5a5);					\
  XOR64(_t, _t, x[7]); SUB64(x[0], x[0], _t);				\
  TIGER_KSTEP(x[0], x[1], x[2], x[3], LSL, 19);				\
  TIGER_KSTEP(x[3], x[4], x[5], x[6], LSR, 23);				\
  TIGER_KSTEP(x[6], x[7], x[0], x[1], LSL, 19);				\
  TIGER_KSTEP(x[1], x[2], x[3], x[4], LSR, 23);				\
  XOR64(x[5], x[5], x[4]);						\
  ADD64(x[6], x[6], x[5]);						\
  SET64(_t, 0x01234567, 0x89abcdef);					\
  XOR64(_t, _t, x[6]); SUB64(x[7], x[7], _t);				\
} while (0)

/* --- The Tiger compression function --- */

#define TIGER_CORE(a, b, c, x) do {					\
  kludge64 _a, _b, _c;							\
  _a = a, _b = b, _c = c;						\
  TIGER_PASS(_a, _b, _c, x, 2, ADD);					\
  TIGER_KSCHED(x);							\
  TIGER_PASS(_c, _a, _b, x, 3, SUB);					\
  TIGER_KSCHED(x);							\
  TIGER_PASS(_b, _c, _a, x, 3, ADD);					\
  XOR64(a, _a, a); SUB64(b, _b, b); ADD64(c, _c, c);			\
} while (0)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
