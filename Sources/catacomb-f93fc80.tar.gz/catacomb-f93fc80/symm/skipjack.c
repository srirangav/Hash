/* -*-c-*-
 *
 * The Skipjack block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "blkc.h"
#include "gcipher.h"
#include "skipjack.h"

/*----- Global variables --------------------------------------------------*/

const octet skipjack_keysz[] = { KSZ_SET, 10, 0 };

/*----- The Skipjack S-box ------------------------------------------------*/

extern const octet skipjack_s[256];

/*----- Main code ---------------------------------------------------------*/

/* --- @skipjack_init@ --- *
 *
 * Arguments:	@skipjack_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Skipjack key buffer.  The key buffer must be
 *		exactly 10 bytes long.
 */

void skipjack_init(skipjack_ctx *k, const void *buf, size_t sz)
{
  const octet *b = buf;
  uint32 crud;
  KSZ_ASSERT(skipjack, sz);
  k->ka = LOAD32(b);
  k->kb = LOAD32(b + 4);
  crud = LOAD16(b + 8);
  k->kc = U32((crud << 16) | (k->ka >> 16));
  k->kd = U32((k->ka << 16) | (k->kb >> 16));
  k->ke = U32((k->kb << 16) | crud);
  crud = 0;
}

/* --- @skipjack_eblk@, @skipjack_dblk@ --- *
 *
 * Arguments:	@const skipjack_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to skipjacktination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

#define G(x, k) do {							\
  octet _x = U8(x >> 8), _y = U8(x);					\
  _x ^= skipjack_s[_y ^ U8(k >> 24)];					\
  _y ^= skipjack_s[_x ^ U8(k >> 16)];					\
  _x ^= skipjack_s[_y ^ U8(k >>	 8)];					\
  _y ^= skipjack_s[_x ^ U8(k >>	 0)];					\
  x = (_x << 8) | _y;							\
} while (0)

#define RULE_A(w, x, y, z, n, k) do {					\
  G(w, k); z ^= w ^ n++;						\
} while (0)

#define RULE_B(w, x, y, z, n, k) do {					\
  x ^= w ^ n++; G(w, k);						\
} while (0)

void skipjack_eblk(const skipjack_ctx *k, const uint32 *s, uint32 *d)
{
  unsigned n = 1;
  uint16 w = U16(s[0] >> 16), x = U16(s[0]);
  uint16 y = U16(s[1] >> 16), z = U16(s[1]);
  uint32 ka = k->ka, kb = k->kb, kc = k->kc, kd = k->kd, ke = k->ke;

  RULE_A(w, x, y, z, n, ka); RULE_A(z, w, x, y, n, kb);
  RULE_A(y, z, w, x, n, kc); RULE_A(x, y, z, w, n, kd);
  RULE_A(w, x, y, z, n, ke); RULE_A(z, w, x, y, n, ka);
  RULE_A(y, z, w, x, n, kb); RULE_A(x, y, z, w, n, kc);
  RULE_B(w, x, y, z, n, kd); RULE_B(z, w, x, y, n, ke);
  RULE_B(y, z, w, x, n, ka); RULE_B(x, y, z, w, n, kb);
  RULE_B(w, x, y, z, n, kc); RULE_B(z, w, x, y, n, kd);
  RULE_B(y, z, w, x, n, ke); RULE_B(x, y, z, w, n, ka);
  RULE_A(w, x, y, z, n, kb); RULE_A(z, w, x, y, n, kc);
  RULE_A(y, z, w, x, n, kd); RULE_A(x, y, z, w, n, ke);
  RULE_A(w, x, y, z, n, ka); RULE_A(z, w, x, y, n, kb);
  RULE_A(y, z, w, x, n, kc); RULE_A(x, y, z, w, n, kd);
  RULE_B(w, x, y, z, n, ke); RULE_B(z, w, x, y, n, ka);
  RULE_B(y, z, w, x, n, kb); RULE_B(x, y, z, w, n, kc);
  RULE_B(w, x, y, z, n, kd); RULE_B(z, w, x, y, n, ke);
  RULE_B(y, z, w, x, n, ka); RULE_B(x, y, z, w, n, kb);

  d[0] = ((uint32)w << 16) | (uint32)x;
  d[1] = ((uint32)y << 16) | (uint32)z;
}

#define G_INV(x, k) do {						\
  octet _x = U8(x >> 8), _y = U8(x);					\
  _y ^= skipjack_s[_x ^ U8(k >>	 0)];					\
  _x ^= skipjack_s[_y ^ U8(k >>	 8)];					\
  _y ^= skipjack_s[_x ^ U8(k >> 16)];					\
  _x ^= skipjack_s[_y ^ U8(k >> 24)];					\
  x = (_x << 8) | _y;							\
} while (0)

#define RULE_A_INV(w, x, y, z, n, i) do {				\
  w ^= x ^ --n; G_INV(x, i);						\
} while (0)

#define RULE_B_INV(w, x, y, z, n, i) do {				\
  G_INV(x, i); y ^= x ^ --n;						\
} while (0)

void skipjack_dblk(const skipjack_ctx *k, const uint32 *s, uint32 *d)
{
  unsigned n = 33;
  uint16 w = U16(s[0] >> 16), x = U16(s[0]);
  uint16 y = U16(s[1] >> 16), z = U16(s[1]);
  uint32 ka = k->ka, kb = k->kb, kc = k->kc, kd = k->kd, ke = k->ke;

  RULE_B_INV(w, x, y, z, n, kb); RULE_B_INV(x, y, z, w, n, ka);
  RULE_B_INV(y, z, w, x, n, ke); RULE_B_INV(z, w, x, y, n, kd);
  RULE_B_INV(w, x, y, z, n, kc); RULE_B_INV(x, y, z, w, n, kb);
  RULE_B_INV(y, z, w, x, n, ka); RULE_B_INV(z, w, x, y, n, ke);
  RULE_A_INV(w, x, y, z, n, kd); RULE_A_INV(x, y, z, w, n, kc);
  RULE_A_INV(y, z, w, x, n, kb); RULE_A_INV(z, w, x, y, n, ka);
  RULE_A_INV(w, x, y, z, n, ke); RULE_A_INV(x, y, z, w, n, kd);
  RULE_A_INV(y, z, w, x, n, kc); RULE_A_INV(z, w, x, y, n, kb);
  RULE_B_INV(w, x, y, z, n, ka); RULE_B_INV(x, y, z, w, n, ke);
  RULE_B_INV(y, z, w, x, n, kd); RULE_B_INV(z, w, x, y, n, kc);
  RULE_B_INV(w, x, y, z, n, kb); RULE_B_INV(x, y, z, w, n, ka);
  RULE_B_INV(y, z, w, x, n, ke); RULE_B_INV(z, w, x, y, n, kd);
  RULE_A_INV(w, x, y, z, n, kc); RULE_A_INV(x, y, z, w, n, kb);
  RULE_A_INV(y, z, w, x, n, ka); RULE_A_INV(z, w, x, y, n, ke);
  RULE_A_INV(w, x, y, z, n, kd); RULE_A_INV(x, y, z, w, n, kc);
  RULE_A_INV(y, z, w, x, n, kb); RULE_A_INV(z, w, x, y, n, ka);

  d[0] = ((uint32)w << 16) | (uint32)x;
  d[1] = ((uint32)y << 16) | (uint32)z;
}

BLKC_TEST(SKIPJACK, skipjack)

/*----- That's all, folks -------------------------------------------------*/
