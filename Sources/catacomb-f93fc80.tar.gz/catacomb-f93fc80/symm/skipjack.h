/* -*-c-*-
 *
 * The Skipjack block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Skipjack block cipher --------------------------------*
 *
 * Skipjack was designed by the NSA, as a type II algorithm to be used in the
 * Clipper system.  It was initially classified, so that it couldn't be used
 * without the key escrow feature, though a team of `respectable'
 * cryptographers, including Dorothy Denning, had a quick look at it and
 * pronounced it `good', as if this was meant to be convincing.  It is
 * apparently a particular parameterization of a family which includes type I
 * algorithms.  Since declassification, Biham has discovered a miss-in-the-
 * middle attack which breaks Skipjack with 31 rounds faster than brute
 * force.
 *
 * This implementation is provided for interest's sake, and possibly for
 * interoperability, rather than as a good cipher to use.
 */

#ifndef CATACOMB_SKIPJACK_H
#define CATACOMB_SKIPJACK_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define SKIPJACK_BLKSZ 8
#define SKIPJACK_KEYSZ 10
#define SKIPJACK_CLASS (N, B, 64)

extern const octet skipjack_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct skipjack_ctx {
  uint32 ka, kb, kc, kd, ke;
} skipjack_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @skipjack_init@ --- *
 *
 * Arguments:	@skipjack_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Skipjack key buffer.  The key buffer must be
 *		exactly 10 bytes long.
 */

extern void skipjack_init(skipjack_ctx */*k*/,
			  const void */*buf*/, size_t /*sz*/);

/* --- @skipjack_eblk@, @skipjack_dblk@ --- *
 *
 * Arguments:	@const skipjack_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to skipjacktination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void skipjack_eblk(const skipjack_ctx */*k*/,
			  const uint32 */*s*/, uint32 */*d*/);
extern void skipjack_dblk(const skipjack_ctx */*k*/,
			  const uint32 */*s*/, uint32 */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
