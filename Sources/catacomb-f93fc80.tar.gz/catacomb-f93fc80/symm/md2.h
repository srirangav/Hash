/* -*-c-*-
 *
 * The MD2 message digest function
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the MD2 hash function ------------------------------------*
 *
 * MD2 was designed by Ron Rivest.  It's not recommended for new applications
 * because only the `checksum' part of the function resists collision-finding
 * attacks.  It's not very fast either.  However, it's still used in
 * standards, and having it available can be useful.
 */

#ifndef CATACOMB_MD2_H
#define CATACOMB_MD2_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

/*----- Magic numbers -----------------------------------------------------*/

#define MD2_BUFSZ 16
#define MD2_HASHSZ 16
#define MD2_STATESZ 32

/*----- Data structures ---------------------------------------------------*/

typedef struct md2_ctx {
  octet c[MD2_BUFSZ];			/* Checksum buffer */
  octet h[MD2_BUFSZ];			/* Hash result buffer */
  octet buf[MD2_BUFSZ];			/* Input buffer */
  unsigned off;				/* Offset into buffer */
} md2_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @md2_compress@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		MD2 compression function.
 */

extern void md2_compress(md2_ctx */*ctx*/, const void */*sbuf*/);

/* --- @md2_init@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

extern void md2_init(md2_ctx */*ctx*/);

/* --- @md2_set@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

extern void md2_set(md2_ctx */*ctx*/, const void */*buf*/,
		    unsigned long /*count*/);

/* --- @md2_hash@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

extern void md2_hash(md2_ctx */*ctx*/, const void */*buf*/, size_t /*sz*/);

/* --- @md2_done@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

extern void md2_done(md2_ctx */*ctx*/, void */*hash*/);

/* --- @md2_state@ --- *
 *
 * Arguments:	@md2_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @md2_set@.
 */

extern unsigned long md2_state(md2_ctx */*ctx*/, void */*state*/);

/*----- Generic hash interface --------------------------------------------*/

extern const gchash md2;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
