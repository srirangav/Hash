/* -*-c-*-
 *
 * Definitions for HMAC and NMAC
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_HMAC_DEF_H
#define CATACOMB_HMAC_DEF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/bits.h>
#include <mLib/sub.h>

#ifndef CATACOMB_ARENA_H
#  include "arena.h"
#endif

#ifndef CATACOMB_GMAC_H
#  include "gmac.h"
#endif

#ifndef CATACOMB_PARANOIA_H
#  include "paranoia.h"
#endif

/*----- Macros ------------------------------------------------------------*/

/* --- @HMAC_DEF@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for the underlying hash function
 *
 * Use:		Creates implementations for the HMAC and NMAC functions.
 */

#define HMAC_DEF(PRE, pre)						\
									\
/* --- Useful constants --- */						\
									\
const octet pre##_hmackeysz[] = { KSZ_ANY, PRE##_STATESZ };		\
const octet pre##_sslmackeysz[] = { KSZ_ANY, PRE##_STATESZ };		\
const octet pre##_nmackeysz[] = { KSZ_SET, 2 * PRE##_STATESZ, 0 };	\
									\
/* --- @pre_nmacinit@ --- *						\
 *									\
 * Arguments:	@pre_macctx *key@ = pointer to a MAC key object		\
 *		@const void *ok@ = pointer to outer hash init vector	\
 *		@const void *ik@ = pointer to inner hash init vector	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes a MAC key for doing NMAC hashing.		\
 */									\
									\
void pre##_nmacinit(pre##_mackey *key, const void *ok, const void *ik)	\
{									\
  memcpy(key->ochain, ok, PRE##_STATESZ);				\
  memcpy(key->ichain, ik, PRE##_STATESZ);				\
  key->ocount = key->icount = 0;					\
}									\
									\
/* --- @pre_hmacinit@ --- *						\
 *									\
 * Arguments:	@pre_mackey *key@ = pointer to MAC key object		\
 *		@const void *k@ = pointer to key to use			\
 *		@size_t sz@ = size of key data				\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes a MAC key for doing HMAC hashing.  Keys	\
 *		longer than the hash function's output size aren't very	\
 *		useful, but are accepted.  Keys longer than the hash's	\
 *		block size are also accepted; they are hashed before	\
 *		use, as specified in RFC2104.				\
 */									\
									\
void pre##_hmacinit(pre##_mackey *key, const void *k, size_t sz)	\
{									\
  int i;								\
  const octet *kbuf = k;						\
  pre##_ctx ctx;							\
  octet buf[PRE##_HASHSZ];						\
									\
  if (sz > PRE##_BUFSZ)	{						\
    pre##_init(&ctx);							\
    pre##_hash(&ctx, k, sz);						\
    pre##_done(&ctx, buf);						\
    kbuf = buf;								\
    sz = PRE##_HASHSZ;							\
  }									\
									\
  pre##_init(&ctx);							\
  memset(ctx.buf, 0x5c, PRE##_BUFSZ);					\
  for (i = 0; i < sz; i++)						\
    ctx.buf[i] ^= kbuf[i];						\
  pre##_compress(&ctx, ctx.buf);					\
  pre##_state(&ctx, key->ochain);					\
									\
  pre##_init(&ctx);							\
  memset(ctx.buf, 0x36, PRE##_BUFSZ);					\
  for (i = 0; i < sz; i++)						\
    ctx.buf[i] ^= kbuf[i];						\
  pre##_compress(&ctx, ctx.buf);					\
  pre##_state(&ctx, key->ichain);					\
									\
  key->ocount = key->icount = PRE##_BUFSZ;				\
  BURN(ctx);								\
}									\
									\
/* --- @pre_sslmacinit@ --- *						\
 *									\
 * Arguments:	@pre_mackey *key@ = pointer to MAC key object		\
 *		@const void *k@ = pointer to key to use			\
 *		@size_t sz@ = size of key data				\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes a MAC key for doing hasing using the SSL3	\
 *		variant of HMAC.					\
 */									\
									\
void pre##_sslmacinit(pre##_mackey *key, const void *k, size_t sz)	\
{									\
  const octet *kbuf = k;						\
  pre##_ctx ctx;							\
  octet buf[PRE##_HASHSZ];						\
									\
  if (sz > PRE##_BUFSZ)	{						\
    pre##_init(&ctx);							\
    pre##_hash(&ctx, k, sz);						\
    pre##_done(&ctx, buf);						\
    kbuf = buf;								\
    sz = PRE##_HASHSZ;							\
  }									\
									\
  pre##_init(&ctx);							\
  memcpy(ctx.buf, kbuf, sz);						\
  memset(ctx.buf + sz, 0x5c, PRE##_BUFSZ - sz);				\
  pre##_compress(&ctx, ctx.buf);					\
  pre##_state(&ctx, key->ochain);					\
									\
  pre##_init(&ctx);							\
  memcpy(ctx.buf, kbuf, sz);						\
  memset(ctx.buf + sz, 0x36, PRE##_BUFSZ - sz);				\
  pre##_compress(&ctx, ctx.buf);					\
  pre##_state(&ctx, key->ichain);					\
									\
  key->ocount = key->icount = PRE##_BUFSZ;				\
  BURN(ctx);								\
}									\
									\
/* --- @pre_macinit@ --- *						\
 *									\
 * Arguments:	@pre_macctx *ctx@ = pointer to MAC context block	\
 *		@const pre_mackey *key@ = pointer to MAC key block	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Instantiates a MAC context from a key block.		\
 */									\
									\
void pre##_macinit(pre##_macctx *ctx, const pre##_mackey *key)		\
{									\
  memcpy(ctx->chain, key->ochain, PRE##_STATESZ);			\
  ctx->count = key->ocount;						\
  pre##_set(&ctx->ctx, key->ichain, key->icount);			\
}									\
									\
/* --- @pre_machash@ --- *						\
 *									\
 * Arguments:	@pre_macctx *ctx@ = pointer to MAC context block	\
 *		@const void *buf@ = pointer to buffer			\
 *		@size_t sz@ = size of the buffer			\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Hashes a buffer.					\
 */									\
									\
void pre##_machash(pre##_macctx *ctx, const void *buf, size_t sz)	\
{									\
  pre##_hash(&ctx->ctx, buf, sz);					\
}									\
									\
/* --- @pre_macdone@ --- *						\
 *									\
 * Arguments:	@pre_macctx *ctx@ = pointer to MAC context block	\
 *		@void *mac@ = pointer to buffer to receive MAC		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Returns the result of a MAC computation.		\
 */									\
									\
void pre##_macdone(pre##_macctx *ctx, void *mac)			\
{									\
  pre##_done(&ctx->ctx, mac);						\
  pre##_set(&ctx->ctx, ctx->chain, ctx->count);				\
  pre##_hash(&ctx->ctx, mac, PRE##_HASHSZ);				\
  pre##_done(&ctx->ctx, mac);						\
}									\
									\
/* --- Generic MAC interface --- */					\
									\
static const gmac_ops gkops;						\
static const ghash_ops gops, gnops, gsslops;				\
									\
typedef struct gkctx {							\
  gmac m;								\
  const ghash_ops *gops;						\
  pre##_mackey k;							\
} gkctx;								\
									\
typedef struct gctx {							\
  ghash h;								\
  pre##_macctx c;							\
  octet buf[PRE##_HASHSZ];						\
} gctx;									\
									\
static ghash *gkinit(gmac *m)						\
{									\
  gkctx *gk = (gkctx *)m;						\
  gctx *g = S_CREATE(gctx);						\
  g->h.ops = gk->gops;							\
  pre##_macinit(&g->c, &gk->k);						\
  return (&g->h);							\
}									\
									\
static gmac *gkey(const void *k, size_t sz)				\
{									\
  gkctx *gk = S_CREATE(gkctx);						\
  gk->m.ops = &gkops;							\
  gk->gops = &gops;							\
  pre##_hmacinit(&gk->k, k, sz);					\
  return (&gk->m);							\
}									\
									\
static gmac *gnkey(const void *k, size_t sz)				\
{									\
  gkctx *gk = S_CREATE(gkctx);						\
  const octet *kk = k;							\
  assert(keysz(sz, pre##_nmackeysz) == sz);				\
  gk->m.ops = &gkops;							\
  gk->gops = &gnops;							\
  pre##_nmacinit(&gk->k, kk, kk + PRE##_STATESZ);			\
  return (&gk->m);							\
}									\
									\
static gmac *gsslkey(const void *k, size_t sz)				\
{									\
  gkctx *gk = S_CREATE(gkctx);						\
  gk->m.ops = &gkops;							\
  gk->gops = &gsslops;							\
  pre##_sslmacinit(&gk->k, k, sz);					\
  return (&gk->m);							\
}									\
									\
static void ghhash(ghash *h, const void *p, size_t sz)			\
{									\
  gctx *g = (gctx *)h;							\
  pre##_machash(&g->c, p, sz);						\
}									\
									\
static octet *ghdone(ghash *h, void *buf)				\
{									\
  gctx *g = (gctx *)h;							\
  if (!buf)								\
    buf = g->buf;							\
  pre##_macdone(&g->c, buf);						\
  return (buf);								\
}									\
									\
static ghash *ghcopy(ghash *h)						\
{									\
  gctx *g = (gctx *)h;							\
  gctx *gg = S_CREATE(gctx);						\
  memcpy(gg, g, sizeof(gctx));						\
  return (&gg->h);							\
}									\
									\
static void ghdestroy(ghash *h)						\
{									\
  gctx *g = (gctx *)h;							\
  BURN(*g);								\
  S_DESTROY(g);								\
}									\
									\
static void gkdestroy(gmac *m)						\
{									\
  gkctx *gk = (gkctx *)m;						\
  BURN(*gk);								\
  S_DESTROY(gk);							\
}									\
									\
static ghash *ghinit(void)						\
{									\
  assert(((void)"Attempt to instantiate an unkeyed MAC", 0));		\
  return (0);								\
}									\
									\
const gcmac pre##_nmac =						\
  { #pre "-nmac", PRE##_HASHSZ, pre##_nmackeysz, gnkey };		\
const gcmac pre##_hmac =						\
  { #pre "-hmac", PRE##_HASHSZ, pre##_hmackeysz, gkey };		\
const gcmac pre##_sslmac =						\
  { #pre "-sslmac", PRE##_HASHSZ, pre##_sslmackeysz, gsslkey };		\
static const gmac_ops gkops = { &pre##_hmac, gkinit, gkdestroy };	\
static const gmac_ops gnkops = { &pre##_nmac, gkinit, gkdestroy };	\
static const gmac_ops gsslkops = { &pre##_sslmac, gkinit, gkdestroy };	\
static const gchash gch = { #pre "-hmac", PRE##_HASHSZ, ghinit };	\
static const ghash_ops gops =						\
  { &gch, ghhash, ghdone, ghdestroy, ghcopy };				\
static const gchash gnch = { #pre "-nmac", PRE##_HASHSZ, ghinit };	\
static const ghash_ops gnops =						\
  { &gch, ghhash, ghdone, ghdestroy, ghcopy };				\
static const gchash gsslch = { #pre "-sslmac", PRE##_HASHSZ, ghinit };	\
static const ghash_ops gsslops =					\
  { &gch, ghhash, ghdone, ghdestroy, ghcopy };				\
									\
HMAC_TEST(PRE, pre)

/* --- @HMAC_TEST@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for hash-specfic definitions
 *
 * Use:		Standard test rig for MAC functions.
 */

#ifdef TEST_RIG

#include <stdio.h>

#include <mLib/dstr.h>
#include <mLib/quis.h>
#include <mLib/testrig.h>

#define HMAC_TEST(PRE, pre)						\
									\
static int macverify(dstr *v)						\
{									\
  pre##_macctx cctx;							\
  pre##_mackey ckey;							\
  int ok = 1;								\
  int i;								\
  octet *p;								\
  int szs[] = { 1, 7, 192, -1, 0 }, *ip;				\
  size_t csz;								\
  dstr d;								\
									\
  dstr_create(&d);							\
  dstr_ensure(&d, PRE##_HASHSZ);					\
  d.len = PRE##_HASHSZ;							\
									\
  pre##_hmacinit(&ckey, v[1].buf, v[1].len);				\
									\
  for (ip = szs; *ip; ip++) {						\
    i = *ip;								\
    csz = v[0].len;							\
    if (i == -1)							\
      i = csz;								\
    if (i > csz)							\
      continue;								\
    p = (octet *)v[0].buf;						\
    pre##_macinit(&cctx, &ckey);					\
    while (csz) {							\
      if (i > csz)							\
	i = csz;							\
      pre##_machash(&cctx, p, i);					\
      p += i;								\
      csz -= i;								\
    }									\
    pre##_macdone(&cctx, d.buf);					\
    if (memcmp(d.buf, v[2].buf, PRE##_HASHSZ) != 0) {			\
      printf("\nfail:\n\tstep = %i\n\tinput = `%s'\n\tkey = ",		\
	     *ip, v[0].buf);						\
      type_hex.dump(&v[1], stdout);					\
      fputs("\n\texpected = ", stdout);					\
      type_hex.dump(&v[2], stdout);					\
      fputs("\n\tcomputed = ", stdout);					\
      type_hex.dump(&d, stdout);					\
      putchar('\n');							\
      ok = 0;								\
    }									\
  }									\
									\
  dstr_destroy(&d);							\
  return (ok);								\
}									\
									\
static test_chunk macdefs[] = {						\
  { #pre "-hmac", macverify,						\
    { &type_string, &type_hex, &type_hex, 0 } },			\
  { 0, 0, { 0 } }							\
};									\
									\
int main(int argc, char *argv[])					\
{									\
  ego(argv[0]);								\
  test_run(argc, argv, macdefs, SRCDIR"/t/" #pre);			\
  return (0);								\
}

#else
#  define HMAC_TEST(PRE, pre)
#endif

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
