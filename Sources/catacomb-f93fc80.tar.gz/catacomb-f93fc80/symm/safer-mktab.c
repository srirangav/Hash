/* -*-c-*-
 *
 * Generate tables for SAFER
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>

#include <mLib/bits.h>

/*----- Main code ---------------------------------------------------------*/

int main(void)
{
  octet s[256], si[256];
  unsigned x, i;

  x = 1;
  for (i = 0; i < 256; i++) {
    if (x < 256) {
      s[i] = x;
      si[x] = i;
    }
    x = (x * 45)%257;
  }
  s[128] = 0;
  si[0] = 128;

  fputs("\
/* -*-c-*-\n\
 *\n\
 * SAFER tables [generated]\n\
 */\n\
\n\
#include <mLib/bits.h>\n\
\n\
", stdout);

  fputs("\
/* --- S-boxes --- */\n\
\n\
const octet safer_s[256] = {\n\
  ", stdout);
  for (i = 0; i < 256; i++) {
    printf("0x%02x", s[i]);
    if (i == 255)
      fputs("\n};\n\n", stdout);
    else if ((i + 1)%8 == 0)
      fputs(",\n  ", stdout);
    else
      fputs(", ", stdout);
  }

  fputs("\
const octet safer_si[256] = {\n\
  ", stdout);
  for (i = 0; i < 256; i++) {
    printf("0x%02x", si[i]);
    if (i == 255)
      fputs("\n};\n", stdout);
    else if ((i + 1)%8 == 0)
      fputs(",\n  ", stdout);
    else
      fputs(", ", stdout);
  }

  if (fclose(stdout)) {
    fprintf(stderr, "error writing data\n");
    exit(EXIT_FAILURE);
  }

  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
