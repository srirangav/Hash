/* -*-c-*-
 *
 * The RIPEMD-128 message digest function
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "rmd128.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @rmd128_compress@ --- *
 *
 * Arguments:	@rmd128_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		RIPEMD-128 compression function.
 */

void rmd128_compress(rmd128_ctx *ctx, const void *sbuf)
{
  uint32 a, b, c, d;
  uint32 A, B, C, D;
  uint32 buf[16];

  /* --- Fetch the chaining variables --- */

  a = A = ctx->a;
  b = B = ctx->b;
  c = C = ctx->c;
  d = D = ctx->d;

  /* --- Fetch the buffer contents --- */

  {
    int i;
    const octet *p;

    for (i = 0, p = sbuf; i < 16; i++, p += 4)
      buf[i] = LOAD32_L(p);
  }

  /* --- Definitions for round functions --- */

#define F(x, y, z) ((x) ^ (y) ^ (z))
#define G(x, y, z) (((x) & (y)) | (~(x) & (z)))
#define H(x, y, z) (((x) | ~(y)) ^ (z))
#define I(x, y, z) (((x) & (z)) | ((y) & ~(z)))

#define T(w, x, y, z, i, r, f, k) do {					\
  uint32 _t = w + f(x, y, z) + buf[i] + k;				\
  w = ROL32(_t, r);							\
} while (0)

#define F1(w, x, y, z, i, r) T(w, x, y, z, i, r, F, 0x00000000)
#define G1(w, x, y, z, i, r) T(w, x, y, z, i, r, G, 0x5a827999)
#define H1(w, x, y, z, i, r) T(w, x, y, z, i, r, H, 0x6ed9eba1)
#define I1(w, x, y, z, i, r) T(w, x, y, z, i, r, I, 0x8f1bbcdc)

#define F2(w, x, y, z, i, r) T(w, x, y, z, i, r, I, 0x50a28be6)
#define G2(w, x, y, z, i, r) T(w, x, y, z, i, r, H, 0x5c4dd124)
#define H2(w, x, y, z, i, r) T(w, x, y, z, i, r, G, 0x6d703ef3)
#define I2(w, x, y, z, i, r) T(w, x, y, z, i, r, F, 0x00000000)

  /* --- First the left hand side --- */

  F1(a, b, c, d,  0, 11);
  F1(d, a, b, c,  1, 14);
  F1(c, d, a, b,  2, 15);
  F1(b, c, d, a,  3, 12);
  F1(a, b, c, d,  4,  5);
  F1(d, a, b, c,  5,  8);
  F1(c, d, a, b,  6,  7);
  F1(b, c, d, a,  7,  9);
  F1(a, b, c, d,  8, 11);
  F1(d, a, b, c,  9, 13);
  F1(c, d, a, b, 10, 14);
  F1(b, c, d, a, 11, 15);
  F1(a, b, c, d, 12,  6);
  F1(d, a, b, c, 13,  7);
  F1(c, d, a, b, 14,  9);
  F1(b, c, d, a, 15,  8);

  G1(a, b, c, d,  7,  7);
  G1(d, a, b, c,  4,  6);
  G1(c, d, a, b, 13,  8);
  G1(b, c, d, a,  1, 13);
  G1(a, b, c, d, 10, 11);
  G1(d, a, b, c,  6,  9);
  G1(c, d, a, b, 15,  7);
  G1(b, c, d, a,  3, 15);
  G1(a, b, c, d, 12,  7);
  G1(d, a, b, c,  0, 12);
  G1(c, d, a, b,  9, 15);
  G1(b, c, d, a,  5,  9);
  G1(a, b, c, d,  2, 11);
  G1(d, a, b, c, 14,  7);
  G1(c, d, a, b, 11, 13);
  G1(b, c, d, a,  8, 12);

  H1(a, b, c, d,  3, 11);
  H1(d, a, b, c, 10, 13);
  H1(c, d, a, b, 14,  6);
  H1(b, c, d, a,  4,  7);
  H1(a, b, c, d,  9, 14);
  H1(d, a, b, c, 15,  9);
  H1(c, d, a, b,  8, 13);
  H1(b, c, d, a,  1, 15);
  H1(a, b, c, d,  2, 14);
  H1(d, a, b, c,  7,  8);
  H1(c, d, a, b,  0, 13);
  H1(b, c, d, a,  6,  6);
  H1(a, b, c, d, 13,  5);
  H1(d, a, b, c, 11, 12);
  H1(c, d, a, b,  5,  7);
  H1(b, c, d, a, 12,  5);

  I1(a, b, c, d,  1, 11);
  I1(d, a, b, c,  9, 12);
  I1(c, d, a, b, 11, 14);
  I1(b, c, d, a, 10, 15);
  I1(a, b, c, d,  0, 14);
  I1(d, a, b, c,  8, 15);
  I1(c, d, a, b, 12,  9);
  I1(b, c, d, a,  4,  8);
  I1(a, b, c, d, 13,  9);
  I1(d, a, b, c,  3, 14);
  I1(c, d, a, b,  7,  5);
  I1(b, c, d, a, 15,  6);
  I1(a, b, c, d, 14,  8);
  I1(d, a, b, c,  5,  6);
  I1(c, d, a, b,  6,  5);
  I1(b, c, d, a,  2, 12);

  /* --- And then the right hand side --- */

  F2(A, B, C, D,  5,  8);
  F2(D, A, B, C, 14,  9);
  F2(C, D, A, B,  7,  9);
  F2(B, C, D, A,  0, 11);
  F2(A, B, C, D,  9, 13);
  F2(D, A, B, C,  2, 15);
  F2(C, D, A, B, 11, 15);
  F2(B, C, D, A,  4,  5);
  F2(A, B, C, D, 13,  7);
  F2(D, A, B, C,  6,  7);
  F2(C, D, A, B, 15,  8);
  F2(B, C, D, A,  8, 11);
  F2(A, B, C, D,  1, 14);
  F2(D, A, B, C, 10, 14);
  F2(C, D, A, B,  3, 12);
  F2(B, C, D, A, 12,  6);

  G2(A, B, C, D,  6,  9);
  G2(D, A, B, C, 11, 13);
  G2(C, D, A, B,  3, 15);
  G2(B, C, D, A,  7,  7);
  G2(A, B, C, D,  0, 12);
  G2(D, A, B, C, 13,  8);
  G2(C, D, A, B,  5,  9);
  G2(B, C, D, A, 10, 11);
  G2(A, B, C, D, 14,  7);
  G2(D, A, B, C, 15,  7);
  G2(C, D, A, B,  8, 12);
  G2(B, C, D, A, 12,  7);
  G2(A, B, C, D,  4,  6);
  G2(D, A, B, C,  9, 15);
  G2(C, D, A, B,  1, 13);
  G2(B, C, D, A,  2, 11);

  H2(A, B, C, D, 15,  9);
  H2(D, A, B, C,  5,  7);
  H2(C, D, A, B,  1, 15);
  H2(B, C, D, A,  3, 11);
  H2(A, B, C, D,  7,  8);
  H2(D, A, B, C, 14,  6);
  H2(C, D, A, B,  6,  6);
  H2(B, C, D, A,  9, 14);
  H2(A, B, C, D, 11, 12);
  H2(D, A, B, C,  8, 13);
  H2(C, D, A, B, 12,  5);
  H2(B, C, D, A,  2, 14);
  H2(A, B, C, D, 10, 13);
  H2(D, A, B, C,  0, 13);
  H2(C, D, A, B,  4,  7);
  H2(B, C, D, A, 13,  5);

  I2(A, B, C, D,  8, 15);
  I2(D, A, B, C,  6,  5);
  I2(C, D, A, B,  4,  8);
  I2(B, C, D, A,  1, 11);
  I2(A, B, C, D,  3, 14);
  I2(D, A, B, C, 11, 14);
  I2(C, D, A, B, 15,  6);
  I2(B, C, D, A,  0, 14);
  I2(A, B, C, D,  5,  6);
  I2(D, A, B, C, 12,  9);
  I2(C, D, A, B,  2, 12);
  I2(B, C, D, A, 13,  9);
  I2(A, B, C, D,  9, 12);
  I2(D, A, B, C,  7,  5);
  I2(C, D, A, B, 10, 15);
  I2(B, C, D, A, 14,  8);

  /* --- Recombine the two halves --- */

  {
    uint32
       tmp = ctx->b + c + D;
    ctx->b = ctx->c + d + A;
    ctx->c = ctx->d + a + B;
    ctx->d = ctx->a + b + C;
    ctx->a = tmp;
  }
}

/* --- @rmd128_init@ --- *
 *
 * Arguments:	@rmd128_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void rmd128_init(rmd128_ctx *ctx)
{
  ctx->a = 0x67452301;
  ctx->b = 0xefcdab89;
  ctx->c = 0x98badcfe;
  ctx->d = 0x10325476;
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

/* --- @rmd128_set@ --- *
 *
 * Arguments:	@rmd128_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void rmd128_set(rmd128_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  ctx->a = LOAD32_L(p +	 0);
  ctx->b = LOAD32_L(p +	 4);
  ctx->c = LOAD32_L(p +	 8);
  ctx->d = LOAD32_L(p + 12);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @rmd128_hash@ --- *
 *
 * Arguments:	@rmd128_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void rmd128_hash(rmd128_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(RMD128, rmd128, ctx, buf, sz);
}

/* --- @rmd128_done@ --- *
 *
 * Arguments:	@rmd128_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

void rmd128_done(rmd128_ctx *ctx, void *hash)
{
  octet *p = hash;
  HASH_MD5STRENGTH(RMD128, rmd128, ctx);
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
}

/* --- @rmd128_state@ --- *
 *
 * Arguments:	@rmd128_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @rmd128_set@.
 */

unsigned long rmd128_state(rmd128_ctx *ctx, void *state)
{
  octet *p = state;
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(RMD128, rmd128)

/* --- Test code --- */

HASH_TEST(RMD128, rmd128)

/*----- That's all, folks -------------------------------------------------*/
