/* -*-c-*-
 *
 * Electronic code book for block ciphers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_ECB_H
#define CATACOMB_ECB_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

/*----- Macros ------------------------------------------------------------*/

/* --- @ECB_DECL@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for the underlying block cipher
 *
 * Use:		Creates declarations for ECB stealing mode.
 */

#define ECB_DECL(PRE, pre)						\
									\
/* --- Electronic codebook context --- */				\
									\
typedef struct pre##_ecbctx {						\
  pre##_ctx ctx;			/* Underlying cipher context */	\
} pre##_ecbctx;								\
									\
/* --- @pre_ecbsetkey@ --- *						\
 *									\
 * Arguments:	@pre_ecbctx *ctx@ = pointer to ECB context block	\
 *		@const pre_ctx *k@ = pointer to cipher context		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the ECB context to use a different cipher key.	\
 */									\
									\
extern void pre##_ecbsetkey(pre##_ecbctx */*ctx*/,			\
			    const pre##_ctx */*k*/);			\
									\
/* --- @pre_ecbinit@ --- *						\
 *									\
 * Arguments:	@pre_ecbctx *ctx@ = pointer to cipher context		\
 *		@const void *key@ = pointer to the key buffer		\
 *		@size_t sz@ = size of the key				\
 *		@const void *iv@ = pointer to initialization vector	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes an ECB context ready for use.  This is	\
 *		equivalent to calls to @pre_init@ and @pre_setkey@.	\
 */									\
									\
extern void pre##_ecbinit(pre##_ecbctx */*ctx*/,			\
			  const void */*key*/, size_t /*sz*/,		\
			  const void */*iv*/);				\
									\
/* --- @pre_ecbencrypt@ --- *						\
 *									\
 * Arguments:	@pre_ecbctx *ctx@ = pointer to ECB context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Encrypts a block with a block cipher in ECB mode, with	\
 *		ciphertext stealing and other clever tricks.		\
 *		Essentially, data can be encrypted in arbitrary sized	\
 *		chunks, although decryption must use the same chunks.	\
 */									\
									\
extern void pre##_ecbencrypt(pre##_ecbctx */*ctx*/,			\
			     const void */*src*/, void */*dest*/,	\
			     size_t /*sz*/);				\
									\
/* --- @pre_ecbdecrypt@ --- *						\
 *									\
 * Arguments:	@pre_ecbctx *ctx@ = pointer to ECB context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Decrypts a block with a block cipher in ECB mode, with	\
 *		ciphertext stealing and other clever tricks.		\
 *		Essentially, data can be encrypted in arbitrary sized	\
 *		chunks, although decryption must use the same chunks.	\
 */									\
									\
extern void pre##_ecbdecrypt(pre##_ecbctx */*ctx*/,			\
			     const void */*src*/, void */*dest*/,	\
			     size_t /*sz*/);				\
									\
/* --- Generic cipher interface --- */					\
									\
extern const gccipher pre##_ecb;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
