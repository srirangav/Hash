/* -*-c-*-
 *
 * The CAST-128 block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the CAST-256 block cipher --------------------------------*
 *
 * CAST, designed by Carlisle Adams and Stafford Tavares, is a method for
 * designing block ciphers, based around the concept of `bent functions'.  It
 * is described in the paper `Constructing Symmetric Ciphers using the CAST
 * Design Procedure' by Carlisle Adams.
 *
 * CAST-256, defined in RFC2612, is a particular instance of the CAST design
 * procedure.  It is an `incomplete' Feistel network.  It uses the same
 * S-boxes and round functions as CAST-128.
 *
 * CAST-256 was submitted to the AES contest, but was not selected as one of
 * the five `finalist' algorithms.
 */

#ifndef CATACOMB_CAST256_H
#define CATACOMB_CAST256_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

/*----- Magic numbers -----------------------------------------------------*/

#define CAST256_BLKSZ 16
#define CAST256_KEYSZ 32
#define CAST256_CLASS (N, B, 128)

extern const octet cast256_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct cast256_ctx {
  uint32 km[48];
  octet kr[48];
} cast256_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @cast256_init@ --- *
 *
 * Arguments:	@cast256_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a CAST-256 key buffer.  CAST-256 accepts
 *		256-bit keys or shorter.
 */

extern void cast256_init(cast256_ctx */*k*/,
			 const void */*buf*/, size_t /*sz*/);

/* --- @cast256_eblk@, @cast256_dblk@ --- *
 *
 * Arguments:	@const cast256_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void cast256_eblk(const cast256_ctx */*k*/,
			 const uint32 */*s*/, uint32 */*d*/);

extern void cast256_dblk(const cast256_ctx */*k*/,
			 const uint32 */*s*/, uint32 */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
