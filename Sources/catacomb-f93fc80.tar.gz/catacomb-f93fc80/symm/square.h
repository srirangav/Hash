/* -*-c-*-
 *
 * The Square block cipher
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Square block cipher ----------------------------------*
 *
 * Invented by Joan Daemen and Vincent Rijmen, Square is a fast and
 * relatively simple 128-bit block cipher.  It is the predecessor to
 * Rijndael.  I have grave doubts about the security of Square, though: a
 * dedicated attack against Square's structure by Knudsen has been extended
 * by the Twofish team against Rijndael, and I believe that this extended
 * attack is also effective against Square.  This is a shame: the structure
 * of Square (and Rijndael) is extremely elegant, and has some extremely nice
 * properties.
 */

#ifndef CATACOMB_SQUARE_H
#define CATACOMB_SQUARE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define SQUARE_BLKSZ 16
#define SQUARE_KEYSZ 16
#define SQUARE_CLASS (N, L, 128)

extern const octet square_keysz[];

/*----- Data structures ---------------------------------------------------*/

#define SQUARE_MAXROUNDS 8
#define SQUARE_KWORDS ((SQUARE_MAXROUNDS + 1) * (SQUARE_BLKSZ / 4))

typedef struct square_ctx {
  uint32 w[SQUARE_KWORDS];
  uint32 wi[SQUARE_KWORDS];
} square_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @square_init@ --- *
 *
 * Arguments:	@square_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Square context with a particular key.  This
 *		implementation of Square doesn't impose any particular
 *		limits on the key size except that it must be multiple of 4
 *		bytes long.  256 bits seems sensible, though.
 */

extern void square_init(square_ctx */*k*/,
			  const void */*buf*/, size_t /*sz*/);

/* --- @square_eblk@, @square_dblk@ --- *
 *
 * Arguments:	@const square_ctx *k@ = pointer to Square context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void square_eblk(const square_ctx */*k*/,
			  const uint32 */*s*/, uint32 */*dst*/);
extern void square_dblk(const square_ctx */*k*/,
			  const uint32 */*s*/, uint32 */*dst*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
