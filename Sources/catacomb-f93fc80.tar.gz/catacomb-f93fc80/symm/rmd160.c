/* -*-c-*-
 *
 * The RIPEMD-160 message digest function
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "rmd160.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @rmd160_compress@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		RIPEMD-160 compression function.
 */

void rmd160_compress(rmd160_ctx *ctx, const void *sbuf)
{
  uint32 a, b, c, d, e;
  uint32 A, B, C, D, E;
  uint32 buf[16];

  /* --- Fetch the chaining variables --- */

  a = A = ctx->a;
  b = B = ctx->b;
  c = C = ctx->c;
  d = D = ctx->d;
  e = E = ctx->e;

  /* --- Fetch the buffer contents --- */

  {
    int i;
    const octet *p;

    for (i = 0, p = sbuf; i < 16; i++, p += 4)
      buf[i] = LOAD32_L(p);
  }

  /* --- Definitions for round functions --- */

#define F(x, y, z) ((x) ^ (y) ^ (z))
#define G(x, y, z) (((x) & (y)) | (~(x) & (z)))
#define H(x, y, z) (((x) | ~(y)) ^ (z))
#define I(x, y, z) (((x) & (z)) | ((y) & ~(z)))
#define J(x, y, z) ((x) ^ ((y) | ~(z)))

#define T(v, w, x, y, z, i, r, f, k) do {				\
  uint32 _t = v + f(w, x, y) + buf[i] + k;				\
  v = ROL32(_t, r) + z; x = ROL32(x, 10);				\
} while (0)

#define F1(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, F, 0x00000000)
#define G1(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, G, 0x5a827999)
#define H1(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, H, 0x6ed9eba1)
#define I1(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, I, 0x8f1bbcdc)
#define J1(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, J, 0xa953fd4e)

#define F2(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, J, 0x50a28be6)
#define G2(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, I, 0x5c4dd124)
#define H2(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, H, 0x6d703ef3)
#define I2(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, G, 0x7a6d76e9)
#define J2(v, w, x, y, z, i, r) T(v, w, x, y, z, i, r, F, 0x00000000)

  /* --- First the left hand side --- */

  F1(a, b, c, d, e,  0, 11);
  F1(e, a, b, c, d,  1, 14);
  F1(d, e, a, b, c,  2, 15);
  F1(c, d, e, a, b,  3, 12);
  F1(b, c, d, e, a,  4,	 5);
  F1(a, b, c, d, e,  5,	 8);
  F1(e, a, b, c, d,  6,	 7);
  F1(d, e, a, b, c,  7,	 9);
  F1(c, d, e, a, b,  8, 11);
  F1(b, c, d, e, a,  9, 13);
  F1(a, b, c, d, e, 10, 14);
  F1(e, a, b, c, d, 11, 15);
  F1(d, e, a, b, c, 12,	 6);
  F1(c, d, e, a, b, 13,	 7);
  F1(b, c, d, e, a, 14,	 9);
  F1(a, b, c, d, e, 15,	 8);

  G1(e, a, b, c, d,  7,	 7);
  G1(d, e, a, b, c,  4,	 6);
  G1(c, d, e, a, b, 13,	 8);
  G1(b, c, d, e, a,  1,	13);
  G1(a, b, c, d, e, 10,	11);
  G1(e, a, b, c, d,  6,	 9);
  G1(d, e, a, b, c, 15,	 7);
  G1(c, d, e, a, b,  3,	15);
  G1(b, c, d, e, a, 12,	 7);
  G1(a, b, c, d, e,  0,	12);
  G1(e, a, b, c, d,  9,	15);
  G1(d, e, a, b, c,  5,	 9);
  G1(c, d, e, a, b,  2,	11);
  G1(b, c, d, e, a, 14,	 7);
  G1(a, b, c, d, e, 11,	13);
  G1(e, a, b, c, d,  8,	12);

  H1(d, e, a, b, c,  3,	11);
  H1(c, d, e, a, b, 10,	13);
  H1(b, c, d, e, a, 14,	 6);
  H1(a, b, c, d, e,  4,	 7);
  H1(e, a, b, c, d,  9,	14);
  H1(d, e, a, b, c, 15,	 9);
  H1(c, d, e, a, b,  8,	13);
  H1(b, c, d, e, a,  1,	15);
  H1(a, b, c, d, e,  2,	14);
  H1(e, a, b, c, d,  7,	 8);
  H1(d, e, a, b, c,  0,	13);
  H1(c, d, e, a, b,  6,	 6);
  H1(b, c, d, e, a, 13,	 5);
  H1(a, b, c, d, e, 11,	12);
  H1(e, a, b, c, d,  5,	 7);
  H1(d, e, a, b, c, 12,	 5);

  I1(c, d, e, a, b,  1,	11);
  I1(b, c, d, e, a,  9,	12);
  I1(a, b, c, d, e, 11,	14);
  I1(e, a, b, c, d, 10,	15);
  I1(d, e, a, b, c,  0,	14);
  I1(c, d, e, a, b,  8,	15);
  I1(b, c, d, e, a, 12,	 9);
  I1(a, b, c, d, e,  4,	 8);
  I1(e, a, b, c, d, 13,	 9);
  I1(d, e, a, b, c,  3,	14);
  I1(c, d, e, a, b,  7,	 5);
  I1(b, c, d, e, a, 15,	 6);
  I1(a, b, c, d, e, 14,	 8);
  I1(e, a, b, c, d,  5,	 6);
  I1(d, e, a, b, c,  6,	 5);
  I1(c, d, e, a, b,  2,	12);

  J1(b, c, d, e, a,  4,	 9);
  J1(a, b, c, d, e,  0,	15);
  J1(e, a, b, c, d,  5,	 5);
  J1(d, e, a, b, c,  9,	11);
  J1(c, d, e, a, b,  7,	 6);
  J1(b, c, d, e, a, 12,	 8);
  J1(a, b, c, d, e,  2,	13);
  J1(e, a, b, c, d, 10,	12);
  J1(d, e, a, b, c, 14,	 5);
  J1(c, d, e, a, b,  1,	12);
  J1(b, c, d, e, a,  3,	13);
  J1(a, b, c, d, e,  8,	14);
  J1(e, a, b, c, d, 11,	11);
  J1(d, e, a, b, c,  6,	 8);
  J1(c, d, e, a, b, 15,	 5);
  J1(b, c, d, e, a, 13,	 6);

  /* --- And then the right hand side --- */

  F2(A, B, C, D, E,  5,	 8);
  F2(E, A, B, C, D, 14,	 9);
  F2(D, E, A, B, C,  7,	 9);
  F2(C, D, E, A, B,  0,	11);
  F2(B, C, D, E, A,  9,	13);
  F2(A, B, C, D, E,  2,	15);
  F2(E, A, B, C, D, 11,	15);
  F2(D, E, A, B, C,  4,	 5);
  F2(C, D, E, A, B, 13,	 7);
  F2(B, C, D, E, A,  6,	 7);
  F2(A, B, C, D, E, 15,	 8);
  F2(E, A, B, C, D,  8,	11);
  F2(D, E, A, B, C,  1,	14);
  F2(C, D, E, A, B, 10,	14);
  F2(B, C, D, E, A,  3,	12);
  F2(A, B, C, D, E, 12,	 6);

  G2(E, A, B, C, D,  6,	 9);
  G2(D, E, A, B, C, 11,	13);
  G2(C, D, E, A, B,  3,	15);
  G2(B, C, D, E, A,  7,	 7);
  G2(A, B, C, D, E,  0,	12);
  G2(E, A, B, C, D, 13,	 8);
  G2(D, E, A, B, C,  5,	 9);
  G2(C, D, E, A, B, 10,	11);
  G2(B, C, D, E, A, 14,	 7);
  G2(A, B, C, D, E, 15,	 7);
  G2(E, A, B, C, D,  8,	12);
  G2(D, E, A, B, C, 12,	 7);
  G2(C, D, E, A, B,  4,	 6);
  G2(B, C, D, E, A,  9,	15);
  G2(A, B, C, D, E,  1,	13);
  G2(E, A, B, C, D,  2,	11);

  H2(D, E, A, B, C, 15,	 9);
  H2(C, D, E, A, B,  5,	 7);
  H2(B, C, D, E, A,  1,	15);
  H2(A, B, C, D, E,  3,	11);
  H2(E, A, B, C, D,  7,	 8);
  H2(D, E, A, B, C, 14,	 6);
  H2(C, D, E, A, B,  6,	 6);
  H2(B, C, D, E, A,  9,	14);
  H2(A, B, C, D, E, 11,	12);
  H2(E, A, B, C, D,  8,	13);
  H2(D, E, A, B, C, 12,	 5);
  H2(C, D, E, A, B,  2,	14);
  H2(B, C, D, E, A, 10,	13);
  H2(A, B, C, D, E,  0,	13);
  H2(E, A, B, C, D,  4,	 7);
  H2(D, E, A, B, C, 13,	 5);

  I2(C, D, E, A, B,  8,	15);
  I2(B, C, D, E, A,  6,	 5);
  I2(A, B, C, D, E,  4,	 8);
  I2(E, A, B, C, D,  1,	11);
  I2(D, E, A, B, C,  3,	14);
  I2(C, D, E, A, B, 11,	14);
  I2(B, C, D, E, A, 15,	 6);
  I2(A, B, C, D, E,  0,	14);
  I2(E, A, B, C, D,  5,	 6);
  I2(D, E, A, B, C, 12,	 9);
  I2(C, D, E, A, B,  2,	12);
  I2(B, C, D, E, A, 13,	 9);
  I2(A, B, C, D, E,  9,	12);
  I2(E, A, B, C, D,  7,	 5);
  I2(D, E, A, B, C, 10,	15);
  I2(C, D, E, A, B, 14,	 8);

  J2(B, C, D, E, A, 12,	 8);
  J2(A, B, C, D, E, 15,	 5);
  J2(E, A, B, C, D, 10,	12);
  J2(D, E, A, B, C,  4,	 9);
  J2(C, D, E, A, B,  1,	12);
  J2(B, C, D, E, A,  5,	 5);
  J2(A, B, C, D, E,  8,	14);
  J2(E, A, B, C, D,  7,	 6);
  J2(D, E, A, B, C,  6,	 8);
  J2(C, D, E, A, B,  2,	13);
  J2(B, C, D, E, A, 13,	 6);
  J2(A, B, C, D, E, 14,	 5);
  J2(E, A, B, C, D,  0,	15);
  J2(D, E, A, B, C,  3,	13);
  J2(C, D, E, A, B,  9,	11);
  J2(B, C, D, E, A, 11,	11);

  /* --- Recombine the two halves --- */

  {
    uint32
       tmp = ctx->b + c + D;
    ctx->b = ctx->c + d + E;
    ctx->c = ctx->d + e + A;
    ctx->d = ctx->e + a + B;
    ctx->e = ctx->a + b + C;
    ctx->a = tmp;
  }
}

/* --- @rmd160_init@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

void rmd160_init(rmd160_ctx *ctx)
{
  ctx->a = 0x67452301;
  ctx->b = 0xefcdab89;
  ctx->c = 0x98badcfe;
  ctx->d = 0x10325476;
  ctx->e = 0xc3d2e1f0;
  ctx->off = 0;
  ctx->nl = ctx->nh = 0;
}

/* --- @rmd160_set@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

void rmd160_set(rmd160_ctx *ctx, const void *buf, unsigned long count)
{
  const octet *p = buf;
  ctx->a = LOAD32_L(p +	 0);
  ctx->b = LOAD32_L(p +	 4);
  ctx->c = LOAD32_L(p +	 8);
  ctx->d = LOAD32_L(p + 12);
  ctx->e = LOAD32_L(p + 16);
  ctx->off = 0;
  ctx->nl = U32(count);
  ctx->nh = U32(((count & ~MASK32) >> 16) >> 16);
}

/* --- @rmd160_hash@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

void rmd160_hash(rmd160_ctx *ctx, const void *buf, size_t sz)
{
  HASH_BUFFER(RMD160, rmd160, ctx, buf, sz);
}

/* --- @rmd160_done@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

void rmd160_done(rmd160_ctx *ctx, void *hash)
{
  octet *p = hash;
  HASH_MD5STRENGTH(RMD160, rmd160, ctx);
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
  STORE32_L(p + 16, ctx->e);
}

/* --- @rmd160_state@ --- *
 *
 * Arguments:	@rmd160_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @rmd160_set@.
 */

unsigned long rmd160_state(rmd160_ctx *ctx, void *state)
{
  octet *p = state;
  STORE32_L(p +	 0, ctx->a);
  STORE32_L(p +	 4, ctx->b);
  STORE32_L(p +	 8, ctx->c);
  STORE32_L(p + 12, ctx->d);
  STORE32_L(p + 16, ctx->e);
  return (ctx->nl | ((ctx->nh << 16) << 16));
}

/* --- Generic interface --- */

GHASH_DEF(RMD160, rmd160)

/* --- Test code --- */

HASH_TEST(RMD160, rmd160)

/*----- That's all, folks -------------------------------------------------*/
