/* -*-c-*-
 *
 * The Rijndael block cipher, 192-bit version
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_RIJNDAEL192_H
#define CATACOMB_RIJNDAEL192_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_RIJNDAEL_H
#  include "rijndael.h"
#endif

/*----- Magical numbers ---------------------------------------------------*/

#define RIJNDAEL192_BLKSZ 24
#define RIJNDAEL192_KEYSZ 32
#define RIJNDAEL192_CLASS (N, B, 192)

#define rijndael192_keysz rijndael_keysz

/*----- Data structures ---------------------------------------------------*/

typedef struct rijndael_ctx rijndael192_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @rijndael192_init@ --- *
 *
 * Arguments:	@rijndael_ctx *k@ = pointer to context to initialize
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Rijndael context with a particular key.  This
 *		implementation of Rijndael doesn't impose any particular
 *		limits on the key size except that it must be multiple of 4
 *		bytes long.  256 bits seems sensible, though.
 */

extern void rijndael192_init(rijndael_ctx */*k*/,
			  const void */*buf*/, size_t /*sz*/);

/* --- @rijndael_eblk@, @rijndael_dblk@ --- *
 *
 * Arguments:	@const rijndael_ctx *k@ = pointer to Rijndael context
 *		@const uint32 s[4]@ = pointer to source block
 *		@uint32 d[4]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void rijndael192_eblk(const rijndael_ctx */*k*/,
			     const uint32 */*s*/, uint32 */*dst*/);
extern void rijndael192_dblk(const rijndael_ctx */*k*/,
			     const uint32 */*s*/, uint32 */*dst*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
