/* -*-c-*-
 *
 * The SEAL pseudo-random function family
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the SEAL pseudo-random function family -------------------*
 *
 * SEAL is a slightly odd cryptographic primitive.  It was designed by Phil
 * Rogaway and Don Coppersmith at IBM, basically as an exercise in producing
 * a really fast symmetric cipher of some kind.  They succeeded: SEAL is
 * faster than the much simpler RC4.
 *
 * For each key, it gives you %$2^{32}$% different output streams.  This
 * implementation imposes no length limits on the size of output streams and
 * performs careful buffer handling to allow arbitrary amounts of data to be
 * extracted.  In practice, extracting more than about 64K is possibly dodgy
 * from a security point of view.
 *
 * SEAL is patented.
 */

#ifndef CATACOMB_SEAL_H
#define CATACOMB_SEAL_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Data structures ---------------------------------------------------*/

#define SEAL_R 256

typedef struct seal_key {
  octet k[20];				/* Copy of the 160-bit key */
  uint32 t[512];			/* Substitution table */
  uint32 s[256];			/* Magic for each iteration */
  uint32 r[SEAL_R];			/* Magic for the first 64K */
} seal_key;

typedef struct seal_ctx {
  seal_key *k;				/* Pointer to the key block */
  uint32 *r, ri;			/* Pointer to current magic */
  uint32 n, l;				/* Various indices into things */
  uint32 a, b, c, d;			/* Current chaining variables */
  uint32 n1, n2, n3, n4;		/* Increments for the variables */
  unsigned i;				/* Index into current iteration */
  octet q[16];				/* Output buffer */
  unsigned qsz;				/* Number of bytes in the buffer */
  uint32 rbuf[SEAL_R];			/* Buffer for later magic */
} seal_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @seal_initkey@ --- *
 *
 * Arguments:	@seal_key *k@ = pointer to key block
 *		@const void *buf@ = pointer to key material
 *		@size_t sz@ = size of the key material
 *
 * Returns:	---
 *
 * Use:		Initializes a SEAL key block.  The key material may be any
 *		size, but if it's not 20 bytes long it's passed to SHA for
 *		hashing first.
 */

extern void seal_initkey(seal_key */*k*/,
			 const void */*buf*/, size_t /*sz*/);

/* --- @seal_initctx@ --- *
 *
 * Arguments:	@seal_ctx *c@ = pointer to a SEAL context
 *		@seal_key *k@ = pointer to a SEAL key
 *		@uint32 n@ = integer sequence number
 *
 * Returns:	---
 *
 * Use:		Initializes a SEAL context which can be used for random
 *		number generation or whatever.
 */

extern void seal_initctx(seal_ctx */*c*/, seal_key */*k*/, uint32 /*n*/);

/* --- @seal_encrypt@ --- *
 *
 * Arguments:	@seal_ctx *c@ = pointer to a SEAL context
 *		@const void *src@ = pointer to source data
 *		@void *dest@ = pointer to destination data
 *		@size_t sz@ = size of the data
 *
 * Returns:	---
 *
 * Use:		Encrypts a block of data using SEAL.  If @src@ is zero,
 *		@dest@ is filled with SEAL output.  If @dest@ is zero, the
 *		SEAL generator is just spun around for a bit.  This shouldn't
 *		be necessary, because SEAL isn't RC4.
 */

extern void seal_encrypt(seal_ctx */*c*/, const void */*src*/,
			 void */*dest*/, size_t /*sz*/);

/*----- Generic cipher interface ------------------------------------------*/

#define SEAL_KEYSZ 20
extern const octet seal_keysz[];

extern const gccipher seal;

/*----- Generic random number generator interface -------------------------*/

/* --- @seal_rand@ --- *
 *
 * Arguments:	@const void *k@ = pointer to key material
 *		@size_t sz@ = size of key material
 *		@uint32 n@ = sequence number
 *
 * Returns:	Pointer to generic random number generator interface.
 *
 * Use:		Creates a random number interface wrapper around a SEAL
 *		pseudorandom function.
 */

extern grand *seal_rand(const void */*k*/, size_t /*sz*/, uint32 /*n*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
