/* -*-c-*-
 *
 * The Blowfish block cipher
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the Blowfish block cipher --------------------------------*
 *
 * Blowfish was invented by Bruce Schneier.  The algorithm is unpatented and
 * free for anyone to use.  It's fast, simple, offers a big key, and is
 * looking relatively bulletproof.  It's also this author's block cipher of
 * choice, for what little that's worth.  The disadvantage is that Blowfish
 * has a particularly heavyweight key schedule.
 */

#ifndef CATACOMB_BLOWFISH_H
#define CATACOMB_BLOWFISH_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

/*----- Magical numbers ---------------------------------------------------*/

#define BLOWFISH_BLKSZ 8
#define BLOWFISH_KEYSZ 32
#define BLOWFISH_CLASS (N, B, 64)

extern const octet blowfish_keysz[];

/*----- Data structures ---------------------------------------------------*/

typedef struct blowfish_ctx {
  uint32 p[18];
  uint32 s0[256], s1[256], s2[256], s3[256];
} blowfish_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @blowfish_init@ --- *
 *
 * Arguments:	@blowfish_ctx *k@ = pointer to key block to fill in
 *		@const void *buf@ = pointer to buffer of key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a Blowfish key buffer.  Blowfish accepts
 *		a more-or-less arbitrary size key.
 */

extern void blowfish_init(blowfish_ctx */*k*/,
			  const void */*buf*/, size_t /*sz*/);

/* --- @blowfish_eblk@, @blowfish_dblk@ --- *
 *
 * Arguments:	@const blowfish_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

extern void blowfish_eblk(const blowfish_ctx */*k*/,
			  const uint32 */*s*/, uint32 */*d*/);

extern void blowfish_dblk(const blowfish_ctx */*k*/,
			  const uint32 */*s*/, uint32 */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
