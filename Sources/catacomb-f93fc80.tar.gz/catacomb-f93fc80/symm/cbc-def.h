/* -*-c-*-
 *
 * Definitions for cipher block chaining mode
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_CBC_DEF_H
#define CATACOMB_CBC_DEF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <string.h>

#include <mLib/bits.h>
#include <mLib/sub.h>

#ifndef CATACOMB_ARENA_H
#  include "arena.h"
#endif

#ifndef CATACOMB_BLKC_H
#  include "blkc.h"
#endif

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

#ifndef CATACOMB_PARANOIA_H
#  include "paranoia.h"
#endif

/*----- Macros ------------------------------------------------------------*/

/* --- @CBC_DEF@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for the underlying block cipher
 *
 * Use:		Creates an implementation for CBC stealing mode.
 */

#define CBC_DEF(PRE, pre)						\
									\
/* --- @pre_cbcgetiv@ --- *						\
 *									\
 * Arguments:	@const pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@void *iv@ = pointer to output data block		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Reads the currently set IV.  Reading and setting an IV	\
 *		is transparent to the CBC encryption or decryption	\
 *		process.						\
 */									\
									\
void pre##_cbcgetiv(const pre##_cbcctx *ctx, void *iv)			\
{									\
  BLKC_STORE(PRE, iv, ctx->iv);						\
}									\
									\
/* --- @pre_cbcsetiv@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@cnost void *iv@ = pointer to IV to set			\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the IV to use for subsequent encryption.		\
 */									\
									\
void pre##_cbcsetiv(pre##_cbcctx *ctx, const void *iv)			\
{									\
  BLKC_LOAD(PRE, ctx->iv, iv);						\
}									\
									\
/* --- @pre_cbcsetkey@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@const pre_ctx *k@ = pointer to cipher context		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets the CBC context to use a different cipher key.	\
 */									\
									\
void pre##_cbcsetkey(pre##_cbcctx *ctx, const pre##_ctx *k)		\
{									\
  ctx->ctx = *k;							\
}									\
									\
/* --- @pre_cbcinit@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to cipher context		\
 *		@const void *key@ = pointer to the key buffer		\
 *		@size_t sz@ = size of the key				\
 *		@const void *iv@ = pointer to initialization vector	\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Initializes a CBC context ready for use.  The @iv@	\
 *		argument may be passed as a null pointer to set a zero	\
 *		IV.  Apart from that, this call is equivalent to calls	\
 *		to @pre_init@, @pre_cbcsetkey@ and @pre_cbcsetiv@.	\
 */									\
									\
void pre##_cbcinit(pre##_cbcctx *ctx,					\
		     const void *key, size_t sz,			\
		     const void *iv)					\
{									\
  static const octet zero[PRE##_BLKSZ] = { 0 };				\
  pre##_init(&ctx->ctx, key, sz);					\
  BLKC_LOAD(PRE, ctx->iv, iv ? iv : zero);				\
}									\
									\
/* --- @pre_cbcencrypt@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Encrypts a block with a block cipher in CBC mode, with	\
 *		ciphertext stealing and other clever tricks.		\
 *		Essentially, data can be encrypted in arbitrary sized	\
 *		chunks, although decryption must use the same chunks.	\
 */									\
									\
void pre##_cbcencrypt(pre##_cbcctx *ctx,				\
			const void *src, void *dest,			\
			size_t sz)					\
{									\
  const octet *s = src;							\
  octet *d = dest;							\
									\
  /* --- Empty blocks are trivial --- */				\
									\
  if (!sz)								\
    return;								\
									\
  /* --- Extra magical case for a short block --- *			\
   *									\
   * Encrypt the IV, then exclusive-or the plaintext with the octets	\
   * of the encrypted IV, shifting ciphertext octets in instead.  This	\
   * basically switches over to CFB.					\
   */									\
									\
  if (sz < PRE##_BLKSZ) {						\
    octet b[PRE##_BLKSZ];						\
    unsigned i;								\
									\
    pre##_eblk(&ctx->ctx, ctx->iv, ctx->iv);				\
    BLKC_STORE(PRE, b, ctx->iv);					\
    if (d) {								\
      for (i = 0; i < sz; i++)						\
	d[i] = b[i] ^ (s ? s[i] : 0);					\
    }									\
    memmove(b, b + sz, PRE##_BLKSZ - sz);				\
    memcpy(b + PRE##_BLKSZ - sz, d, sz);				\
    BLKC_LOAD(PRE, ctx->iv, b);						\
    return;								\
  }									\
									\
  /* --- Do the main chunk of encryption --- *				\
   *									\
   * This will do the whole lot if it's a whole number of blocks.  For	\
   * each block, XOR it with the previous ciphertext in @iv@, encrypt,	\
   * and keep a copy of the ciphertext for the next block.		\
   */									\
									\
  while (sz >= 2 * PRE##_BLKSZ || sz == PRE##_BLKSZ) {			\
    if (s) {								\
      BLKC_XLOAD(PRE, ctx->iv, s);					\
      s += PRE##_BLKSZ;							\
    }									\
    pre##_eblk(&ctx->ctx, ctx->iv, ctx->iv);				\
    if (d) {								\
      BLKC_STORE(PRE, d, ctx->iv);					\
      d += PRE##_BLKSZ;							\
    }									\
    sz -= PRE##_BLKSZ;							\
  }									\
									\
  /* --- Do the tail-end block and bit-left-over --- *			\
   *									\
   * This isn't very efficient.  That shouldn't matter much.		\
   */									\
									\
  if (sz) {								\
    octet b[PRE##_BLKSZ];						\
    unsigned i;								\
									\
    /* --- Let @sz@ be the size of the partial block --- */		\
									\
    sz -= PRE##_BLKSZ;							\
									\
    /* --- First stage --- *						\
     *									\
     * XOR the complete block with the current IV, and encrypt it.  The	\
     * first part of the result is the partial ciphertext block.  Don't	\
     * write that out yet, because I've not read the partial plaintext	\
     * block.								\
     */									\
									\
    if (s) BLKC_XLOAD(PRE, ctx->iv, s);					\
    pre##_eblk(&ctx->ctx, ctx->iv, ctx->iv);				\
    BLKC_STORE(PRE, b, ctx->iv);					\
									\
    /* --- Second stage --- *						\
     *									\
     * Now XOR in the partial plaintext block, writing out the		\
     * ciphertext as I go.  Then encrypt, and write the complete	\
     * ciphertext block.						\
     */									\
									\
    if (s) s += PRE##_BLKSZ;						\
    if (d) d += PRE##_BLKSZ;						\
    for (i = 0; i < sz; i++) {						\
      register octet x = b[i];						\
      if (s) b[i] ^= s[i];						\
      if (d) d[i] = x;							\
    }									\
    BLKC_LOAD(PRE, ctx->iv, b);						\
    pre##_eblk(&ctx->ctx, ctx->iv, ctx->iv);				\
    if (d) BLKC_STORE(PRE, d - PRE##_BLKSZ, ctx->iv);			\
  }									\
									\
  /* --- Done --- */							\
									\
  return;								\
}									\
									\
/* --- @pre_cbcdecrypt@ --- *						\
 *									\
 * Arguments:	@pre_cbcctx *ctx@ = pointer to CBC context block	\
 *		@const void *src@ = pointer to source data		\
 *		@void *dest@ = pointer to destination data		\
 *		@size_t sz@ = size of block to be encrypted		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Decrypts a block with a block cipher in CBC mode, with	\
 *		ciphertext stealing and other clever tricks.		\
 *		Essentially, data can be encrypted in arbitrary sized	\
 *		chunks, although decryption must use the same chunks.	\
 */									\
									\
void pre##_cbcdecrypt(pre##_cbcctx *ctx,				\
			const void *src, void *dest,			\
			size_t sz)					\
{									\
  const octet *s = src;							\
  octet *d = dest;							\
									\
  /* --- Empty blocks are trivial --- */				\
									\
  if (!sz)								\
    return;								\
									\
  /* --- Extra magical case for a short block --- *			\
   *									\
   * Encrypt the IV, then exclusive-or the ciphertext with the octets	\
   * of the encrypted IV, shifting ciphertext octets in instead.  This	\
   * basically switches over to CFB.					\
   */									\
									\
  if (sz < PRE##_BLKSZ) {						\
    octet b[PRE##_BLKSZ], c[PRE##_BLKSZ];				\
    unsigned i;								\
									\
    pre##_eblk(&ctx->ctx, ctx->iv, ctx->iv);				\
    BLKC_STORE(PRE, b, ctx->iv);					\
    for (i = 0; i < sz; i++) {						\
      register octet x = s[i];						\
      d[i] = b[i] ^ x;							\
      c[i] = x;								\
    }									\
    memmove(b, b + sz, PRE##_BLKSZ - sz);				\
    memcpy(b + PRE##_BLKSZ - sz, c, sz);				\
    BLKC_LOAD(PRE, ctx->iv, b);						\
    return;								\
  }									\
									\
  /* --- Do the main chunk of decryption --- *				\
   *									\
   * This will do the whole lot if it's a whole number of blocks.  For	\
   * each block, decrypt, XOR it with the previous ciphertext in @iv@,	\
   * and keep a copy of the ciphertext for the next block.		\
   */									\
									\
  while (sz >= 2 * PRE##_BLKSZ || sz == PRE##_BLKSZ) {			\
    uint32 b[PRE##_BLKSZ / 4], niv[PRE##_BLKSZ / 4];			\
    BLKC_LOAD(PRE, niv, s);						\
    pre##_dblk(&ctx->ctx, niv, b);					\
    BLKC_XSTORE(PRE, d, b, ctx->iv);					\
    BLKC_MOVE(PRE, ctx->iv, niv);					\
    s += PRE##_BLKSZ;							\
    d += PRE##_BLKSZ;							\
    sz -= PRE##_BLKSZ;							\
  }									\
									\
  /* --- Do the tail-end block and bit-left-over --- *			\
   *									\
   * This isn't very efficient.  That shouldn't matter much.		\
   */									\
									\
  if (sz) {								\
    octet b[PRE##_BLKSZ];						\
    uint32 bk[PRE##_BLKSZ / 4], niv[PRE##_BLKSZ / 4];			\
    unsigned i;								\
									\
    /* --- Let @sz@ be the size of the partial block --- */		\
									\
    sz -= PRE##_BLKSZ;							\
									\
    /* --- First stage --- *						\
     *									\
     * Take the complete ciphertext block, and decrypt it.  This block	\
     * is carried over for the next encryption operation.		\
     */									\
									\
    BLKC_LOAD(PRE, niv, s);						\
    pre##_dblk(&ctx->ctx, niv, bk);					\
									\
    /* --- Second stage --- *						\
     *									\
     * XORing the first few bytes of this with the partial ciphertext	\
     * block recovers the partial plaintext block.  At the same time,	\
     * write the partial ciphertext block's contents in ready for stage	\
     * three.								\
     */									\
									\
    BLKC_STORE(PRE, b, bk);						\
    s += PRE##_BLKSZ;							\
    d += PRE##_BLKSZ;							\
    for (i = 0; i < sz; i++) {						\
      register octet x = s[i];						\
      d[i] = b[i] ^ x;							\
      b[i] = x;								\
    }									\
									\
    /* --- Third stage --- *						\
     *									\
     * Decrypt the block we've got left, and XOR with the initial IV to	\
     * recover the complete plaintext block.				\
     */									\
									\
    BLKC_LOAD(PRE, bk, b);						\
    pre##_dblk(&ctx->ctx, bk, bk);					\
    BLKC_XSTORE(PRE, d - PRE##_BLKSZ, bk, ctx->iv);			\
    BLKC_MOVE(PRE, ctx->iv, niv);					\
  }									\
									\
  /* --- Done --- */							\
									\
  return;								\
}									\
									\
/* --- Generic cipher interface --- */					\
									\
static const gcipher_ops gops;						\
									\
typedef struct gctx {							\
  gcipher c;								\
  pre##_cbcctx k;							\
} gctx;									\
									\
static gcipher *ginit(const void *k, size_t sz)				\
{									\
  gctx *g = S_CREATE(gctx);						\
  g->c.ops = &gops;							\
  pre##_cbcinit(&g->k, k, sz, 0);					\
  return (&g->c);							\
}									\
									\
static void gencrypt(gcipher *c, const void *s, void *t, size_t sz)	\
{									\
  gctx *g = (gctx *)c;							\
  pre##_cbcencrypt(&g->k, s, t, sz);					\
}									\
									\
static void gdecrypt(gcipher *c, const void *s, void *t, size_t sz)	\
{									\
  gctx *g = (gctx *)c;							\
  pre##_cbcdecrypt(&g->k, s, t, sz);					\
}									\
									\
static void gdestroy(gcipher *c)					\
{									\
  gctx *g = (gctx *)c;							\
  BURN(*g);								\
  S_DESTROY(g);								\
}									\
									\
static void gsetiv(gcipher *c, const void *iv)				\
{									\
  gctx *g = (gctx *)c;							\
  pre##_cbcsetiv(&g->k, iv);						\
}									\
									\
static const gcipher_ops gops = {					\
  &pre##_cbc,								\
  gencrypt, gdecrypt, gdestroy, gsetiv, 0				\
};									\
									\
const gccipher pre##_cbc = {						\
  #pre "-cbc", pre##_keysz, PRE##_BLKSZ,				\
  ginit									\
};									\
									\
CBC_TEST(PRE, pre)

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#include <stdio.h>

#include "daftstory.h"

/* --- @CBC_TEST@ --- *
 *
 * Arguments:	@PRE@, @pre@ = prefixes for block cipher definitions
 *
 * Use:		Standard test rig for CBC functions.
 */

#define CBC_TEST(PRE, pre)						\
									\
/* --- Initial plaintext for the test --- */				\
									\
static const octet text[] = TEXT;					\
									\
/* --- Key and IV to use --- */						\
									\
static const octet key[] = KEY;						\
static const octet iv[] = IV;						\
									\
/* --- Buffers for encryption and decryption output --- */		\
									\
static octet ct[sizeof(text)];						\
static octet pt[sizeof(text)];						\
									\
static void hexdump(const octet *p, size_t sz)				\
{									\
  const octet *q = p + sz;						\
  for (sz = 0; p < q; p++, sz++) {					\
    printf("%02x", *p);							\
    if ((sz + 1) % PRE##_BLKSZ == 0)					\
      putchar(':');							\
  }									\
}									\
									\
int main(void)								\
{									\
  size_t sz = 0, rest;							\
  pre##_cbcctx ctx;							\
  pre##_ctx k;								\
  int status = 0;							\
  int done = 0;								\
									\
  size_t keysz = PRE##_KEYSZ ?						\
    PRE##_KEYSZ : strlen((const char *)key);				\
									\
  fputs(#pre "-cbc: ", stdout);						\
									\
  pre##_init(&k, key, keysz);						\
  pre##_cbcsetkey(&ctx, &k);						\
									\
  while (sz <= sizeof(text)) {						\
    rest = sizeof(text) - sz;						\
    memcpy(ct, text, sizeof(text));					\
    pre##_cbcsetiv(&ctx, iv);						\
    pre##_cbcencrypt(&ctx, ct, ct, sz);					\
    pre##_cbcencrypt(&ctx, ct + sz, ct + sz, rest);			\
    memcpy(pt, ct, sizeof(text));					\
    pre##_cbcsetiv(&ctx, iv);						\
    pre##_cbcdecrypt(&ctx, pt, pt, sz);					\
    pre##_cbcdecrypt(&ctx, pt + sz, pt + sz, rest);			\
    if (memcmp(pt, text, sizeof(text)) == 0) {				\
      done++;								\
      if (sizeof(text) < 40 || done % 8 == 0)				\
	fputc('.', stdout);						\
      if (done % 480 == 0)						\
	fputs("\n\t", stdout);						\
      fflush(stdout);							\
    } else {								\
      printf("\nError (sz = %lu)\n", (unsigned long)sz);		\
      status = 1;							\
      printf("\tplaintext      = "); hexdump(text, sz);			\
	printf(", "); hexdump(text + sz, rest);				\
	fputc('\n', stdout);						\
      printf("\tciphertext     = "); hexdump(ct, sz);			\
	printf(", "); hexdump(ct + sz, rest);				\
	fputc('\n', stdout);						\
      printf("\trecovered text = "); hexdump(pt, sz);			\
	printf(", "); hexdump(pt + sz, rest);				\
	fputc('\n', stdout);						\
      fputc('\n', stdout);						\
    }									\
    if (sz < 63)							\
      sz++;								\
    else								\
      sz += 9;								\
  }									\
									\
  fputs(status ? " failed\n" : " ok\n", stdout);			\
  return (status);							\
}

#else
#  define CBC_TEST(PRE, pre)
#endif

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
