/* -*-c-*-
 *
 * Implementation of DESX
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/bits.h>

#include "blkc.h"
#include "des-base.h"
#include "des.h"
#include "desx.h"
#include "gcipher.h"

/*----- Tables ------------------------------------------------------------*/

extern const octet desx_s[256];

/*----- Global variables --------------------------------------------------*/

const octet desx_keysz[] = { KSZ_SET, 23, 7, 8, 15, 16, 24, 0 };

/*----- Main code ---------------------------------------------------------*/

/* --- @desx_init@ --- *
 *
 * Arguments:	@desx_ctx *k@ = pointer to key block
 *		@const void *buf@ = pointer to key buffer
 *		@size_t sz@ = size of key material
 *
 * Returns:	---
 *
 * Use:		Initializes a DESX key buffer.  The key buffer contains, in
 *		order, a single-DES key (either 7 or 8 bytes), an optional
 *		8-byte pre-whitening key, and an optional 8-byte
 *		port-whitening key.  If no whitening keys are specified, the
 *		algorithm becomes the same as single-DES.
 */

static void mangle(octet *b, const octet *p)
{
  unsigned i;

  for (i = 0; i < 8; i++)
    b[i] = *p++ ^ desx_s[b[i] ^ b[(i + 1) & 7u]];
}

void desx_init(desx_ctx *k, const void *buf, size_t sz)
{
  const octet *p = buf, *kk = buf;
  size_t n;

  KSZ_ASSERT(desx, sz);

  n = sz % 8 == 7 ? 7 : 8;
  des_init(&k->k, p, n);
  p += n;
  sz -= n;
  if (!sz)
    k->prea = k->preb = k->posta = k->postb = 0;
  else {
    const octet *q = p;
    k->prea = LOAD32(q + 0);
    k->preb = LOAD32(q + 4);
    p += 8;
    sz -= 8;
    if (sz) {
      k->posta = LOAD32(p + 0);
      k->postb = LOAD32(p + 4);
    } else {
      octet b[16];
      uint32 x, y;

      des_expand(kk, n, &x, &y);
      STORE32(b + 8, x); STORE32(b + 12, y);
      memset(b, 0, 8);
      mangle(b, b + 8);
      mangle(b, q);
      k->posta = LOAD32(b + 0);
      k->postb = LOAD32(b + 4);
    }
  }
}

/* --- @desx_eblk@, @desx_dblk@ --- *
 *
 * Arguments:	@const desx_ctx *k@ = pointer to key block
 *		@const uint32 s[2]@ = pointer to source block
 *		@uint32 d[2]@ = pointer to destination block
 *
 * Returns:	---
 *
 * Use:		Low-level block encryption and decryption.
 */

void desx_eblk(const desx_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 x = s[0], y = s[1];
  x ^= k->prea; y ^= k->preb;
  DES_IP(x, y);
  DES_EBLK(k->k.k, x, y, x, y);
  DES_IPINV(x, y);
  x ^= k->posta; y ^= k->postb;
  d[0] = x, d[1] = y;
}

void desx_dblk(const desx_ctx *k, const uint32 *s, uint32 *d)
{
  uint32 x = s[0], y = s[1];
  x ^= k->posta; y ^= k->postb;
  DES_IP(x, y);
  DES_DBLK(k->k.k, x, y, x, y);
  DES_IPINV(x, y);
  x ^= k->prea; y ^= k->preb;
  d[0] = x, d[1] = y;
}

BLKC_TEST(DESX, desx)

/*----- That's all, folks -------------------------------------------------*/
