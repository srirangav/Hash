/* -*-c-*-
 *
 * Stub code for SHA-384
 */

#include "ghash.h"
#include "ghash-def.h"
#include "hash.h"
#include "sha384.h"

GHASH_DEF(SHA384, sha384)
HASH_TEST(SHA384, sha384)
