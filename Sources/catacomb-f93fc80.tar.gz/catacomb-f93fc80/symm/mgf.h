/* -*-c-*-
 *
 * The MGF mask generation function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the MGF-1 mask generating function -----------------------*
 *
 * The idea of a mask-generating function is that given an input of arbitrary
 * size, it can emit a pseudorandom output `mask' of arbitrary size.  This is
 * used in PKCS#1 OAEP (RFC2437).  My recommendation would be to use a decent
 * stream cipher instead, like RC4 or SEAL.  MGF-1 isn't very fast.
 */

#ifndef CATACOMB_MGF_H
#define CATACOMB_MGF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Macros ------------------------------------------------------------*/

#define MGF_DECL(PRE, pre)						\
									\
/* --- An MGF generation context --- */					\
									\
typedef struct pre##_mgfctx {						\
  pre##_ctx k;				/* Underlying key context */	\
  uint32 c;				/* Counter */			\
  octet buf[PRE##_HASHSZ];		/* Output buffer */		\
  size_t bsz;				/* Size of buffered data */	\
} pre##_mgfctx;								\
									\
/* --- Other useful constants --- */					\
									\
extern const octet pre##_mgfkeysz[];					\
									\
/* --- @pre_mgfkeybegin@, @pre_mgfkeyadd@ --- *				\
 *									\
 * Arguments:	@pre_mgfctx *k@ = pointer to context to initialize	\
 *		@const void *p@ = pointer to data to contribute		\
 *		@size_t sz@ = size of data to contribute		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		A multi-step keying procedure for initializing an MGF	\
 *		context.  The data is contributed to a hashing context	\
 *		which is then used for mask generation.  If you only	\
 *		have a fixed buffer, you can save a lot of effort by	\
 *		simply calling @pre_mgfinit@.				\
 */									\
									\
extern void pre##_mgfkeybegin(pre##_mgfctx */*k*/);			\
extern void pre##_mgfkeyadd(pre##_mgfctx */*k*/,			\
			    const void */*p*/, size_t /*sz*/);		\
									\
/* ---- @pre_mgfinit@ --- *						\
 *									\
 * Arguments:	@pre_mgfctx *k@ = pointer to context to initialize	\
 *		@const void *p@ = pointer to data to contribute		\
 *		@size_t sz@ = size of data to contribute		\
 *									\
 * Returns:	---							\
 *									\
 * Use:		A simpler interface to initialization if all of your	\
 *		keying material is in one place.			\
 */									\
									\
extern void pre##_mgfinit(pre##_mgfctx */*k*/,				\
			  const void */*p*/, size_t /*sz*/);		\
									\
/* --- @pre_mgfencrypt@ --- *						\
 *									\
 * Arguments:	@pre_mgfctx *k@ = pointer to masking context		\
 *		@const void *s@ = pointer to source buffer		\
 *		@void *d@ = pointer to destination buffer		\
 *		@size_t sz@ = size of buffers				\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Outputs pseudorandom data, or masks an input buffer.	\
 *									\
 *		If @s@ is nonzero, the source material is exclusive-	\
 *		orred with the generated mask.  If @d@ is zero, the	\
 *		generator is simply spun around for a while, which	\
 *		isn't very useful.					\
 */									\
									\
extern void pre##_mgfencrypt(pre##_mgfctx */*k*/, const void */*s*/,	\
			     void */*d*/, size_t /*sz*/);		\
									\
/* --- @pre_mgfsetindex@ --- *						\
 *									\
 * Arguments:	@pre_mgfctx *k@ = pointer to masking context		\
 *		@uint32 *c@ = new index to set				\
 *									\
 * Returns:	---							\
 *									\
 * Use:		Sets a new index.  This may be used to step around the	\
 *		output stream in a rather crude way.			\
 */									\
									\
extern void pre##_mgfsetindex(pre##_mgfctx */*k*/, uint32 /*c*/);	\
									\
/* --- @pre_mgfrand@ --- *						\
 *									\
 * Arguments:	@const void *k@ = pointer to key material		\
 *		@size_t sz@ = size of key material			\
 *									\
 * Returns:	Pointer to a generic random number generator instance.	\
 *									\
 * Use:		Creates a random number interface wrapper around an	\
 *		MGF-1-mode hash function.				\
 */									\
									\
extern grand *pre##_mgfrand(const void */*k*/, size_t /*sz*/);		\
									\
/* --- Generic cipher interface --- */					\
									\
extern const gccipher pre##_mgf;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
