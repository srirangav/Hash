/* -*-c-*-
 *
 * The alleged RC4 stream cipher
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on RC4 ------------------------------------------------------*
 *
 * RC4 is a stream cipher desgigned by Ron Rivest.  For a while RC4 was a
 * trade secret of RSA Data Security, Inc., but somehow source code for a
 * cipher which interworks with RC4 was posted to the Cypherpunks mailing
 * list.
 *
 * RC4 has some quite bad biases, and its use for cryptographic purposes is
 * no longer recommended.
 */

#ifndef CATACOMB_RC4_H
#define CATACOMB_RC4_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <assert.h>

#include <mLib/bits.h>

#ifndef CATACOMB_GCIPHER_H
#  include "gcipher.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct rc4_ctx {
  unsigned i, j;			/* Indices into the @S@ table */
  unsigned f;				/* Flags word */
  octet s[256];				/* The ever-changing @S@ table */
} rc4_ctx;

#define RC4F_OPEN 1u

/*----- Macros ------------------------------------------------------------*/

/* --- @RC4_OPEN@ --- *
 *
 * Arguments:	@ctx@ = pointer to an RC4 context
 *		@guts@ = code to perform within the RC4 context
 *
 * Use:		Performs some code within an RC4 context.  Some of the
 *		parameters are extracted from the context and held in local
 *		variables for speed.  Multiple calls to @RC4_BYTE@ may be
 *		made within the open context.  A context must only be
 *		opened once at a time.
 */

#define RC4_OPEN(ctx, guts) do {					\
  unsigned _rc4_i = (ctx)->i;						\
  unsigned _rc4_j = (ctx)->j;						\
  octet *_rc4_s = (ctx)->s;						\
									\
  assert(((void)"RC4 context may only be opened once at a time",	\
	  ((ctx)->f & RC4F_OPEN) == 0));				\
  (ctx)->f |= RC4F_OPEN;						\
									\
  guts									\
									\
  (ctx)->f &= ~RC4F_OPEN;						\
  (ctx)->i = _rc4_i;							\
  (ctx)->j = _rc4_j;							\
} while (0)

/* --- @RC4_BYTE@ --- *
 *
 * Arguments:	@x@ = output variable to set
 *
 * Use:		Extracts an octet from the lexically innermost open RC4
 *		context and places it in the variable @x@.
 */

#define RC4_BYTE(x) do {						\
  unsigned _si, _sj;							\
  _rc4_i = (_rc4_i + 1) & 0xff;						\
  _si = _rc4_s[_rc4_i];							\
  _rc4_j = (_rc4_j + _si) & 0xff;					\
  _sj = _rc4_s[_rc4_j];							\
  _rc4_s[_rc4_i] = _sj;							\
  _rc4_s[_rc4_j] = _si;							\
  (x) = _rc4_s[(_si + _sj) & 0xff];					\
} while (0)

/*----- Functions provided ------------------------------------------------*/

/* --- @rc4_addkey@ --- *
 *
 * Arguments:	@rc4_ctx *ctx@ = pointer to context to key
 *		@const void *k@ = pointer to key data to use
 *		@size_t sz@ = size of the key data
 *
 * Returns:	---
 *
 * Use:		Mixes key data with an RC4 context.  The RC4 context is not
 *		reset before mixing.  This may be used to mix new key
 *		material with an existing RC4 context.
 */

extern void rc4_addkey(rc4_ctx */*ctx*/, const void */*k*/, size_t /*sz*/);

/* --- @rc4_init@ --- *
 *
 * Arguments:	@rc4_ctx *ctx@ = pointer to context to initialize
 *		@const void *k@ = pointer to key data to use
 *		@size_t sz@ = size of the key data
 *
 * Returns:	---
 *
 * Use:		Initializes an RC4 context ready for use.
 */

extern void rc4_init(rc4_ctx */*ctx*/, const void */*k*/, size_t /*sz*/);

/* --- @rc4_encrypt@ --- *
 *
 * Arguments:	@rc4_ctx *ctx@ = pointer to context to use
 *		@const void *src@ = pointer to the source block
 *		@void *dest@ = pointer to the destination block
 *		@size_t sz@ = size of the block
 *
 * Returns:	---
 *
 * Use:		Encrypts or decrypts a block of data.  The destination may
 *		be null to just grind the generator around for a while.  It's
 *		recommended that you say `@rc4_encrypt(&ctx, 0, 0, 1024)@'
 *		after initializing a new context, to prevent keystream
 *		guessing attacks.  The source may be null to just extract a
 *		big lump of data from the generator.
 */

extern void rc4_encrypt(rc4_ctx */*ctx*/,
			const void */*src*/, void */*dest*/,
			size_t /*sz*/);

/*----- Generic cipher interface ------------------------------------------*/

#define RC4_KEYSZ 16
extern const octet rc4_keysz[];

extern const gccipher rc4;

/*----- Generic random number generator interface -------------------------*/

/* --- @rc4_rand@ --- *
 *
 * Arguments:	@const void *k@ = pointer to key material
 *		@size_t sz@ = size of key material
 *
 * Returns:	Pointer to generic random number generator interface.
 *
 * Use:		Creates a random number interface wrapper around the RC4
 *		stream cipher.
 */

extern grand *rc4_rand(const void */*k*/, size_t /*sz*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
