/* -*-c-*-
 *
 * Generic symmetric cipher interface
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GCIPHER_H
#define CATACOMB_GCIPHER_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

#ifndef CATACOMB_KEYSZ_H
#  include "keysz.h"
#endif

/*----- Generic symmetric cipher interface --------------------------------*/

typedef struct gcipher {
  const struct gcipher_ops *ops;	/* Pointer to cipher operations */
} gcipher;

typedef struct gcipher_ops {
  const struct gccipher *c;		/* Pointer to cipher class */
  void (*encrypt)(gcipher */*c*/, const void */*s*/,
		  void */*t*/, size_t /*sz*/);
  void (*decrypt)(gcipher */*c*/, const void */*s*/,
		  void */*t*/, size_t /*sz*/);
  void (*destroy)(gcipher */*c*/);
  void (*setiv)(gcipher */*c*/, const void */*iv*/);
  void (*bdry)(gcipher */*c*/);
} gcipher_ops;

typedef struct gccipher {
  const char *name;			/* Cipher name */
  const octet *keysz;			/* Preferred key size table */
  size_t blksz;				/* Block size or zero if none */
  gcipher *(*init)(const void */*k*/, size_t /*sz*/);
} gccipher;

#define GC_INIT(cc, k, sz)	(cc)->init((k), (sz))
#define GC_CLASS(cc)		(cc)->ops->c
#define GC_ENCRYPT(c, s, t, sz)	(c)->ops->encrypt((c), (s), (t), (sz))
#define GC_DECRYPT(c, s, t, sz)	(c)->ops->decrypt((c), (s), (t), (sz))
#define GC_DESTROY(c)		(c)->ops->destroy((c))
#define GC_SETIV(c, iv)		(c)->ops->setiv((c), (iv))
#define GC_BDRY(c)		(c)->ops->bdry((c))

/*----- Tables ------------------------------------------------------------*/

extern const gccipher *const gciphertab[];

/* --- @gcipher_byname@ --- *
 *
 * Arguments:	@const char *p@ = pointer to name string
 *
 * Returns:	The named cipher class, or null.
 */

extern const gccipher *gcipher_byname(const char */*p*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
