/* -*-c-*-
 *
 * Generate tables for Whirlpool hash function
 *
 * (c) 2005 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include <mLib/bits.h>

/*----- Static variables --------------------------------------------------*/

static const octet E[] = {
  0x1, 0xb, 0x9, 0xc, 0xd, 0x6, 0xf, 0x3,
  0xe, 0x8, 0x7, 0x4, 0xa, 0x2, 0x5, 0x0
}, R[] = {
  0x7, 0xc, 0xb, 0xd, 0xe, 0x4, 0x9, 0xf,
  0x6, 0x3, 0x8, 0xa, 0x2, 0x5, 0x1, 0x0
}, C[] = {
  0x1, 0x1, 0x4, 0x1, 0x8, 0x5, 0x2, 0x9
};

static octet S[256], T[256][8], log[256], alog[256];

/*----- Main code ---------------------------------------------------------*/

#define S_MOD 0x11d

static void logtable(void)
{
  unsigned i, x;

  for (i = 0, x = 1; i < 255; i++) {
    log[x] = i;
    alog[i] = x;
    x <<= 1;
    if (x & 0x100) x ^= S_MOD;
  }
}

static octet mul(octet x, octet y)
  { if (!x || !y) return (0); return (alog[(log[x] + log[y]) % 255]); }

static void sbox(void)
{
  unsigned i, j;
  octet EI[16];
  octet l, r, y;

  for (i = 0; i < 16; i++) EI[E[i]] = i;
  for (i = 0; i < 256; i++) {
    l = (i >> 4) & 0xf;
    r = (i >> 0) & 0xf;
    l = E[l]; r = EI[r];
    y = R[l ^ r];
    l = E[l ^ y]; r = EI[r ^ y];
    S[i] = (l << 4) | r;
  }

  for (i = 0; i < 256; i++) {
    for (j = 0; j < 8; j++)
      T[i][j] = mul(S[i], C[j]);
  }
}

static unsigned long w32(int i, int j, int k)
{
  kludge64 x;
  LOAD64_L_(x, T[j]);
  ROL64_(x, x, i * 8);
  return (k ? LO64(x) : HI64(x));
}

int main(void)
{
  int i, j;

  puts("\
/* -*-c-*-\n\
 *\n\
 * Whirlpool tables [generated]\n\
 */\n\
\n\
#include <mLib/bits.h>\n\
\n\
#if defined(HAVE_UINT64)\n\
#  define USE64\n\
#endif\n\
\n\
");

  /* --- Write out the S-box --- */

  logtable();
  sbox();
  fputs("\
/* --- The byte substitution --- */\n\
\n\
const octet whirlpool_s[256] = {\n\
  ", stdout);
  for (i = 0; i < 256; i++) {
    printf("0x%02x", S[i]);
    if (i == 255)
      fputs("\n};\n\n", stdout);
    else if (i % 8 == 7)
      fputs(",\n  ", stdout);
    else
      fputs(", ", stdout);
  }

  /* --- Write out the key constant tables --- */

  fputs("\
/* --- The key generation constants --- */\n\
\n\
const kludge64 whirlpool_c[10] = {\n\
  ", stdout);
  for (i = 0; i < 10; i++) {
    printf("X64(%08lx, %08lx)",
	   (unsigned long)LOAD32_L(&S[i * 8 + 4]),
	   (unsigned long)LOAD32_L(&S[i * 8 + 0]));
    if (i == 9)
      fputs("\n};\n\n", stdout);
    else if (i % 2 == 1)
      fputs(",\n  ", stdout);
    else
      fputs(", ", stdout);
  }

  /* --- Write out the big T tables --- */

  fputs("\
#ifdef USE64\n\
\n\
/* --- The 64-bit big round tables --- */\n\
\n\
const kludge64 whirlpool_t[8][256] = {\n\
  { ", stdout);
  for (j = 0; j < 8; j++) {
    for (i = 0; i < 256; i++) {
      printf("X64(%08lx, %08lx)", w32(j, i, 0), w32(j, i, 1));
      if (i == 255) {
	if (j == 7)
	  fputs(" }\n};\n\n", stdout);
	else
	  fputs(" },\n\n  { ", stdout);
      } else if (i % 2 == 1)
	fputs(",\n    ", stdout);
      else
	fputs(", ", stdout);
    }
  }

  /* --- Write out the smaller U and V tables --- */

  fputs("\
#else\n\
\n\
/* --- The 32-bit round tables --- */\n\
\n\
const uint32 whirlpool_u[4][256] = {\n\
  { ", stdout);
  for (j = 0; j < 4; j++) {
    for (i = 0; i < 256; i++) {
      printf("0x%08lx", w32(j, i, 1));
      if (i == 255) {
	if (j == 3)
	  fputs(" }\n};\n\n", stdout);
	else
	  fputs(" },\n\n  { ", stdout);
      } else if (i % 4 == 3)
	fputs(",\n    ", stdout);
      else
	fputs(", ", stdout);
    }
  }

  fputs("\
const uint32 whirlpool_v[4][256] = {\n\
  { ", stdout);
  for (j = 0; j < 4; j++) {
    for (i = 0; i < 256; i++) {
      printf("0x%08lx", w32(j, i, 0));
      if (i == 255) {
	if (j == 3)
	  fputs(" }\n};\n\n", stdout);
	else
	  fputs(" },\n\n  { ", stdout);
      } else if (i % 4 == 3)
	fputs(",\n    ", stdout);
      else
	fputs(", ", stdout);
    }
  }

  /* --- Done --- */

  puts("#endif");

  if (fclose(stdout)) {
    fprintf(stderr, "error writing data\n");
    exit(EXIT_FAILURE);
  }

  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
