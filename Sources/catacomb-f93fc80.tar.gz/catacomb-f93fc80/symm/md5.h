/* -*-c-*-
 *
 * The MD5 message digest function
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the MD5 hash function ------------------------------------*
 *
 * MD5 was designed by Ron Rivest.  It was intended to be a more conservative
 * design than the slightly earlier MD4, and indeed while MD4 has been pretty
 * much demolished by subsequent cryptanalysis, MD5 is still standing
 * shakily.  It's provided here not because the author recommends its use but
 * because it's a common standard, and is often handy in non-cryptographic
 * applications.  It's also still useful in constructions such as HMAC.
 */

#ifndef CATACOMB_MD5_H
#define CATACOMB_MD5_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

/*----- Magic numbers -----------------------------------------------------*/

#define MD5_BUFSZ 64
#define MD5_HASHSZ 16
#define MD5_STATESZ 16

/*----- Data structures ---------------------------------------------------*/

typedef struct md5_ctx {
  uint32 a, b, c, d;			/* Chaining variables */
  uint32 nl, nh;			/* Byte count so far */
  unsigned off;				/* Offset into buffer */
  octet buf[MD5_BUFSZ];			/* Accumulation buffer */
} md5_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @md5_compress@ --- *
 *
 * Arguments:	@md5_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		MD5 compression function.
 */

extern void md5_compress(md5_ctx */*ctx*/, const void */*sbuf*/);

/* --- @md5_init@ --- *
 *
 * Arguments:	@md5_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

extern void md5_init(md5_ctx */*ctx*/);

/* --- @md5_set@ --- *
 *
 * Arguments:	@md5_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

extern void md5_set(md5_ctx */*ctx*/, const void */*buf*/,
		    unsigned long /*count*/);

/* --- @md5_hash@ --- *
 *
 * Arguments:	@md5_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

extern void md5_hash(md5_ctx */*ctx*/, const void */*buf*/, size_t /*sz*/);

/* --- @md5_done@ --- *
 *
 * Arguments:	@md5_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

extern void md5_done(md5_ctx */*ctx*/, void */*hash*/);

/* --- @md5_state@ --- *
 *
 * Arguments:	@md5_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @md5_set@.
 */

extern unsigned long md5_state(md5_ctx */*ctx*/, void */*state*/);

/*----- Generic hash interface --------------------------------------------*/

extern const gchash md5;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
