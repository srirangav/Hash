/* -*-c-*-
 *
 * The MD4 message digest function
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the MD4 hash function ------------------------------------*
 *
 * MD4 was designed by Ron Rivest.  It's now well and truly broken: not only
 * have collisions been discovered, a slightly cut-down version has been
 * shown to be non-preimage-resistant.  On the other hand, MD4 is fast and
 * makes a good heavy-duty checksum.  Just don't rely on it being
 * cryptographically strong, 'cos it ain't.
 */

#ifndef CATACOMB_MD4_H
#define CATACOMB_MD4_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

/*----- Magic numbers -----------------------------------------------------*/

#define MD4_BUFSZ 64
#define MD4_HASHSZ 16
#define MD4_STATESZ 16

/*----- Data structures ---------------------------------------------------*/

typedef struct md4_ctx {
  uint32 a, b, c, d;			/* Chaining variables */
  uint32 nl, nh;			/* Byte count so far */
  unsigned off;				/* Offset into buffer */
  octet buf[MD4_BUFSZ];			/* Accumulation buffer */
} md4_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @md4_compress@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block
 *		@const void *sbuf@ = pointer to buffer of appropriate size
 *
 * Returns:	---
 *
 * Use:		MD4 compression function.
 */

extern void md4_compress(md4_ctx */*ctx*/, const void */*sbuf*/);

/* --- @md4_init@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a context block ready for hashing.
 */

extern void md4_init(md4_ctx */*ctx*/);

/* --- @md4_set@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = pointer to state buffer
 *		@unsigned long count@ = current count of bytes processed
 *
 * Returns:	---
 *
 * Use:		Initializes a context block from a given state.  This is
 *		useful in cases where the initial hash state is meant to be
 *		secret, e.g., for NMAC and HMAC support.
 */

extern void md4_set(md4_ctx */*ctx*/, const void */*buf*/,
		    unsigned long /*count*/);

/* --- @md4_hash@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block
 *		@const void *buf@ = buffer of data to hash
 *		@size_t sz@ = size of buffer to hash
 *
 * Returns:	---
 *
 * Use:		Hashes a buffer of data.  The buffer may be of any size and
 *		alignment.
 */

extern void md4_hash(md4_ctx */*ctx*/, const void */*buf*/, size_t /*sz*/);

/* --- @md4_done@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context block
 *		@void *hash@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Returns the hash of the data read so far.
 */

extern void md4_done(md4_ctx */*ctx*/, void */*hash*/);

/* --- @md4_state@ --- *
 *
 * Arguments:	@md4_ctx *ctx@ = pointer to context
 *		@void *state@ = pointer to buffer for current state
 *
 * Returns:	Number of bytes written to the hash function so far.
 *
 * Use:		Returns the current state of the hash function such that
 *		it can be passed to @md4_set@.
 */

extern unsigned long md4_state(md4_ctx */*ctx*/, void */*state*/);

/*----- Generic hash interface --------------------------------------------*/

extern const gchash md4;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
