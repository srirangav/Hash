/* -*-c-*-
 *
 * Generalized version of DSA
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "dsa.h"
#include "gdsa.h"
#include "group.h"
#include "ghash.h"
#include "mpbarrett.h"
#include "mprand.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @gdsa_beginhash@ --- *
 *
 * Arguments:	@const gdsa *c@ = pointer to the context structure
 *
 * Returns:	A hashing context for you to hash the message.
 *
 * Use:		Initializes a hash function correctly for you to hash a
 *		message.  Requires @h@.
 */

ghash *gdsa_beginhash(const gdsa *c) { return (GH_INIT(c->h)); }

/* --- @gdsa_endhash@ --- *
 *
 * Arguments:	@const gdsa *c@ = pointer to the context structure
 *		@ghash *h@ = the hashing context
 *
 * Returns:	---
 *
 * Use:		Does any final thing that DSA wants to do when hashing a
 *		message.  (Actually, there's nothing.)	The hashing context
 *		isn't finalized.
 */

void gdsa_endhash(const gdsa *c, ghash *h) { ; }

/* --- @gdsa_sign@ --- *
 *
 * Arguments:	@const gdsa *c@ = my context structure
 *		@gdsa_sig *s@ = where to put the signature (initialized)
 *		@const void *m@ = pointer to message hash
 *		@mp *k@ = random exponent for this message or null
 *
 * Returns:	---
 *
 * Use:		Signs a message.  Requires @g@, @u@, @h@, and @r@ if @k@ is
 *		null.  This is a better idea than inventing @k@ yourself.
 */

void gdsa_sign(const gdsa *c, gdsa_sig *s, const void *m, mp *k)
{
  group *g = c->g;
  mp *mr = dsa_h2n(MP_NEW, g->r, m, c->h->hashsz);
  ge *z = G_CREATE(g);
  mp *sr = s->r, *ss = s->s;
  mpbarrett b;

  if (k) { MP_COPY(k); goto have_k; }
new_k:
  k = dsa_nonce(k, g->r, c->u, m, c->h, c->r);
have_k:
  if (MP_ZEROP(k)) goto new_k;
  G_EXP(g, z, g->g, k);
  sr = G_TOINT(g, sr, z); assert(sr);
  if (MP_ZEROP(sr)) goto new_k;

  mp_div(0, &sr, sr, g->r);
  mpbarrett_create(&b, g->r);
  ss = mp_mul(ss, sr, c->u); ss = mpbarrett_reduce(&b, ss, ss);
  ss = mp_add(ss, ss, mr); mp_div(0, &ss, ss, g->r);
  k = mp_modinv(k, k, g->r);
  ss = mp_mul(ss, ss, k); ss = mpbarrett_reduce(&b, ss, ss);
  s->r = sr; s->s = ss;
  mp_drop(k); mp_drop(mr); mpbarrett_destroy(&b); G_DESTROY(g, z);
}

/* --- @gdsa_verify@ --- *
 *
 * Arguments:	@const gdsa *c@ = my context structure
 *		@const gdsa_sig *s@ = the signature to verify
 *		@const void *m@ = pointer to message hash
 *
 * Returns:	Zero if OK, negative on failure.
 *
 * Use:		Checks a signature on a message,  Requires @g@, @p@ and @h@.
 */

int gdsa_verify(const gdsa *c, const gdsa_sig *s, const void *m)
{
  group *g = c->g;
  group_expfactor e[2];
  mpbarrett b;
  mp *h, *t;
  ge *w;
  int rc = -1;

  if (MP_CMP(s->r, <, MP_ONE) || MP_CMP(s->r, >=, g->r) ||
      MP_CMP(s->s, <, MP_ONE) || MP_CMP(s->s, >=, g->r))
    return (-1);
  mpbarrett_create(&b, g->r); h = mp_modinv(MP_NEW, s->s, g->r);
  e[0].base = g->g; e[1].base = c->p;
  t = dsa_h2n(MP_NEW, g->r, m, c->h->hashsz); mp_div(0, &t, t, g->r);
  t = mp_mul(t, t, h); e[0].exp = t = mpbarrett_reduce(&b, t, t);
  h = mp_mul(h, s->r, h); e[1].exp = h = mpbarrett_reduce(&b, h, h);
  w = G_CREATE(g); G_MEXP(g, w, e, 2);
  t = G_TOINT(g, t, w); if (!t) goto done;
  mp_div(0, &t, t, g->r); if (MP_EQ(t, s->r)) rc = 0;
done:
  G_DESTROY(g, w); mp_drop(t); mp_drop(h); mpbarrett_destroy(&b);
  return (rc);
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#include "rand.h"

static group *getgroup(const char *p) {
  group *g; qd_parse qd;
  qd.p = p; qd.e = 0; g = group_parse(&qd);
  if (g && !qd_eofp(&qd)) { G_DESTROYGROUP(g); g = 0; qd.e = "junk at eof"; }
  if (!g) {
    fprintf(stderr, "bad group string `%.*s|%s': %s\n",
	    (int)(qd.p - p), p, qd.p, qd.e);
    exit(1);
  }
  return (g);
}

static ge *getge(group *g, const char *p) {
  ge *x = G_CREATE(g);
  if (group_readstring(g, x, p, 0)) {
    fprintf(stderr, "bad group element `%s'\n", p);
    exit(1);
  }
  return (x);
}

static void showge(group *g, const char *p, ge *x) {
  fprintf(stderr, "*** %s = ", p); group_writefile(g, x, stderr);
  putc('\n', stderr);
}

static void showmp(const char *p, mp *x, int r) {
  fprintf(stderr, "*** %s = ", p); mp_writefile(x, stderr, r);
  putc('\n', stderr);
}

static int tsign(dstr *v)
{
  gdsa c;
  gdsa_sig s, ss = GDSA_SIG_INIT;
  ghash *h;
  octet *m;
  mp *k;
  int ok = 1;

  c.g = getgroup(v[0].buf); c.h = ghash_byname(v[1].buf);
  c.u = *(mp **)v[2].buf; k = *(mp **)v[4].buf;
  s.r = *(mp **)v[5].buf; s.s = *(mp **)v[6].buf;
  c.p = G_CREATE(c.g); G_EXP(c.g, c.p, c.g->g, c.u);

  h = gdsa_beginhash(&c);
  GH_HASH(h, v[3].buf, v[3].len);
  gdsa_endhash(&c, h);
  gdsa_sign(&c, &ss, GH_DONE(h, 0), k);
  if (!MP_EQ(s.r, ss.r) || !MP_EQ(s.s, ss.s)) {
    ok = 0;
    fprintf(stderr, "*** sign failed!\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    fprintf(stderr, "*** hash: %s\n", c.h->name);
    showmp("private key", c.u, 16);
    fprintf(stderr, "*** message: `%s'\n", v[3].buf);
    showmp("computed r", ss.r, 16); showmp("computed s", ss.s, 16);
    showmp("expected r", s.r, 16); showmp("expected s", s.s, 16);
  }

  c.r = &rand_global;
  h = gdsa_beginhash(&c);
  GH_HASH(h, v[3].buf, v[3].len);
  m = GH_DONE(h, 0);
  GH_DESTROY(h);
  gdsa_sign(&c, &ss, m, 0);
  if (gdsa_verify(&c, &ss, m)) {
    ok = 0;
    fprintf(stderr, "*** sign cross-check failed!\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    fprintf(stderr, "*** hash: %s\n", c.h->name);
    showmp("private key", c.u, 16);
    showge(c.g, "public key", c.p);
    fprintf(stderr, "*** message: `%s'\n", v[3].buf);
    showmp("computed r", ss.r, 16); showmp("computed s", ss.s, 16);
  }

  mp_drop(s.r); mp_drop(s.s); mp_drop(ss.r); mp_drop(ss.s);
  mp_drop(k); mp_drop(c.u); G_DESTROY(c.g, c.p); G_DESTROYGROUP(c.g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int tverify(dstr *v)
{
  gdsa c;
  gdsa_sig s;
  ghash *h;
  int rc, erc;
  int ok = 1;

  c.g = getgroup(v[0].buf); c.h = ghash_byname(v[1].buf);
  c.p = getge(c.g, v[2].buf);
  s.r = *(mp **)v[4].buf; s.s = *(mp **)v[5].buf;
  erc = *(int *)v[6].buf;

  h = gdsa_beginhash(&c);
  GH_HASH(h, v[3].buf, v[3].len);
  gdsa_endhash(&c, h);
  rc = gdsa_verify(&c, &s, GH_DONE(h, 0));
  if (!rc != !erc) {
    ok = 0;
    fprintf(stderr, "*** verify failed!\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    fprintf(stderr, "*** hash: %s\n", c.h->name);
    showge(c.g, "public key", c.p);
    fprintf(stderr, "*** message: `%s'\n", v[3].buf);
    showmp("sig r", s.r, 16); showmp("sig s", s.s, 16);
    fprintf(stderr, "*** expected %s\n", !erc ? "pass" : "fail");
  }
  mp_drop(s.r); mp_drop(s.s); G_DESTROY(c.g, c.p); G_DESTROYGROUP(c.g);
  GH_DESTROY(h);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static const test_chunk tests[] = {
  { "sign", tsign, { &type_string, &type_string, &type_mp, &type_string,
		     &type_mp, &type_mp, &type_mp } },
  { "verify", tverify, { &type_string, &type_string, &type_string,
			 &type_string, &type_mp, &type_mp, &type_int } },
  { 0 }
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/gdsa");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
