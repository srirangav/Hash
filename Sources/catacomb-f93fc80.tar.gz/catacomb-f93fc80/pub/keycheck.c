/* -*-c-*-
 *
 * Framework for checking consistency of keys
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdarg.h>

#include <mLib/dstr.h>

#include "keycheck.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @keycheck_report@ --- *
 *
 * Arguments:	@keycheck *kc@ = keycheck state
 *		@unsigned sev@ = severity of this report
 *		@const char *msg@ = message to send along
 *		@...@ = things to fill the message in with
 *
 * Returns:	Zero to continue, or nonzero to stop and give up.
 *
 * Use:		Reports a message to the user function.
 */

int keycheck_report(keycheck *kc, unsigned sev, const char *msg, ...)
{
  int rc;
  va_list ap;
  dstr d = DSTR_INIT;

  kc->sev[sev]++;
  va_start(ap, msg);
  dstr_vputf(&d, msg, &ap);
  va_end(ap);
  rc = kc->func ? kc->func(sev, d.buf, kc->p) : 0;
  dstr_destroy(&d);
  return (rc);
}

/* --- @keycheck_init@ --- *
 *
 * Arguments:	@keycheck *kc@ = pointer to block to initialize
 *		@int (*func)(unsigned sev, const char *msg, void *p)@ =
 *			handler function for problems
 *		@void *p@ = pointer to give to handler
 *
 * Returns:	---
 *
 * Use:		Initializes a key checking context.
 */

void keycheck_init(keycheck *kc,
		   int (*func)(unsigned /*sev*/,
			       const char */*msg*/,
			       void */*p*/),
		   void *p)
{
  unsigned i;
  kc->func = func;
  kc->p = p;
  for (i = 0; i < KCSEV_MAX; i++)
    kc->sev[i] = 0;
}

/* --- @keycheck_allclear@ --- *
 *
 * Arguments:	@keycheck *kc@ = pointer to keycheck context
 *		@unsigned sev@ = minimum severity to care about
 *
 * Returns:	Nonzero if no problems of @sev@ or above were noticed.
 */

int keycheck_allclear(keycheck *kc, unsigned sev)
{
  while (sev < KCSEV_MAX) {
    if (kc->sev[sev])
      return (0);
    sev++;
  }
  return (1);
}

/*----- That's all, folks -------------------------------------------------*/
