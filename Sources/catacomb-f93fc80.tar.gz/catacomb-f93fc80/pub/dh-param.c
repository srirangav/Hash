/* -*-c-*-
 *
 * Reading Diffie-Hellman parameters
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "dh.h"
#include "ptab.h"
#include "bintab.h"

/*----- Main code ---------------------------------------------------------*/

/* ---- @dh_infofromdata@ --- *
 *
 * Arguments:	@dh_param *dp@ = parameters to fill in
 *		@pdata *pd@ = packed data structure
 *
 * Returns:	---
 *
 * Use:		Fills in a parameters structure from a packed data block.
 */

void dh_infofromdata(dh_param *dp, pdata *pd)
  { dp->p = &pd->p; dp->q = &pd->q; dp->g = &pd->g; }

/* --- @dh_parse@, @dhbin_parse@ --- *
 *
 * Arguments:	@qd_parse *qd@ = parser context
 *		@dh_param *dp@ = parameters to fill in
 *
 * Returns:	Zero if OK, nonzero on error.
 *
 * Use:		Parses a prime group string.  This is either one of the
 *		standard group strings, or a %$p$%, %$q$%, %$g$% triple
 *		separated by commas.
 */

static int parse(qd_parse *qd, gprime_param *dp)
{
  mp *p = MP_NEW, *q = MP_NEW, *g = MP_NEW;

  if ((p = qd_getmp(qd)) == 0) goto fail;
  qd_delim(qd, ','); if ((q = qd_getmp(qd)) == 0) goto fail;
  qd_delim(qd, ','); if ((g = qd_getmp(qd)) == 0) goto fail;
  dp->p = p; dp->q = q; dp->g = g;
  return (0);
fail:
  mp_drop(p); mp_drop(q); mp_drop(g);
  return (-1);
}

int dh_parse(qd_parse *qd, dh_param *dp)
{
  const pentry *pe;

  for (pe = ptab; pe->name; pe++) {
    if (qd_enum(qd, pe->name) >= 0) {
      dh_infofromdata(dp, pe->data);
      goto found;
    }
  }
  if (parse(qd, dp))
    return (-1);
found:
  return (0);
}

int dhbin_parse(qd_parse *qd, gbin_param *gb)
{
  const binentry *be;

  for (be = bintab; be->name; be++) {
    if (qd_enum(qd, be->name) >= 0) {
      dh_infofromdata(gb, be->data);
      goto found;
    }
  }
  if (parse(qd, gb))
    return (-1);
found:
  return (0);
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#include "fibrand.h"

int main(int argc, char *argv[])
{
  const pentry *pe;
  const binentry *be;
  const char *e;
  int ok = 1, aok = 1;
  grand *gr;

  gr = fibrand_create(0);
  fputs("checking standard prime groups:", stdout);
  fflush(stdout);
  for (pe = ptab; pe->name; pe++) {
    dh_param dp;
    group *g;
    dh_infofromdata(&dp, pe->data);
    g = group_prime(&dp);
    if (mp_bits(dp.p) > 2048 &&
	(!argv[1] || strcmp(argv[1], "keen") != 0)) {
      printf(" [%s skipped]", pe->name);
      fflush(stdout);
      continue;
    }
    e = G_CHECK(g, gr);
    G_DESTROYGROUP(g);
    dh_paramfree(&dp);
    if (e) {
      printf(" [%s failed: %s]", pe->name, e);
      ok = aok = 0;
    } else
      printf(" %s", pe->name);
    fflush(stdout);
  }
  fputs(ok ? " ok\n" : " failed\n", stdout);
  ok = 1;
  fputs("checking standard binary groups:", stdout);
  for (be = bintab; be->name; be++) {
    gbin_param gb;
    group *g;
    dh_infofromdata(&gb, be->data);
    g = group_binary(&gb);
    e = G_CHECK(g, gr);
    G_DESTROYGROUP(g);
    dh_paramfree(&gb);
    if (e) {
      printf(" [%s failed: %s]", be->name, e);
      ok = aok = 0;
    } else
      printf(" %s", be->name);
    fflush(stdout);
  }
  fputs(ok ? " ok\n" : " failed\n", stdout);
  gr->ops->destroy(gr);
  return (!aok);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
