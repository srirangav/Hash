/* -*-c-*-
 *
 * [RSA encryption with padding *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/alloc.h>
#include <mLib/bits.h>
#include <mLib/dstr.h>

#include "mp.h"
#include "mpmont.h"
#include "rsa.h"

/*----- Public key operations ---------------------------------------------*/

/* --- @rsa_pubcreate@ --- *
 *
 * Arguments:	@rsa_pubctx *rd@ = pointer to an RSA public key context
 *		@rsa_pub *rp@ = pointer to RSA public key
 *
 * Returns:	---
 *
 * Use:		Initializes an RSA public-key context.
 */

void rsa_pubcreate(rsa_pubctx *rd, rsa_pub *rp)
{
  rd->rp = rp;
  mpmont_create(&rd->mm, rp->n);
}

/* --- @rsa_pubdestroy@ --- *
 *
 * Arguments:	@rsa_pubctx *rd@ = pointer to an RSA public key context
 *
 * Returns:	---
 *
 * Use:		Destroys an RSA public-key context.
 */

void rsa_pubdestroy(rsa_pubctx *rd)
{
  mpmont_destroy(&rd->mm);
}

/* --- @rsa_pubop@ --- *
 *
 * Arguments:	@rsa_pubctx *rd@ = pointer to an RSA public key context
 *		@mp *d@ = destination
 *		@mp *p@ = input message
 *
 * Returns:	The transformed output message.
 *
 * Use:		Performs an RSA public key operation.
 */

mp *rsa_pubop(rsa_pubctx *rd, mp *d, mp *p)
{
  return (mpmont_exp(&rd->mm, d, p, rd->rp->e));
}

/* --- @rsa_qpubop@ --- *
 *
 * Arguments:	@rsa_pub *rp@ = pointer to RSA parameters
 *		@mp *d@ = destination
 *		@mp *p@ = input message
 *
 * Returns:	Correctly transformed output message.
 *
 * Use:		Performs an RSA public key operation.
 */

mp *rsa_qpubop(rsa_pub *rp, mp *d, mp *c)
{
  rsa_pubctx rd;
  rsa_pubcreate(&rd, rp);
  d = rsa_pubop(&rd, d, c);
  rsa_pubdestroy(&rd);
  return (d);
}

/*----- Operations with padding -------------------------------------------*/

/* --- @rsa_encrypt@ --- *
 *
 * Arguments:	@rsa_pubctx *rp@ = pointer to an RSA public key context
 *		@mp *d@ = proposed destination integer
 *		@const void *m@ = pointer to input message
 *		@size_t msz@ = size of input message
 *		@rsa_pad *e@ = encoding procedure
 *		@void *earg@ = argument pointer for encoding procedure
 *
 * Returns:	The encrypted message, as a multiprecision integer, or null
 *		on failure.
 *
 * Use:		Does RSA encryption.
 */

mp *rsa_encrypt(rsa_pubctx *rp, mp *d, const void *m, size_t msz,
		rsa_pad *e, void *earg)
{
  octet *p;
  unsigned long nb = mp_bits(rp->rp->n);
  size_t n = (nb + 7)/8;
  arena *a = d && d->a ? d->a->a : arena_global;

  p = x_alloc(a, n);
  d = e(d, m, msz, p, n, nb, earg);
  x_free(a, p);
  return (d ? rsa_pubop(rp, d, d) : 0);
}

/* --- @rsa_verify@ --- *
 *
 * Arguments:	@rsa_pubctx *rp@ = pointer to an RSA public key contxt
 *		@mp *s@ = the signature, as a multiprecision integer
 *		@const void *m@ = pointer to message to verify, or null
 *		@size_t msz@ = size of input message
 *		@dstr *d@ = pointer to output string, or null
 *		@rsa_vfrunpad *e@ = decoding procedure
 *		@void *earg@ = argument pointer for decoding procedure
 *
 * Returns:	The length of the output string if successful (0 if no output
 *		was wanted); negative on failure.
 *
 * Use:		Does RSA signature verification.  To use a signature scheme
 *		with recovery, pass in @m == 0@ and @d != 0@: the recovered
 *		message should appear in @d@.  To use a signature scheme with
 *		appendix, provide @m != 0@ and @d == 0@; the result should be
 *		zero for success.
 */

int rsa_verify(rsa_pubctx *rp, mp *s, const void *m, size_t msz,
	       dstr *d, rsa_vrfunpad *e, void *earg)
{
  mp *p = rsa_pubop(rp, MP_NEW, s);
  unsigned long nb = mp_bits(rp->rp->n);
  size_t n = (nb + 7)/8;
  dstr dd = DSTR_INIT;
  int rc;

  /* --- Decoder protocol --- *
   *
   * We deal with two kinds of decoders: ones with message recovery and ones
   * with appendix.  A decoder with recovery will leave a message in the
   * buffer and exit nonzero: we'll check that against @m@ if provided and
   * just leave it otherwise.  A decoder with appendix will inspect @m@ and
   * return zero or @-1@ itself.
   */

  if (!d) d = &dd;
  dstr_ensure(d, n);
  rc = e(p, m, msz, (octet *)d->buf + d->len, n, nb, earg);
  if (rc > 0 && m) {
    if (rc != msz || memcmp(d->buf + d->len, m, msz) != 0)
      rc = -1;
    else
      rc = 0;
  }
  if (rc > 0)
    d->len += rc;
  mp_drop(p);
  dstr_destroy(&dd);
  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
