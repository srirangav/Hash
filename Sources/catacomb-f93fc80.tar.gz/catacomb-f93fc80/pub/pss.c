/* -*-c-*-
 *
 * Probabistic signature scheme
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <string.h>

#include <mLib/alloc.h>
#include <mLib/bits.h>
#include <mLib/dstr.h>

#include "gcipher.h"
#include "ghash.h"
#include "grand.h"
#include "rsa.h"

/*----- Magic statics -----------------------------------------------------*/

static const octet z8[8] = { 0 };

/*----- Main code ---------------------------------------------------------*/

/* --- @pss_encode@ --- *
 *
 * Arguments:	@mp *d@ = where to put the answer
 *		@const void *m@ = pointer to the message hash
 *		@size_t msz@ = the size of the message hash
 *		@octet *b@ = scratch buffer
 *		@size_t sz@ = sizeo of the buffer (large enough)
 *		@unsigned long nbits@ = size in bits of @n@
 *		@void *p@ = pointer to the PSS parameters
 *
 * Returns:	Encoded message representative, or null on error.
 *
 * Use:		Implements the operation @EMSA-PSS-ENCODE@, as defined in
 *		PKCS#1 v. 2.1 (RFC3447).
 */

mp *pss_encode(mp *d, const void *m, size_t msz, octet *b, size_t sz,
	       unsigned long nbits, void *p)
{
  pss *pp = p;
  octet *s, *r;
  ghash *h;
  gcipher *c;
  unsigned mask;
  size_t pssz, hsz = pp->ch->hashsz;

  /* --- Check the message length --- */

  nbits--;
  sz = (nbits + 7)/8;
  mask = (1 << nbits%8) - 1;
  if (!mask) mask = 0xff;
  if (hsz + pp->ssz + 2 > sz)
    return (0);

  /* --- Generate a random salt --- */

  pssz = sz - pp->ssz - hsz - 2;
  memset(b, 0, pssz);
  b[pssz] = 0x01;
  s = b + pssz + 1;
  r = s + pp->ssz;
  GR_FILL(pp->r, s, pp->ssz);

  /* --- Compute the salted hash --- */

  h = GH_INIT(pp->ch);
  GH_HASH(h, z8, 8);
  GH_HASH(h, m, msz);
  GH_HASH(h, s, pp->ssz);
  GH_DONE(h, r);
  r[hsz] = 0xbc;

  /* --- Do the masking --- */

  c = GC_INIT(pp->cc, r, hsz);
  GC_ENCRYPT(c, b, b, pssz + pp->ssz + 1);
  GC_DESTROY(c);
  b[0] &= mask;
  return (mp_loadb(d, b, sz));
}

/* --- @pss_decode@ --- *
 *
 * Arguments:	@mp *s@ = the message representative
 *		@const void *m@ = the original message
 *		@size_t msz@ = the message size
 *		@octet *b@ = a scratch buffer
 *		@size_t sz@ = size of the buffer (large enough)
 *		@unsigned long nbits@ = number of bits in @n@
 *		@void *p@ = pointer to PKCS1 parameters
 *
 * Returns:	The length of the output string if successful, negative on
 *		failure.
 *
 * Use:		Implements the operation @EMSA_PSS_VERIFY@, as defined in
 *		PCSK#1 v. 2.1 (RFC3447).
 */

int pss_decode(mp *mi, const void *m, size_t msz, octet *b, size_t sz,
	       unsigned long nbits, void *p)
{
  pss *pp = p;
  octet *s, *r;
  ghash *h;
  gcipher *c;
  unsigned mask;
  size_t pssz, hsz = pp->ch->hashsz, i;
  int rc;

  /* --- Check the message length --- */

  nbits--;
  sz = (nbits + 7)/8;
  if (mp_octets(mi) > sz)
    return (-1);
  mask = (1 << nbits%8) - 1;
  if (!mask) mask = 0xff;
  if (hsz + pp->ssz + 2 > sz)
    return (-1);
  mp_storeb(mi, b, sz);

  /* --- Split up the buffer --- */

  pssz = sz - hsz - pp->ssz - 2;
  s = b + pssz + 1;
  r = s + pp->ssz;
  if (r[hsz] != 0xbc)
    return (-1);

  /* --- Decode the seed --- */

  if (b[0] & ~mask)
    return (-1);
  c = GC_INIT(pp->cc, r, hsz);
  GC_DECRYPT(c, b, b, pssz + pp->ssz + 1);
  GC_DESTROY(c);
  b[0] &= mask;
  for (i = 0; i < pssz; i++)
    if (b[i]) return (-1);
  if (b[pssz] != 0x01)
    return (-1);

  /* --- Hash the message --- */

  h = GH_INIT(pp->ch);
  GH_HASH(h, z8, 8);
  GH_HASH(h, m, msz);
  GH_HASH(h, s, pp->ssz);
  s = GH_DONE(h, 0);
  rc = !memcmp(s, r, hsz);
  GH_DESTROY(h);
  if (!rc) return (-1);

  /* --- Done --- */

  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
