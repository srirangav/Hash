/* -*-c-*-
 *
 * Key fetching for BBS public and private keys
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "bbs.h"
#include "key.h"

/*----- Key fetching ------------------------------------------------------*/

const key_fetchdef bbs_pubfetch[] = {
  { "n",	offsetof(bbs_pub, n),		KENC_MP,	0 },
  { 0,		0,				0,		0 }
};

static const key_fetchdef priv[] = {
  { "p",	offsetof(bbs_priv, p),		KENC_MP,	0 },
  { "q",	offsetof(bbs_priv, q),		KENC_MP,	0 },
  { 0,		0,				0,		0 }
};

const key_fetchdef bbs_privfetch[] = {
  { "n",	offsetof(bbs_priv, n),		KENC_MP,	0 },
  { "private",	0,				KENC_STRUCT,	priv },
  { 0,		0,				0,		0 }
};

/* --- @bbs_pubfree@, @bbs_privfree@ --- *
 *
 * Arguments:	@bbs_pub *bp@, @bbs_priv *bp@ = pointer to key block
 *
 * Returns:	---
 *
 * Use:		Frees an RSA key block.
 */

void bbs_pubfree(bbs_pub *bp)
{
  mp_drop(bp->n);
}

void bbs_privfree(bbs_priv *bp)
{
  mp_drop(bp->n);
  mp_drop(bp->p);
  mp_drop(bp->q);
}

/*----- That's all, folks -------------------------------------------------*/
