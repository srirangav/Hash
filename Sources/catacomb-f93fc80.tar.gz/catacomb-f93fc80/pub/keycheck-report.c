/* -*-c-*-
 *
 * A standard reporter function
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>

#include "keycheck.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @keycheck_stdreport@ --- *
 *
 * Arguments:	@unsigned sev@ = problem severity
 *		@const char *msg@ = message to report
 *		@void *p@ = an uninteresting pointer
 *
 * Returns:	Zero.
 *
 * Use:		Reports a message to stderr.
 */

int keycheck_stdreport(unsigned sev, const char *msg, void *p)
{
  static const char *const sevtab[] = {
    "informational", "warning", "error"
  };
  keycheck_reportctx *r = p;
  if (r && sev < r->sev)
    return (0);
  fprintf(r ? r->fp : stderr, "keycheck: %s: %s\n", sevtab[sev], msg);
  return (0);
}

/*----- that's all, folks -------------------------------------------------*/
