/* -*-c-*-
 *
 * Useful functions for doing DSA
 *
 * (c) 2008 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "dsa.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @dsa_h2n@ --- *
 *
 * Arguments:	@mp *d@ = destination integer
 *		@mp *r@ = order of the DSA group
 *		@const void *h@ = pointer to message hash
 *		@size_t hsz@ = size (in bytes) of the hash output
 *
 * Returns:	Resulting integer.
 *
 * Use:		Converts a hash to an integer in the demented way necessary
 *		for DSA/ECDSA.  This is, of course, completely insane, but
 *		there you go.
 */

mp *dsa_h2n(mp *d, mp *r, const void *h, size_t hsz)
{
  size_t n = mp_bits(r);
  size_t l = hsz;
  size_t s = 0;

  if (n < 8*l) {
    l = (n + 7)/8;
    s = 8*l - n;
  }
  d = mp_loadb(d, h, l);
  if (s)
    d = mp_lsr(d, d, s);
  return (d);
}

/* --- @dsa_nonce@ --- *
 *
 * Arguments:	@mp *d@ = destination integer
 *		@mp *q@ = order of the DSA group
 *		@mp *x@ = secret key
 *		@const octet *m@ = message hash
 *		@const gchash *h@ = hash class
 *		@grand *r@ = random bit source, or null
 *
 * Returns:	A nonce.
 *
 * Use:		Generates a nonce for use in DSA (or another Fiat--Shamir
 *		signature scheme).
 */

mp *dsa_nonce(mp *d, mp *q, mp *x, const octet *m,
	      const gchash *ch, grand *r)
{
  uint32 i = 0;
  size_t nb = mp_bits(q), n = (nb + 7)/8, j;
  size_t bsz = 2*n + 2*ch->hashsz;
  octet *b = XS_ALLOC(bsz);
  octet *kb = b, *rb = kb + n, *hb = rb + ch->hashsz;
  static const char prefix[] = "catacomb-dsa-nonce";
  ghash *h;

  mp_storeb(x, kb, n);
  if (r) grand_fill(r, rb, ch->hashsz);

  do {
    for (j = 0; j < n; j += ch->hashsz) {
      h = GH_INIT(ch);
      GH_HASH(h, prefix, sizeof(prefix));
      GH_HASHBUF32(h, kb, n);
      GH_HASHBUF32(h, m, ch->hashsz);
      if (r) GH_HASHBUF32(h, rb, ch->hashsz);
      GH_HASHU32(h, i);
      GH_DONE(h, hb + j);
      GH_DESTROY(h);
      i++;
    }
    d = mp_loadb(d, hb, n);
    d = mp_lsr(d, d, 8*n - nb);
  } while (MP_CMP(d, >=, q));

  memset(b, 0, bsz); XS_FREE(b);
  return (d);
}

/*----- That's all, folks -------------------------------------------------*/
