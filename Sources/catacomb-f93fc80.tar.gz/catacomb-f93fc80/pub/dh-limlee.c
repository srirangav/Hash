/* -*-c-*-
 *
 * Generate Diffie-Hellman parameters from Lim-Lee primes
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "dh.h"
#include "limlee.h"
#include "mpmont.h"
#include "prim.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @dh_limlee@ --- *
 *
 * Arguments:	@dh_param *dp@ = pointer to output parameter block
 *		@unsigned ql@ = length of smallest factor of %$(p - 1)/2$%
 *		@unsigned pl@ = length of %$p$% in bits
 *		@unsigned flags@ = other generation flags
 *		@unsigned steps@ = number of steps to go
 *		@grand *r@ = random number source
 *		@pgen_proc *oev@ = outer event handler function
 *		@void *oec@ = argument for the outer event handler
 *		@pgen_proc *iev@ = inner event handler function
 *		@void *iec@ = argument for the inner event handler
 *		@size_t *nf@, @mp ***f@ = output array for factors
 *
 * Returns:	@PGEN_DONE@ if it worked, @PGEN_ABORT@ if it didn't.
 *
 * Use:		Generates Diffie-Hellman parameters based on a Lim-Lee prime.
 *
 *		The modulus is a large prime %$p = 2 \prod q_i + 1$%, @pl@
 *		bits long, where the %$q_i$% are smaller primes each at least
 *		@ql@ bits long.  It is safe to set @nf@ and @f@ to zero if
 *		you're not interested in the factor values.
 *
 *		The returned %$g$% generates a subgroup of order %$q_0$% (the
 *		first factor, returned as @f[0]@), if the flag @DH_SUBGROUP@
 *		is set on entry; otherwise %$g$% will have order
 *		%$(p - 1)/2$%.
 */

int dh_limlee(dh_param *dp, unsigned ql, unsigned pl,
	      unsigned flags, unsigned steps, grand *r,
	      pgen_proc *oev, void *oec, pgen_proc *iev,
	      void *iec, size_t *nf, mp ***f)
{
  mp **ff;
  size_t nff;
  prim_ctx pc;
  size_t i;
  int j;
  mp *pp;

  /* --- Generate the Lim-Lee prime --- */

  if ((dp->p = limlee("p", MP_NEW, MP_NEW, ql, pl,
		      r, steps, oev, oec, iev, iec, &nff, &ff)) == 0)
    return (PGEN_ABORT);

  /* --- Now find a primitive element --- */

  mpmont_create(&pc.mm, dp->p);
  pp = mp_sub(MP_NEW, dp->p, MP_ONE);
  if (flags & DH_SUBGROUP) {
    dp->q = mp_copy(ff[0]);
    pc.exp = MP_NEW;
    mp_div(&pc.exp, 0, pp, dp->q);
    pc.n = 0;
    pc.f = 0;
  } else {
    dp->q = mp_lsr(MP_NEW, dp->p, 1);
    pc.exp = MP_TWO;
    pc.n = nff;
    pc.f = xmalloc(nff * sizeof(mp *));
    for (i = 0; i < nff; i++) {
      pc.f[i] = MP_NEW;
      mp_div(&pc.f[i], 0, pp, ff[i]);
    }
  }

  j = 0;
  dp->g = pgen("g", MP_NEW, MP_NEW, oev, oec,
	       0, prim_step, &j, 1, prim_test, &pc);

  mp_drop(pp);
  if (pc.f) {
    for (i = 0; i < pc.n; i++)
      mp_drop(pc.f[i]);
    xfree(pc.f);
  }
  mpmont_destroy(&pc.mm);

  /* --- Do something sensible with the list of primes --- */

  if (dp->g && f) {
    *f = ff;
    *nf = nff;
  } else {
    for (i = 0; i < nff; i++)
      mp_drop(ff[i]);
    xfree(ff);
  }

  /* --- Tidy up and return --- */

  if (!dp->g) {
    mp_drop(dp->p);
    mp_drop(dp->q);
    return (PGEN_ABORT);
  }
  return (PGEN_DONE);
}

/*----- That's all, folks -------------------------------------------------*/
