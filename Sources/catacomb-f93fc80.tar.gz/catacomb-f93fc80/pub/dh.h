/* -*-c-*-
 *
 * Diffie-Hellman and related public-key systems
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_DH_H
#define CATACOMB_DH_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GROUP_H
#  include "group.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

#ifndef CATACOMB_KEY_H
#  include "key.h"
#endif

#ifndef CATACOMB_KEYCHECK_H
#  include "keycheck.h"
#endif

#ifndef CATACOMB_PGEN_H
#  include "pgen.h"
#endif

#ifndef CATACOMB_QDPARSE_H
#  include "qdparse.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef gprime_param dh_param;		/* Group parameters */

typedef struct dh_pub {
  dh_param dp;				/* Shared parameters */
  mp *y;				/* Public key */
} dh_pub;

typedef struct dh_priv {
  dh_param dp;				/* Shared parameters */
  mp *x;				/* Private key */
  mp *y;				/* %$y \equiv g^x \pmod{p}$% */
} dh_priv;

/*----- Key fetching ------------------------------------------------------*/

extern const key_fetchdef dh_paramfetch[];
#define DH_PARAMFETCHSZ 5

extern const key_fetchdef dh_pubfetch[];
#define DH_PUBFETCHSZ 6

extern const key_fetchdef dh_privfetch[];
#define DH_PRIVFETCHSZ 9

/* --- @dh_paramfree@, @dh_pubfree@, @dh_privfree@ --- *
 *
 * Arguments:	@dh_param *dp@, @dh_pub *dp@, @dh_priv *dp@ = pointer to
 *			key block to free
 *
 * Returns:	---
 *
 * Use:		Frees a Diffie-Hellman key block.
 */

extern void dh_paramfree(dh_param */*dp*/);
extern void dh_pubfree(dh_pub */*dp*/);
extern void dh_privfree(dh_priv */*dp*/);

/*----- Functions provided ------------------------------------------------*/

/* --- @dh_gen@ --- *
 *
 * Arguments:	@dh_param *dp@ = pointer to output parameter block
 *		@unsigned ql@ = length of %$q$% in bits, or zero
 *		@unsigned pl@ = length of %$p$% in bits
 *		@unsigned steps@ = number of steps to go
 *		@grand *r@ = random number source
 *		@pgen_proc *event@ = event handler function
 *		@void *ectx@ = argument for the event handler
 *
 * Returns:	@PGEN_DONE@ if it worked, @PGEN_ABORT@ if it didn't.
 *
 * Use:		Generates Diffie-Hellman parameters.
 *
 *		The parameters are a prime %$q$%, relatively small, and a
 *		large prime %$p = kq + 1$% for some %$k$%, together with a
 *		generator %$g$% of the cyclic subgroup of order %$q$%.  These
 *		are actually the same as the DSA parameter set, but the
 *		generation algorithm is different.  Also, if @ql@ is zero,
 *		this algorithm forces %$k = 2$%, and chooses %$g = 4$%.  Make
 *		sure you have something interesting to do if you choose this
 *		option.
 */

extern int dh_gen(dh_param */*dp*/, unsigned /*ql*/, unsigned /*pl*/,
		  unsigned /*steps*/, grand */*r*/, pgen_proc */*event*/,
		  void */*ectx*/);

/* --- @dh_limlee@ --- *
 *
 * Arguments:	@dh_param *dp@ = pointer to output parameter block
 *		@unsigned ql@ = length of smallest factor of %$(p - 1)/2$%
 *		@unsigned pl@ = length of %$p$% in bits
 *		@unsigned flags@ = other generation flags
 *		@unsigned steps@ = number of steps to go
 *		@grand *r@ = random number source
 *		@pgen_proc *oev@ = outer event handler function
 *		@void *oec@ = argument for the outer event handler
 *		@pgen_proc *iev@ = inner event handler function
 *		@void *iec@ = argument for the inner event handler
 *		@size_t *nf@, @mp ***f@ = output array for factors
 *
 * Returns:	@PGEN_DONE@ if it worked, @PGEN_ABORT@ if it didn't.
 *
 * Use:		Generates Diffie-Hellman parameters based on a Lim-Lee prime.
 *
 *		The modulus is a large prime %$p = 2 \prod q_i + 1$%, @pl@
 *		bits long, where the %$q_i$% are smaller primes each at least
 *		@ql@ bits long.  It is safe to set @nf@ and @f@ to zero if
 *		you're not interested in the factor values.
 *
 *		The returned %$g$% generates a subgroup of order %$q_0$% (the
 *		first factor, returned as @f[0]@), if the flag @DH_SUBGROUP@
 *		is set on entry; otherwise %$g$% will have order
 *		%$(p - 1)/2$%.
 */

#define DH_SUBGROUP 1u

extern int dh_limlee(dh_param */*dp*/, unsigned /*ql*/, unsigned /*pl*/,
		     unsigned /*flags*/, unsigned /*steps*/, grand */*r*/,
		     pgen_proc */*oev*/, void */*oec*/, pgen_proc */*iev*/,
		     void */*iec*/, size_t */*nf*/, mp ***/*f*/);

/* --- @dh_kcdsagen@ --- *
 *
 * Arguments:	@dh_param *dp@ = pointer to output parameter block
 *		@unsigned ql@ = size of small factor of %$(p - 1)/2$%
 *		@unsigned pl@ = size of %$p$% in bits
 *		@unsigned flags@ = other generation flags (none defined)
 *		@unsigned steps@ = number of steps to go
 *		@grand *r@ = random number source
 *		@pgen_proc *ev@ = event handler function
 *		@void *ec@ = context for the event handler
 *
 * Returns:	@PGEN_DONE@ if it worked, @PGEN_ABORT@ if it failed.
 *
 * Use:		Generates a KCDSA prime group.  That is, it chooses a prime
 *		%$p$%, such that $%p = 2 q v + 1$%, for primes %$q$% and
 *		%$v$%.  The actual group of interest is the subgroup of order
 *		%$q$%.
 */

extern int dh_kcdsagen(dh_param */*dp*/, unsigned /*ql*/, unsigned /*pl*/,
		       unsigned /*flags*/, unsigned /*steps*/, grand */*r*/,
		       pgen_proc */*ev*/, void */*ec*/);

/* --- @dh_checkparam@ --- *
 *
 * Arguments:	@keycheck *kc@ = keycheck state
 *		@const dh_param *dp@ = pointer to the parameter set
 *		@mp **v@ = optional vector of factors
 *		@size_t n@ = size of vector
 *
 * Returns:	Zero if all OK, or return status from function.
 *
 * Use:		Checks a set of Diffie-Hellman parameters for consistency and
 *		security.
 */

extern int dh_checkparam(keycheck */*kc*/, const dh_param */*dp*/,
			 mp **/*v*/, size_t /*n*/);

/* ---- @dh_infofromdata@ --- *
 *
 * Arguments:	@dh_param *dp@ = parameters to fill in
 *		@pdata *pd@ = packed data structure
 *
 * Returns:	---
 *
 * Use:		Fills in a parameters structure from a packed data block.
 */

struct pdata;
extern void dh_infofromdata(dh_param */*dp*/, struct pdata */*pd*/);

/* --- @dh_parse@, @dhbin_parse@ --- *
 *
 * Arguments:	@qd_parse *qd@ = parser context
 *		@dh_param *dp@ = parameters to fill in
 *
 * Returns:	Zero if OK, nonzero on error.
 *
 * Use:		Parses a prime/binary group string.  This is either one of
 *		the standard group strings, or a %$p$%, %$q$%, %$g$% triple
 *		separated by commas.
 */

extern int dh_parse(qd_parse */*qd*/, dh_param */*dp*/);
extern int dhbin_parse(qd_parse */*qd*/, gbin_param */*gb*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
