/* -*-c-*-
 *
 * Generalized version of DSA
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GDSA_H
#define CATACOMB_GDSA_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

#ifndef CATACOMB_GROUP_H
#  include "group.h"
#endif

/*----- Data structures ---------------------------------------------------*/

/* --- GDSA context --- *
 *
 * You don't need to fill in all of this stuff.  See the description of the
 * function you want to use to find out what members are needed.
 */

typedef struct gdsa {
  group *g;				/* The group we work in */
  mp *u;				/* Private key, for signing */
  ge *p;				/* Public key, for verifying */
  grand *r;				/* Random number source */
  const gchash *h;			/* Hash function */
} gdsa;

/* --- GDSA signatures --- */

typedef struct gdsa_sig { mp *r, *s; } gdsa_sig;
#define GDSA_SIG_INIT { MP_NEW, MP_NEW }

/*----- Functions provided ------------------------------------------------*/

/* --- @gdsa_beginhash@ --- *
 *
 * Arguments:	@const gdsa *c@ = pointer to the context structure
 *
 * Returns:	A hashing context for you to hash the message.
 *
 * Use:		Initializes a hash function correctly for you to hash a
 *		message.  Requires @h@.
 */

extern ghash *gdsa_beginhash(const gdsa */*c*/);

/* --- @gdsa_endhash@ --- *
 *
 * Arguments:	@const gdsa *c@ = pointer to the context structure
 *		@ghash *h@ = the hashing context
 *
 * Returns:	---
 *
 * Use:		Does any final thing that DSA wants to do when hashing a
 *		message.  (Actually, there's nothing.)	The hashing context
 *		isn't finalized.
 */

extern void gdsa_endhash(const gdsa */*c*/, ghash */*h*/);

/* --- @gdsa_sign@ --- *
 *
 * Arguments:	@const gdsa *c@ = my context structure
 *		@gdsa_sig *s@ = where to put the signature (initialized)
 *		@const void *m@ = pointer to message hash
 *		@mp *k@ = random exponent for this message or null
 *
 * Returns:	---
 *
 * Use:		Signs a message.  Requires @g@, @u@, @h@, and @r@ if @k@ is
 *		null.  This is a better idea than inventing @k@ yourself.
 */

extern void gdsa_sign(const gdsa */*c*/, gdsa_sig */*s*/,
		      const void */*m*/, mp */*k*/);

/* --- @gdsa_verify@ --- *
 *
 * Arguments:	@const gdsa *c@ = my context structure
 *		@const gdsa_sig *s@ = the signature to verify
 *		@const void *m@ = pointer to message hash
 *
 * Returns:	Zero if OK, negative on failure.
 *
 * Use:		Checks a signature on a message,  Requires @g@, @p@, @h@.
 */

extern int gdsa_verify(const gdsa */*c*/, const gdsa_sig */*s*/,
		       const void */*m*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
