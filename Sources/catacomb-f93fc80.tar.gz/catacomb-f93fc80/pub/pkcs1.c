/* -*-c-*-
 *
 * PKCS#1 1.5 packing
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <string.h>

#include <mLib/bits.h>
#include <mLib/dstr.h>

#include "ct.h"
#include "grand.h"
#include "rsa.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @pkcs1_cryptencode@ --- *
 *
 * Arguments:	@mp *d@ = where to put the answer
 *		@const void *m@ = pointer to message data
 *		@size_t msz@ = size of message data
 *		@octet *b@ = spare buffer
 *		@size_t sz@ = size of the buffer (big enough)
 *		@unsigned long nbits@ = length of bits of @n@
 *		@void *p@ = pointer to PKCS1 parameter block
 *
 * Returns:	The encoded result, or null.
 *
 * Use:		Implements the operation @EME-PKCS1-V1_5-ENCODE@, as defined
 *		in PKCS#1 v. 2.0 (RFC2437).
 */

mp *pkcs1_cryptencode(mp *d, const void *m, size_t msz, octet *b, size_t sz,
		      unsigned long nbits, void *p)
{
  pkcs1 *pp = p;
  grand *r = pp->r;
  octet *q;
  size_t i, n;

  /* --- Ensure that the buffer is sensibly sized --- */

  if (pp->epsz + msz + 11 > sz)
    return (0);

  /* --- Allocate the buffer and fill it in --- */

  q = b;
  *q++ = 0x00;
  *q++ = 0x02;
  n = sz - msz - pp->epsz - 3;
  GR_FILL(r, q, n);
  for (i = 0; i < n; i++) {
    if (*q == 0)
      *q = r->ops->range(r, 255) + 1;
    q++;
  }
  *q++ = 0;
  if (pp->ep) {
    memcpy(q, pp->ep, pp->epsz);
    q += pp->epsz;
  }
  memcpy(q, m, msz);
  q += msz;
  assert(q == b + sz);

  /* --- Collect the result --- */

  return (mp_loadb(d, b, sz));
}

/* --- @pkcs1_cryptdecode@ --- *
 *
 * Arguments:	@mp *m@ = the decrypted message
 *		@octet *b@ = pointer to a buffer to work in
 *		@size_t sz@ = the size of the buffer (big enough)
 *		@unsigned long nbits@ = the number of bits in @n@
 *		@void *p@ = pointer to PKCS1 parameter block
 *
 * Returns:	The length of the output string if successful, negative on
 *		failure.
 *
 * Use:		Implements the operation @EME-PKCS1-V1_5-DECODE@, as defined
 *		in PKCS#1 v. 2.0 (RFC2437).
 */

int pkcs1_cryptdecode(mp *m, octet *b, size_t sz,
		      unsigned long nbits, void *p)
{
  pkcs1 *pp = p;
  const octet *q, *qq;
  size_t n, i;
  uint32 goodp = 1;

  /* --- Check the size of the block looks sane --- */

  if (pp->epsz + 11 > sz)		/* OK: independent of ciphertext */
    return (-1);
  mp_storeb(m, b, sz);
  q = b;
  qq = q + sz;

  /* --- Ensure that the block looks OK --- */

  goodp &= ct_inteq(*q++, 0);
  goodp &= ct_inteq(*q++, 2);

  /* --- Check the nonzero padding --- */

  i = 0;
  while (*q != 0 && q < qq)
    i++, q++;
  goodp &= ct_intle(8, i);
  goodp &= ~ct_intle(qq - q, pp->epsz + 1);
  q++;

  /* --- Check the encoding parameters --- */

  if (pp->ep)
    goodp &= ct_memeq(b + ct_pick(goodp, 0, q - b), pp->ep, pp->epsz);
  q += pp->epsz;

  /* --- Done --- */

  n = qq - q;
  memmove(b, b + ct_pick(goodp, 1, q - b), n);
  return (goodp ? n : -1);
}

/* --- @pkcs1_sigencode@ --- *
 *
 * Arguments:	@mp *d@ = where to put the answer
 *		@const void *m@ = pointer to message data
 *		@size_t msz@ = size of message data
 *		@octet *b@ = spare buffer
 *		@size_t sz@ = size of the buffer (big enough)
 *		@unsigned long nbits@ = length of bits of @n@
 *		@void *p@ = pointer to PKCS1 parameter block
 *
 * Returns:	The encoded message representative, or null.
 *
 * Use:		Implements the operation @EMSA-PKCS1-V1_5-ENCODE@, as defined
 *		in PKCS#1 v. 2.0 (RFC2437).
 */

mp *pkcs1_sigencode(mp *d, const void *m, size_t msz, octet *b, size_t sz,
		    unsigned long nbits, void *p)
{
  pkcs1 *pp = p;
  octet *q;
  size_t n;

  /* --- Ensure that the buffer is sensibly sized --- */

  if (pp->epsz + msz + 11 > sz)
    return (0);

  /* --- Fill in the buffer --- */

  q = b;
  *q++ = 0x00;
  *q++ = 0x01;
  n = sz - msz - pp->epsz - 3;
  memset(q, 0xff, n);
  q += n;
  *q++ = 0;
  if (pp->ep) {
    memcpy(q, pp->ep, pp->epsz);
    q += pp->epsz;
  }
  memcpy(q, m, msz);
  q += msz;
  assert(q == b + sz);
  return (mp_loadb(d, b, sz));
}

/* --- @pkcs1_sigdecode@ --- *
 *
 * Arguments:	@mp *s@ = the message representative
 *		@const void *m@ = the original message, or null (ignored)
 *		@size_t msz@ = the message size (ignored)
 *		@octet *b@ = a scratch buffer
 *		@size_t sz@ = size of the buffer (large enough)
 *		@unsigned long nbits@ = number of bits in @n@
 *		@void *p@ = pointer to PKCS1 parameters
 *
 * Returns:	The length of the output string if successful, negative on
 *		failure.
 *
 * Use:		Implements the operation @EMSA-PKCS1-V1_5-DECODE@, as defined
 *		in PKCS#1 v. 2.0 (RFC2437).
 */

int pkcs1_sigdecode(mp *s, const void *m, size_t msz, octet *b, size_t sz,
		    unsigned long nbits, void *p)
{
  pkcs1 *pp = p;
  const octet *q, *qq;
  size_t i, n;

  /* --- Check the size of the block looks sane --- */

  if (pp->epsz + 10 > sz)
    return (-1);
  mp_storeb(s, b, sz);
  q = b;
  qq = q + sz;

  /* --- Ensure that the block looks OK --- */

  if (*q++ != 0x00 || *q++ != 0x01)
    return (-1);

  /* --- Check the padding --- */

  i = 0;
  while (*q == 0xff && q < qq)
    i++, q++;
  if (i < 8 || qq - q < pp->epsz + 1 || *q++ != 0)
    return (-1);

  /* --- Check the encoding parameters --- */

  if (pp->ep && memcmp(q, pp->ep, pp->epsz) != 0)
    return (-1);
  q += pp->epsz;

  /* --- Done --- */

  n = qq - q;
  memmove(b, q, n);
  return (n);
}

/*----- That's all, folks -------------------------------------------------*/
