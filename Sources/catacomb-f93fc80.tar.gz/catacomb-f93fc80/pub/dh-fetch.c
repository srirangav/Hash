/* -*-c-*-
 *
 * Key fetching for Diffie-Hellman public and private keys
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "dh.h"
#include "key.h"

/*----- Key fetching ------------------------------------------------------*/

const key_fetchdef dh_paramfetch[] = {
  { "p",	offsetof(dh_param, p),		KENC_MP,	0 },
  { "q",	offsetof(dh_param, q),		KENC_MP,	0 },
  { "g",	offsetof(dh_param, g),		KENC_MP,	0 },
  { 0,		0,				0,		0 }
};

const key_fetchdef dh_pubfetch[] = {
  { "p",	offsetof(dh_pub, dp.p),		KENC_MP,	0 },
  { "q",	offsetof(dh_pub, dp.q),		KENC_MP,	0 },
  { "g",	offsetof(dh_pub, dp.g),		KENC_MP,	0 },
  { "y",	offsetof(dh_pub, y),		KENC_MP,	0 },
  { 0,		0,				0,		0 }
};

static const key_fetchdef priv[] = {
  { "x",	offsetof(dh_priv, x),		KENC_MP,	0 },
  { 0,		0,				0,		0 }
};

const key_fetchdef dh_privfetch[] = {
  { "p",	offsetof(dh_priv, dp.p),	KENC_MP,	0 },
  { "q",	offsetof(dh_priv, dp.q),	KENC_MP,	0 },
  { "g",	offsetof(dh_priv, dp.g),	KENC_MP,	0 },
  { "y",	offsetof(dh_priv, y),		KENC_MP,	0 },
  { "private",	0,				KENC_STRUCT,	priv },
  { 0,		0,				0,		0 }
};

/* --- @dh_paramfree@, @dh_pubfree@, @dh_privfree@ --- *
 *
 * Arguments:	@dh_param *dp@, @dh_pub *dp@, @dh_priv *dp@ = pointer
 *			to key block to free
 *
 * Returns:	---
 *
 * Use:		Frees a Diffie-Hellman key block.
 */

void dh_paramfree(dh_param *dp)
{
  mp_drop(dp->p);
  mp_drop(dp->q);
  mp_drop(dp->g);
}

void dh_pubfree(dh_pub *dp)
{
  mp_drop(dp->dp.p);
  mp_drop(dp->dp.q);
  mp_drop(dp->dp.g);
  mp_drop(dp->y);
}

void dh_privfree(dh_priv *dp)
{
  mp_drop(dp->dp.p);
  mp_drop(dp->dp.q);
  mp_drop(dp->dp.g);
  mp_drop(dp->y);
  mp_drop(dp->x);
}

/*----- That's all, folks -------------------------------------------------*/
