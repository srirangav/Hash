/* -*-c-*-
 *
 * Consistency checking for DSA keys
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "dh.h"
#include "dsa.h"
#include "dsarand.h"
#include "grand.h"
#include "keycheck.h"
#include "mp.h"
#include "mprand.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @dsa_checkparam@ --- *
 *
 * Arguments:	@keycheck *kc@ = keycheck state
 *		@const dsa_param *dp@ = pointer to the parameter set
 *		@const dsa_seed *ds@ = pointer to seed information
 *
 * Returns:	Zero if all OK, or return status from function.
 *
 * Use:		Checks a set of DSA parameters for consistency and security.
 */

int dsa_checkparam(keycheck *kc, const dsa_param *dp, const dsa_seed *ds)
{
  if (ds) {
    grand *r = dsarand_create(ds->p, ds->sz);
    mp *p = MP_NEW, *q = MP_NEW;
    int rc = 0;
    unsigned i;
    unsigned long n;

    r->ops->misc(r, DSARAND_PASSES, 2);
    q = mprand(q, mp_bits(dp->q), r, 1);
    if (!mp_eq(q, dp->q) &&
	keycheck_report(kc, KCSEV_ERR, "q doesn't match seed provided"))
      rc = -1;
    else {
      n = mp_bits(dp->p);
      r->ops->misc(r, DSARAND_PASSES, 1);
      for (i = 0; i <= ds->count; i++)
	p = mprand(p, n, r, 0);
      q = mp_lsl(q, q, 1);
      mp_div(0, &q, p, q);
      p = mp_sub(p, p, q);
      p->v[0] |= 1;
      if (!mp_eq(p, dp->p) &&
	  keycheck_report(kc, KCSEV_ERR, "p doesn't match seed provided"))
	rc = -1;
    }
    mp_drop(p);
    mp_drop(q);
    r->ops->destroy(r);
    if (rc)
      return (rc);
  }
  return (dh_checkparam(kc, dp, 0, 0));
}

/*----- That's all, folks -------------------------------------------------*/
