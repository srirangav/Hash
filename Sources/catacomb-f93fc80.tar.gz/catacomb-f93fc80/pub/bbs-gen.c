/* -*-c-*-
 *
 * Generate Blum integers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bbs.h"
#include "mp.h"
#include "mprand.h"
#include "pgen.h"
#include "strongprime.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @bbs_gen@ --- *
 *
 * Arguments:	@bbs_priv *bp@ = pointer to parameter block
 *		@unsigned nbits@ = number of bits in the modulus
 *		@grand *r@ = pointer to random number source
 *		@unsigned n@ = number of attempts to make
 *		@pgen_proc *event@ = event handler function
 *		@void *ectx@ = argument for event handler
 *
 * Returns:	If it worked OK, @PGEN_DONE@, otherwise @PGEN_ABORT@.
 *
 * Use:		Finds two prime numbers %$p'$% and %$q'$% such that both are
 *		congruent to %$3 \bmod 4$%, and	 $(p - 1)/2$% and
 *		%$(q - 1)/2$% have no common factors.  The product %$n = pq$%
 *		is eminently suitable for use as a modulus in a Blum-Blum-
 *		Shub pseudorandom bit generator.
 */

int bbs_gen(bbs_priv *bp, unsigned nbits, grand *r, unsigned n,
	    pgen_proc *event, void *ectx)
{
  rabin rb;
  pfilt jp;
  pgen_jumpctx j;
  pgen_gcdstepctx g;
  unsigned nb = nbits/2;
  mp *x = MP_NEW;

  /* --- Generate @p@ --- */

again:
  if ((x = strongprime_setup("p", x, &jp, nb, r, n, event, ectx)) == 0)
    goto fail_x;
  j.j = &jp;
  bp->p = pgen("p", MP_NEW, x, event, ectx, n, pgen_jump, &j,
	       rabin_iters(nb), pgen_test, &rb);
  pfilt_destroy(&jp);
  if (!bp->p) {
    if (n)
      goto fail_p;
    goto again;
  }

  /* --- Generate @q@ --- */

  nb = nbits - nb;
  if ((x = strongprime_setup("q", x, &g.jp, nb, r, n, event, ectx)) == 0)
    goto fail_q;
  if ((x->v[0] & 3) != 3)
    x = mp_add(x, x, g.jp.m);
  pfilt_muladd(&g.jp, &g.jp, 2, 0);
  g.r = mp_lsr(MP_NEW, bp->p, 1);
  g.g = MP_NEW;
  g.max = MP_ONE;
  bp->q = pgen("q", MP_NEW, x, event, ectx, n, pgen_gcdstep, &g,
	       rabin_iters(nb), pgen_test, &rb);
  pfilt_destroy(&g.jp);
  mp_drop(g.r);
  mp_drop(g.g);
  if (!bp->q) {
    if (n)
      goto fail_q;
    mp_drop(bp->p);
    goto again;
  }

  /* --- Compute @n@ --- */

  bp->n = mp_mul(MP_NEW, bp->p, bp->q);
  mp_drop(x);
  return (PGEN_DONE);

  /* --- Tidy up if things went wrong --- */

fail_q:
  mp_drop(bp->p);
fail_p:
  mp_drop(x);
fail_x:
  return (PGEN_ABORT);
}

/*----- That's all, folks -------------------------------------------------*/
