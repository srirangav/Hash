/* -*-c-*-
 *
 * Framework for checking consistency of keys
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_KEYCHECK_H
#define CATACOMB_KEYCHECK_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

/*----- Data structures ---------------------------------------------------*/

enum {
  KCSEV_ALL,
  KCSEV_INFO = KCSEV_ALL,
  KCSEV_WARN,
  KCSEV_ERR,
  KCSEV_MAX
};

typedef struct keycheck {
  unsigned sev[KCSEV_MAX];
  int (*func)(unsigned /*sev*/, const char */*msg*/, void */*p*/);
  void *p;
} keycheck;

typedef struct keycheck_reportctx {
  FILE *fp;
  unsigned sev;
} keycheck_reportctx;

/*----- Generic functions -------------------------------------------------*/

/* --- @keycheck_report@ --- *
 *
 * Arguments:	@keycheck *kc@ = keycheck state
 *		@unsigned sev@ = severity of this report
 *		@const char *msg@ = message to send along
 *		@...@ = things to fill the message in with
 *
 * Returns:	Zero to continue, or nonzero to stop and give up.
 *
 * Use:		Reports a message to the user function.
 */

extern int PRINTF_LIKE(3, 4)
  keycheck_report(keycheck */*kc*/, unsigned /*sev*/,
		  const char */*msg*/, ...);

/* --- @keycheck_init@ --- *
 *
 * Arguments:	@keycheck *kc@ = pointer to block to initialize
 *		@int (*func)(unsigned sev, const char *msg, void *p)@ =
 *			handler function for problems
 *		@void *p@ = pointer to give to handler
 *
 * Returns:	---
 *
 * Use:		Initializes a key checking context.
 */

extern void keycheck_init(keycheck */*kc*/,
			  int (*/*func*/)(unsigned /*sev*/,
					  const char */*msg*/,
					  void */*p*/),
			  void */*p*/);

/* --- @keycheck_allclear@ --- *
 *
 * Arguments:	@keycheck *kc@ = pointer to keycheck context
 *		@unsigned sev@ = minimum severity to care about
 *
 * Returns:	Nonzero if no problems of @sev@ or above were noticed.
 */

extern int keycheck_allclear(keycheck */*kc*/, unsigned /*sev*/);

/*----- A standard report function ----------------------------------------*/

/* --- @keycheck_stdreport@ --- *
 *
 * Arguments:	@unsigned sev@ = problem severity
 *		@const char *msg@ = message to report
 *		@void *p@ = pointer to a @keycheck_reportctx@ structure
 *
 * Returns:	Zero.
 *
 * Use:		Reports a message to stderr.
 */

extern int keycheck_stdreport(unsigned /*sev*/,
			      const char */*msg*/, void */*p*/);

/*----- Special support functions for large integers ----------------------*/

/* --- @keycheck_prime@ --- *
 *
 * Arguments:	@keycheck *kc@ = keycheck state
 *		@unsigned sev@ = severity if not prime
 *		@mp *m@ = a number to check for primality
 *		@const char *name@ = name of this number
 *
 * Returns:	Zero if OK, or return status from function.
 *
 * Use:		Checks that a number is prime.
 */

extern int keycheck_prime(keycheck */*kc*/, unsigned /*sev*/,
			  mp */*m*/, const char */*name*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
