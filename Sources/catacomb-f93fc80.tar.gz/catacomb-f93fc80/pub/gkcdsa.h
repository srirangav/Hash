/* -*-c-*-
 *
 * Generalized version of KCDSA
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GKCDSA_H
#define CATACOMB_GKCDSA_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GROUP_H
#  include "group.h"
#endif

#ifndef CATACOMB_GHASH_H
#  include "ghash.h"
#endif

#ifndef CATACOMB_GDSA_H
#  include "gdsa.h"
#endif

/*----- Data structures ---------------------------------------------------*/

/* --- Careful! --- *
 *
 * These structures are the same as for DSA.  However, the private key @u@ is
 * the %$\emph{inverse}$% of the exponent.  Do this wrong and the maths will
 * fail hopelessly.
 */

typedef gdsa gkcdsa;

typedef struct gkcdsa_sig {
  octet *r;				/* Null means @xmalloc@ me */
  mp *s;
} gkcdsa_sig;
#define GKCDSA_SIG_INIT { 0, 0 }

/*----- Functions provided ------------------------------------------------*/

/* --- @gkcdsa_beginhash@ --- *
 *
 * Arguments:	@const gkcdsa *c@ = pointer to the context structure
 *
 * Returns:	A hashing context for you to hash the message.
 *
 * Use:		Initializes a hash function correctly for you to hash a
 *		message.  Requires @h@, @g@ and @p@.
 */

extern ghash *gkcdsa_beginhash(const gkcdsa */*c*/);

/* --- @gkcdsa_endhash@ --- *
 *
 * Arguments:	@const gkcdsa *c@ = pointer to the context structure
 *		@ghash *h@ = the hashing context
 *
 * Returns:	---
 *
 * Use:		Does any final thing that KCDSA wants to do when hashing a
 *		message.  (Actually, there's nothing.)	The hashing context
 *		isn't finalized.
 */

extern void gkcdsa_endhash(const gkcdsa */*c*/, ghash */*h*/);

/* --- @gkcdsa_sign@ --- *
 *
 * Arguments:	@const gkcdsa *c@ = my context structure
 *		@gkcdsa_sig *s@ = where to put the signature (initialized)
 *		@const void *m@ = pointer to message hash
 *		@mp *k@ = random exponent for this message or null
 *
 * Returns:	---
 *
 * Use:		Signs a message.  Requires @g@, @u@, @h@, and @r@ if @k@ is
 *		null.  This is a better idea than inventing @k@ yourself.
 */

extern void gkcdsa_sign(const gkcdsa */*c*/, gkcdsa_sig */*s*/,
			const void */*m*/, mp */*k*/);

/* --- @gkcdsa_verify@ --- *
 *
 * Arguments:	@const gkcdsa *c@ = my context structure
 *		@const gkcdsa_sig *s@ = the signature to verify
 *		@const void *m@ = pointer to message hash
 *
 * Returns:	Zero if OK, negative on failure.
 *
 * Use:		Checks a signature on a message,  Requires @g@, @p@, @h@.
 */

extern int gkcdsa_verify(const gkcdsa */*c*/, const gkcdsa_sig */*s*/,
			 const void */*m*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
