/* -*-c-*-
 *
 * Key consistency checking tools for large integers
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/dstr.h>

#include "fibrand.h"
#include "grand.h"
#include "keycheck.h"
#include "mp.h"
#include "mprand.h"
#include "pfilt.h"
#include "pgen.h"
#include "rabin.h"
#include "rand.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @keycheck_prime@ --- *
 *
 * Arguments:	@keycheck *kc@ = keycheck state
 *		@unsigned sev@ = severity if not prime
 *		@mp *m@ = a number to check for primality
 *		@const char *name@ = name of this number
 *
 * Returns:	Zero if OK, or return status from function.
 *
 * Use:		Checks that a number is prime.
 */

int keycheck_prime(keycheck *kc, unsigned sev, mp *m, const char *name)
{
  int rc;

  rc = pfilt_smallfactor(m);
  if (rc == PGEN_TRY) {
    rabin rn;
    grand *r = fibrand_create(0);
    unsigned n;
    mp *x = MP_NEW;

    r->ops->misc(r, GRAND_SEEDRAND, &rand_global);
    n = rabin_iters(mp_bits(m));
    rabin_create(&rn, m);
    do {
      x = mprand_range(x, m, r, 0);
      rc = rabin_test(&rn, x);
      n--;
    } while (n && rc == PGEN_PASS);
    rabin_destroy(&rn);
    mp_drop(x);
    r->ops->destroy(r);
  }
  if (rc != PGEN_FAIL)
    rc = 0;
  else
    rc = keycheck_report(kc, sev, "%s not prime", name);
  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
