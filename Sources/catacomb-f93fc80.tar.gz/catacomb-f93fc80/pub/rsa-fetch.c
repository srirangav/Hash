/* -*-c-*-
 *
 * Key fetching for RSA public and private keys
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "key.h"
#include "rsa.h"

/*----- Key fetching ------------------------------------------------------*/

const key_fetchdef rsa_pubfetch[] = {
  { "n",	offsetof(rsa_pub, n),		KENC_MP,	0 },
  { "e",	offsetof(rsa_pub, e),		KENC_MP,	0 },
  { 0,		0,				0,		0 }
};

static const key_fetchdef priv[] = {
  { "p",	offsetof(rsa_priv, p),		KENC_MP,	0 },
  { "q",	offsetof(rsa_priv, q),		KENC_MP,	0 },
  { "q-inv",	offsetof(rsa_priv, q_inv),	KENC_MP,	0 },
  { "d",	offsetof(rsa_priv, d),		KENC_MP,	0 },
  { "d-mod-p",	offsetof(rsa_priv, dp),		KENC_MP,	0 },
  { "d-mod-q",	offsetof(rsa_priv, dq),		KENC_MP,	0 },
  { 0,		0,				0,		0 }
};

const key_fetchdef rsa_privfetch[] = {
  { "n",	offsetof(rsa_priv, n),		KENC_MP,	0 },
  { "e",	offsetof(rsa_priv, e),		KENC_MP,	0 },
  { "private",	0,				KENC_STRUCT,	priv },
  { 0,		0,				0,		0 }
};

/* --- @rsa_pubfree@, @rsa_privfree@ --- *
 *
 * Arguments:	@rsa_pub *rp@, @rsa_priv *rp@ = pointer to key block
 *
 * Returns:	---
 *
 * Use:		Frees an RSA key block.
 */

void rsa_pubfree(rsa_pub *rp)
{
  mp_drop(rp->n);
  mp_drop(rp->e);
}

void rsa_privfree(rsa_priv *rp)
{
  mp_drop(rp->n);
  mp_drop(rp->e);
  mp_drop(rp->p);
  mp_drop(rp->q);
  mp_drop(rp->q_inv);
  mp_drop(rp->d);
  mp_drop(rp->dp);
  mp_drop(rp->dq);
}

/*----- That's all, folks -------------------------------------------------*/
