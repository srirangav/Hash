/* -*-c-*-
 *
 * Abstraction for memory allocation arenas
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/arena.h>
#include <mLib/sub.h>

#include "arena.h"

/*----- Global variables --------------------------------------------------*/

arena *arena_secure = &arena_stdlib;
subarena *arena_subsecure = &sub_global;

/*----- Static variables --------------------------------------------------*/

static subarena sub;

/*----- Main code ---------------------------------------------------------*/

/* --- @arena_setsecure@ --- *
 *
 * Arguments:	@arena *a@ = arena to use for secure allocation
 *
 * Returns:	---
 *
 * Use:		Call at the beginning of the program to set the arena for
 *		secure allocations.
 */

void arena_setsecure(arena *a)
{
  arena_secure = a;
  subarena_create(&sub, a);
  arena_subsecure = &sub;
}

/*----- That's all, folks -------------------------------------------------*/
