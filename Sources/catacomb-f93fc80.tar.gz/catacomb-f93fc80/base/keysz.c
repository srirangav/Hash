/* -*-c-*-
 *
 * General block cipher utilities
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>

#include "gcipher.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @keysz@ --- *
 *
 * Arguments:	@size_t sz@ = a proposed key size, or zero
 *		@const octet *ksz@ = pointer to key size table
 *
 * Returns:	See below.
 *
 * Use:		Returns a sensible key size.  If @sz@ is nonzero, it is
 *		interpreted as an amount (in bytes) of key material which the
 *		caller has available, and the return value is either the
 *		largest allowable key size less than or equal to the caller's
 *		size, or zero if there is no valid key length small enough.
 *		If @sz@ is zero, the function returns a `recommended' key
 *		size.
 */

size_t keysz(size_t sz, const octet *ksz)
{
  if (sz == 0)
    return (ksz[1]);
  else switch (ksz[0]) {
    case KSZ_ANY:
      return (sz);
    case KSZ_RANGE:
      if (ksz[4])
	sz -= sz % ksz[4];
      if (sz < ksz[2])
	return (0);
      if (ksz[3] && sz > ksz[3])
	return (ksz[3]);
      return (sz);
    case KSZ_SET: {
      unsigned q = 0;
      for (ksz++; *ksz; ksz++) {
	if (sz >= *ksz && q < *ksz)
	  q = *ksz;
      }
      return (q);
    }
  }

  assert(((void)"bad key size table", 0));
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
