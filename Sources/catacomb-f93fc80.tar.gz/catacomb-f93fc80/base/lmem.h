/* -*-c-*-
 *
 * Locked memory allocation
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_LMEM_H
#define CATACOMB_LMEM_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/arena.h>
#include <mLib/dstr.h>

/*----- Data structures ---------------------------------------------------*/

/* --- Block list --- *
 *
 * The block list is kept in normal memory, to avoid wasting precious locked
 * memory.  Entries are sorted into ascending address order to make
 * coalescing free blocks easier.  All blocks, free or not, are included in
 * the list.
 */

typedef struct l_node {
  struct l_node *next;			/* Next free block in chain */
  char *p;				/* Pointer to the block */
  size_t sz;				/* Size of the block */
  unsigned f;				/* Various flags */
} l_node;

#define LF_ALLOC 1u

/* --- Locked memory buffer state --- */

typedef struct lmem {
  arena a;				/* Arena header block */
  unsigned f;				/* Various flags */
  char *p;				/* Pointer to locked buffer */
  l_node *l;				/* Pointer to block list */
  size_t sz;				/* Size of locked buffer */
  size_t free;				/* Size of free area */
  int err; char *emsg;			/* Error indicators */
} lmem;

#define LF_LOCKED 1u

/*----- Functions provided ------------------------------------------------*/

/* --- @l_init@ --- *
 *
 * Arguments:	@lmem *lm@ = pointer to locked memory descriptor
 *		@size_t sz@ = size of locked memory area requested
 *
 * Returns:	Zero if everything is fine, @+1@ if some insecure memory was
 *		allocated, and @-1@ if everything went horribly wrong.
 *
 * Use:		Initializes the locked memory manager.  This function is safe
 *		to call in a privileged program; privileges should usually be
 *		dropped after allocating the locked memory block.
 *
 *		You must call @sub_init@ before allocating locked memory
 *		buffers.
 */

extern int l_init(lmem */*lm*/, size_t /*sz*/);

/* --- @l_alloc@ --- *
 *
 * Arguments:	@lmem *lm@ = pointer to locked memory descriptor
 *		@size_t sz@ = size requested
 *
 * Returns:	Pointer to allocated memory.
 *
 * Use:		Allocates @sz@ bytes of locked memory.
 */

extern void *l_alloc(lmem */*lm*/, size_t /*sz*/);

/* --- @l_free@ --- *
 *
 * Arguments:	@lmem *lm@ = pointer to locked memory descriptor
 *		@void *p@ = pointer to block
 *
 * Returns:	---
 *
 * Use:		Releases a block of locked memory.
 */

extern void l_free(lmem */*lm*/, void */*p*/);

/* --- @l_purge@ --- *
 *
 * Arguments:	@lmem *lm@ = pointer to locked memory descriptor
 *
 * Returns:	---
 *
 * Use:		Purges all the free blocks in the buffer, and clears all of
 *		the locked memory.  Memory is not freed back to the system.
 */

extern void l_purge(lmem */*lm*/);

/* --- @l_destroy@ --- *
 *
 * Arguments:	@lmem *lm@ = pointer to locked memory descriptor
 *
 * Returns:	---
 *
 * Use:		Disposes of a locked memory arena permanently.
 */

extern void l_destroy(lmem */*lm*/);

/* --- @l_report@ --- *
 *
 * Arguments:	@lmem *lm@ = pointer to locked memory descriptor
 *		@dstr *d@ = string to write the error message on
 *
 * Returns:	Zero if the buffer is fine, @+1@ if there was a problem
 *		getting locked memory but insecure stuff could be allocated,
 *		and @-1@ if not even insecure memory could be found.
 *
 * Use:		Returns a user-digestable explanation for the state of a
 *		locked memory buffer.  If the return code is zero, no message
 *		is emitted to the string @d@.
 */

extern int l_report(lmem */*lm*/, dstr */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
