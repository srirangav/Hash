/* -*-c-*-
 *
 * Abstraction for memory allocation arenas
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_ARENA_H
#define CATACOMB_ARENA_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/arena.h>
#include <mLib/sub.h>

/*----- Global variables --------------------------------------------------*/

extern arena *arena_secure;
extern subarena *arena_subsecure;

/*----- Handy macros ------------------------------------------------------*/

#define S_ALLOC(sz) A_ALLOC(arena_secure, sz)
#define S_FREE(sz) A_FREE(arena_secure, sz)

#define XS_ALLOC(sz) x_alloc(arena_secure, sz)
#define XS_REALLOC(p, sz) x_realloc(arena_secure, p, sz)
#define XS_FREE(p) x_free(arena_secure, p)

#define S_CREATE(type) A_CREATE(arena_subsecure, type)
#define S_DESTROY(p) A_DESTROY(arena_subsecure, p)

/*----- Functions provided ------------------------------------------------*/

/* --- @arena_setsecure@ --- *
 *
 * Arguments:	@arena *a@ = arena to use for secure allocation
 *
 * Returns:	---
 *
 * Use:		Call at the beginning of the program to set the arena for
 *		secure allocations.
 */

extern void arena_setsecure(arena */*a*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
