/* -*-c-*-
 *
 * Secret sharing over %$\gf{2^8}$%
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the system -----------------------------------------------*
 *
 * This uses a variant of Shamir's secret sharing system.  Shamir's original
 * system used polynomials modulo a large prime.  This implementation instead
 * uses the field %$\gf{2^8}$%, represented by
 *
 *   %$\gf{2}[x]/(x^8 + x^4 + x^3 + x^2 + 1)$%
 *
 * and shares each byte of the secret independently.  It is therefore limited
 * to 255 players, although this probably isn't a serious limitation in
 * practice.
 *
 * Share creation and reconstruction is extremely efficient.  Contrast the
 * performance of the straightforward implementation based on multiprecision
 * arithmetic.
 */

#ifndef CATACOMB_GFSHARE_H
#define CATACOMB_GFSHARE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Data structures ---------------------------------------------------*/

/* --- A secret sharing context --- */

typedef struct gfshare {
  unsigned t;				/* Threshold */
  unsigned i;				/* Next free slot in vector */
  size_t sz;				/* Size of the secret and shares */
  octet *v;				/* Vector of share information */
} gfshare;

#define GFSHARE_INIT(t, sz) { t, 0, sz, 0 }

#define GFSHARE_INDEX(s, i) ((s)->v[(i) * ((s)->sz + 1)])

/*----- Functions provided ------------------------------------------------*/

/* --- @gfshare_create@ --- *
 *
 * Arguments:	@gfshare *s@ = pointer to share context to initialize
 *		@unsigned t@ = threshold for the system
 *		@size_t sz@ = size of the secret
 *
 * Returns:	---
 *
 * Use:		Initializes a sharing context.
 */

extern void gfshare_create(gfshare */*s*/, unsigned /*t*/, size_t /*sz*/);

/* --- @gfshare_destroy@ --- *
 *
 * Arguments:	@gfshare *s@ = pointer to share context to destroy
 *
 * Returns:	---
 *
 * Use:		Disposes of a sharing context.  The allocations for the
 *		individual shares and the vector @v@ are freed; the secret is
 *		left alone.
 */

extern void gfshare_destroy(gfshare */*s*/);

/* --- @gfshare_mkshares@ --- *
 *
 * Arguments:	@gfshare *s@ = pointer to share context to fill in
 *		@grand *r@ = pointer to random number source
 *		@const void *buf@ = pointer to the secret to share
 *
 * Returns:	---
 *
 * Use:		Initializes a sharing context to be able to create shares.
 *		The context structure is expected to be mostly filled in.  In
 *		particular, @t@ must be initialized.  If @v@ is zero, a
 *		vector of appropriate size is allocated.  You should use the
 *		macro @GFSHARE_INIT@ or @gfshare_create@ to construct sharing
 *		contexts.
 */

extern void gfshare_mkshares(gfshare */*s*/, grand */*r*/,
			     const void */*buf*/);

/* --- @gfshare_get@ --- *
 *
 * Arguments:	@gfshare *s@ = pointer to share conext
 *		@unsigned x@ = share index to fetch
 *		@void *buf@ = pointer to output buffer
 *
 * Returns:	---
 *
 * Use:		Extracts a share from the system.  You may extract up to 255
 *		shares from the system.  Shares are indexed from 0.
 */

extern void gfshare_get(gfshare */*s*/, unsigned /*x*/, void */*buf*/);

/* --- @gfshare_addedp@ --- *
 *
 * Arguments:	@gfshare *s@ = pointer to sharing context
 *		@unsigned x@ = which share number to check
 *
 * Returns:	Nonzero if share @x@ has been added already, zero if it
 *		hasn't.
 */

extern int gfshare_addedp(gfshare */*s*/, unsigned /*x*/);

/* --- @gfshare_add@ --- *
 *
 * Arguments:	@gfshare *s@ = pointer to sharing context
 *		@unsigned x@ = which share number this is
 *		@const void *y@ = the share value
 *
 * Returns:	Number of shares required before recovery may be performed.
 *
 * Use:		Adds a share to the context.  The context must have been
 *		initialized with the correct threshold @t@.
 */

extern unsigned gfshare_add(gfshare */*s*/,
			    unsigned /*x*/, const void */*y*/);

/* --- @gfshare_combine@ --- *
 *
 * Arguments:	@gfshare *s@ = pointer to share context
 *		@void *buf@ = pointer to output buffer for the secret
 *
 * Returns:	---
 *
 * Use:		Reconstructs a secret, given enough shares.
 */

extern void gfshare_combine(gfshare */*s*/, void */*buf*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
