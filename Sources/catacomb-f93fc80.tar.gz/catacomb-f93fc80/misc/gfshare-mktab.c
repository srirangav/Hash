/* -*-c-*-
 *
 * Generate tables for %$\gf{2^8}$% multiplication
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>

#include <mLib/bits.h>

/*----- Magic numbers -----------------------------------------------------*/

#define MOD 0x11d

/*----- Main code ---------------------------------------------------------*/

int main(int argc, char *argv[])
{
  octet log[256], alog[256];
  unsigned x;
  unsigned i;

  x = 1;
  for (i = 0; i < 255; i++) {
    alog[i] = x;
    log[x] = i;
    x <<= 1;
    if (x & 0x100)
      x ^= MOD;
  }
  log[0] = 0;
  alog[255] = 1;

  fputs("\
/* -*-c-*-\n\
 *\n\
 * Log tables for secret sharing in %$\\gf{2^8}$% [generated]\n\
 */\n\
\n\
#include <mLib/bits.h>\n\
\n\
const octet gfshare_log[256] = {\n\
  ", stdout);

  for (i = 0; i < 256; i++) {
    printf("0x%02x", log[i]);
    if (i == 255)
      puts("\n};\n");
    else if (i % 8 == 7)
      fputs(",\n  ", stdout);
    else
      fputs(", ", stdout);
  }

  fputs("\
const octet gfshare_exp[510] = {\n\
  ", stdout);

  for (i = 0; i < 510; i++) {
    printf("0x%02x", alog[i % 255]);
    if (i == 509)
      puts("\n};");
    else if (i % 8 == 7)
      fputs(",\n  ", stdout);
    else
      fputs(", ", stdout);
  }

  /* --- Done --- */

  if (fclose(stdout)) {
    fprintf(stderr, "error writing data\n");
    exit(EXIT_FAILURE);
  }

  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
