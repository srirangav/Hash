#ifndef FACTOR_H
#define FACTOR_H

#include <mLib/darray.h>

#include "mp.h"

typedef struct fact {
  mp *p;
  unsigned e;
  mp *n;
  mp *r;
} fact;
DA_DECL(fact_v, fact);

extern void factor(mp *, fact_v *);
extern void freefactors(fact_v *);

#endif
