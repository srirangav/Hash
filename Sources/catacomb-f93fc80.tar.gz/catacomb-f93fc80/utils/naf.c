#include <stdio.h>
#include <stdlib.h>

#include "mp.h"
#include "mptext.h"


int main(int argc, char *argv[])
{
  mp *x;
  mpscan sc;
  unsigned long d, i;
  enum { Z = 0, Z1 = 2, X = 4, X0 = 6 };
  unsigned st = Z;

  x = mp_readstring(MP_NEW, argv[1], 0, 0);
  d = mp_bits(x);

  for (i = 0, mp_scan(&sc, x); mp_step(&sc); i++) {
    switch (st | mp_bit(&sc)) {
      case  Z | 1: st = Z1; printf("\t-> Z1\n"); break;
      case Z1 | 0: st =	 Z; printf("+ %lu\t-> Z\n", i - 1); break;
      case Z1 | 1: st =	 X; printf("- %lu\t-> X\n", i - 1); break;
      case  X | 0: st = X0; printf("\t-> X0\n"); break;
      case X0 | 1: st =	 X; printf("- %lu\t-> X\n", i - 1); break;
      case X0 | 0: st =	 Z; printf("+ %lu\t-> Z\n", i - 1); break;
    }
  }
  switch (st) {
    case Z1: case X0: printf("+ %lu\n", i - 1); break;
    case X: printf("+ %lu\n", i); break;
  }
}
