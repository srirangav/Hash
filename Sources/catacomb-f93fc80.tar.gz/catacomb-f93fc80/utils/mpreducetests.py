#! /usr/bin/python

import random as R

print "# mpreduce torture"

print "reduce {"
first = True
for i in xrange(16, 90):
  for j in xrange(1, i - 1):
    m = (1L << i) - (1L << j)
    for k in xrange(i + 1, i + 16):
      x = R.randrange(1L << k)
      print "  0x%x" % m
      print "    0x%x" % x
      print "    0x%x;" % (x%m)
      if not first:
        print
      first = False
print "}"
