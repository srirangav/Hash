#! /usr/bin/perl

sub gather {
  my ($what) = @_;
  print "$what?\n";
  my $x = "";
  while (<>) {
    chomp;
    last if $_ eq ".";
    $x .= $_;
  }
  $x =~ s/\s+//g;
  $x =~ s/[.,]//g;
  return lc($x);
}

my %CTYPE = ("niceprime" => "primeproj",
	     "prime" => "primeproj",
	     "binpoly" => "binproj",
	     "binnorm" => "binproj");

my $name = shift;
my $kind = shift;

my $p = gather("p");
my $beta = ($kind eq "binnorm") ? "0x".gather("beta") : "";
my $a = gather("a");
my $b = gather("b");
my $r = gather("r");
my $h = gather("h");
my $g = gather("g");

print "curve $name $kind\n";
$p = "0x".$p if $kind =~ /bin/;
my @l = ("./ecptd", "$kind $p $beta $CTYPE{$kind} 0x$a 0x$b", "0x$r", $h, $g);
# print join(" ", @l), "\n";
system @l;
