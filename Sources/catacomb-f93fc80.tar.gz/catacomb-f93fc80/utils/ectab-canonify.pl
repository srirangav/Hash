#! /usr/bin/perl

while (<>) {
  print, next if /^\s*(\#|$)/;
  @F = split;
  $k = shift @F;
  print, next if $k eq "curve";
  $n = lc(join("", @F));
  if ($n =~ m"^/") {
    $p = join(" + ", map("2^$_", split(m"/", substr($n, 1))));
    $n = `calc 'printf("%x", $p)'`;
  } elsif ($n =~ /../ && $n !~ /^0x/) {
    $n = "0x$n";
  }
  print "  $k $n\n";
}
