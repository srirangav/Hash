#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/quis.h>

#include "factor.h"

int main(int argc, char *argv[])
{
  mp *n;
  fact_v fv = DA_INIT;
  unsigned i;

  ego(argv[0]);
  if (argc != 2) {
    fprintf(stderr, "Usage: %s N\n", QUIS);
    exit(1);
  }
  n = mp_readstring(MP_NEW, argv[1], 0, 10);
  factor(n, &fv);
  for (i = 0; i < DA_LEN(&fv); i++) {
    mp_writefile(DA(&fv)[i].p, stdout, 10);
    printf("^%u\n", DA(&fv)[i].e);
  }
  freefactors(&fv);
  return (0);
}
