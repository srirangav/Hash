/* -*-c-*-
 *
 * Barrett modular reduction
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"
#include "mpbarrett.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @mpbarrett_create@ --- *
 *
 * Arguments:	@mpbarrett *mb@ = pointer to Barrett reduction context
 *		@mp *m@ = modulus to work to
 *
 *
 * Returns:	Zero on success, nonzero on error.
 *
 * Use:		Initializes a Barrett reduction context ready for use.
 */

int mpbarrett_create(mpbarrett *mb, mp *m)
{
  mp *b;

  /* --- Validate the arguments --- */

  if (!MP_POSP(m))
    return (-1);

  /* --- Compute %$\mu$% --- */

  mp_shrink(m);
  mb->k = MP_LEN(m);
  mb->m = MP_COPY(m);
  b = mp_new(2 * mb->k + 1, 0);
  MPX_ZERO(b->v, b->vl - 1);
  b->vl[-1] = 1;
  mp_div(&b, 0, b, m);
  mb->mu = b;
  return (0);
}

/* --- @mpbarrett_destroy@ --- *
 *
 * Arguments:	@mpbarrett *mb@ = pointer to Barrett reduction context
 *
 * Returns:	---
 *
 * Use:		Destroys a Barrett reduction context releasing any resources
 *		claimed.
 */

void mpbarrett_destroy(mpbarrett *mb)
{
  mp_drop(mb->m);
  mp_drop(mb->mu);
}

/* --- @mpbarrett_reduce@ --- *
 *
 * Arguments:	@mpbarrett *mb@ = pointer to Barrett reduction context
 *		@mp *d@ = destination for result
 *		@mp *m@ = number to reduce
 *
 * Returns:	The residue of @m@ modulo the number in the reduction
 *		context.
 *
 * Use:		Performs an efficient modular reduction.
 */

mp *mpbarrett_reduce(mpbarrett *mb, mp *d, mp *m)
{
  mp *q;
  size_t k = mb->k;

  /* --- Special case if @m@ is too small --- */

  if (MP_LEN(m) < k) {
    m = MP_COPY(m);
    if (d)
      MP_DROP(d);
    return (m);
  }

  /* --- First stage --- */

  {
    mp qq;
    mp_build(&qq, m->v + (k - 1), m->vl);
    q = mp_mul(MP_NEW, &qq, mb->mu);
    if (MP_LEN(q) <= k) {
      m = MP_COPY(m);
      if (d)
	MP_DROP(d);
      MP_DROP(q);
      return (m);
    }
  }

  /* --- Second stage --- */

  {
    mp *r;
    mpw *mvl;

    MP_COPY(m);
    if (MP_LEN(m) <= k + 1)
      mvl = m->vl;
    else
      mvl = m->v + k + 1;
    r = mp_new(k + 1, (q->f | mb->m->f) & MP_BURN);
    mpx_umul(r->v, r->vl, q->v + k + 1, q->vl, mb->m->v, mb->m->vl);
    MP_DEST(d, k + 1, r->f | MP_UNDEF);
    mpx_usub(d->v, d->vl, m->v, mvl, r->v, r->vl);
    d->f = (m->f | r->f) & (MP_BURN | MP_NEG);
    MP_DROP(r);
    MP_DROP(q);
    MP_DROP(m);
  }

  /* --- Final stage --- */

  MP_SHRINK(d);
  while (MPX_UCMP(d->v, d->vl, >=, mb->m->v, mb->m->vl))
    mpx_usub(d->v, d->vl, d->v, d->vl, mb->m->v, mb->m->vl);

  /* --- Fix up the sign --- */

  if (d->f & MP_NEG) {
    mpx_usub(d->v, d->vl, mb->m->v, mb->m->vl, d->v, d->vl);
    d->f &= ~MP_NEG;
  }

  MP_SHRINK(d);
  return (d);
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

static int vmod(dstr *v)
{
  mp *x = *(mp **)v[0].buf;
  mp *n = *(mp **)v[1].buf;
  mp *r = *(mp **)v[2].buf;
  mp *s;
  mpbarrett mb;
  int ok = 1;

  mpbarrett_create(&mb, n);
  s = mpbarrett_reduce(&mb, MP_NEW, x);

  if (!MP_EQ(s, r)) {
    fputs("\n*** barrett reduction failure\n", stderr);
    fputs("x = ", stderr); mp_writefile(x, stderr, 10); fputc('\n', stderr);
    fputs("n = ", stderr); mp_writefile(n, stderr, 10); fputc('\n', stderr);
    fputs("r = ", stderr); mp_writefile(r, stderr, 10); fputc('\n', stderr);
    fputs("s = ", stderr); mp_writefile(s, stderr, 10); fputc('\n', stderr);
    ok = 0;
  }

  mpbarrett_destroy(&mb);
  mp_drop(x);
  mp_drop(n);
  mp_drop(r);
  mp_drop(s);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static test_chunk tests[] = {
  { "mpbarrett-reduce", vmod, { &type_mp, &type_mp, &type_mp, 0 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/mpbarrett");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
