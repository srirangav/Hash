/* -*-c-*-
 *
 * Table of standard elliptic curves
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_ECTAB_H
#define CATACOMB_ECTAB_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include "ec.h"

/*----- Data structures ---------------------------------------------------*/

typedef struct ecdata {
  unsigned ftag;			/* The kind of curve this is */
  mp p, beta;				/* Modulus, and conversion magic */
  mp a, b;				/* Elliptic curve parameters */
  mp r;					/* Order of common point %$g$% */
  mp h;					/* Cofactor %$h = \#E/r$% */
  mp gx, gy;				/* Common point */
} ecdata;

enum {
  FTAG_PRIME,				/* Prime but not nice */
  FTAG_NICEPRIME,			/* Nice prime field */
  FTAG_BINPOLY,				/* Binary field, poly basis */
  FTAG_BINNORM				/* Binary field, normal basis */
};

typedef struct ecentry {
  const char *name;
  ecdata *data;
} ecentry;

/*----- Global variables --------------------------------------------------*/

extern const ecentry ectab[];

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
