/* -*-c-*-
 *
 * Conversion between MPs and standard C integers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mpint.h"

/*----- Main code ---------------------------------------------------------*/

/* --- Conversion from C integers --- */

#define FROM(name, type, max)						\
  mp *mp_from##name(mp *d, type i) {					\
    MP_FROMINT(d, type, i);						\
    return (d);								\
  }
MPINT_CONVERSIONS(FROM)

/* --- Conversion to C integers --- */

#define TO(name, type, max)						\
  type mp_to##name(const mp *m)						\
  {									\
    type i;								\
    MP_TOINT(m, type, max, i);						\
    return (i);								\
  }
MPINT_CONVERSIONS(TO)

#undef TO

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#include <mLib/testrig.h>

static int fromuint(dstr *v)
{
  unsigned long i = *(unsigned long *)v[0].buf;
  mp *m = *(mp **)v[1].buf;
  mp *d = mp_fromuint(MP_NEW, i);
  int ok = 1;

  if (!MP_EQ(d, m)) {
    fputs("\n*** fromint failed.\n", stderr);
    fprintf(stderr, "i = %lu", i);
    fputs("\nexpect = ", stderr); mp_writefile(m, stderr, 10);
    fputs("\nresult = ", stderr); mp_writefile(d, stderr, 10);
    fputc('\n', stderr);
    ok = 0;
  }

  mp_drop(m);
  mp_drop(d);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int fromint(dstr *v)
{
  long i = *(long *)v[0].buf;
  mp *m = *(mp **)v[1].buf;
  mp *d = mp_fromint(MP_NEW, i);
  int ok = 1;

  if (!MP_EQ(d, m)) {
    fputs("\n*** fromint failed.\n", stderr);
    fprintf(stderr, "i = %li", i);
    fputs("\nexpect = ", stderr); mp_writefile(m, stderr, 10);
    fputs("\nresult = ", stderr); mp_writefile(d, stderr, 10);
    fputc('\n', stderr);
    ok = 0;
  }

  mp_drop(m);
  mp_drop(d);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int touint(dstr *v)
{
  mp *m = *(mp **)v[0].buf;
  unsigned long i = *(unsigned long *)v[1].buf;
  unsigned j = mp_touint(m);
  int ok = 1;

  if ((unsigned)i != j) {
    fputs("\n*** touint failed.\n", stderr);
    fputs("m = ", stderr); mp_writefile(m, stderr, 10);
    fprintf(stderr, "\nexpect = %lu; result = %u\n", i, j);
    ok = 0;
  }

  mp_drop(m);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int toint(dstr *v)
{
  mp *m = *(mp **)v[0].buf;
  long i = *(long *)v[1].buf;
  int j = mp_toint(m);
  int ok = 1;

  if (i != j) {
    fputs("\n*** toint failed.\n", stderr);
    fputs("m = ", stderr); mp_writefile(m, stderr, 10);
    fprintf(stderr, "\nexpect = %li; result = %i\n", i, j);
    ok = 0;
  }

  mp_drop(m);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static test_chunk tests[] = {
  { "fromuint", fromuint, { &type_ulong, &type_mp, 0 } },
  { "fromint", fromint, { &type_long, &type_mp, 0 } },
  { "touint", touint, { &type_mp, &type_ulong, 0 } },
  { "toint", toint, { &type_mp, &type_long, 0 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/mpint");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
