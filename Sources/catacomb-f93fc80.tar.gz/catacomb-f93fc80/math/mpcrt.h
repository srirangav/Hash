/* -*-c-*-
 *
 * Chinese Remainder Theorem computations (Gauss's algorithm)
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPCRT_H
#define CATACOMB_MPCRT_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

#ifndef CATACOMB_MPBARRETT_H
#  include "mpbarrett.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct mpcrt_mod {
  mp *m;				/* %$n_i$% -- the modulus */
  mp *n;				/* %$N_i = n / n_i$% */
  mp *ni;				/* %$M_i = N_i^{-1} \bmod n_i$% */
  mp *nni;				/* %$N_i M_i \bmod m$% */
} mpcrt_mod;

typedef struct mpcrt {
  size_t k;				/* Number of distinct moduli */
  mpbarrett mb;				/* Barrett context for product */
  mpcrt_mod *v;				/* Vector of information for each */
} mpcrt;

/*----- Functions provided ------------------------------------------------*/

/* --- @mpcrt_create@ --- *
 *
 * Arguments:	@mpcrt *c@ = pointer to CRT context
 *		@mpcrt_mod *v@ = pointer to vector of moduli
 *		@size_t k@ = number of moduli
 *		@mp *n@ = product of all moduli (@MP_NEW@ if unknown)
 *
 * Returns:	---
 *
 * Use:		Initializes a context for solving Chinese Remainder Theorem
 *		problems.  The vector of moduli can be incomplete.  Omitted
 *		items must be left as null pointers.  Not all combinations of
 *		missing things can be coped with, even if there is
 *		technically enough information to cope.  For example, if @n@
 *		is unspecified, all the @m@ values must be present, even if
 *		there is one modulus with both @m@ and @n@ (from which the
 *		product of all moduli could clearly be calculated).
 */

extern void mpcrt_create(mpcrt */*c*/, mpcrt_mod */*v*/,
			 size_t /*k*/, mp */*n*/);

/* --- @mpcrt_destroy@ --- *
 *
 * Arguments:	@mpcrt *c@ - pointer to CRT context
 *
 * Returns:	---
 *
 * Use:		Destroys a CRT context, releasing all the resources it holds.
 */

extern void mpcrt_destroy(mpcrt */*c*/);

/* --- @mpcrt_solve@ --- *
 *
 * Arguments:	@mpcrt *c@ = pointer to CRT context
 *		@mp *d@ = fake destination
 *		@mp **v@ = array of residues
 *
 * Returns:	The unique solution modulo the product of the individual
 *		moduli, which leaves the given residues.
 *
 * Use:		Constructs a result given its residue modulo an array of
 *		coprime integers.  This can be used to improve performance of
 *		RSA encryption or Blum-Blum-Shub generation if the factors
 *		of the modulus are known, since results can be computed mod
 *		each of the individual factors and then combined at the end.
 *		This is rather faster than doing the full-scale modular
 *		exponentiation.
 */

extern mp *mpcrt_solve(mpcrt */*c*/, mp */*d*/, mp **/*v*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
