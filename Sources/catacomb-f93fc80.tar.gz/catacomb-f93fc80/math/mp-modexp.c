/* -*-c-*-
 *
 * General-purpose modular exponentiation
 *
 * (c) 2006 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"
#include "mpbarrett.h"
#include "mpmont.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @mp_modexp@ --- *
 *
 * Arguments:	@mp *d@ = fake destination
 *		@mp *x@ = base of exponentiation
 *		@mp *e@ = exponent
 *		@mp *n@ = modulus (must be positive)
 *
 * Returns:	The value %$x^e \bmod n$%.
 */

mp *mp_modexp(mp *d, mp *x, mp *e, mp *n)
{
  if (MP_ODDP(n)) {
    mpmont mm;
    mpmont_create(&mm, n);
    d = mpmont_exp(&mm, d, x, e);
    mpmont_destroy(&mm);
  } else {
    mpbarrett mb;
    mpbarrett_create(&mb, n);
    d = mpbarrett_exp(&mb, d, x, e);
    mpbarrett_destroy(&mb);
  }
  return (d);
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

static int tmodexp(dstr *v)
{
  mp *a = *(mp **)v[0].buf;
  mp *b = *(mp **)v[1].buf;
  mp *m = *(mp **)v[2].buf;
  mp *r = *(mp **)v[3].buf;
  mp *mr;
  int ok = 1;

  mr = mp_modexp(MP_NEW, a, b, m);

  if (!MP_EQ(mr, r)) {
    fputs("\n*** modexp failed", stderr);
    fputs("\n a = ", stderr); mp_writefile(a, stderr, 10);
    fputs("\n e = ", stderr); mp_writefile(b, stderr, 10);
    fputs("\n m = ", stderr); mp_writefile(m, stderr, 10);
    fputs("\n r = ", stderr); mp_writefile(r, stderr, 10);
    fputs("\nmr = ", stderr); mp_writefile(mr, stderr, 10);
    fputc('\n', stderr);
    ok = 0;
  }

  MP_DROP(m);
  MP_DROP(a);
  MP_DROP(b);
  MP_DROP(r);
  MP_DROP(mr);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return ok;
}

static test_chunk tests[] = {
  { "modexp", tmodexp, { &type_mp, &type_mp, &type_mp, &type_mp, 0 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/mp");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
