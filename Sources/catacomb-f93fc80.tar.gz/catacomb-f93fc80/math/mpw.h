/* -*-c-*-
 *
 * Very low-level multiprecision definitions
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPW_H
#define CATACOMB_MPW_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_BITS_H
#  include <mLib/bits.h>
#endif

#ifndef CATACOMB_MPTYPES_H
#  include "mptypes.h"
#endif

/*----- Useful macros -----------------------------------------------------*/

/* --- @MPW@ --- *
 *
 * Arguments:	@x@ = an unsigned value
 *
 * Use:		Expands to the value of @x@ masked and typecast to a
 *		multiprecision integer word.
 */

#define MPW(x) ((mpw)((x) & MPW_MAX))

/* --- @MPWS@ --- *
 *
 * Arguments:	@n@ = number of words
 *
 * Use:		Expands to the number of bytes occupied by a given number of
 *		words.
 */

#define MPWS(n) ((n) * sizeof(mpw))

/* --- @MPW_RQ@ --- *
 *
 * Arguments:	@sz@ = size of an octet array, in octets
 *
 * Use:		Expands to the number of @mpw@ words required to represent
 *		the number held in the octet array.
 */

#define MPW_RQ(sz) (((sz) * 8 + MPW_BITS - 1) / MPW_BITS)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
