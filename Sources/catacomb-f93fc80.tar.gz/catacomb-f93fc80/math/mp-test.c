/* -*-c-*-
 *
 * Testing functionality for multiprecision integers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/dstr.h>
#include <mLib/report.h>
#include <mLib/sub.h>
#include <mLib/testrig.h>

#include "mp.h"
#include "mptext.h"

/*----- The `MP' testrig data type ----------------------------------------*/

static void mp_cvt(const char *buf, dstr *d)
{
  mp *m;
  DENSURE(d, sizeof(mp *));
  m = mp_readstring(MP_NEW, (char *)buf, 0, 0);
  if (!m)
    die(1, "bad integer `%s'", buf);
  *(mp **)d->buf = m;
}

static void mp_dump(dstr *d, FILE *fp)
{
  mp *m = *(mp **)d->buf;
  mp_writefile(m, fp, 10);
}

const test_type type_mp = { mp_cvt, mp_dump };

/*----- That's all, folks -------------------------------------------------*/
