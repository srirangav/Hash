/* -*-c-*-
 *
 * Check the bit operations work
 *
 * (c) 2002 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include "bitops.h"
#include "mpx.h"

/*----- Main code ---------------------------------------------------------*/

int main(void)
{
  int rc = 0;
#define CHECK(string) do {						\
  const char *ref = #string;						\
  char buf[5];								\
  buf[0] = B##string(0u, 0u) & 1u? '1' : '0';				\
  buf[1] = B##string(0u, 1u) & 1u? '1' : '0';				\
  buf[2] = B##string(1u, 0u) & 1u? '1' : '0';				\
  buf[3] = B##string(1u, 1u) & 1u? '1' : '0';				\
  buf[4] = 0;								\
  if (strcmp(buf, ref) != 0) {						\
    fprintf(stderr, "mismatch ref `%s' != buf `%s'\n", ref, buf);	\
    rc = 1;								\
  }									\
} while (0);
  MPX_DOBIN(CHECK)
  return (rc);
}
/*----- That's all, folks -------------------------------------------------*/
