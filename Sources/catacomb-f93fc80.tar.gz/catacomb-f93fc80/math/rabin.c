/* -*-c-*-
 *
 * Miller-Rabin primality test
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"
#include "mpbarrett.h"
#include "mpmont.h"
#include "pgen.h"
#include "rabin.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @rabin_create@ --- *
 *
 * Arguments:	@rabin *r@ = pointer to Rabin-Miller context
 *		@mp *m@ = pointer to number to test
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Precomputes some useful values for performing the
 *		Miller-Rabin probabilistic primality test.
 */

int rabin_create(rabin *r, mp *m)
{
  mp *m1 = mp_sub(MP_NEW, m, MP_ONE);
  if (mpmont_create(&r->mm, m)) {
    MP_DROP(m1);
    return (-1);
  }
  r->r = mp_odd(MP_NEW, m1, &r->s);
  r->m1 = mp_sub(MP_NEW, m, r->mm.r);
  mp_drop(m1);
  return (0);
}

/* --- @rabin_destroy@ --- *
 *
 * Arguments:	@rabin *r@ = pointer to Rabin-Miller context
 *
 * Returns:	---
 *
 * Use:		Disposes of a Rabin-Miller context when it's no longer
 *		needed.
 */

void rabin_destroy(rabin *r)
{
  mp_drop(r->r);
  mp_drop(r->m1);
  mpmont_destroy(&r->mm);
}

/* --- @rabin_test@, @rabin_rtest@ --- *
 *
 * Arguments:	@rabin *r@ = pointer to Rabin-Miller context
 *		@mp *g@ = base to test the number against
 *
 * Returns:	Either @PGEN_FAIL@ if the test failed, or @PGEN_PASS@
 *		if it succeeded.
 *
 * Use:		Performs a single iteration of the Rabin-Miller primality
 *		test.  The @rtest@ variant assumes that %$g$% is either
 *		already in Montgomery representation, or you don't care.
 */

int rabin_rtest(rabin *r, mp *g)
{
  mp *y;
  mp *dd, *spare = MP_NEW;
  size_t j;
  int rc = PGEN_FAIL;

  /* --- Calculate %$y R = g^r R \bmod m$% --- *
   *
   * If %$y = 1$% or %$y = m - 1$% then %$m$% is prime.  If course, note that
   * @y@ here has an extra factor of %$R$%.
   */

  y = mpmont_expr(&r->mm, MP_NEW, g, r->r);
  if (MP_EQ(y, r->mm.r) || MP_EQ(y, r->m1)) {
    rc = PGEN_PASS;
    goto done;
  }

  /* --- Now for the main loop --- *
   *
   * If %$y^{2^j} \ne m - 1$% for any %$0 \le j < s$% then %$m$% is
   * composite.  Of course, %$j = 0$% has already been tested.
   */

  for (j = 1; j < r->s; j++) {
    dd = mp_sqr(spare, y);
    dd = mpmont_reduce(&r->mm, dd, dd);
    spare = y; y = dd;
    if (MP_EQ(y, r->mm.r))
      break;
    if (MP_EQ(y, r->m1)) {
      rc = PGEN_PASS;
      break;
    }
  }

  /* --- Done --- */

done:
  if (spare != MP_NEW)
    MP_DROP(spare);
  MP_DROP(y);
  return (rc);
}

int rabin_test(rabin *r, mp *g)
{
  int rc;
  g = mpmont_mul(&r->mm, MP_NEW, g, r->mm.r2);
  rc = rabin_rtest(r, g);
  mp_drop(g);
  return (rc);
}

/* --- @rabin_iters@ --- *
 *
 * Arguments:	@unsigned len@ = number of bits in value
 *
 * Returns:	Number of iterations recommended.
 *
 * Use:		Returns the recommended number of iterations to ensure that a
 *		number with @len@ bits is really prime.
 */

int rabin_iters(unsigned len)
{
  static const struct {
    unsigned b;
    int i;
  } *p, *q, tab[] = {
    { 100, 27 },
    { 150, 18 },
    { 200, 15 },
    { 250, 12 },
    { 300, 9 },
    { 350, 8 },
    { 400, 7 },
    { 450, 6 },
    { 550, 5 },
    { 650, 4 },
    { 850, 3 },
    { 1300, 2 }
  };

  unsigned i;

  /* --- Binary search through the table --- */

  p = tab;
  q = tab + (sizeof(tab)/sizeof(tab[0]));
  for (;;) {
    i = (q - p) / 2;
    if (!i)
      break;
    if (len >= p[i].b && len < p[i + 1].b)
      break;
    if (len > p[i].b)
      p = p + i;
    else
      q = p + i;
  }
  return (p[i].i);
}

/*----- That's all, folks -------------------------------------------------*/
