/* -*-c-*-
 *
 * Dump a multiprecision integer as C data
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <errno.h>
#include <stdio.h>
#include <string.h>

#include "mp.h"

/*----- Main code ---------------------------------------------------------*/

int main(int argc, char *argv[])
{
  mp *x;
  int i;
  int w, n;

  if (argc != 2) {
    fprintf(stderr, "%s: missing argument\n", argv[0]);
    return (1);
  }
  if ((x = mp_readstring(0, argv[1], 0, 0)) == 0) {
    fprintf(stderr, "%s: bad integer `%s'", argv[0], argv[1]);
    return (1);
  }
  fputs("  ", stdout);
  w = (MPW_BITS + 3)/4;
  n = 1;
  while (2 + 2 * n * (4 + w) < 72) n <<= 1;
  i = 0;
  for (;;) {
    printf("0x%0*x", w, x->v[i]);
    i++;
    if (i >= MP_LEN(x)) break;
    fputs(",", stdout);
    if (i % n) fputs(" ", stdout); else fputs("\n  ", stdout);
  }
  if (fflush(stdout) || ferror(stdout)) {
    fprintf(stderr, "%s: error writing data: %s", argv[0], strerror(errno));
    return (1);
  }
  fputs("\n", stdout);
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
