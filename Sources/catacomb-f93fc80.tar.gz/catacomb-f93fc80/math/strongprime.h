/* -*-c-*-
 *
 * Generate `strong' prime numbers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_STRONGPRIME_H
#define CATACOMB_STRONGPRIME_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

#ifndef CATACOMB_PGEN_H
#  include "pgen.h"
#endif

/*----- Functions provided ------------------------------------------------*/

/* --- @strongprime_setup@ --- *
 *
 * Arguments:	@const char *name@ = pointer to name root
 *		@mp *d@ = destination for search start point
 *		@pfilt *f@ = where to store filter jump context
 *		@unsigned nbits@ = number of bits wanted
 *		@grand *r@ = random number source
 *		@unsigned n@ = number of attempts to make
 *		@pgen_proc *event@ = event handler function
 *		@void *ectx@ = argument for the event handler
 *
 * Returns:	A starting point for a `strong' prime search, or zero.
 *
 * Use:		Sets up for a strong prime search, so that primes with
 *		particular properties can be found.  It's probably important
 *		to note that the number left in the filter context @f@ is
 *		congruent to 2 (mod 4).
 */

extern mp *strongprime_setup(const char */*name*/, mp */*d*/, pfilt */*f*/,
			     unsigned /*nbits*/, grand */*r*/,
			     unsigned /*n*/, pgen_proc */*event*/,
			     void */*ectx*/);

/* --- @strongprime@ --- *
 *
 * Arguments:	@const char *name@ = pointer to name root
 *		@mp *d@ = destination integer
 *		@unsigned nbits@ = number of bits wanted
 *		@grand *r@ = random number source
 *		@unsigned n@ = number of attempts to make
 *		@pgen_proc *event@ = event handler function
 *		@void *ectx@ = argument for the event handler
 *
 * Returns:	A `strong' prime, or zero.
 *
 * Use:		Finds `strong' primes.  A strong prime %$p$% is such that
 *
 *		  * %$p - 1$% has a large prime factor %$r$%,
 *		  * %$p + 1$% has a large prime factor %$s$%, and
 *		  * %$r - 1$% has a large prime factor %$t$%.
 *
 *		The numbers produced may be slightly larger than requested,
 *		by a few bits.
 */

extern mp *strongprime(const char */*name*/, mp */*d*/, unsigned /*nbits*/,
		       grand */*r*/, unsigned /*n*/,
		       pgen_proc */*event*/, void */*ectx*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
