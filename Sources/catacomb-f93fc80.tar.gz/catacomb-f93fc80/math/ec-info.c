/* -*-c-*-
 *
 * Elliptic curve information management
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/darray.h>

#include "ec.h"
#include "ectab.h"
#include "gf.h"
#include "keysz.h"
#include "mpbarrett.h"
#include "pgen.h"
#include "primeiter.h"
#include "mprand.h"
#include "mpint.h"
#include "rabin.h"

/*----- Embedding degree checking -----------------------------------------*
 *
 * Let %$q = p^m$% be a prime power, and let %$E$% be an elliptic curve over
 * %$\gf{q}$% with %$n = \#E(\gf{q}) = r h$% where %$r$% is prime.  Then the
 * Weil and Tate pairings can be used to map %$r$%-torsion points on
 * %$E(\gf{q})$% onto the %$r$%-th roots of unity (i.e., the order-%$r$%
 * subgroup) in an extension field %$\gf{p^k}$% of %$\gf{p}$% (%%\emph{not}%%
 * of %$\gf{q}$% -- see [Hitt]).  We call the smallest such %$k$% the
 * %%\emph{embedding degree}%% of the curve %$E$%.  The
 * Menezes-Okamoto-Vanstone (MOV) attack solves the discrete log problem in
 * %$E(\gf{q})$% by using the pairing and then applying index calculus to
 * extract a discrete log in %$\gf{p^k}$%; obviously this only works if %$k$%
 * is small enough.
 *
 * The usual check, suggested in, e.g., [P1363] or [SEC1], only covers
 * extension fields %$\gf{q^\ell}$% of %$\gf{q}$%, which is fine when %$q$%
 * is prime, but when we're dealing with binary fields it works less well.
 * Indeed, as [Hitt] demonstrates, the embedding field can actually be
 * %%\emph{smaller}%% than %$\gf{q}$%, and choosing %$m$% prime doesn't help
 * (even though I previously thought it did).
 *
 * Define the %%\emph{embedding degree bound}%% %$B$% to be the smallest
 * %$i$% such that discrete logs in %$\gf{p^i}$% are about as hard as in
 * %$E(\gf{q})$%.
 *
 * The embedding group is a subgroup of the multiplicative group
 * %$\gf{p^k}^*$% which contains %$p^k - 1$% elements; therefore we must have
 * %$r \mid p^k - 1$%, or, equivalently, %$p^k \equiv 1 \pmod{r}$%.
 *
 * The recommended checking procedure, e.g., in [P1363], is just to check
 * %$q^i \not\equiv 1 \pmod{r}$% for each %$0 < i < B$%.  This is fast when
 * you only consider extension fields of %$\gf{q}$%, since %$B$% is at most
 * about 27.  However, as noted above, this is inadequate when %$q$% is a
 * prime power, and we must check all the extension fields of %$p$%.  Now
 * %$B$% can be about 15000, which is rather scarier -- we need a better
 * algorithm.
 *
 * As noted, we must have %$p^k \equiv 1 \pmod{r}$%; but by minimality of
 * %$k$%, we must have %$p^i \not\equiv 1 \pmod{r}$% for %$0 < i < k$%.
 * Therefore %$p$% generates an order-%$k$% subgroup in %$\gf{r}^*$%, so we
 * must have %$k \mid r - 1$%.
 *
 * Of course, factoring %$r - 1$% is a mug's game; but we're not interested
 * in the complete factorization -- just the %$B$%-smooth portion.  An
 * algorithm suggests itself:
 *
 *   1. Extract the factors of %$r - 1$% which are less than %$B$%.
 *
 *   2. For each divisor %$d$% of %$r - 1$% less than %$B$% (which we can
 *	construct using this factorization), make sure that
 *	%$p^d \not\equiv 1 \pmod{r}$%.
 *
 * This takes a little while but not ever-so long.
 *
 * This is enough for cryptosystems based on the computational Diffie-
 * Hellman problem to be secure.  However, it's %%\emph{not}%% enough for the
 * %%\emph{decisional}%% Diffie-Hellman problem to be hard; it appears we
 * also need to hope that there aren't any suitable distortion maps with
 * which one can solve the DDH problem.  I don't know how to check for those
 * at the moment.
 *
 * We'll take the subgroup order as indicative of the security level actually
 * wanted.  Then, to ensure security against the MOV attack, we must ensure
 * that the embedding degree is sufficiently large that discrete logs in
 * %$\gf{q^m}$% are at least as hard as discrete logs over the curve.
 *
 * We actually allow a small amount of slop in the conversions, in order to
 * let people pick nice round numbers for their key lengths.
 *
 * References:
 *
 * [Hitt]  L. Hitt, On an improved definition of embedding degree;
 *	   http://eprint.iacr.org/2006/415
 *
 * [P1363] IEEE 1363-2000: Standard Specifications for Public Key
 *	   Cryptography; http://grouper.ieee.org/groups/1363/P1363/index.html
 *
 * [SEC1]  SEC 1: Elliptic Curve Cryptography;
 *	   http://www.secg.org/download/aid-385/sec1_final.pdf
 */

/* --- @movcheck@ --- *
 *
 * Arguments:	@mp *r@ = curve subgroup order
 *		@mp *p@ = field characteristic
 *		@unsigned long B@ = embedding degree bound
 *
 * Returns:	Zero if OK, nonzero if an embedding was found.
 *
 * Use:		Checks a curve for embeddings with degree less than the
 *		stated bound %$B$%.  See above for explanation and a
 *		description of the algorithm.
 */

static int movcheck(mp *r, mp *p, unsigned long B)
{
  mpmont mm;
  mp *r1, *pp = MP_NEW, *t = MP_NEW, *u = MP_NEW, *v = MP_NEW, *tt;
  struct factor {
    unsigned long f;
    unsigned c, e;
  };
  DA_DECL(factor_v, struct factor);
  factor_v fv = DA_INIT;
  size_t nf;
  struct factor *ff;
  primeiter pi;
  mp *BB;
  unsigned long d, f;
  unsigned i, j;
  int rc = 0;

  /* --- Special case --- *
   *
   * If %$r = 2$% then (a) Montgomery reduction won't work, and (b) we have
   * no security worth checking anyway.  Otherwise we're guaranteed that
   * %$r$% is a prime, so it must be odd.
   */

  if (MP_EQ(r, MP_TWO))
    return (0);

  /* --- First factor the %$B%-smooth portion of %$r - 1$% --- *
   *
   * We can generate prime numbers up to %$B$% efficiently, so trial division
   * it is.
   */

  BB = mp_fromulong(MP_NEW, B);
  r1 = mp_sub(MP_NEW, r, MP_ONE);
  primeiter_create(&pi, 0);
  for (;;) {
    pp = primeiter_next(&pi, pp);
    if (MP_CMP(pp, >, BB))
      break;
    mp_div(&u, &v, r1, pp);
    if (!MP_ZEROP(v))
      continue;
    i = 0;
    do {
      tt = r1; r1 = u; u = tt; i++;
      mp_div(&u, &v, r1, pp);
    } while (MP_ZEROP(v));
    DA_ENSURE(&fv, 1);
    DA_UNSAFE_EXTEND(&fv, 1);
    DA_LAST(&fv).f = mp_toulong(pp);
    DA_LAST(&fv).e = i;
    DA_LAST(&fv).c = 0;
  }
  MP_DROP(BB); MP_DROP(pp); primeiter_destroy(&pi);
  nf = DA_LEN(&fv); ff = DA(&fv);

  /* --- Now generate divisors of %$r - 1$% less than %$B$% --- *
   *
   * For each divisor %$d$%, check whether %$p^d \equiv 1 \pmod{r}$%.
   */

  mpmont_create(&mm, r);
  u = mpmont_mul(&mm, u, p, mm.r2);
  for (;;) {

    /* --- Construct the divisor --- */

    d = 1;
    for (i = 0; i < nf; i++) {
      f = ff[i].f; j = ff[i].c; if (!j) continue;
      for (;;) {
	if (f >= (B + d - 1)/d) goto toobig;
	if (j & 1) d *= f;
	j >>= 1; if (!j) break;
	f *= f;
      }
    }
    v = mp_fromulong(v, d);

    /* --- Compute %$p^k \bmod r$% and check --- */

    t = mpmont_expr(&mm, t, u, v);
    if (MP_EQ(t, mm.r)) {
      rc = -1;
      break;
    }

    /* --- Step the divisors along --- */

  toobig:
    for (i = 0; i < nf; i++) {
      if (ff[i].c < ff[i].e) {
	ff[i].c++;
	goto more;
      }
      ff[i].c = 0;
    }
    break;
  more:;
  }

  /* --- Clear away the debris --- */

  mpmont_destroy(&mm);
  MP_DROP(t); MP_DROP(u); MP_DROP(v); MP_DROP(r1);
  DA_DESTROY(&fv);
  return (rc);
}

/*----- Main code ---------------------------------------------------------*/

/* --- @ec_curveparse@ --- *
 *
 * Arguments:	@qd_parse *qd@ = parser context
 *
 * Returns:	Elliptic curve pointer if OK, or null.
 *
 * Use:		Parses an elliptic curve description, which has the form
 *
 *		  * a field description
 *		  * an optional `;'
 *		  * `prime', `primeproj', `bin', or `binproj'
 *		  * an optional `:'
 *		  * the %$a$% parameter
 *		  * an optional `,'
 *		  * the %$b$% parameter
 */

ec_curve *ec_curveparse(qd_parse *qd)
{
  mp *a = MP_NEW, *b = MP_NEW;
  ec_curve *c;
  field *f;

  if ((f = field_parse(qd)) == 0) goto fail;
  qd_delim(qd, ';');
  switch (qd_enum(qd, "prime,primeproj,bin,binproj")) {
    case 0:
      if (F_TYPE(f) != FTY_PRIME) {
	qd->e = "field not prime";
	goto fail;
      }
      qd_delim(qd, ':');
      if ((a = qd_getmp(qd)) == 0) goto fail;
      qd_delim(qd, ',');
      if ((b = qd_getmp(qd)) == 0) goto fail;
      c = ec_prime(f, a, b);
      break;
    case 1:
      if (F_TYPE(f) != FTY_PRIME) {
	qd->e = "field not prime";
	goto fail;
      }
      qd_delim(qd, ':');
      if ((a = qd_getmp(qd)) == 0) goto fail;
      qd_delim(qd, ',');
      if ((b = qd_getmp(qd)) == 0) goto fail;
      c = ec_primeproj(f, a, b);
      break;
    case 2:
      if (F_TYPE(f) != FTY_BINARY) {
	qd->e = "field not binary";
	goto fail;
      }
      qd_delim(qd, ':');
      if ((a = qd_getmp(qd)) == 0) goto fail;
      qd_delim(qd, ',');
      if ((b = qd_getmp(qd)) == 0) goto fail;
      c = ec_bin(f, a, b);
      break;
    case 3:
      if (F_TYPE(f) != FTY_BINARY) {
	qd->e = "field not binary";
	goto fail;
      }
      qd_delim(qd, ':');
      if ((a = qd_getmp(qd)) == 0) goto fail;
      qd_delim(qd, ',');
      if ((b = qd_getmp(qd)) == 0) goto fail;
      c = ec_binproj(f, a, b);
      break;
    default:
      goto fail;
  }
  if (!c) {
    qd->e = "bad curve parameters";
    goto fail;
  }
  if (a) MP_DROP(a);
  if (b) MP_DROP(b);
  return (c);

fail:
  if (f) F_DESTROY(f);
  if (a) MP_DROP(a);
  if (b) MP_DROP(b);
  return (0);
}

/* --- @ec_ptparse@ --- *
 *
 * Arguments:	@qd_parse *qd@ = parser context
 *		@ec *p@ = where to put the point
 *
 * Returns:	The point address, or null.
 *
 * Use:		Parses an elliptic curve point.  This has the form
 *
 *		  * %$x$%-coordinate
 *		  * optional `,'
 *		  * %$y$%-coordinate
 */

ec *ec_ptparse(qd_parse *qd, ec *p)
{
  mp *x = MP_NEW, *y = MP_NEW;

  if (qd_enum(qd, "inf") >= 0) {
    EC_SETINF(p);
    return (p);
  }
  if ((x = qd_getmp(qd)) == 0) goto fail;
  qd_delim(qd, ',');
  if ((y = qd_getmp(qd)) == 0) goto fail;
  EC_DESTROY(p);
  p->x = x;
  p->y = y;
  p->z = 0;
  return (p);

fail:
  if (x) MP_DROP(x);
  if (y) MP_DROP(y);
  return (0);
}

/* --- @ec_infofromdata@ --- *
 *
 * Arguments:	@ec_info *ei@ = where to write the information
 *		@ecdata *ed@ = raw data
 *
 * Returns:	---
 *
 * Use:		Loads elliptic curve information about one of the standard
 *		curves.
 */

void ec_infofromdata(ec_info *ei, ecdata *ed)
{
  field *f;

  switch (ed->ftag) {
    case FTAG_PRIME:
      f = field_prime(&ed->p);
      ei->c = ec_primeproj(f, &ed->a, &ed->b);
      break;
    case FTAG_NICEPRIME:
      f = field_niceprime(&ed->p);
      ei->c = ec_primeproj(f, &ed->a, &ed->b);
      break;
    case FTAG_BINPOLY:
      f = field_binpoly(&ed->p);
      ei->c = ec_binproj(f, &ed->a, &ed->b);
      break;
    case FTAG_BINNORM:
      f = field_binnorm(&ed->p, &ed->beta);
      ei->c = ec_binproj(f, &ed->a, &ed->b);
      break;
    default:
      abort();
  }

  assert(f); assert(ei->c);
  EC_CREATE(&ei->g); ei->g.x = &ed->gx; ei->g.y = &ed->gy; ei->g.z = 0;
  ei->r = &ed->r; ei->h = &ed->h;
}

/* --- @ec_infoparse@ --- *
 *
 * Arguments:	@qd_parse *qd@ = parser context
 *		@ec_info *ei@ = curve information block, currently
 *			uninitialized
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Parses an elliptic curve information string, and stores the
 *		information in @ei@.  This is either the name of a standard
 *		curve, or it has the form
 *
 *		  * elliptic curve description
 *		  * optional `;'
 *		  * common point
 *		  * optional `:'
 *		  * group order
 *		  * optional `*'
 *		  * cofactor
 */

int ec_infoparse(qd_parse *qd, ec_info *ei)
{
  ec_curve *c = 0;
  field *f;
  ec g = EC_INIT;
  const ecentry *ee;
  mp *r = MP_NEW, *h = MP_NEW;

  for (ee = ectab; ee->name; ee++) {
    if (qd_enum(qd, ee->name) >= 0) {
      ec_infofromdata(ei, ee->data);
      goto found;
    }
  }

  if ((c = ec_curveparse(qd)) == 0) goto fail;
  qd_delim(qd, ';'); if (!ec_ptparse(qd, &g)) goto fail;
  qd_delim(qd, ':'); if ((r = qd_getmp(qd)) == 0) goto fail;
  qd_delim(qd, '*'); if ((h = qd_getmp(qd)) == 0) goto fail;
  ei->c = c; ei->g = g; ei->r = r; ei->h = h;

found:
  return (0);

fail:
  EC_DESTROY(&g);
  if (r) MP_DROP(r);
  if (h) MP_DROP(h);
  if (c) { f = c->f; ec_destroycurve(c); F_DESTROY(f); }
  return (-1);
}

/* --- @ec_getinfo@ --- *
 *
 * Arguments:	@ec_info *ei@ = where to write the information
 *		@const char *p@ = string describing a curve
 *
 * Returns:	Null on success, or a pointer to an error message.
 *
 * Use:		Parses out information about a curve.  The string is either a
 *		standard curve name, or a curve info string.
 */

const char *ec_getinfo(ec_info *ei, const char *p)
{
  qd_parse qd;

  qd.p = p;
  qd.e = 0;
  if (ec_infoparse(&qd, ei))
    return (qd.e);
  if (!qd_eofp(&qd)) {
    ec_freeinfo(ei);
    return ("junk found at end of string");
  }
  return (0);
}

/* --- @ec_sameinfop@ --- *
 *
 * Arguments:	@ec_info *ei, *ej@ = two elliptic curve parameter sets
 *
 * Returns:	Nonzero if the curves are identical (not just isomorphic).
 *
 * Use:		Checks for sameness of curve parameters.
 */

int ec_sameinfop(ec_info *ei, ec_info *ej)
{
  return (ec_samep(ei->c, ej->c) &&
	  MP_EQ(ei->r, ej->r) && MP_EQ(ei->h, ej->h) &&
	  EC_EQ(&ei->g, &ej->g));
}

/* --- @ec_freeinfo@ --- *
 *
 * Arguments:	@ec_info *ei@ = elliptic curve information block to free
 *
 * Returns:	---
 *
 * Use:		Frees the information block.
 */

void ec_freeinfo(ec_info *ei)
{
  field *f;

  EC_DESTROY(&ei->g);
  MP_DROP(ei->r);
  MP_DROP(ei->h);
  f = ei->c->f; ec_destroycurve(ei->c); F_DESTROY(f);
}

/* --- @ec_checkinfo@ --- *
 *
 * Arguments:	@const ec_info *ei@ = elliptic curve information block
 *
 * Returns:	Null if OK, or pointer to error message.
 *
 * Use:		Checks an elliptic curve according to the rules in SEC1.
 */

static const char *gencheck(const ec_info *ei, grand *gr, mp *q, mp *ch)
{
  ec_curve *c = ei->c;
  unsigned long qmbits, rbits, cbits, B;
  mp *qq;
  mp *nn;
  mp *x, *y;
  ec p;
  int rc;

  /* --- Check curve isn't anomalous --- */

  if (MP_EQ(ei->r, q)) return ("curve is anomalous");

  /* --- Check %$G \in E \setminus \{ 0 \}$% --- */

  if (EC_ATINF(&ei->g)) return ("generator at infinity");
  if (ec_check(c, &ei->g)) return ("generator not on curve");

  /* --- Check %$r$% is prime --- */

  if (!pgen_primep(ei->r, gr)) return ("generator order not prime");

  /* --- Check that the cofactor is correct --- *
   *
   * Let %$q$% be the size of the field, and let %$n = h r = \#E(\gf{q})$% be
   * the number of %$\gf{q}$%-rational points on our curve.  Hasse's theorem
   * tells us that
   *
   *   %$|q + 1 - n| \le 2\sqrt{q}$%
   *
   * or, if we square both sides,
   *
   *   %$(q + 1 - n)^2 \le 4 q$%.
   *
   * We'd like the cofactor to be uniquely determined by this equation, which
   * is possible as long as it's not too big.  (If it is, we have to mess
   * about with Weil pairings, which is no fun.)  For this, we need the
   * following inequalities:
   *
   *   * %$A = (q + 1 - n)^2 \le 4 q$% (both lower and upper bounds from
   *	 Hasse's theorem);
   *
   *   * %$B = (q + 1 - n - r)^2 > 4 q$% (check %$h - 1$% isn't possible);
   *	 and
   *
   *   * %$C = (q + 1 - n + r)^2 > 4 q$% (check %$h + 1$% isn't possible).
   */

  rc = 1;
  qq = mp_add(MP_NEW, q, MP_ONE);
  nn = mp_mul(MP_NEW, ei->r, ei->h);
  nn = mp_sub(nn, qq, nn);
  qq = mp_lsl(qq, q, 2);

  y = mp_sqr(MP_NEW, nn);
  if (MP_CMP(y, >, qq)) rc = 0;

  x = mp_sub(MP_NEW, nn, ei->r);
  y = mp_sqr(y, x);
  if (MP_CMP(y, <=, qq)) rc = 0;

  x = mp_add(x, nn, ei->r);
  y = mp_sqr(y, x);
  if (MP_CMP(y, <=, qq)) rc = 0;

  MP_DROP(x);
  MP_DROP(y);
  MP_DROP(nn);
  MP_DROP(qq);
  if (!rc) return ("incorrect or ambiguous cofactor");

  /* --- Check %$n G = 0$% --- */

  EC_CREATE(&p);
  ec_mul(c, &p, &ei->g, ei->r);
  rc = EC_ATINF(&p);
  EC_DESTROY(&p);
  if (!rc) return ("incorrect group order");

  /* --- Check the embedding degree --- */

  rbits = mp_bits(ei->r);
  cbits = mp_bits(ch);
  qmbits = keysz_todl(keysz_fromec(rbits * 7/8));
  B = (qmbits + cbits - 1)/cbits;
  if (movcheck(ei->r, ch, B))
    return("curve embedding degree too low");

  /* --- Done --- */

  return (0);
}

static int primeeltp(mp *x, field *f)
  { return (!MP_NEGP(x) && MP_CMP(x, <, f->m)); }

static const char *primecheck(const ec_info *ei, grand *gr)
{
  ec_curve *c = ei->c;
  field *f = c->f;
  mp *x, *y;
  int rc;
  const char *err;

  /* --- Check %$p$% is an odd prime --- */

  if (!pgen_primep(f->m, gr)) return ("p not prime");

  /* --- Check %$a$%, %$b$%, %$G_x$% and %$G_y$% are in %$[0, p)$% --- */

  if (!primeeltp(c->a, f)) return ("a out of range");
  if (!primeeltp(c->b, f)) return ("b out of range");
  if (!primeeltp(ei->g.x, f)) return ("G_x out of range");
  if (!primeeltp(ei->g.x, f)) return ("G_y out of range");

  /* --- Check %$4 a^3 + 27 b^2 \not\equiv 0 \pmod{p}$% --- */

  x = F_SQR(f, MP_NEW, c->a);
  x = F_MUL(f, x, x, c->a);
  x = F_QDL(f, x, x);
  y = F_SQR(f, MP_NEW, c->b);
  y = F_TPL(f, y, y);
  y = F_TPL(f, y, y);
  y = F_TPL(f, y, y);
  x = F_ADD(f, x, x, y);
  rc = F_ZEROP(f, x);
  MP_DROP(x);
  MP_DROP(y);
  if (rc) return ("not an elliptic curve");

  /* --- Now do the general checks --- */

  err = gencheck(ei, gr, f->m, f->m);
  return (err);
}

static const char *bincheck(const ec_info *ei, grand *gr)
{
  ec_curve *c = ei->c;
  field *f = c->f;
  mp *x;
  int rc;
  const char *err;

  /* --- Check that %$m$% is prime --- */

  x = mp_fromuint(MP_NEW, f->nbits);
  rc = pfilt_smallfactor(x);
  mp_drop(x);
  if (rc != PGEN_DONE) return ("degree not prime");

  /* --- Check that %$p$% is irreducible --- */

  if (!gf_irreduciblep(f->m)) return ("p not irreducible");

  /* --- Check that %$a, b, G_x, G_y$% have degree less than %$p$% --- */

  if (mp_bits(c->a) > f->nbits) return ("a out of range");
  if (mp_bits(c->b) > f->nbits) return ("a out of range");
  if (mp_bits(ei->g.x) > f->nbits) return ("G_x out of range");
  if (mp_bits(ei->g.y) > f->nbits) return ("G_y out of range");

  /* --- Check that %$b \ne 0$% --- */

  if (F_ZEROP(f, c->b)) return ("b is zero");

  /* --- Now do the general checks --- */

  x = mp_lsl(MP_NEW, MP_ONE, f->nbits);
  err = gencheck(ei, gr, x, MP_TWO);
  mp_drop(x);
  return (err);
}

const char *ec_checkinfo(const ec_info *ei, grand *gr)
{
  switch (F_TYPE(ei->c->f)) {
    case FTY_PRIME: return (primecheck(ei, gr)); break;
    case FTY_BINARY: return (bincheck(ei, gr)); break;
  }
  return ("unknown curve type");
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#include "fibrand.h"

int main(int argc, char *argv[])
{
  const ecentry *ee;
  const char *e;
  int ok = 1;
  int i;
  grand *gr;

  gr = fibrand_create(0);
  if (argc > 1) {
    for (i = 1; i < argc; i++) {
      ec_info ei;
      if ((e = ec_getinfo(&ei, argv[i])) != 0)
	fprintf(stderr, "bad curve spec `%s': %s\n", argv[i], e);
      else {
	e = ec_checkinfo(&ei, gr);
	ec_freeinfo(&ei);
	if (!e)
	  printf("OK %s\n", argv[i]);
	else {
	  printf("BAD %s: %s\n", argv[i], e);
	  ok = 0;
	}
      }
      assert(mparena_count(MPARENA_GLOBAL) == 0);
    }
  } else {
    fputs("checking standard curves:", stdout);
    fflush(stdout);
    for (ee = ectab; ee->name; ee++) {
      ec_info ei;
      ec_infofromdata(&ei, ee->data);
      e = ec_checkinfo(&ei, gr);
      ec_freeinfo(&ei);
      if (e) {
	printf(" [%s fails: %s]", ee->name, e);
	ok = 0;
      } else
	printf(" %s", ee->name);
      fflush(stdout);
      assert(mparena_count(MPARENA_GLOBAL) == 0);
    }
    fputs(ok ? " ok\n" : " failed\n", stdout);
  }
  gr->ops->destroy(gr);
  return (!ok);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
