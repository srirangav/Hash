/* -*-c-*-
 *
 * Generate a prime-iteration wheel
 *
 * (c) 2007 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/darray.h>
#include <mLib/dstr.h>
#include <mLib/mdwopt.h>
#include <mLib/quis.h>
#include <mLib/report.h>

/*----- Data structures ---------------------------------------------------*/

DA_DECL(uintv, unsigned int);

/*----- Main code ---------------------------------------------------------*/

static unsigned long gcd(unsigned long a, unsigned long b)
{
  int t;
  if (!a) return (b);
  while (b) { t = a%b; a = b; b = t; }
  return (a);
}

int main(int argc, char *argv[])
{
  int np = 5;
  const char *type = "unsigned char";
  const char *source = "wheel.c";
  const char *header = "wheel.h";
  const char *name = "wheel";
  const char *sym = 0;
  const char *hdrbase;
  unsigned long i, n;
  unsigned long mod;
  int o;
  uintv v = DA_INIT;

  ego(argv[0]);
  for (;;) {
    o = getopt(argc, argv, "n:c:h:s:t:i:");
    if (o < 0)
      break;
    switch (o) {
      case 'n':
	np = atoi(optarg);
	break;
      case 's':
	sym = optarg;
	break;
      case 'c':
	source = optarg;
	break;
      case 'h':
	header = optarg;
	break;
      case 't':
	type = optarg;
	break;
      case 'i':
	name = optarg;
	break;
      default:
	pquis(stderr, "Usage: $ [-n nprimes] [-s source] [-h header]\n");
	exit(EXIT_FAILURE);
    }
  }

  if ((hdrbase = strrchr(header, '/')) == 0) hdrbase = header;
  else hdrbase++;

  for (mod = 1, i = 2, n = 0;
       n < np;
       i++) {
    if (gcd(i, mod) == 1) {
      mod *= i;
      n++;
    }
  }

  n = 1;
  for (i = 2; i < mod; i++) {
    if (gcd(mod, i) == 1) {
      DA_PUSH(&v, i - n);
      n = i;
    }
  }
  DA_PUSH(&v, mod + 1 - n);

  {
    FILE *fp = fopen(header, "w");
    dstr d = DSTR_INIT;
    const char *q;
    if (!fp)
      die(EXIT_FAILURE, "couldn't write `%s': %s", header, strerror(errno));
    if (!sym) {
      for (q = header; *q; q++) {
	int ch = (unsigned char)*q;
	if (isalnum(ch))
	  ch = toupper(ch);
	else
	  ch = '_';
	DPUTC(&d, ch);
      }
      DPUTZ(&d);
      sym = d.buf;
    }
    fprintf(fp, "\
/* -*-c-*-\n\
 *\n\
 * Wheel for small prime iteration [generated]\n\
 */\n\
\n\
#ifndef %s\n\
#define %s\n\
\n\
#define WHEELN %luu\n\
#define WHEELMOD %luu\n\
\n\
extern const %s %s[];\n\
\n\
#endif\n\
",
	    sym, sym,
	    (unsigned long)DA_LEN(&v),
	    mod,
	    type, name);
    dstr_destroy(&d);
    if (fclose(fp) == EOF) {
      remove(header);
      die(EXIT_FAILURE, "error writing `%s': %s", header, strerror(errno));
    }
  }

  {
    FILE *fp = fopen(source, "w");
    int i;
    if (!fp)
      die(EXIT_FAILURE, "couldn't write `%s': %s", source, strerror(errno));
    fprintf(fp, "\
/* -*-c-*-\n\
 *\n\
 * Wheel for small prime iteration [generated]\n\
 */\n\
\n\
#include \"%s\"\n\
\n\
const %s %s[] = {",
	    hdrbase, type, name);
    for (i = 0; i < DA_LEN(&v); i++) {
      if (i % 8 == 0)
	fputs("\n  ", fp);
      fprintf(fp, "%5u, ", DA(&v)[i]);
    }
    fputs("\n\
};\n\
", fp);
    if (fclose(fp) == EOF) {
      remove(source);
      die(EXIT_FAILURE, "error writing `%s': %s", source, strerror(errno));
    }
  }

  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
