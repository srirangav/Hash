/* -*-c-*-
 *
 * Reduction modulo sparse binary polynomials
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GFREDUCE_H
#define CATACOMB_GFREDUCE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>

#ifndef CATACOMB_GF_H
#  include "gf.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct gfreduce_instr {
  unsigned op;				/* Instruction opcode */
  size_t arg;				/* Immediate argument */
} gfreduce_instr;

enum {
  GFRI_LOAD,				/* Load @p[arg]@ */
  GFRI_LSL,				/* XOR with @w << arg@ */
  GFRI_LSR,				/* XOR with @w >> arg@ */
  GFRI_STORE,				/* Store @p[arg]@ */
  GFRI_MAX
};

typedef struct gfreduce {
  size_t lim;				/* Word of degree bit */
  mpw mask;				/* Mask for degree word */
  mp *p;				/* Copy of the polynomial */
  size_t in;				/* Number of instruction words */
  gfreduce_instr *iv;			/* Vector of instructions */
  gfreduce_instr *fiv;			/* Final-pass instruction suffix */
} gfreduce;

/*----- Functions provided ------------------------------------------------*/

/* --- @gfreduce_create@ --- *
 *
 * Arguments:	@gfreduce *r@ = structure to fill in
 *		@mp *x@ = a (hopefully sparse) polynomial
 *
 * Returns:	---
 *
 * Use:		Initializes a context structure for reduction.
 */

extern void gfreduce_create(gfreduce */*r*/, mp */*p*/);

/* --- @gfreduce_destroy@ --- *
 *
 * Arguments:	@gfreduce *r@ = structure to free
 *
 * Returns:	---
 *
 * Use:		Reclaims the resources from a reduction context.
 */

extern void gfreduce_destroy(gfreduce */*r*/);

/* --- @gfreduce_dump@ --- *
 *
 * Arguments:	@gfreduce *r@ = structure to dump
 *		@FILE *fp@ = file to dump on
 *
 * Returns:	---
 *
 * Use:		Dumps a reduction context.
 */

extern void gfreduce_dump(gfreduce */*r*/, FILE */*fp*/);

/* --- @gfreduce_do@ --- *
 *
 * Arguments:	@gfreduce *r@ = reduction context
 *		@mp *d@ = destination
 *		@mp *x@ = source
 *
 * Returns:	Destination, @x@ reduced modulo the reduction poly.
 */

extern mp *gfreduce_do(gfreduce */*r*/, mp */*d*/, mp */*x*/);

/* --- @gfreduce_sqrt@ --- *
 *
 * Arguments:	@gfreduce *r@ = pointer to reduction context
 *		@mp *d@ = destination
 *		@mp *x@ = some polynomial
 *
 * Returns:	The square root of @x@ modulo @r->p@, or null.
 */

extern mp *gfreduce_sqrt(gfreduce */*r*/, mp */*d*/, mp */*x*/);

/* --- @gfreduce_trace@ --- *
 *
 * Arguments:	@gfreduce *r@ = pointer to reduction context
 *		@mp *x@ = some polynomial
 *
 * Returns:	The trace of @x@. (%$\Tr(x)=x + x^2 + \cdots + x^{2^{m-1}}$%
 *		if %$x \in \gf{2^m}$%).  Since the trace is invariant under
 *		the Frobenius automorphism (i.e., %$\Tr(x)^2 = \Tr(x)$%), it
 *		must be an element of the base field, i.e., %$\gf{2}$%, and
 *		we only need a single bit to represent it.
 */

extern int gfreduce_trace(gfreduce */*r*/, mp */*x*/);

/* --- @gfreduce_halftrace@ --- *
 *
 * Arguments:	@gfreduce *r@ = pointer to reduction context
 *		@mp *d@ = destination
 *		@mp *x@ = some polynomial
 *
 * Returns:	The half-trace of @x@.
 *		(%$\HfTr(x)= x + x^{2^2} + \cdots + x^{2^{m-1}}$%
 *		if %$x \in \gf{2^m}$% with %$m$% odd).
 */

extern mp *gfreduce_halftrace(gfreduce */*r*/, mp */*d*/, mp */*x*/);

/* --- @gfreduce_quadsolve@ --- *
 *
 * Arguments:	@gfreduce *r@ = pointer to reduction context
 *		@mp *d@ = destination
 *		@mp *x@ = some polynomial
 *
 * Returns:	A polynomial @y@ such that %$y^2 + y = x$%, or null.
 *
 * Use:		Solves quadratic equations in a field with characteristic 2.
 *		Suppose we have an equation %$y^2 + A y + B = 0$% where
 *		%$A \ne 0$%.  (If %$A = 0$% then %$y = \sqrt{B}$% and you
 *		want @gfreduce_sqrt@ instead.)  Use this function to solve
 *		%$z^2 + z = B/A^2$%; then set %$y = A z$%, since
 *		%$y^2 + y = A^2 z^2 + A^2 z = A^2 (z^2 + z) = B$% as
 *		required.
 *
 *		The two roots are %$z$% and %$z + 1$%; this function always
 *		returns the one with zero scalar coefficient.
 */

extern mp *gfreduce_quadsolve(gfreduce */*r*/, mp */*d*/, mp */*x*/);

/* --- @gfreduce_exp@ --- *
 *
 * Arguments:	@gfreduce *gr@ = pointer to reduction context
 *		@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$a^e \bmod m$%.
 */

extern mp *gfreduce_exp(gfreduce */*gr*/, mp */*d*/, mp */*a*/, mp */*e*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
