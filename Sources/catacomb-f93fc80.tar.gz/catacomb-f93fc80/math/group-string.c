/* -*-c-*-
 *
 * String I/O for group elements
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "group.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @group_readstring@ --- *
 *
 * Arguments:	@group *g@ = an abstract group
 *		@ge *d@ = destination group element
 *		@const char *p@ = where the string is
 *		@char **end@ = where to put the end pointer
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Parses a group element from a string.
 */

int group_readstring(group *g, ge *d, const char *p, char **end)
{
  mptext_stringctx ms;

  ms.buf = (/*unconst*/ char *)p;
  ms.lim = (/*unconst*/ char *)p + strlen(p);
  if (G_READ(g, d, &mptext_stringops, &ms))
    return (-1);
  if (end) *end = ms.buf;
  return (0);
}

/* --- @group_writestring@ --- *
 *
 * Arguments:	@group *g@ = an abstract group
 *		@ge *x@ = a group element
 *		@char *p@ = where the string should go
 *		@size_t sz@ = how long the buffer is
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Writes a group element to a string buffer.
 */

int group_writestring(group *g, ge *x, char *p, size_t sz)
{
  mptext_stringctx ms;

  ms.buf = p;
  ms.lim = p + sz - 1;
  if (G_WRITE(g, x, &mptext_stringops, &ms))
    return (-1);
  *ms.buf = 0;
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
