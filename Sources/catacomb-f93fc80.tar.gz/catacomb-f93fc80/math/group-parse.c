/* -*-c-*-
 *
 * Parse group description strings
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Trivial IP Encryption (TrIPE).
 *
 * TrIPE is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * TrIPE is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with TrIPE; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "group.h"
#include "dh.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @group_parse@ --- *
 *
 * Arguments:	@qd_parse *qd@ = quick-and-dirty parser
 *
 * Returns:	Group pointer, or null for failure.
 *
 * Use:		Parses a group description and returns the group.  This has
 *		the form `TYPE { SPEC }' where TYPE is `prime' or `ec', and
 *		SPEC is the appropriate kind of group specification of the
 *		given type.
 */

group *group_parse(qd_parse *qd)
{
  group *g = 0;

  switch (qd_enum(qd, "prime,ec")) {
    case 0: {
      dh_param dp;
      qd_delim(qd, '{');
      if (dh_parse(qd, &dp)) goto ouch;
      qd_delim(qd, '}');
      g = group_prime(&dp);
      dh_paramfree(&dp);
    } break;
    case 1: {
      ec_info ei;
      qd_delim(qd, '{');
      if (ec_infoparse(qd, &ei)) goto ouch;
      qd_delim(qd, '}');
      g = group_ec(&ei);
    } break;
  }
  if (!g) qd->e = "bad group parameters";
ouch:
  return (g);
}

/* --- @group_fromstring@ --- *
 *
 * Arguments:	@const char *p@ = pointer to string to read
 *		@group **gg@ = where to put the group pointer
 *
 * Returns:	Null if OK, or an error string.
 *
 * Use:		Parses a group spec from a string, and returns the group.
 */

const char *group_fromstring(const char *p, group **gg)
{
  group *g;
  qd_parse qd;

  qd.p = p;
  qd.e = 0;
  if ((g = group_parse(&qd)) == 0) return (qd.e);
  if (!qd_eofp(&qd)) { G_DESTROYGROUP(g); return ("junk at end of string"); }
  *gg = g;
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
