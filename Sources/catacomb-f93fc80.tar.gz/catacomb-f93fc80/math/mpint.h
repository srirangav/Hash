/* -*-c-*-
 *
 * Conversion between MPs and standard C integers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPINT_H
#define CATACOMB_MPINT_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <limits.h>

#include <mLib/macros.h>

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

/*----- Generic translation macros ----------------------------------------*/

/* --- Warning damage control --- *
 *
 * GCC (at least) isn't clever enough to work out that the division in
 * @MP_FROMINT@ is actually safe (since it will only be executed if @_i >
 * MPW_MAX@, which would prove that @(type)MPW_MAX + 1 != 0@).
 */

/* --- @MP_FROMINT@ --- *
 *
 * Arguments:	@d@ = destination multiprecision integer
 *		@type@ = type of integer which @i@ is
 *		@i@ = a standard C integer
 *
 * Use:		Stores the value of @i@ in @d@.  This macro is actually
 *		rather subtle in places.  Be careful what you change.
 */

#define MP_FROMINT(d, type, i) do {					\
  type _i = (i);							\
  size_t _o = 0;							\
  mp *_d = (d);								\
  size_t _sz = 4;							\
									\
  MP_DEST(_d, _sz, 0);							\
  _d->f &= ~(MP_NEG | MP_UNDEF);					\
									\
  if (_i >= 0) {							\
    while (_i) {							\
      if (_o == _sz) {							\
	_sz <<= 1;							\
	MP_ENSURE(_d, _sz);						\
      }									\
      _d->v[_o++] = MPW(_i);						\
      if (_i <= MPW_MAX)						\
	break;								\
      else								\
	MUFFLE_WARNINGS_STMT(GCC_WARNING("-Wdiv-by-zero"), {		\
	  _i /= (type)MPW_MAX + 1;					\
	});								\
    }									\
  } else {								\
    _d->f |= MP_NEG;							\
    while (_i) {							\
      if (_o == _sz) {							\
	_sz <<= 1;							\
	MP_ENSURE(_d, _sz);						\
      }									\
      _d->v[_o++] = MPW(-_i);						\
      if (_i >= -MPW_MAX)						\
	break;								\
      else								\
	MUFFLE_WARNINGS_STMT(GCC_WARNING("-Wdiv-by-zero"), {		\
	  _i /= (type)MPW_MAX + 1;					\
	});								\
    }									\
  }									\
									\
  _d->vl = _d->v + _o;							\
  (d) = _d;								\
} while (0)

/* --- @MP_TOINT@ --- *
 *
 * Arguments:	@m@ = a multiprecision integer
 *		@type@ = the type of @i@
 *		@max@ = the largest value @i@ can represent
 *		@i@ = an integer variable
 *
 * Use:		Stores the value of a multiprecision integer in a standard C
 *		integer.  If the value won't fit, the behaviour is determined
 *		by the type of @i@: if @i@ is unsigned, the value of the
 *		multiprecision integer modulo @max + 1@ is stored; if @i@ is
 *		signed, the behaviour is undefined.
 *
 *		If you don't want to be bitten by these sorts of things, keep
 *		copies of @INT_MAX@ or whatever is appropriate in
 *		multiprecision form and compare before conversion.
 */

#define MP_TOINT(m, type, max, i) do {					\
  type _i = 0;								\
  type _max = (max);							\
  unsigned _s = 0;							\
  const mp *_m = (m);							\
  const mpw *_v = _m->v, *_vl = _m->vl;					\
									\
  /* --- Do all the arithmetic in negative numbers --- */		\
									\
  while (_v < _vl && _max > 0) {					\
    _i -= *_v << _s;							\
    _s += MPW_BITS;							\
    _v++;								\
    _max /= (mpd)MPW_MAX + 1;						\
  }									\
  if (!MP_NEGP(_m))							\
    _i = -_i;								\
  (i) = _i;								\
} while (0)

/*----- Functions provided ------------------------------------------------*/

/* --- Build up the list of conversions to be supplied --- */

#ifdef ULLONG_MAX
#  ifndef LLONG_MAX
#    define LLONG_MAX LONG_LONG_MAX
#  endif
#  define MPINT_CONV_LLONG(_)						\
  _(llong, long long, LLONG_MAX)					\
  _(ullong, unsigned long long, ULLONG_MAX)
#else
#  define MPINT_CONV_LLONG(_)
#endif

#ifdef INTMAX_MAX
#  define MPINT_CONV_INTMAX(_)						\
  _(intmax, intmax_t, INTMAX_MAX)					\
  _(uintmax, uintmax_t, UINTMAX_MAX)
#else
#  define MPINT_CONV_INTMAX(_)
#endif

#ifdef HAVE_UINT64
#  define MPINT_CONV_U64(_) _(uint64, uint64, MASK64)
#else
#  define MPINT_CONV_U64(_)
#endif

#define MPINT_CONVERSIONS(_)						\
  _(short, short, SHRT_MAX)						\
  _(ushort, unsigned short, USHRT_MAX)					\
  _(int, int, INT_MAX)							\
  _(uint, unsigned, UINT_MAX)						\
  _(long, long, LONG_MAX)						\
  _(ulong, unsigned long, ULONG_MAX)					\
  MPINT_CONV_LLONG(_)							\
  _(uint8, uint8, MASK8)						\
  _(uint16, uint16, MASK16)						\
  _(uint24, uint24, MASK24)						\
  _(uint32, uint32, MASK32)						\
  MPINT_CONV_U64(_)							\
  MPINT_CONV_INTMAX(_)							\
  _(sizet, size_t, (size_t)-1)

/* --- @mp_fromINT@ --- *
 *
 * Arguments:	@mp *d@ = pointer to destination multiprecision integer
 *		@INT i@ = standard C integer to convert
 *
 * Returns:	The resulting multiprecision integer.
 *
 * Use:		Converts a standard C integer to a multiprecision integer.
 */

#define mp_fromINT(name, type, max)					\
  extern mp *mp_from##name(mp */*d*/, type /*i*/);
MPINT_CONVERSIONS(mp_fromINT)
#undef mp_fromINT

/* --- @mp_toINT@ --- *
 *
 * Arguments:	@const mp *m@ = pointer to a multiprecision integer
 *
 * Returns:	The value of the integer @m@ as a C integer.
 *
 * Use:		Converts a multiprecision integer to a standard C integer.
 *		If the value of the multiprecision integer cannot be
 *		represented in the return type, and the return type is
 *		unsigned, it is reduced modulo @TYPE_MAX + 1@; if the return
 *		type is signed, the behaviour is undefined.
 */

#define mp_toINT(name, type, max)					\
  extern type mp_to##name(const mp */*m*/);
MPINT_CONVERSIONS(mp_toINT)
#undef mp_toINT

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
