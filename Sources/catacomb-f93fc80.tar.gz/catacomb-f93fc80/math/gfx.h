/* -*-c-*-
 *
 * Low-level arithmetic on binary polynomials
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GFX_H
#define CATACOMB_GFX_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MPX_H
#  include "mpx.h"
#endif

/*----- Functions provided ------------------------------------------------*/

/* --- @gfx_add@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = first addend vector base and limit
 *		@const mpw *bv, *bvl@ = second addend vector base and limit
 *
 * Returns:	---
 *
 * Use:		Adds two %$\gf{2}$% polynomials.  This is the same as
 *		subtraction.
 */

extern void gfx_add(mpw */*dv*/, mpw */*dvl*/,
		    const mpw */*av*/, const mpw */*avl*/,
		    const mpw */*bv*/, const mpw */*bvl*/);

/* --- @gfx_acc@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = addend vector base and limit
 *
 * Returns:	---
 *
 * Use:		Adds the addend into the destination.  This is considerably
 *		faster than the three-address add call.
 */

extern void gfx_acc(mpw */*dv*/, mpw */*dvl*/,
		    const mpw */*av*/, const mpw */*avl*/);

/* --- @gfx_accshift@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = addend vector base and limit
 *		@size_t n@ = number of bits to shift
 *
 * Returns:	---
 *
 * Use:		Shifts the argument left by %$n$% places and adds it to the
 *		destination.  This is a primitive used by multiplication and
 *		division.
 */

extern void gfx_accshift(mpw */*dv*/, mpw */*dvl*/,
			 const mpw */*av*/, const mpw */*avl*/,
			 size_t /*n*/);

/* --- @gfx_mul@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = first argument vector base and limit
 *		@const mpw *bv, *bvl@ = second argument vector base and limit
 *
 * Returns:	---
 *
 * Use:		Does multiplication of polynomials over %$\gf{2}$%.
 */

extern void gfx_mul(mpw */*dv*/, mpw */*dvl*/,
		    const mpw */*av*/, const mpw */*avl*/,
		    const mpw */*bv*/, const mpw */*bvl*/);

/* --- @gfx_sqr@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = argument vector base and limit
 *
 * Returns:	---
 *
 * Use:		Performs squaring of binary polynomials.
 */

extern void gfx_sqr(mpw */*dv*/, mpw */*dvl*/,
		    const mpw */*av*/, const mpw */*avl*/);

/* --- @gfx_div@ --- *
 *
 * Arguments:	@mpw *qv, *qvl@ = quotient vector base and limit
 *		@mpw *rv, *rvl@ = dividend/remainder vector base and limit
 *		@const mpw *dv, *dvl@ = divisor vector base and limit
 *
 * Returns:	---
 *
 * Use:		Performs division on polynomials over %$\gf{2}$%.
 */

extern void gfx_div(mpw */*qv*/, mpw */*qvl*/, mpw */*rv*/, mpw */*rvl*/,
		    const mpw */*dv*/, const mpw */*dvl*/);

/*----- Karatsuba multiplication algorithms -------------------------------*/

/* --- @GFK_THRESH@ --- *
 *
 * This is the limiting length for using Karatsuba algorithms.  It's best to
 * use the simpler classical multiplication method on numbers smaller than
 * this.
 */

#define GFK_THRESH 2

/* --- @gfx_kmul@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = pointer to destination buffer
 *		@const mpw *av, *avl@ = pointer to first argument
 *		@const mpw *bv, *bvl@ = pointer to second argument
 *		@mpw *sv, *svl@ = pointer to scratch workspace
 *
 * Returns:	---
 *
 * Use:		Multiplies two binary polynomials using Karatsuba's
 *		algorithm.  This is rather faster than traditional long
 *		multiplication (e.g., @gfx_umul@) on polynomials with large
 *		degree, although more expensive on small ones.
 *
 *		The destination must be twice as large as the larger
 *		argument.  The scratch space must be twice as large as the
 *		larger argument.
 */

extern void gfx_kmul(mpw */*dv*/, mpw */*dvl*/,
		     const mpw */*av*/, const mpw */*avl*/,
		     const mpw */*bv*/, const mpw */*bvl*/,
		     mpw */*sv*/, mpw */*svl*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
