/* -*-c-*-
 *
 * Exponentiation in finite fields
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_FIELD_EXP_H
#define CATACOMB_FIELD_EXP_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Exponentiation definitions ----------------------------------------*/

#define EXP_TYPE mp *

#define EXP_COPY(d, x) d = MP_COPY(x)
#define EXP_DROP(x) MP_DROP(x)

#define EXP_MUL(a, x) a = F_MUL(f, a, a, x)
#define EXP_SQR(a) a = F_SQR(f, a, a)
#define EXP_FIX(x)

#define EXP_SETMUL(d, x, y) d = F_MUL(f, MP_NEW, x, y)
#define EXP_SETSQR(d, x) d = F_SQR(f, MP_NEW, x)

#include "exp.h"

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
