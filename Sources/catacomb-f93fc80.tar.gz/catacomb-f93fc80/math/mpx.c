/* -*-c-*-
 *
 * Low-level multiprecision arithmetic
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/bits.h>
#include <mLib/macros.h>

#include "mptypes.h"
#include "mpx.h"
#include "bitops.h"

/*----- Loading and storing -----------------------------------------------*/

/* --- These are all variations on a theme --- *
 *
 * Essentially we want to feed bits into a shift register, @ibits@ bits at a
 * time, and extract them @obits@ bits at a time whenever there are enough.
 * Of course, @i@ and @o@ will, in general, be different sizes, and we don't
 * necessarily know which is larger.
 *
 * During an operation, we have a shift register @w@ and a most-recent input
 * @t@.  Together, these hold @bits@ significant bits of input.  We arrange
 * that @bits < ibits + obits <= 2*MPW_BITS@, so we can get away with using
 * an @mpw@ for both of these quantitities.
 */

/* --- @MPX_GETBITS@ --- *
 *
 * Arguments:	@ibits@ = width of input units, in bits
 *		@obits@ = width of output units, in bits
 *		@iavail@ = condition expression: is input data available?
 *		@getbits@ = function or macro: set argument to next input
 *
 * Use:		Read an input unit into @t@ and update the necessary
 *		variables.
 *
 *		It is assumed on entry that @bits < obits@.  On exit, we have
 *		@bits < ibits + obits@, and @t@ is live.
 */

#define MPX_GETBITS(ibits, obits, iavail, getbits) do {			\
  if (!iavail) goto flush;						\
  if (bits >= ibits) w |= t << (bits - ibits);				\
  getbits(t);								\
  bits += ibits;							\
} while (0)

/* --- @MPX_PUTBITS@ --- *
 *
 * Arguments:	@ibits@ = width of input units, in bits
 *		@obits@ = width of output units, in bits
 *		@oavail@ = condition expression: is output space available?
 *		@putbits@ = function or macro: write its argument to output
 *
 * Use:		Emit an output unit, and update the necessary variables.  If
 *		the output buffer is full, then force an immediate return.
 *
 *		We assume that @bits < ibits + obits@, and that @t@ is only
 *		relevant if @bits >= ibits@.  (The @MPX_GETBITS@ macro
 *		ensures that this is true.)
 */

#define SHRW(w, b) ((b) < MPW_BITS ? (w) >> (b) : 0)

#define MPX_PUTBITS(ibits, obits, oavail, putbits) do {			\
  if (!oavail) return;							\
  if (bits < ibits) {							\
    putbits(w);								\
    bits -= obits;							\
    w = SHRW(w, obits);							\
  } else {								\
    putbits(w | (t << (bits - ibits)));					\
    bits -= obits;							\
    if (bits >= ibits) w = SHRW(w, obits) | (t << (bits - ibits));	\
    else w = SHRW(w, obits) | (t >> (ibits - bits));			\
    t = 0;								\
  }									\
} while (0)

/* --- @MPX_LOADSTORE@ --- *
 *
 * Arguments:	@name@ = name of function to create, without @mpx_@ prefix
 *		@wconst@ = qualifiers for @mpw *@ arguments
 *		@oconst@ = qualifiers for octet pointers
 *		@decls@ = additional declarations needed
 *		@ibits@ = width of input units, in bits
 *		@iavail@ = condition expression: is input data available?
 *		@getbits@ = function or macro: set argument to next input
 *		@obits@ = width of output units, in bits
 *		@oavail@ = condition expression: is output space available?
 *		@putbits@ = function or macro: write its argument to output
 *		@clear@ = statements to clear remainder of output
 *
 * Use:		Generates a function to convert between a sequence of
 *		multiprecision words and a vector of octets.
 *
 *		The arguments @ibits@, @iavail@ and @getbits@ are passed on
 *		to @MPX_GETBITS@; similarly, @obits@, @oavail@, and @putbits@
 *		are passed on to @MPX_PUTBITS@.
 *
 *		The following variables are in scope: @v@ and @vl are the
 *		current base and limit of the word vector; @p@ and @q@ are
 *		the base and limit of the octet vector; @w@ and @t@ form the
 *		shift register used during the conversion (see commentary
 *		above); and @bits@ tracks the number of live bits in the
 *		shift register.
 */

#define MPX_LOADSTORE(name, wconst, oconst, decls,			\
		      ibits, iavail, getbits, obits, oavail, putbits,	\
		      clear)						\
									\
void mpx_##name(wconst mpw *v, wconst mpw *vl,				\
		oconst void *pp, size_t sz)				\
{									\
  mpw t = 0, w = 0;							\
  oconst octet *p = pp, *q = p + sz;					\
  int bits = 0;								\
  decls									\
									\
  for (;;) {								\
    while (bits < obits) MPX_GETBITS(ibits, obits, iavail, getbits);	\
    while (bits >= obits) MPX_PUTBITS(ibits, obits, oavail, putbits);	\
  }									\
									\
flush:									\
  while (bits > 0) MPX_PUTBITS(ibits, obits, oavail, putbits);		\
  clear;								\
}

#define EMPTY

/* --- Macros for @getbits@ and @putbits@ --- */

#define GETMPW(t) do { t = *v++; } while (0)
#define PUTMPW(x) do { *v++ = MPW(x); } while (0)

#define GETOCTETI(t) do { t = *p++; } while (0)
#define PUTOCTETD(x) do { *--q = U8(x); } while (0)

#define PUTOCTETI(x) do { *p++ = U8(x); } while (0)
#define GETOCTETD(t) do { t = *--q; } while (0)

/* --- Machinery for two's complement I/O --- */

#define DECL_2CN							\
  unsigned c = 1;

#define GETMPW_2CN(t) do {						\
  t = MPW(~*v++ + c);							\
  c = c && !t;								\
} while (0)

#define PUTMPW_2CN(t) do {						\
  mpw _t = MPW(~(t) + c);						\
  c = c && !_t;								\
  *v++ = _t;								\
} while (0)

#define FLUSHW_2CN do {							\
  if (c) MPX_ONE(v, vl);						\
  else MPX_ZERO(v, vl);							\
} while (0)

#define FLUSHO_2CN do {							\
  memset(p, c ? 0xff : 0, q - p);					\
} while (0)

/* --- @mpx_storel@ --- *
 *
 * Arguments:	@const mpw *v, *vl@ = base and limit of source vector
 *		@void *pp@ = pointer to octet array
 *		@size_t sz@ = size of octet array
 *
 * Returns:	---
 *
 * Use:		Stores an MP in an octet array, least significant octet
 *		first.  High-end octets are silently discarded if there
 *		isn't enough space for them.
 */

MPX_LOADSTORE(storel, const, EMPTY, EMPTY,
	      MPW_BITS, (v < vl), GETMPW,
	      8, (p < q), PUTOCTETI,
	      { memset(p, 0, q - p); })

/* --- @mpx_loadl@ --- *
 *
 * Arguments:	@mpw *v, *vl@ = base and limit of destination vector
 *		@const void *pp@ = pointer to octet array
 *		@size_t sz@ = size of octet array
 *
 * Returns:	---
 *
 * Use:		Loads an MP in an octet array, least significant octet
 *		first.  High-end octets are ignored if there isn't enough
 *		space for them.
 */

MPX_LOADSTORE(loadl, EMPTY, const, EMPTY,
	      8, (p < q), GETOCTETI,
	      MPW_BITS, (v < vl), PUTMPW,
	      { MPX_ZERO(v, vl); })


/* --- @mpx_storeb@ --- *
 *
 * Arguments:	@const mpw *v, *vl@ = base and limit of source vector
 *		@void *pp@ = pointer to octet array
 *		@size_t sz@ = size of octet array
 *
 * Returns:	---
 *
 * Use:		Stores an MP in an octet array, most significant octet
 *		first.  High-end octets are silently discarded if there
 *		isn't enough space for them.
 */

MPX_LOADSTORE(storeb, const, EMPTY, EMPTY,
	      MPW_BITS, (v < vl), GETMPW,
	      8, (p < q), PUTOCTETD,
	      { memset(p, 0, q - p); })

/* --- @mpx_loadb@ --- *
 *
 * Arguments:	@mpw *v, *vl@ = base and limit of destination vector
 *		@const void *pp@ = pointer to octet array
 *		@size_t sz@ = size of octet array
 *
 * Returns:	---
 *
 * Use:		Loads an MP in an octet array, most significant octet
 *		first.  High-end octets are ignored if there isn't enough
 *		space for them.
 */

MPX_LOADSTORE(loadb, EMPTY, const, EMPTY,
	      8, (p < q), GETOCTETD,
	      MPW_BITS, (v < vl), PUTMPW,
	      { MPX_ZERO(v, vl); })

/* --- @mpx_storel2cn@ --- *
 *
 * Arguments:	@const mpw *v, *vl@ = base and limit of source vector
 *		@void *pp@ = pointer to octet array
 *		@size_t sz@ = size of octet array
 *
 * Returns:	---
 *
 * Use:		Stores a negative MP in an octet array, least significant
 *		octet first, as two's complement.  High-end octets are
 *		silently discarded if there isn't enough space for them.
 *		This obviously makes the output bad.
 */

MPX_LOADSTORE(storel2cn, const, EMPTY, DECL_2CN,
	      MPW_BITS, (v < vl), GETMPW_2CN,
	      8, (p < q), PUTOCTETI,
	      { FLUSHO_2CN; })

/* --- @mpx_loadl2cn@ --- *
 *
 * Arguments:	@mpw *v, *vl@ = base and limit of destination vector
 *		@const void *pp@ = pointer to octet array
 *		@size_t sz@ = size of octet array
 *
 * Returns:	---
 *
 * Use:		Loads a negative MP in an octet array, least significant
 *		octet first, as two's complement.  High-end octets are
 *		ignored if there isn't enough space for them.  This probably
 *		means you made the wrong choice coming here.
 */

MPX_LOADSTORE(loadl2cn, EMPTY, const, DECL_2CN,
	      8, (p < q), GETOCTETI,
	      MPW_BITS, (v < vl), PUTMPW_2CN,
	      { FLUSHW_2CN; })

/* --- @mpx_storeb2cn@ --- *
 *
 * Arguments:	@const mpw *v, *vl@ = base and limit of source vector
 *		@void *pp@ = pointer to octet array
 *		@size_t sz@ = size of octet array
 *
 * Returns:	---
 *
 * Use:		Stores a negative MP in an octet array, most significant
 *		octet first, as two's complement.  High-end octets are
 *		silently discarded if there isn't enough space for them,
 *		which probably isn't what you meant.
 */

MPX_LOADSTORE(storeb2cn, const, EMPTY, DECL_2CN,
	      MPW_BITS, (v < vl), GETMPW_2CN,
	      8, (p < q), PUTOCTETD,
	      { FLUSHO_2CN; })

/* --- @mpx_loadb2cn@ --- *
 *
 * Arguments:	@mpw *v, *vl@ = base and limit of destination vector
 *		@const void *pp@ = pointer to octet array
 *		@size_t sz@ = size of octet array
 *
 * Returns:	---
 *
 * Use:		Loads a negative MP in an octet array, most significant octet
 *		first as two's complement.  High-end octets are ignored if
 *		there isn't enough space for them.  This probably means you
 *		chose this function wrongly.
 */

MPX_LOADSTORE(loadb2cn, EMPTY, const, DECL_2CN,
	      8, (p < q), GETOCTETD,
	      MPW_BITS, (v < vl), PUTMPW_2CN,
	      { FLUSHW_2CN; })

/*----- Logical shifting --------------------------------------------------*/

/* --- @MPX_SHIFT1@ --- *
 *
 * Arguments:	@init@ = initial accumulator value
 *		@out@ = expression to store in each output word
 *		@next@ = expression for next accumulator value
 *
 * Use:		Performs a single-position shift.  The input is scanned
 *		right-to-left.  In the expressions @out@ and @next@, the
 *		accumulator is available in @w@ and the current input word is
 *		in @t@.
 *
 *		This macro is intended to be used in the @shift1@ argument of
 *		@MPX_SHIFTOP@, and expects variables describing the operation
 *		to be set up accordingly.
 */

#define MPX_SHIFT1(init, out, next) do {				\
  mpw t, w = (init);							\
  while (av < avl) {							\
    if (dv >= dvl) break;						\
    t = MPW(*av++);							\
    *dv++ = (out);							\
    w = (next);								\
  }									\
  if (dv < dvl) { *dv++ = MPW(w); MPX_ZERO(dv, dvl); }			\
} while (0)

/* --- @MPX_SHIFTW@ --- *
 *
 * Arguments:	@max@ = the maximum shift (in words) which is nontrivial
 *		@clear@ = function (or macro) to clear low-order output words
 *		@copy@ = statement to copy words from input to output
 *
 * Use:		Performs a shift by a whole number of words.  If the shift
 *		amount is @max@ or more words, then the destination is
 *		@clear@ed entirely; otherwise, @copy@ is executed.
 *
 *		This macro is intended to be used in the @shiftw@ argument of
 *		@MPX_SHIFTOP@, and expects variables describing the operation
 *		to be set up accordingly.
 */

#define MPX_SHIFTW(max, clear, copy) do {				\
  if (nw >= (max)) clear(dv, dvl);					\
  else copy								\
} while (0)

/* --- @MPX_SHIFTOP@ --- *
 *
 * Arguments:	@name@ = name of function to define (without `@mpx_@' prefix)
 *		@shift1@ = statement to shift by a single bit
 *		@shiftw@ = statement to shift by a whole number of words
 *		@shift@ = statement to perform a general shift
 *
 * Use:		Emits a shift operation.  The input is @av@..@avl@; the
 *		output is @dv@..@dvl@; and the shift amount (in bits) is
 *		@n@.  In @shiftw@ and @shift@, @nw@ and @nb@ are set up such
 *		that @n = nw*MPW_BITS + nb@ and @nb < MPW_BITS@.
 */

#define MPX_SHIFTOP(name, shift1, shiftw, shift)			\
									\
void mpx_##name(mpw *dv, mpw *dvl,					\
		const mpw *av, const mpw *avl,				\
		size_t n)						\
{									\
									\
  if (n == 0)								\
    MPX_COPY(dv, dvl, av, avl);						\
  else if (n == 1)							\
    do shift1 while (0);						\
  else {								\
    size_t nw = n/MPW_BITS;						\
    unsigned nb = n%MPW_BITS;						\
    if (!nb) do shiftw while (0);					\
    else do shift while (0);						\
  }									\
}

/* --- @MPX_SHIFT_LEFT@ --- *
 *
 * Arguments:	@name@ = name of function to define (without `@mpx_@' prefix)
 *		@init1@ = initializer for single-bit shift accumulator
 *		@clear@ = function (or macro) to clear low-order output words
 *		@flush@ = expression for low-order nontrivial output word
 *
 * Use:		Emits a left-shift operation.  This expands to a call on
 *		@MPX_SHIFTOP@, but implements the complicated @shift@
 *		statement.
 *
 *		The @init1@ argument is as for @MPX_SHIFT1@, and @clear@ is
 *		as for @MPX_SHIFTW@ (though is used elsewhere).  In a general
 *		shift, @nw@ whole low-order output words are set using
 *		@clear@; high-order words are zeroed; and the remaining words
 *		set with a left-to-right pass across the input; at the end of
 *		the operation, the least significant output word above those
 *		@clear@ed is set using @flush@, which may use the accumulator
 *		@w@ = @av[0] << nb@.
 */

#define MPX_SHIFT_LEFT(name, init1, clear, flush)			\
MPX_SHIFTOP(name, {							\
  MPX_SHIFT1(init1,							\
	     w | (t << 1),						\
	     t >> (MPW_BITS - 1));					\
}, {									\
  MPX_SHIFTW(dvl - dv, clear, {						\
    MPX_COPY(dv + nw, dvl, av, avl);					\
    clear(dv, dv + nw);							\
  });									\
}, {									\
  size_t nr = MPW_BITS - nb;						\
  size_t dvn = dvl - dv;						\
  size_t avn = avl - av;						\
  mpw w;								\
									\
  if (dvn <= nw) {							\
    clear(dv, dvl);							\
    break;								\
  }									\
									\
  if (dvn <= avn + nw) {						\
    avl = av + dvn - nw;						\
    w = *--avl << nb;							\
  } else {								\
    size_t off = avn + nw + 1;						\
    MPX_ZERO(dv + off, dvl);						\
    dvl = dv + off;							\
    w = 0;								\
  }									\
									\
  while (avl > av) {							\
    mpw t = *--avl;							\
    *--dvl = MPW(w | (t >> nr));					\
    w = t << nb;							\
  }									\
									\
  *--dvl = MPW(flush);							\
  clear(dv, dvl);							\
})

/* --- @mpx_lsl@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = source vector base and limit
 *		@size_t n@ = number of bit positions to shift by
 *
 * Returns:	---
 *
 * Use:		Performs a logical shift left operation on an integer.
 */

MPX_SHIFT_LEFT(lsl, 0, MPX_ZERO, w)

/* --- @mpx_lslc@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = source vector base and limit
 *		@size_t n@ = number of bit positions to shift by
 *
 * Returns:	---
 *
 * Use:		Performs a logical shift left operation on an integer, only
 *		it fills in the bits with ones instead of zeroes.
 */

MPX_SHIFT_LEFT(lslc, 1, MPX_ONE, w | (MPW_MAX >> nr))

/* --- @mpx_lsr@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = source vector base and limit
 *		@size_t n@ = number of bit positions to shift by
 *
 * Returns:	---
 *
 * Use:		Performs a logical shift right operation on an integer.
 */

MPX_SHIFTOP(lsr, {
  MPX_SHIFT1(av < avl ? *av++ >> 1 : 0,
	     w | (t << (MPW_BITS - 1)),
	     t >> 1);
}, {
  MPX_SHIFTW(avl - av, MPX_ZERO,
	     { MPX_COPY(dv, dvl, av + nw, avl); });
}, {
  size_t nr = MPW_BITS - nb;
  mpw w;

  av += nw;
  w = av < avl ? *av++ : 0;
  while (av < avl) {
    mpw t;
    if (dv >= dvl) goto done;
    t = *av++;
    *dv++ = MPW((w >> nb) | (t << nr));
    w = t;
  }
  if (dv < dvl) {
    *dv++ = MPW(w >> nb);
    MPX_ZERO(dv, dvl);
  }
done:;
})

/*----- Bitwise operations ------------------------------------------------*/

/* --- @mpx_bitop@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector
 *		@const mpw *av, *avl@ = first source vector
 *		@const mpw *bv, *bvl@ = second source vector
 *
 * Returns:	---
 *
 * Use;		Provides the dyadic boolean functions.
 */

#define MPX_BITBINOP(string)						\
									\
void mpx_bit##string(mpw *dv, mpw *dvl, const mpw *av, const mpw *avl,	\
		     const mpw *bv, const mpw *bvl)			\
{									\
  MPX_SHRINK(av, avl);							\
  MPX_SHRINK(bv, bvl);							\
									\
  while (dv < dvl) {							\
    mpw a, b;								\
    a = (av < avl) ? *av++ : 0;						\
    b = (bv < bvl) ? *bv++ : 0;						\
    *dv++ = B##string(a, b);						\
    IGNORE(a); IGNORE(b);						\
  }									\
}

MPX_DOBIN(MPX_BITBINOP)

void mpx_not(mpw *dv, mpw *dvl, const mpw *av, const mpw *avl)
{
  MPX_SHRINK(av, avl);

  while (dv < dvl) {
    mpw a;
    a = (av < avl) ? *av++ : 0;
    *dv++ = ~a;
  }
}

/*----- Unsigned arithmetic -----------------------------------------------*/

/* --- @mpx_2c@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector
 *		@const mpw *v, *vl@ = source vector
 *
 * Returns:	---
 *
 * Use:		Calculates the two's complement of @v@.
 */

void mpx_2c(mpw *dv, mpw *dvl, const mpw *v, const mpw *vl)
{
  mpw c = 0;
  while (dv < dvl && v < vl)
    *dv++ = c = MPW(~*v++);
  if (dv < dvl) {
    if (c > MPW_MAX / 2)
      c = MPW(~0);
    while (dv < dvl)
      *dv++ = c;
  }
  MPX_UADDN(dv, dvl, 1);
}

/* --- @mpx_ueq@ --- *
 *
 * Arguments:	@const mpw *av, *avl@ = first argument vector base and limit
 *		@const mpw *bv, *bvl@ = second argument vector base and limit
 *
 * Returns:	Nonzero if the two vectors are equal.
 *
 * Use:		Performs an unsigned integer test for equality.
 */

int mpx_ueq(const mpw *av, const mpw *avl, const mpw *bv, const mpw *bvl)
{
  MPX_SHRINK(av, avl);
  MPX_SHRINK(bv, bvl);
  if (avl - av != bvl - bv)
    return (0);
  while (av < avl) {
    if (*av++ != *bv++)
      return (0);
  }
  return (1);
}

/* --- @mpx_ucmp@ --- *
 *
 * Arguments:	@const mpw *av, *avl@ = first argument vector base and limit
 *		@const mpw *bv, *bvl@ = second argument vector base and limit
 *
 * Returns:	Less than, equal to, or greater than zero depending on
 *		whether @a@ is less than, equal to or greater than @b@,
 *		respectively.
 *
 * Use:		Performs an unsigned integer comparison.
 */

int mpx_ucmp(const mpw *av, const mpw *avl, const mpw *bv, const mpw *bvl)
{
  MPX_SHRINK(av, avl);
  MPX_SHRINK(bv, bvl);

  if (avl - av > bvl - bv)
    return (+1);
  else if (avl - av < bvl - bv)
    return (-1);
  else while (avl > av) {
    mpw a = *--avl, b = *--bvl;
    if (a > b)
      return (+1);
    else if (a < b)
      return (-1);
  }
  return (0);
}

/* --- @mpx_uadd@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = first addend vector base and limit
 *		@const mpw *bv, *bvl@ = second addend vector base and limit
 *
 * Returns:	---
 *
 * Use:		Performs unsigned integer addition.  If the result overflows
 *		the destination vector, high-order bits are discarded.  This
 *		means that two's complement addition happens more or less for
 *		free, although that's more a side-effect than anything else.
 *		The result vector may be equal to either or both source
 *		vectors, but may not otherwise overlap them.
 */

void mpx_uadd(mpw *dv, mpw *dvl, const mpw *av, const mpw *avl,
	      const mpw *bv, const mpw *bvl)
{
  mpw c = 0;

  while (av < avl || bv < bvl) {
    mpw a, b;
    mpd x;
    if (dv >= dvl)
      return;
    a = (av < avl) ? *av++ : 0;
    b = (bv < bvl) ? *bv++ : 0;
    x = (mpd)a + (mpd)b + c;
    *dv++ = MPW(x);
    c = x >> MPW_BITS;
  }
  if (dv < dvl) {
    *dv++ = c;
    MPX_ZERO(dv, dvl);
  }
}

/* --- @mpx_uaddn@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = source and destination base and limit
 *		@mpw n@ = other addend
 *
 * Returns:	---
 *
 * Use:		Adds a small integer to a multiprecision number.
 */

void mpx_uaddn(mpw *dv, mpw *dvl, mpw n) { MPX_UADDN(dv, dvl, n); }

/* --- @mpx_uaddnlsl@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination and first argument vector
 *		@mpw a@ = second argument
 *		@unsigned o@ = offset in bits
 *
 * Returns:	---
 *
 * Use:		Computes %$d + 2^o a$%.  If the result overflows then
 *		high-order bits are discarded, as usual.  We must have
 *		@0 < o < MPW_BITS@.
 */

void mpx_uaddnlsl(mpw *dv, mpw *dvl, mpw a, unsigned o)
{
  mpd x = (mpd)a << o;

  while (x && dv < dvl) {
    x += *dv;
    *dv++ = MPW(x);
    x >>= MPW_BITS;
  }
}

/* --- @mpx_usub@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = first argument vector base and limit
 *		@const mpw *bv, *bvl@ = second argument vector base and limit
 *
 * Returns:	---
 *
 * Use:		Performs unsigned integer subtraction.  If the result
 *		overflows the destination vector, high-order bits are
 *		discarded.  This means that two's complement subtraction
 *		happens more or less for free, althuogh that's more a side-
 *		effect than anything else.  The result vector may be equal to
 *		either or both source vectors, but may not otherwise overlap
 *		them.
 */

void mpx_usub(mpw *dv, mpw *dvl, const mpw *av, const mpw *avl,
	      const mpw *bv, const mpw *bvl)
{
  mpw c = 0;

  while (av < avl || bv < bvl) {
    mpw a, b;
    mpd x;
    if (dv >= dvl)
      return;
    a = (av < avl) ? *av++ : 0;
    b = (bv < bvl) ? *bv++ : 0;
    x = (mpd)a - (mpd)b - c;
    *dv++ = MPW(x);
    if (x >> MPW_BITS)
      c = 1;
    else
      c = 0;
  }
  if (c)
    c = MPW_MAX;
  while (dv < dvl)
    *dv++ = c;
}

/* --- @mpx_usubn@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = source and destination base and limit
 *		@n@ = subtrahend
 *
 * Returns:	---
 *
 * Use:		Subtracts a small integer from a multiprecision number.
 */

void mpx_usubn(mpw *dv, mpw *dvl, mpw n) { MPX_USUBN(dv, dvl, n); }

/* --- @mpx_uaddnlsl@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination and first argument vector
 *		@mpw a@ = second argument
 *		@unsigned o@ = offset in bits
 *
 * Returns:	---
 *
 * Use:		Computes %$d + 2^o a$%.  If the result overflows then
 *		high-order bits are discarded, as usual.  We must have
 *		@0 < o < MPW_BITS@.
 */

void mpx_usubnlsl(mpw *dv, mpw *dvl, mpw a, unsigned o)
{
  mpw b = a >> (MPW_BITS - o);
  a <<= o;

  if (dv < dvl) {
    mpd x = (mpd)*dv - MPW(a);
    *dv++ = MPW(x);
    if (x >> MPW_BITS)
      b++;
    MPX_USUBN(dv, dvl, b);
  }
}

/* --- @mpx_umul@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = multiplicand vector base and limit
 *		@const mpw *bv, *bvl@ = multiplier vector base and limit
 *
 * Returns:	---
 *
 * Use:		Performs unsigned integer multiplication.  If the result
 *		overflows the desination vector, high-order bits are
 *		discarded.  The result vector may not overlap the argument
 *		vectors in any way.
 */

void mpx_umul(mpw *dv, mpw *dvl, const mpw *av, const mpw *avl,
	      const mpw *bv, const mpw *bvl)
{
  /* --- This is probably worthwhile on a multiply --- */

  MPX_SHRINK(av, avl);
  MPX_SHRINK(bv, bvl);

  /* --- Deal with a multiply by zero --- */

  if (bv == bvl) {
    MPX_ZERO(dv, dvl);
    return;
  }

  /* --- Do the initial multiply and initialize the accumulator --- */

  MPX_UMULN(dv, dvl, av, avl, *bv++);

  /* --- Do the remaining multiply/accumulates --- */

  while (dv < dvl && bv < bvl) {
    mpw m = *bv++;
    mpw c = 0;
    const mpw *avv = av;
    mpw *dvv = ++dv;

    while (avv < avl) {
      mpd x;
      if (dvv >= dvl)
	goto next;
      x = (mpd)*dvv + (mpd)m * (mpd)*avv++ + c;
      *dvv++ = MPW(x);
      c = x >> MPW_BITS;
    }
    MPX_UADDN(dvv, dvl, c);
  next:;
  }
}

/* --- @mpx_umuln@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *avl@ = multiplicand vector base and limit
 *		@mpw m@ = multiplier
 *
 * Returns:	---
 *
 * Use:		Multiplies a multiprecision integer by a single-word value.
 *		The destination and source may be equal.  The destination
 *		is completely cleared after use.
 */

void mpx_umuln(mpw *dv, mpw *dvl, const mpw *av, const mpw *avl, mpw m)
  { MPX_UMULN(dv, dvl, av, avl, m); }

/* --- @mpx_umlan@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination/accumulator base and limit
 *		@const mpw *av, *avl@ = multiplicand vector base and limit
 *		@mpw m@ = multiplier
 *
 * Returns:	---
 *
 * Use:		Multiplies a multiprecision integer by a single-word value
 *		and adds the result to an accumulator.
 */

void mpx_umlan(mpw *dv, mpw *dvl, const mpw *av, const mpw *avl, mpw m)
  { MPX_UMLAN(dv, dvl, av, avl, m); }

/* --- @mpx_usqr@ --- *
 *
 * Arguments:	@mpw *dv, *dvl@ = destination vector base and limit
 *		@const mpw *av, *av@ = source vector base and limit
 *
 * Returns:	---
 *
 * Use:		Performs unsigned integer squaring.  The result vector must
 *		not overlap the source vector in any way.
 */

void mpx_usqr(mpw *dv, mpw *dvl, const mpw *av, const mpw *avl)
{
  MPX_ZERO(dv, dvl);

  /* --- Main loop --- */

  while (av < avl) {
    const mpw *avv = av;
    mpw *dvv = dv;
    mpw a = *av;
    mpd c;

    /* --- Stop if I've run out of destination --- */

    if (dvv >= dvl)
      break;

    /* --- Work out the square at this point in the proceedings --- */

    {
      mpd x = (mpd)a * (mpd)a + *dvv;
      *dvv++ = MPW(x);
      c = MPW(x >> MPW_BITS);
    }

    /* --- Now fix up the rest of the vector upwards --- */

    avv++;
    while (dvv < dvl && avv < avl) {
      mpd x = (mpd)a * (mpd)*avv++;
      mpd y = ((x << 1) & MPW_MAX) + c + *dvv;
      c = (x >> (MPW_BITS - 1)) + (y >> MPW_BITS);
      *dvv++ = MPW(y);
    }
    while (dvv < dvl && c) {
      mpd x = c + *dvv;
      *dvv++ = MPW(x);
      c = x >> MPW_BITS;
    }

    /* --- Get ready for the next round --- */

    av++;
    dv += 2;
  }
}

/* --- @mpx_udiv@ --- *
 *
 * Arguments:	@mpw *qv, *qvl@ = quotient vector base and limit
 *		@mpw *rv, *rvl@ = dividend/remainder vector base and limit
 *		@const mpw *dv, *dvl@ = divisor vector base and limit
 *		@mpw *sv, *svl@ = scratch workspace
 *
 * Returns:	---
 *
 * Use:		Performs unsigned integer division.  If the result overflows
 *		the quotient vector, high-order bits are discarded.  (Clearly
 *		the remainder vector can't overflow.)  The various vectors
 *		may not overlap in any way.  Yes, I know it's a bit odd
 *		requiring the dividend to be in the result position but it
 *		does make some sense really.  The remainder must have
 *		headroom for at least two extra words.  The scratch space
 *		must be at least one word larger than the divisor.
 */

void mpx_udiv(mpw *qv, mpw *qvl, mpw *rv, mpw *rvl,
	      const mpw *dv, const mpw *dvl,
	      mpw *sv, mpw *svl)
{
  unsigned norm = 0;
  size_t scale;
  mpw d, dd;

  /* --- Initialize the quotient --- */

  MPX_ZERO(qv, qvl);

  /* --- Perform some sanity checks --- */

  MPX_SHRINK(dv, dvl);
  assert(((void)"division by zero in mpx_udiv", dv < dvl));

  /* --- Normalize the divisor --- *
   *
   * The algorithm requires that the divisor be at least two digits long.
   * This is easy to fix.
   */

  {
    unsigned b;

    d = dvl[-1];
    for (b = MPW_P2; b; b >>= 1) {
      if (d <= (MPW_MAX >> b)) {
	d <<= b;
	norm += b;
      }
    }
    if (dv + 1 == dvl)
      norm += MPW_BITS;
  }

  /* --- Normalize the dividend/remainder to match --- */

  if (norm) {
    mpx_lsl(rv, rvl, rv, rvl, norm);
    mpx_lsl(sv, svl, dv, dvl, norm);
    dv = sv;
    dvl = svl;
    MPX_SHRINK(dv, dvl);
  }

  MPX_SHRINK(rv, rvl);
  d = dvl[-1];
  dd = dvl[-2];

  /* --- Work out the relative scales --- */

  {
    size_t rvn = rvl - rv;
    size_t dvn = dvl - dv;

    /* --- If the divisor is clearly larger, notice this --- */

    if (dvn > rvn) {
      mpx_lsr(rv, rvl, rv, rvl, norm);
      return;
    }

    scale = rvn - dvn;
  }

  /* --- Calculate the most significant quotient digit --- *
   *
   * Because the divisor has its top bit set, this can only happen once.  The
   * pointer arithmetic is a little contorted, to make sure that the
   * behaviour is defined.
   */

  if (MPX_UCMP(rv + scale, rvl, >=, dv, dvl)) {
    mpx_usub(rv + scale, rvl, rv + scale, rvl, dv, dvl);
    if (qvl - qv > scale)
      qv[scale] = 1;
  }

  /* --- Now for the main loop --- */

  {
    mpw *rvv = rvl - 2;

    while (scale) {
      mpw q;
      mpd rh;

      /* --- Get an estimate for the next quotient digit --- */

      mpw r = rvv[1];
      mpw rr = rvv[0];
      mpw rrr = *--rvv;

      scale--;
      rh = ((mpd)r << MPW_BITS) | rr;
      if (r == d)
	q = MPW_MAX;
      else
	q = MPW(rh / d);

      /* --- Refine the estimate --- */

      {
	mpd yh = (mpd)d * q;
	mpd yy = (mpd)dd * q;
	mpw yl;

	if (yy > MPW_MAX)
	  yh += yy >> MPW_BITS;
	yl = MPW(yy);

	while (yh > rh || (yh == rh && yl > rrr)) {
	  q--;
	  yh -= d;
	  if (yl < dd)
	    yh--;
	  yl = MPW(yl - dd);
	}
      }

      /* --- Remove a chunk from the dividend --- */

      {
	mpw *svv;
	const mpw *dvv;
	mpw mc = 0, sc = 0;

	/* --- Calculate the size of the chunk --- *
	 *
	 * This does the whole job of calculating @r >> scale - qd@.
	 */

	for (svv = rv + scale, dvv = dv;
	     dvv < dvl && svv < rvl;
	     svv++, dvv++) {
	  mpd x = (mpd)*dvv * (mpd)q + mc;
	  mc = x >> MPW_BITS;
	  x = (mpd)*svv - MPW(x) - sc;
	  *svv = MPW(x);
	  if (x >> MPW_BITS)
	    sc = 1;
	  else
	    sc = 0;
	}

	if (svv < rvl) {
	  mpd x = (mpd)*svv - mc - sc;
	  *svv++ = MPW(x);
	  if (x >> MPW_BITS)
	    sc = MPW_MAX;
	  else
	    sc = 0;
	  while (svv < rvl)
	    *svv++ = sc;
	}

	/* --- Fix if the quotient was too large --- *
	 *
	 * This doesn't seem to happen very often.
	 */

	if (rvl[-1] > MPW_MAX / 2) {
	  mpx_uadd(rv + scale, rvl, rv + scale, rvl, dv, dvl);
	  q--;
	}
      }

      /* --- Done for another iteration --- */

      if (qvl - qv > scale)
	qv[scale] = q;
      r = rr;
      rr = rrr;
    }
  }

  /* --- Now fiddle with unnormalizing and things --- */

  mpx_lsr(rv, rvl, rv, rvl, norm);
}

/* --- @mpx_udivn@ --- *
 *
 * Arguments:	@mpw *qv, *qvl@ = storage for the quotient (may overlap
 *			dividend)
 *		@const mpw *rv, *rvl@ = dividend
 *		@mpw d@ = single-precision divisor
 *
 * Returns:	Remainder after divison.
 *
 * Use:		Performs a single-precision division operation.
 */

mpw mpx_udivn(mpw *qv, mpw *qvl, const mpw *rv, const mpw *rvl, mpw d)
{
  size_t i;
  size_t ql = qvl - qv;
  mpd r = 0;

  i = rvl - rv;
  while (i > 0) {
    i--;
    r = (r << MPW_BITS) | rv[i];
    if (i < ql)
      qv[i] = r / d;
    r %= d;
  }
  return (MPW(r));
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#include <mLib/alloc.h>
#include <mLib/dstr.h>
#include <mLib/quis.h>
#include <mLib/testrig.h>

#include "mpscan.h"

#define ALLOC(v, vl, sz) do {						\
  size_t _sz = (sz);							\
  mpw *_vv = xmalloc(MPWS(_sz));					\
  mpw *_vvl = _vv + _sz;						\
  (v) = _vv;								\
  (vl) = _vvl;								\
} while (0)

#define LOAD(v, vl, d) do {						\
  const dstr *_d = (d);							\
  mpw *_v, *_vl;							\
  ALLOC(_v, _vl, MPW_RQ(_d->len));					\
  mpx_loadb(_v, _vl, _d->buf, _d->len);					\
  (v) = _v;								\
  (vl) = _vl;								\
} while (0)

#define MAX(x, y) ((x) > (y) ? (x) : (y))

static void dumpbits(const char *msg, const void *pp, size_t sz)
{
  const octet *p = pp;
  fputs(msg, stderr);
  for (; sz; sz--)
    fprintf(stderr, " %02x", *p++);
  fputc('\n', stderr);
}

static void dumpmp(const char *msg, const mpw *v, const mpw *vl)
{
  fputs(msg, stderr);
  MPX_SHRINK(v, vl);
  while (v < vl)
    fprintf(stderr, " %08lx", (unsigned long)*--vl);
  fputc('\n', stderr);
}

static int chkscan(const mpw *v, const mpw *vl,
		   const void *pp, size_t sz, int step)
{
  mpscan mps;
  const octet *p = pp;
  unsigned bit = 0;
  int ok = 1;

  mpscan_initx(&mps, v, vl);
  while (sz) {
    unsigned x = *p;
    int i;
    p += step;
    for (i = 0; i < 8 && MPSCAN_STEP(&mps); i++) {
      if (MPSCAN_BIT(&mps) != (x & 1)) {
	fprintf(stderr,
		"\n*** error, step %i, bit %u, expected %u, found %u\n",
		step, bit, x & 1, MPSCAN_BIT(&mps));
	ok = 0;
      }
      x >>= 1;
      bit++;
    }
    sz--;
  }

  return (ok);
}

static int loadstore(dstr *v)
{
  dstr d = DSTR_INIT;
  size_t sz = MPW_RQ(v->len) * 2, diff;
  mpw *m, *ml;
  int ok = 1;

  dstr_ensure(&d, v->len);
  m = xmalloc(MPWS(sz));

  for (diff = 0; diff < sz; diff += 5) {
    size_t oct;

    ml = m + sz - diff;

    mpx_loadl(m, ml, v->buf, v->len);
    if (!chkscan(m, ml, v->buf, v->len, +1))
      ok = 0;
    MPX_OCTETS(oct, m, ml);
    mpx_storel(m, ml, d.buf, d.sz);
    if (memcmp(d.buf, v->buf, oct) != 0) {
      dumpbits("\n*** storel failed", d.buf, d.sz);
      ok = 0;
    }

    mpx_loadb(m, ml, v->buf, v->len);
    if (!chkscan(m, ml, v->buf + v->len - 1, v->len, -1))
      ok = 0;
    MPX_OCTETS(oct, m, ml);
    mpx_storeb(m, ml, d.buf, d.sz);
    if (memcmp(d.buf + d.sz - oct, v->buf + v->len - oct, oct) != 0) {
      dumpbits("\n*** storeb failed", d.buf, d.sz);
      ok = 0;
    }
  }

  if (!ok)
    dumpbits("input data", v->buf, v->len);

  xfree(m);
  dstr_destroy(&d);
  return (ok);
}

static int twocl(dstr *v)
{
  dstr d = DSTR_INIT;
  mpw *m, *ml;
  size_t sz;
  int ok = 1;

  sz = v[0].len; if (v[1].len > sz) sz = v[1].len;
  dstr_ensure(&d, sz);

  sz = MPW_RQ(sz);
  m = xmalloc(MPWS(sz));
  ml = m + sz;

  mpx_loadl(m, ml, v[0].buf, v[0].len);
  mpx_storel2cn(m, ml, d.buf, v[1].len);
  if (memcmp(d.buf, v[1].buf, v[1].len)) {
    dumpbits("\n*** storel2cn failed", d.buf, v[1].len);
    ok = 0;
  }

  mpx_loadl2cn(m, ml, v[1].buf, v[1].len);
  mpx_storel(m, ml, d.buf, v[0].len);
  if (memcmp(d.buf, v[0].buf, v[0].len)) {
    dumpbits("\n*** loadl2cn failed", d.buf, v[0].len);
    ok = 0;
  }

  if (!ok) {
    dumpbits("pos", v[0].buf, v[0].len);
    dumpbits("neg", v[1].buf, v[1].len);
  }

  xfree(m);
  dstr_destroy(&d);

  return (ok);
}

static int twocb(dstr *v)
{
  dstr d = DSTR_INIT;
  mpw *m, *ml;
  size_t sz;
  int ok = 1;

  sz = v[0].len; if (v[1].len > sz) sz = v[1].len;
  dstr_ensure(&d, sz);

  sz = MPW_RQ(sz);
  m = xmalloc(MPWS(sz));
  ml = m + sz;

  mpx_loadb(m, ml, v[0].buf, v[0].len);
  mpx_storeb2cn(m, ml, d.buf, v[1].len);
  if (memcmp(d.buf, v[1].buf, v[1].len)) {
    dumpbits("\n*** storeb2cn failed", d.buf, v[1].len);
    ok = 0;
  }

  mpx_loadb2cn(m, ml, v[1].buf, v[1].len);
  mpx_storeb(m, ml, d.buf, v[0].len);
  if (memcmp(d.buf, v[0].buf, v[0].len)) {
    dumpbits("\n*** loadb2cn failed", d.buf, v[0].len);
    ok = 0;
  }

  if (!ok) {
    dumpbits("pos", v[0].buf, v[0].len);
    dumpbits("neg", v[1].buf, v[1].len);
  }

  xfree(m);
  dstr_destroy(&d);

  return (ok);
}

static int lsl(dstr *v)
{
  mpw *a, *al;
  int n = *(int *)v[1].buf;
  mpw *c, *cl;
  mpw *d, *dl;
  int ok = 1;

  LOAD(a, al, &v[0]);
  LOAD(c, cl, &v[2]);
  ALLOC(d, dl, al - a + (n + MPW_BITS - 1) / MPW_BITS);

  mpx_lsl(d, dl, a, al, n);
  if (!mpx_ueq(d, dl, c, cl)) {
    fprintf(stderr, "\n*** lsl(%i) failed\n", n);
    dumpmp("	   a", a, al);
    dumpmp("expected", c, cl);
    dumpmp("  result", d, dl);
    ok = 0;
  }

  xfree(a); xfree(c); xfree(d);
  return (ok);
}

static int lslc(dstr *v)
{
  mpw *a, *al;
  int n = *(int *)v[1].buf;
  mpw *c, *cl;
  mpw *d, *dl;
  int ok = 1;

  LOAD(a, al, &v[0]);
  LOAD(c, cl, &v[2]);
  ALLOC(d, dl, al - a + (n + MPW_BITS - 1) / MPW_BITS);

  mpx_lslc(d, dl, a, al, n);
  if (!mpx_ueq(d, dl, c, cl)) {
    fprintf(stderr, "\n*** lslc(%i) failed\n", n);
    dumpmp("	   a", a, al);
    dumpmp("expected", c, cl);
    dumpmp("  result", d, dl);
    ok = 0;
  }

  xfree(a); xfree(c); xfree(d);
  return (ok);
}

static int lsr(dstr *v)
{
  mpw *a, *al;
  int n = *(int *)v[1].buf;
  mpw *c, *cl;
  mpw *d, *dl;
  int ok = 1;

  LOAD(a, al, &v[0]);
  LOAD(c, cl, &v[2]);
  ALLOC(d, dl, al - a + (n + MPW_BITS - 1) / MPW_BITS + 1);

  mpx_lsr(d, dl, a, al, n);
  if (!mpx_ueq(d, dl, c, cl)) {
    fprintf(stderr, "\n*** lsr(%i) failed\n", n);
    dumpmp("	   a", a, al);
    dumpmp("expected", c, cl);
    dumpmp("  result", d, dl);
    ok = 0;
  }

  xfree(a); xfree(c); xfree(d);
  return (ok);
}

static int uadd(dstr *v)
{
  mpw *a, *al;
  mpw *b, *bl;
  mpw *c, *cl;
  mpw *d, *dl;
  int ok = 1;

  LOAD(a, al, &v[0]);
  LOAD(b, bl, &v[1]);
  LOAD(c, cl, &v[2]);
  ALLOC(d, dl, MAX(al - a, bl - b) + 1);

  mpx_uadd(d, dl, a, al, b, bl);
  if (!mpx_ueq(d, dl, c, cl)) {
    fprintf(stderr, "\n*** uadd failed\n");
    dumpmp("	   a", a, al);
    dumpmp("	   b", b, bl);
    dumpmp("expected", c, cl);
    dumpmp("  result", d, dl);
    ok = 0;
  }

  xfree(a); xfree(b); xfree(c); xfree(d);
  return (ok);
}

static int usub(dstr *v)
{
  mpw *a, *al;
  mpw *b, *bl;
  mpw *c, *cl;
  mpw *d, *dl;
  int ok = 1;

  LOAD(a, al, &v[0]);
  LOAD(b, bl, &v[1]);
  LOAD(c, cl, &v[2]);
  ALLOC(d, dl, al - a);

  mpx_usub(d, dl, a, al, b, bl);
  if (!mpx_ueq(d, dl, c, cl)) {
    fprintf(stderr, "\n*** usub failed\n");
    dumpmp("	   a", a, al);
    dumpmp("	   b", b, bl);
    dumpmp("expected", c, cl);
    dumpmp("  result", d, dl);
    ok = 0;
  }

  xfree(a); xfree(b); xfree(c); xfree(d);
  return (ok);
}

static int umul(dstr *v)
{
  mpw *a, *al;
  mpw *b, *bl;
  mpw *c, *cl;
  mpw *d, *dl;
  int ok = 1;

  LOAD(a, al, &v[0]);
  LOAD(b, bl, &v[1]);
  LOAD(c, cl, &v[2]);
  ALLOC(d, dl, (al - a) + (bl - b));

  mpx_umul(d, dl, a, al, b, bl);
  if (!mpx_ueq(d, dl, c, cl)) {
    fprintf(stderr, "\n*** umul failed\n");
    dumpmp("	   a", a, al);
    dumpmp("	   b", b, bl);
    dumpmp("expected", c, cl);
    dumpmp("  result", d, dl);
    ok = 0;
  }

  xfree(a); xfree(b); xfree(c); xfree(d);
  return (ok);
}

static int usqr(dstr *v)
{
  mpw *a, *al;
  mpw *c, *cl;
  mpw *d, *dl;
  int ok = 1;

  LOAD(a, al, &v[0]);
  LOAD(c, cl, &v[1]);
  ALLOC(d, dl, 2 * (al - a));

  mpx_usqr(d, dl, a, al);
  if (!mpx_ueq(d, dl, c, cl)) {
    fprintf(stderr, "\n*** usqr failed\n");
    dumpmp("	   a", a, al);
    dumpmp("expected", c, cl);
    dumpmp("  result", d, dl);
    ok = 0;
  }

  xfree(a); xfree(c); xfree(d);
  return (ok);
}

static int udiv(dstr *v)
{
  mpw *a, *al;
  mpw *b, *bl;
  mpw *q, *ql;
  mpw *r, *rl;
  mpw *qq, *qql;
  mpw *s, *sl;
  int ok = 1;

  ALLOC(a, al, MPW_RQ(v[0].len) + 2); mpx_loadb(a, al, v[0].buf, v[0].len);
  LOAD(b, bl, &v[1]);
  LOAD(q, ql, &v[2]);
  LOAD(r, rl, &v[3]);
  ALLOC(qq, qql, al - a);
  ALLOC(s, sl, (bl - b) + 1);

  mpx_udiv(qq, qql, a, al, b, bl, s, sl);
  if (!mpx_ueq(qq, qql, q, ql) ||
      !mpx_ueq(a, al, r, rl)) {
    fprintf(stderr, "\n*** udiv failed\n");
    dumpmp(" divisor", b, bl);
    dumpmp("expect r", r, rl);
    dumpmp("result r", a, al);
    dumpmp("expect q", q, ql);
    dumpmp("result q", qq, qql);
    ok = 0;
  }

  xfree(a); xfree(b); xfree(r); xfree(q); xfree(s); xfree(qq);
  return (ok);
}

static test_chunk defs[] = {
  { "load-store", loadstore, { &type_hex, 0 } },
  { "2cl", twocl, { &type_hex, &type_hex, } },
  { "2cb", twocb, { &type_hex, &type_hex, } },
  { "lsl", lsl, { &type_hex, &type_int, &type_hex, 0 } },
  { "lslc", lslc, { &type_hex, &type_int, &type_hex, 0 } },
  { "lsr", lsr, { &type_hex, &type_int, &type_hex, 0 } },
  { "uadd", uadd, { &type_hex, &type_hex, &type_hex, 0 } },
  { "usub", usub, { &type_hex, &type_hex, &type_hex, 0 } },
  { "umul", umul, { &type_hex, &type_hex, &type_hex, 0 } },
  { "usqr", usqr, { &type_hex, &type_hex, 0 } },
  { "udiv", udiv, { &type_hex, &type_hex, &type_hex, &type_hex, 0 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  test_run(argc, argv, defs, SRCDIR"/t/mpx");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
