/* -*-c-*-
 *
 * Dynamic string I/O for group elements
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "group.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @group_readdstr@ --- *
 *
 * Arguments:	@group *g@ = an abstract group
 *		@ge *d@ = destination group element
 *		@dstr *dd@ = string to read from
 *		@size_t *off@ = offset to start at (updated)
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Parses a group element from a dynamic string.
 */

int group_readdstr(group *g, ge *d, dstr *dd, size_t *off)
{
  mptext_dstrctx md;

  md.d = dd;
  md.i = off ? *off : 0;
  if (G_READ(g, d, &mptext_dstrops, &md))
    return (-1);
  if (off) *off = md.i;
  return (0);
}

/* --- @group_writedstr@ --- *
 *
 * Arguments:	@group *g@ = an abstract group
 *		@ge *x@ = a group element
 *		@dstr *d@ = string to write to
 *		@size_t sz@ = how long the buffer is
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Writes a group element to a dstr buffer.
 */

int group_writedstr(group *g, ge *x, dstr *d)
{
  mptext_dstrctx md;

  md.d = d;
  if (G_WRITE(g, x, &mptext_dstrops, &md))
    return (-1);
  DPUTZ(d);
  return (0);
}



/*----- That's all, folks -------------------------------------------------*/
