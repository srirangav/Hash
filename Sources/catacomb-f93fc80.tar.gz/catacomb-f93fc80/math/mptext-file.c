/* -*-c-*-
 *
 * Reading and writing large integers on files
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>

#include "mptext.h"

/*----- Main code ---------------------------------------------------------*/

/* --- Operations table --- */

static int get(void *p) { FILE *fp = p; return getc(fp); }

static void unget(int ch, void *p) { FILE *fp = p; ungetc(ch, fp); }

static int put(const char *s, size_t sz, void *p)
{
  FILE *fp = p;
  return (fwrite(s, 1, sz, fp) != sz);
}

const mptext_ops mptext_fileops = { get, unget, put };

/* --- Convenience functions --- */

mp *mp_readfile(mp *m, FILE *fp, int radix)
{
  return mp_read(m, radix, &mptext_fileops, fp);
}

int mp_writefile(mp *m, FILE *fp, int radix)
{
  return mp_write(m, radix, &mptext_fileops, fp);
}

/*----- That's all, folks -------------------------------------------------*/
