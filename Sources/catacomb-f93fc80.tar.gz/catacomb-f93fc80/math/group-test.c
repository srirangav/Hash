/* -*-c-*-
 *
 * Testing group operations
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdarg.h>

#include <mLib/testrig.h>

#include "group.h"
#include "fibrand.h"
#include "ec.h"
#include "ec-test.h"

/*----- Main code ---------------------------------------------------------*/

static group *getgroup(const char *p) {
  group *g; qd_parse qd;
  qd.p = p; qd.e = 0; g = group_parse(&qd);
  if (g && !qd_eofp(&qd)) { G_DESTROYGROUP(g); g = 0; qd.e = "junk at eof"; }
  if (!g) {
    fprintf(stderr, "bad group string `%.*s|%s': %s\n",
	    (int)(qd.p - p), p, qd.p, qd.e);
    exit(1);
  }
  return (g);
}

static ge *getge(group *g, const char *p) {
  ge *x = G_CREATE(g);
  if (group_readstring(g, x, p, 0)) {
    fprintf(stderr, "bad group element `%s'\n", p);
    exit(1);
  }
  return (x);
}

static void show(group *g, const char *p, ge *x) {
  fprintf(stderr, "*** %s = ", p); group_writefile(g, x, stderr);
  putc('\n', stderr);
}

static void showec(const char *p, ec *q) {
  fprintf(stderr, "*** %s = ", p);
  if (EC_ATINF(q)) fprintf(stderr, "inf\n");
  else {
    mp_writefile(q->x, stderr, 16); fputs(", ", stderr);
    mp_writefile(q->x, stderr, 16); putchar('\n');
  }
}

static void showmp(const char *p, mp *x, int r) {
  fprintf(stderr, "*** %s = ", p); mp_writefile(x, stderr, r);
  putc('\n', stderr);
}

static int EXECL_LIKE(0)
  check(const char *op, const char *gd, group *g, ge *r, ge *c, ...)
{
  va_list ap;

  if (G_EQ(g, r, c)) return (1);
  fprintf(stderr, "\n*** %s failed\n", op);
  fprintf(stderr, "*** group: %s\n", gd);
  va_start(ap, c);
  for (;;) {
    const char *p; ge *x;
    p = va_arg(ap, const char *); if (!p) break;
    x = va_arg(ap, ge *); show(g, p, x);
  }
  show(g, "expected", r);
  show(g, "computed", c);
  return (0);
}

/*----- Actual tests ------------------------------------------------------*/

static int vcheck(dstr *v)
{
  group *g = getgroup(v[0].buf);
  grand *gr = fibrand_create(0);
  const char *e = G_CHECK(g, gr);
  int ok = 1;
  gr->ops->destroy(gr);
  if (!e) e = "ok";
  G_DESTROYGROUP(g);
  if (strcmp(e, v[1].buf)) {
    ok = 0;
    fprintf(stderr, "*** check failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    fprintf(stderr, "*** expected: %s\n", v[1].buf);
    fprintf(stderr, "*** returned: %s\n", e);
  }
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vcheckelt(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  int ir = *(int *)v[2].buf;
  int ic = group_check(g, x);
  int ok = 1;
  if (ir != ic) {
    ok = 0;
    fprintf(stderr, "*** check failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    show(g, "x", x);
    fprintf(stderr, "*** expected %s\n", ir ? "failure" : "success");
  }
  G_DESTROY(g, x);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vmul(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  ge *y = getge(g, v[2].buf);
  ge *r = getge(g, v[3].buf);
  ge *c = G_CREATE(g);
  int ok = 1;
  G_MUL(g, c, x, y);
  ok &= check("mul", v[0].buf, g, r, c, "x", x, "y", y, (char *)0);
  G_DESTROY(g, x); G_DESTROY(g, y); G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vsqr(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  ge *r = getge(g, v[2].buf);
  ge *c = G_CREATE(g);
  int ok = 1;
  G_SQR(g, c, x);
  ok &= check("sqr", v[0].buf, g, r, c, "x", x, (char *)0);
  G_DESTROY(g, x); G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vinv(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  ge *r = getge(g, v[2].buf);
  ge *c = G_CREATE(g);
  int ok = 1;
  G_INV(g, c, x);
  ok &= check("inv", v[0].buf, g, r, c, "x", x, (char *)0);
  G_DESTROY(g, x); G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vdiv(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  ge *y = getge(g, v[2].buf);
  ge *r = getge(g, v[3].buf);
  ge *c = G_CREATE(g);
  int ok = 1;
  G_DIV(g, c, x, y);
  ok &= check("div", v[0].buf, g, r, c, "x", x, "y", y, (char *)0);
  group_stddiv(g, c, x, y);
  ok &= check("stddiv", v[0].buf, g, r, c, "x", x, "y", y, (char *)0);
  G_DESTROY(g, x); G_DESTROY(g, y); G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vexp(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  mp *n = *(mp **)v[2].buf;
  ge *r = getge(g, v[3].buf);
  ge *c = G_CREATE(g);
  int ok = 1;
  G_EXP(g, c, x, n);
  if (!G_EQ(g, r, c)) {
    ok = 0;
    fprintf(stderr, "\n*** exp failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    show(g, "x", x); showmp("n", n, 10);
    show(g, "expected", r); show(g, "computed", c);
  }
  group_stdexp(g, c, x, n);
  if (!G_EQ(g, r, c)) {
    ok = 0;
    fprintf(stderr, "\n*** stdexp failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    show(g, "x", x); showmp("n", n, 10);
    show(g, "expected", r); show(g, "computed", c);
  }
  G_DESTROY(g, x); MP_DROP(n); G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vmexp(size_t n, dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *c, *r;
  group_expfactor *f = xmalloc(n * sizeof(group_expfactor));
  int ok = 1;
  size_t i;
  for (i = 0; i < n; i++) {
    f[i].base = getge(g, v[1 + 2 * i].buf);
    f[i].exp = *(mp **)v[2 + 2 * i].buf;
  }
  r = getge(g, v[1 + 2 * n].buf);
  c = G_CREATE(g);
  G_MEXP(g, c, f, n);
  if (!G_EQ(g, r, c)) {
    ok = 0;
    fprintf(stderr, "\n*** mexp failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    for (i = 0; i < n; i++) {
      show(g, "base", f[i].base);
      showmp("exp", f[i].exp, 10);
    }
    show(g, "expected", r); show(g, "computed", c);
  }
  group_stdmexp(g, c, f, n);
  if (!G_EQ(g, r, c)) {
    ok = 0;
    fprintf(stderr, "\n*** stdmexp failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    for (i = 0; i < n; i++) {
      show(g, "base", f[i].base);
      showmp("exp", f[i].exp, 10);
    }
    show(g, "expected", r); show(g, "computed", c);
  }
  for (i = 0; i < n; i++) { G_DESTROY(g, f[i].base); MP_DROP(f[i].exp); }
  G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vmexp1(dstr *v) { return vmexp(1, v); }
static int vmexp2(dstr *v) { return vmexp(2, v); }
static int vmexp3(dstr *v) { return vmexp(3, v); }
static int vmexp4(dstr *v) { return vmexp(4, v); }

static int vtoint(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  int ir = *(int *)v[2].buf;
  mp *r = *(mp **)v[3].buf;
  mp *c;
  int ic;
  int ok = 1;
  c = G_TOINT(g, MP_NEW, x);
  ic = c ? 0 : -1;
  if (ir != ic || (!ic && !MP_EQ(r, c))) {
    ok = 0;
    fprintf(stderr, "\n*** toint failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    if (ir) fprintf(stderr, "*** expected failure\n");
    else { show(g, "x", x); showmp("expected", r, 16);
    showmp("computed", c, 16); }
  }
  G_DESTROY(g, x); mp_drop(r); mp_drop(c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vfromint(dstr *v)
{
  group *g = getgroup(v[0].buf);
  mp *x = *(mp **)v[1].buf;
  int ir = *(int *)v[2].buf;
  ge *r = getge(g, v[3].buf);
  int ic;
  ge *c = G_CREATE(g);
  int ok = 1;
  ic = G_FROMINT(g, c, x);
  if (ir != ic || (!ic && !G_EQ(g, r, c))) {
    ok = 0;
    fprintf(stderr, "\n*** fromint failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    showmp("x", x, 16); if (ir) fprintf(stderr, "*** should have failed\n");
    else { show(g, "expected", r); show(g, "computed", c); }
  }
  MP_DROP(x); G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vtoec(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  int ir = *(int *)v[2].buf;
  ec *r = (ec *)v[3].buf;
  int ic;
  ec c = EC_INIT;
  int ok = 1;
  ic = G_TOEC(g, &c, x);
  if (ir != ic || (!ic && !EC_EQ(r, &c))) {
    ok = 0;
    fprintf(stderr, "\n*** toec failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    show(g, "x", x);
    if (ir) fprintf(stderr, "*** should have failed\n");
    else { showec("expected", r); showec("computed", &c); }
  }
  G_DESTROY(g, x); EC_DESTROY(&c); EC_DESTROY(r);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vfromec(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ec *p = (ec *)v[1].buf;
  int ir = *(int *)v[2].buf;
  ge *r = getge(g, v[3].buf);
  int ic;
  ge *c = G_CREATE(g);
  int ok = 1;
  ic = G_FROMEC(g, c, p);
  if (ir != ic || (!ic && !G_EQ(g, r, c))) {
    ok = 0;
    fprintf(stderr, "\n*** fromec failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    showec("p", p); if (ir) fprintf(stderr, "*** should have failed\n");
    else { show(g, "expected", r); show(g, "computed", c); }
  }
  EC_DESTROY(p); G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vtobuf(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  int ir = *(int *)v[2].buf;
  dstr c = DSTR_INIT;
  int ic;
  buf b;
  int ok = 1;

  dstr_ensure(&c, v[3].len);
  buf_init(&b, c.buf, v[3].len);
  ic = G_TOBUF(g, &b, x);
  c.len = BLEN(&b);
  if (ic != ir || (!ic && (c.len != v[3].len ||
			   memcmp(c.buf, v[3].buf, c.len)))) {
    ok = 0;
    fprintf(stderr, "*** tobuf failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    show(g, "x", x);
    if (ir) fprintf(stderr, "*** expected failure\n");
    else {
      fprintf(stderr, "*** expected: "); type_hex.dump(&v[3], stderr);
      fprintf(stderr, "\n*** computed: "); type_hex.dump(&c, stderr);
      fputc('\n', stderr);
    }
  }
  G_DESTROY(g, x); dstr_destroy(&c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vfrombuf(dstr *v)
{
  group *g = getgroup(v[0].buf);
  int ir = *(int *)v[2].buf;
  ge *r = getge(g, v[3].buf);
  int ic;
  ge *c = G_CREATE(g);
  buf b;
  int ok = 1;

  buf_init(&b, v[1].buf, v[1].len);
  ic = G_FROMBUF(g, &b, c);
  if ((ic < 0) != (ir < 0) || (ir >= 0 &&
			       (ir != BLEN(&b) || !G_EQ(g, r, c)))) {
    ok = 0;
    fprintf(stderr, "*** frombuf failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    fprintf(stderr, "*** input string: "); type_hex.dump(&v[1], stderr);
    fputc('\n', stderr);
    if (ir < 0) fprintf(stderr, "*** expected failure\n");
    else {
      show(g, "expected", r); show(g, "computed", c);
      fprintf(stderr, "*** expected used = %d\n", ir);
      fprintf(stderr, "*** computed used = %lu\n", (unsigned long)BLEN(&b));
    }
  }
  G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vtoraw(dstr *v)
{
  group *g = getgroup(v[0].buf);
  ge *x = getge(g, v[1].buf);
  int ir = *(int *)v[2].buf;
  dstr c = DSTR_INIT;
  int ic;
  buf b;
  int ok = 1;

  dstr_ensure(&c, v[3].len);
  buf_init(&b, c.buf, v[3].len);
  ic = G_TORAW(g, &b, x);
  c.len = BLEN(&b);
  if (ic != ir || (!ic && (c.len != v[3].len ||
			   memcmp(c.buf, v[3].buf, c.len)))) {
    ok = 0;
    fprintf(stderr, "*** toraw failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    show(g, "x", x);
    if (ir) fprintf(stderr, "*** expected failure\n");
    else {
      fprintf(stderr, "*** expected: "); type_hex.dump(&v[3], stderr);
      fprintf(stderr, "\n*** computed: "); type_hex.dump(&c, stderr);
      fputc('\n', stderr);
    }
  }
  G_DESTROY(g, x); dstr_destroy(&c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int vfromraw(dstr *v)
{
  group *g = getgroup(v[0].buf);
  int ir = *(int *)v[2].buf;
  ge *r = getge(g, v[3].buf);
  int ic;
  ge *c = G_CREATE(g);
  buf b;
  int ok = 1;

  buf_init(&b, v[1].buf, v[1].len);
  ic = G_FROMRAW(g, &b, c);
  if ((ic < 0) != (ir < 0) || (ir >= 0 &&
			       (ir != BLEN(&b) || !G_EQ(g, r, c)))) {
    ok = 0;
    fprintf(stderr, "*** fromraw failed\n");
    fprintf(stderr, "*** group: %s\n", v[0].buf);
    fprintf(stderr, "*** input string: "); type_hex.dump(&v[1], stderr);
    fputc('\n', stderr);
    if (ir < 0) fprintf(stderr, "*** expected failure\n");
    else {
      show(g, "expected", r); show(g, "computed", c);
      fprintf(stderr, "*** expected used = %d\n", ir);
      fprintf(stderr, "*** computed used = %lu\n", (unsigned long)BLEN(&b));
    }
  }
  G_DESTROY(g, r); G_DESTROY(g, c);
  G_DESTROYGROUP(g);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static const test_chunk tests[] = {
  { "check",	vcheck,		{ &type_string, &type_string } },
  { "checkelt",	vcheckelt,	{ &type_string, &type_string, &type_int } },
  { "mul",	vmul,		{ &type_string, &type_string,
				  &type_string, &type_string } },
  { "sqr",	vsqr,		{ &type_string, &type_string,
				  &type_string } },
  { "inv",	vinv,		{ &type_string, &type_string,
				  &type_string } },
  { "div",	vdiv,		{ &type_string, &type_string,
				  &type_string, &type_string } },
  { "exp",	vexp,		{ &type_string, &type_string,
				  &type_mp, &type_string } },
  { "mexp-1",	vmexp1,		{ &type_string,
				  &type_string, &type_mp,
				  &type_string } },
  { "mexp-2",	vmexp2,		{ &type_string,
				  &type_string, &type_mp,
				  &type_string, &type_mp,
				  &type_string } },
  { "mexp-3",	vmexp3,		{ &type_string,
				  &type_string, &type_mp,
				  &type_string, &type_mp,
				  &type_string, &type_mp,
				  &type_string } },
  { "mexp-4",	vmexp4,		{ &type_string,
				  &type_string, &type_mp,
				  &type_string, &type_mp,
				  &type_string, &type_mp,
				  &type_string, &type_mp,
				  &type_string } },
  { "toint",	vtoint,		{ &type_string, &type_string,
				  &type_int, &type_mp } },
  { "fromint",	vfromint,	{ &type_string, &type_mp,
				  &type_int, &type_string } },
  { "toec",	vtoec,		{ &type_string, &type_string,
				  &type_int, &type_ec } },
  { "fromec",	vfromec,	{ &type_string, &type_ec,
				  &type_int, &type_string } },
  { "tobuf",	vtobuf,		{ &type_string, &type_string,
				  &type_int, &type_hex } },
  { "frombuf",	vfrombuf,	{ &type_string, &type_hex,
				  &type_int, &type_string } },
  { "toraw",	vtoraw,		{ &type_string, &type_string,
				  &type_int, &type_hex } },
  { "fromraw",	vfromraw,	{ &type_string, &type_hex,
				  &type_int, &type_string } },
  { 0 }
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/group");
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
