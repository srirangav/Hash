/* -*-c-*-
 *
 * Macros for Karatsuba functions
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_KARATSUBA_H
#define CATACOMB_KARATSUBA_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MPW_H
#  include "mpw.h"
#endif

/*----- Normal arithmetic macros ------------------------------------------*/

#define UADD(dv, av, avl) do {						\
  mpw *_dv = (dv);							\
  const mpw *_av = (av), *_avl = (avl);					\
  mpw _c = 0;								\
									\
  while (_av < _avl) {							\
    mpw _a, _b;								\
    mpd _x;								\
    _a = *_av++;							\
    _b = *_dv;								\
    _x = (mpd)_a + (mpd)_b + _c;					\
    *_dv++ = MPW(_x);							\
    _c = _x >> MPW_BITS;						\
  }									\
  while (_c) {								\
    mpd _x = (mpd)*_dv + (mpd)_c;					\
    *_dv++ = MPW(_x);							\
    _c = _x >> MPW_BITS;						\
  }									\
} while (0)

#define UADD2(dv, dvl, av, avl, bv, bvl) do {				\
  mpw *_dv = (dv), *_dvl = (dvl);					\
  const mpw *_av = (av), *_avl = (avl);					\
  const mpw *_bv = (bv), *_bvl = (bvl);					\
  mpw _c = 0;								\
									\
  while (_av < _avl || _bv < _bvl) {					\
    mpw _a, _b;								\
    mpd _x;								\
    _a = (_av < _avl) ? *_av++ : 0;					\
    _b = (_bv < _bvl) ? *_bv++ : 0;					\
    _x = (mpd)_a + (mpd)_b + _c;					\
    *_dv++ = MPW(_x);							\
    _c = _x >> MPW_BITS;						\
  }									\
  *_dv++ = _c;								\
  while (_dv < _dvl)							\
    *_dv++ = 0;								\
} while (0)

#define USUB(dv, av, avl) do {						\
  mpw *_dv = (dv);							\
  const mpw *_av = (av), *_avl = (avl);					\
  mpw _c = 0;								\
									\
  while (_av < _avl) {							\
    mpw _a, _b;								\
    mpd _x;								\
    _a = *_av++;							\
    _b = *_dv;								\
    _x = (mpd)_b - (mpd)_a - _c;					\
    *_dv++ = MPW(_x);							\
    if (_x >> MPW_BITS)							\
      _c = 1;								\
    else								\
      _c = 0;								\
  }									\
  while (_c) {								\
    mpd _x = (mpd)*_dv - (mpd)_c;					\
    *_dv++ = MPW(_x);							\
    if (_x >> MPW_BITS)							\
      _c = 1;								\
    else								\
      _c = 0;								\
  }									\
} while (0)

/*----- Binary polynomial arithmetic macros -------------------------------*/

#define UXOR(dv, av, avl) do {						\
  mpw *_dv = (dv);							\
  const mpw *_av = (av), *_avl = (avl);					\
									\
  while (_av < _avl)							\
    *_dv++ ^= *_av++;							\
} while (0)

#define UXOR2(dv, dvl, av, avl, bv, bvl) do {				\
  mpw *_dv = (dv), *_dvl = (dvl);					\
  const mpw *_av = (av), *_avl = (avl);					\
  const mpw *_bv = (bv), *_bvl = (bvl);					\
									\
  while (_av < _avl || _bv < _bvl) {					\
    mpw _a, _b;								\
    _a = (_av < _avl) ? *_av++ : 0;					\
    _b = (_bv < _bvl) ? *_bv++ : 0;					\
    *_dv++ = _a ^ _b;							\
  }									\
  while (_dv < _dvl)							\
    *_dv++ = 0;								\
} while (0)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
