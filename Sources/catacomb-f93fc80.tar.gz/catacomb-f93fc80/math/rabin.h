/* -*-c-*-
 *
 * Miller-Rabin primality test
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_RABIN_H
#define CATACOMB_RABIN_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

#ifndef CATACOMB_MPMONT_H
#  include "mpmont.h"
#endif

#ifndef CATACOMB_PFILT_H
#  include "pfilt.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct rabin {
  mpmont mm;				/* Montgomery arithmetic context */
  size_t s;				/* %$m = 2^s r + 1$% */
  mp *r;				/* %$m = 2^s r + 1$% */
  mp *m1;				/* %$(m - 1)R \bmod m$% */
} rabin;

/*----- Functions provided ------------------------------------------------*/

/* --- @rabin_create@ --- *
 *
 * Arguments:	@rabin *r@ = pointer to Rabin-Miller context
 *		@mp *m@ = pointer to number to test
 *
 * Returns:	Zero on success, nonzero for failure.
 *
 * Use:		Precomputes some useful values for performing the
 *		Miller-Rabin probabilistic primality test.
 */

extern int rabin_create(rabin */*r*/, mp */*m*/);

/* --- @rabin_destroy@ --- *
 *
 * Arguments:	@rabin *r@ = pointer to Rabin-Miller context
 *
 * Returns:	---
 *
 * Use:		Disposes of a Rabin-Miller context when it's no longer
 *		needed.
 */

extern void rabin_destroy(rabin */*r*/);

/* --- @rabin_test@, @rabin_rtest@ --- *
 *
 * Arguments:	@rabin *r@ = pointer to Rabin-Miller context
 *		@mp *g@ = base to test the number against
 *
 * Returns:	Either @PGEN_FAIL@ if the test failed, or @PGEN_PASS@
 *		if it succeeded.
 *
 * Use:		Performs a single iteration of the Rabin-Miller primality
 *		test.  The @rtest@ variant assumes that %$g$% is either
 *		already in Montgomery representation, or you don't care.
 */

extern int rabin_rtest(rabin */*r*/, mp */*g*/);
extern int rabin_test(rabin */*r*/, mp */*g*/);

/* --- @rabin_iters@ --- *
 *
 * Arguments:	@unsigned len@ = number of bits in value
 *
 * Returns:	Number of iterations recommended.
 *
 * Use:		Returns the recommended number of iterations to ensure that a
 *		number with @len@ bits is really prime.
 */

extern int rabin_iters(unsigned /*len*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
