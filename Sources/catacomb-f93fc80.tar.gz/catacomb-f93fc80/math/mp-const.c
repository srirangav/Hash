/* -*-c-*-
 *
 * Useful multiprecision constants
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"

/*----- Global variables --------------------------------------------------*/

static mpw mpw_const[] = { 1, 2, 3, 4, 5, 10, 256 };

mp mp_const[] = {
  { &mpw_const[0], &mpw_const[0], 0, 0, MP_CONST, 0 },
  { &mpw_const[0], &mpw_const[0] + 1, 1, 0, MP_CONST, 0 },
  { &mpw_const[1], &mpw_const[1] + 1, 1, 0, MP_CONST, 0 },
  { &mpw_const[2], &mpw_const[2] + 1, 1, 0, MP_CONST, 0 },
  { &mpw_const[3], &mpw_const[3] + 1, 1, 0, MP_CONST, 0 },
  { &mpw_const[4], &mpw_const[4] + 1, 1, 0, MP_CONST, 0 },
  { &mpw_const[5], &mpw_const[5] + 1, 1, 0, MP_CONST, 0 },
  { &mpw_const[6], &mpw_const[6] + 1, 1, 0, MP_CONST, 0 },
  { &mpw_const[0], &mpw_const[0] + 1, 1, 0, MP_CONST | MP_NEG, 0 },
  { 0, mpw_const, 1, 0, MP_CONST | MP_BURN, 0 },
};

/*----- That's all, folks -------------------------------------------------*/
