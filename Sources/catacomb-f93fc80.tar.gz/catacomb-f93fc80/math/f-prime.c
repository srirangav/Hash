/* -*-c-*-
 *
 * Prime fields with Montgomery arithmetic
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/sub.h>

#include "field.h"
#include "mprand.h"
#include "field-guts.h"

/*----- Main code ---------------------------------------------------------*/

/* --- Field operations --- */

static void fdestroy(field *ff) {
  fctx_prime *f = (fctx_prime *)ff;
  mpmont_destroy(&f->mm);
  DESTROY(f);
}

static mp *frand(field *ff, mp *d, grand *r) {
  fctx_prime *f = (fctx_prime *)ff;
  return (mprand_range(d, f->mm.m, r, 0));
}

static mp *fin(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff;
  mp_div(0, &d, x, f->mm.m);
  return (mpmont_mul(&f->mm, d, d, f->mm.r2));
}

static mp *fout(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff;
  return (mpmont_reduce(&f->mm, d, x));
}

static int fzerop(field *ff, mp *x) { return (MP_ZEROP(x)); }

static mp *fneg(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff;
  if (MP_ZEROP(x)) { if (d != x) mp_drop(d); return (MP_COPY(x)); }
  else return (mp_sub(d, f->mm.m, x));
}

static mp *fadd(field *ff, mp *d, mp *x, mp *y) {
  fctx_prime *f = (fctx_prime *)ff; d = mp_add(d, x, y);
  if (MP_NEGP(d)) d = mp_add(d, d, f->mm.m);
  else if (MP_CMP(d, >=, f->mm.m)) d = mp_sub(d, d, f->mm.m);
  return (d);
}

static mp *fsub(field *ff, mp *d, mp *x, mp *y) {
  fctx_prime *f = (fctx_prime *)ff; d = mp_sub(d, x, y);
  if (MP_NEGP(d)) d = mp_add(d, d, f->mm.m);
  else if (MP_CMP(d, >=, f->mm.m)) d = mp_sub(d, d, f->mm.m);
  return (d);
}

static mp *fmul(field *ff, mp *d, mp *x, mp *y) {
  fctx_prime *f = (fctx_prime *)ff;
  return (mpmont_mul(&f->mm, d, x, y));
}

static mp *fsqr(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff; d = mp_sqr(d, x);
  return (mpmont_reduce(&f->mm, d, d));
}

static mp *finv(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff; d = mpmont_reduce(&f->mm, d, x);
  d = mp_modinv(d, d, f->mm.m); return (mpmont_mul(&f->mm, d, d, f->mm.r2));
}

static mp *freduce(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff;
  mp_div(0, &d, x, f->mm.m);
  return (d);
}

static mp *fsqrt(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff; d = mpmont_reduce(&f->mm, d, x);
  d = mp_modsqrt(d, d, f->mm.m); if (!d) return (d);
  return (mpmont_mul(&f->mm, d, d, f->mm.r2));
}

static mp *fdbl(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff; d = mp_lsl(d, x, 1);
  if (MP_CMP(d, >=, f->mm.m)) d = mp_sub(d, d, f->mm.m);
  return (d);
}

static mp *ftpl(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff; MP_DEST(d, MP_LEN(x) + 1, x->f);
  MPX_UMULN(d->v, d->vl, x->v, x->vl, 3); d->f &= ~MP_UNDEF;
  while (MP_CMP(d, >=, f->mm.m)) d = mp_sub(d, d, f->mm.m);
  return (d);
}

static mp *fqdl(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff; d = mp_lsl(d, x, 2);
  while (MP_CMP(d, >=, f->mm.m)) d = mp_sub(d, d, f->mm.m);
  return (d);
}

static mp *fhlv(field *ff, mp *d, mp *x) {
  fctx_prime *f = (fctx_prime *)ff;
  if (MP_ZEROP(x)) { MP_COPY(x); MP_DROP(d); return (x); }
  if (x->v[0] & 1) { d = mp_add(d, x, f->mm.m); x = d; }
  return (mp_lsr(d, x, 1));
}

/* --- Field operations table --- */

static const field_ops fops = {
  FTY_PRIME, "prime",
  fdestroy, frand, field_stdsamep,
  fin, fout,
  fzerop, fneg, fadd, fsub, fmul, fsqr, finv, freduce, fsqrt,
  0,
  fdbl, ftpl, fqdl, fhlv
};

/* --- @field_prime@ --- *
 *
 * Arguments:	@mp *p@ = the characteristic of the field
 *
 * Returns:	A pointer to the field or null.
 *
 * Use:		Creates a field structure for a prime field of size %$p$%,
 *		using Montgomery reduction for arithmetic.
 */

field *field_prime(mp *p)
{
  fctx_prime *f;

  f = CREATE(fctx_prime);
  f->f.ops = &fops;
  if (mpmont_create(&f->mm, p)) {
    DESTROY(f);
    return (0);
  }
  f->f.zero = MP_ZERO;
  f->f.one = f->mm.r;
  f->f.m = f->mm.m;
  f->f.nbits = mp_bits(p);
  f->f.noctets = (f->f.nbits + 7) >> 3;
  f->f.q = f->mm.m;
  return (&f->f);
}

/*----- That's all, folks -------------------------------------------------*/
