/* -*-c-*-
 *
 * Generate prime number table
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/darray.h>
#include <mLib/dstr.h>
#include <mLib/mdwopt.h>
#include <mLib/quis.h>
#include <mLib/report.h>

/*----- Data structures ---------------------------------------------------*/

DA_DECL(intv, int);

/*----- Main code ---------------------------------------------------------*/

int main(int argc, char *argv[])
{
  int p_max = 0, p_n = 0;
  char *type = "unsigned int";
  char *header = "primetab.h";
  char *source = "primetab.c";
  char *name = "primetab";
  char *hdrbase;
  char *sym = 0;
  intv p = DA_INIT;
  int i;

  ego(argv[0]);

  for (;;) {
    int i = getopt(argc, argv, "h:c:i:n:m:t:s:");
    if (i < 0)
      break;
    switch (i) {
      case 'h':
	header = optarg;
	break;
      case 'c':
	source = optarg;
	break;
      case 'i':
	name = optarg;
	break;
      case 'n':
	p_max = 0;
	p_n = atoi(optarg);
	break;
      case 'm':
	p_n = 0;
	p_max = atoi(optarg);
	break;
      case 't':
	type = optarg;
	break;
      case 's':
	sym = optarg;
	break;
      default:
	pquis(stderr, "Usage: $ [-n nprimes] [-m maxprime] [-t type]\n");
	exit(EXIT_FAILURE);
    }
  }

  if (!p_max && !p_n)
    die(EXIT_FAILURE, "bad arguments to `-n' or `-m'");

  if ((hdrbase = strrchr(header, '/')) == 0) hdrbase = header;
  else hdrbase++;

  if (p_n || p_max >= 2)
    DA_PUSH(&p, 2);
  for (i = 3; (!p_max && !p_n) ||
	      (p_n && DA_LEN(&p) < p_n) ||
	      (p_max && i <= p_max);
       i += 2) {
    int j;
    for (j = 0; j < DA_LEN(&p); j++) {
      if (i % DA(&p)[j] == 0)
	goto composite;
    }
    DA_PUSH(&p, i);
  composite:;
  }

  {
    FILE *fp = fopen(header, "w");
    dstr d = DSTR_INIT;
    char *q;
    if (!fp)
      die(EXIT_FAILURE, "couldn't write `%s': %s", header, strerror(errno));
    if (!sym) {
      for (q = header; *q; q++) {
	int ch = (unsigned char)*q;
	if (isalnum(ch))
	  ch = toupper(ch);
	else
	  ch = '_';
	DPUTC(&d, ch);
      }
      DPUTZ(&d);
      sym = d.buf;
    }
    fprintf(fp, "\
/* -*-c-*-\n\
 *\n\
 * Table of small prime numbers [generated]\n\
 */\n\
\n\
#ifndef %s\n\
#define %s\n\
\n\
#define NPRIME %luu\n\
#define MAXPRIME %uu\n\
\n\
typedef %s smallprime;\n\
extern const smallprime %s[];\n\
\n\
#endif\n\
",
	    sym, sym,
	    (unsigned long)DA_LEN(&p),
	    DA_LAST(&p),
	    type, name);
    dstr_destroy(&d);
    if (fclose(fp) == EOF) {
      remove(header);
      die(EXIT_FAILURE, "error writing `%s': %s", header, strerror(errno));
    }
  }

  {
    FILE *fp = fopen(source, "w");
    int i;
    if (!fp)
      die(EXIT_FAILURE, "couldn't write `%s': %s", source, strerror(errno));
    fprintf(fp, "\
/* -*-c-*-\n\
 *\n\
 * Table of small prime numbers [generated]\n\
 */\n\
\n\
#include \"%s\"\n\
\n\
const %s %s[] = {",
	    hdrbase, type, name);
    for (i = 0; i < DA_LEN(&p); i++) {
      if (i % 8 == 0)
	fputs("\n  ", fp);
      fprintf(fp, "%5i, ", DA(&p)[i]);
    }
    fputs("\n\
};\n\
", fp);
    if (fclose(fp) == EOF) {
      remove(source);
      die(EXIT_FAILURE, "error writing `%s': %s", source, strerror(errno));
    }
  }

  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
