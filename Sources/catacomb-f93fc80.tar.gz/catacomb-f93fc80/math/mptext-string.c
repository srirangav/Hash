/* -*-c-*-
 *
 * Reading and writing large integers on strings
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <string.h>

#include "mptext.h"

/*----- Main code ---------------------------------------------------------*/

/* --- Operations table --- */

static int get(void *p)
{
  mptext_stringctx *c = p;
  if (c->buf >= c->lim)
    return (EOF);
  return ((unsigned char)*c->buf++);
}

static void unget(int ch, void *p)
{
  mptext_stringctx *c = p;
  if (ch != EOF)
    c->buf--;
}

static int put(const char *s, size_t sz, void *p)
{
  mptext_stringctx *c = p;
  int rc = 0;
  if (sz > c->lim - c->buf) {
    sz = c->lim - c->buf;
    rc = EOF;
  }
  if (sz) {
    memcpy(c->buf, s, sz);
    c->buf += sz;
  }
  return (rc);
}

const mptext_ops mptext_stringops = { get, unget, put };

/* --- Convenience functions --- */

mp *mp_readstring(mp *m, const char *p, char **end, int radix)
{
  mptext_stringctx c;
  c.buf = (/*unconst */ char *)p;
  c.lim = c.buf + strlen(p);
  m = mp_read(m, radix, &mptext_stringops, &c);
  if (end)
    *end = c.buf;
  return (m);
}

int mp_writestring(mp *m, char *p, size_t sz, int radix)
{
  mptext_stringctx c;
  int rc;
  if (!sz)
    return (0);
  c.buf = p;
  c.lim = p + sz - 1;
  rc = mp_write(m, radix, &mptext_stringops, &c);
  *c.buf = 0;
  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
