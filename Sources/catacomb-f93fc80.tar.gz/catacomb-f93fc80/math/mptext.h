/* -*-c-*-
 *
 * Textual representation of multiprecision numbers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPTEXT_H
#define CATACOMB_MPTEXT_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct mptext_ops {
  int (*get)(void */*p*/);
  void (*unget)(int /*ch*/, void */*p*/);
  int (*put)(const char */*s*/, size_t /*len*/, void */*p*/);
} mptext_ops;

/*----- Functions provided ------------------------------------------------*/

/* --- @mp_read@ --- *
 *
 * Arguments:	@mp *m@ = destination multiprecision number
 *		@int radix@ = base to assume for data (or zero to guess)
 *		@const mptext_ops *ops@ = pointer to operations block
 *		@void *p@ = data for the operations block
 *
 * Returns:	The integer read, or zero if it didn't work.
 *
 * Use:		Reads an integer from some source.  If the @radix@ is
 *		specified, the number is assumed to be given in that radix,
 *		with the letters `a' (either upper- or lower-case) upwards
 *		standing for digits greater than 9.  Otherwise, base 10 is
 *		assumed unless the number starts with `0' (octal), `0x' (hex)
 *		or `nnn_' (base `nnn').  An arbitrary amount of whitespace
 *		before the number is ignored.
 */

extern mp *mp_read(mp */*m*/, int /*radix*/,
		   const mptext_ops */*ops*/, void */*p*/);

/* --- @mp_write@ --- *
 *
 * Arguments:	@mp *m@ = pointer to a multi-precision integer
 *		@int radix@ = radix to use when writing the number out
 *		@const mptext_ops *ops@ = pointer to an operations block
 *		@void *p@ = data for the operations block
 *
 * Returns:	Zero if it worked, nonzero otherwise.
 *
 * Use:		Writes a large integer in textual form.
 */

extern int mp_write(mp */*m*/, int /*radix*/,
		    const mptext_ops */*ops*/, void */*p*/);

/* --- @mptext_len@ --- *
 *
 * Arguments:	@mp *x@ = number to work on
 *		@int r@ = radix the number will be expressed in
 *
 * Returns:	The number of digits needed to represent the number in the
 *		given base.  This will not include space for a leading sign
 *		(use @MP_NEGP@ to check that, or just add one on for luck);
 *		neither will it add space for a terminating null.  In general
 *		the answer will be an overestimate.
 */

extern size_t mptext_len(mp */*x*/, int /*r*/);

/*----- File I/O ----------------------------------------------------------*/

#include <stdio.h>

/* --- Operations table --- *
 *
 * The @mptext_fileops@ expect the pointer argument to be a @FILE *@.
 */

extern const mptext_ops mptext_fileops;

/* --- Convenience functions --- */

extern mp *mp_readfile(mp */*m*/, FILE */*fp*/, int /*radix*/);
extern int mp_writefile(mp */*m*/, FILE */*fp*/, int /*radix*/);

#define MP_DOFPRINTFR(fp, args, m, r) do {				\
  fprintf args;								\
  if (m)								\
    mp_writefile(m, fp, r);						\
  else									\
    fputs("<null>", fp);						\
  fputc('\n', fp);							\
} while (0)

#define MP_DOFPRINTR(fp, name, m, r)					\
  MP_DOFPRINTFR(fp, (fp, "%s = ", name), m, r)

#define MP_PRINT(name, m) MP_DOFPRINTR(stdout, name, m, 10)
#define MP_EPRINT(name, m) MP_DOFPRINTR(stderr, name, m, 10)
#define MP_PRINTX(name, m) MP_DOFPRINTR(stdout, name, m, 16)
#define MP_EPRINTX(name, m) MP_DOFPRINTR(stderr, name, m, 16)

#define MP_FPRINTF(fp, args, m) MP_DOFPRINTFR(fp, args, m, 10)
#define MP_FPRINTFX(fp, args, m) MP_DOFPRINTFR(fp, args, m, 16)

/*----- String I/O --------------------------------------------------------*/

/* --- Context format --- */

typedef struct mptext_stringctx {
  char *buf;
  char *lim;
} mptext_stringctx;

/* --- Operations table --- */

extern const mptext_ops mptext_stringops;

/* --- Convenience functions --- */

extern mp *mp_readstring(mp */*m*/, const char */*p*/, char **/*end*/,
			 int /*radix*/);
extern int mp_writestring(mp */*m*/, char */*p*/, size_t /*sz*/,
			  int /*radix*/);

/*----- Dynamic string I/O ------------------------------------------------*/

#include <mLib/dstr.h>

/* --- Context format --- */

typedef struct mptext_dstrctx {
  dstr *d;
  size_t i;
} mptext_dstrctx;

/* --- Operations table --- */

extern const mptext_ops mptext_dstrops;

/* --- Convenience functions --- */

extern mp *mp_readdstr(mp */*m*/, dstr */*d*/, size_t */*off*/,
		       int /*radix*/);
extern int mp_writedstr(mp */*m*/, dstr */*d*/, int /*radix*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
