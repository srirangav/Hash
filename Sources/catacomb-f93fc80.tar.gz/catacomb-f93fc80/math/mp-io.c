/* -*-c-*-
 *
 * Loading and storing of multiprecision integers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @mp_octets@ --- *
 *
 * Arguments:	@const mp *m@ = a multiprecision integer
 *
 * Returns:	The number of octets required to represent @m@.
 *
 * Use:		Calculates the external storage required for a multiprecision
 *		integer.
 */

size_t mp_octets(const mp *m)
{
  size_t sz;
  MPX_OCTETS(sz, m->v, m->vl);
  return (sz);
}

/* --- @mp_octets2c@ --- *
 *
 * Arguments:	@const mp *m@ = a multiprecision integer
 *
 * Returns:	The number of octets required to represent @m@.
 *
 * Use:		Calculates the external storage required for a multiprecision
 *		integer represented as two's complement.
 */

size_t mp_octets2c(const mp *m)
{
  size_t sz;
  MPX_OCTETS2C(sz, m->v, m->vl);
  return (sz);
}

/* --- @mp_bits@ --- *
 *
 * Arguments:	@const mp *m@ = a multiprecision integer
 *
 * Returns:	The number of bits required to represent @m@.
 *
 * Use:		Calculates the external storage required for a multiprecision
 *		integer.
 */

unsigned long mp_bits(const mp *m)
{
  unsigned long bits;
  MPX_BITS(bits, m->v, m->vl);
  return (bits);
}

/* --- @mp_loadl@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@const void *pv@ = pointer to source data
 *		@size_t sz@ = size of the source data
 *
 * Returns:	Resulting multiprecision number.
 *
 * Use:		Loads a multiprecision number from an array of octets.  The
 *		first byte in the array is the least significant.  More
 *		formally, if the bytes are %$b_0, b_1, \ldots, b_{n-1}$%
 *		then the result is %$N = \sum_{0 \le i < n} b_i 2^{8i}$%.
 */

mp *mp_loadl(mp *d, const void *pv, size_t sz)
{
  MP_DEST(d, MPW_RQ(sz), MP_UNDEF);
  mpx_loadl(d->v, d->vl, pv, sz);
  d->f &= ~(MP_UNDEF | MP_NEG);
  mp_shrink(d);
  return (d);
}

/* --- @mp_storel@ --- *
 *
 * Arguments:	@const mp *m@ = source
 *		@void *pv@ = pointer to output array
 *		@size_t sz@ = size of the output array
 *
 * Returns:	---
 *
 * Use:		Stores a multiprecision number in an array of octets.  The
 *		first byte in the array is the least significant.  If the
 *		array is too small to represent the number, high-order bits
 *		are truncated; if the array is too large, high order bytes
 *		are filled with zeros.  More formally, if the number is
 *		%$N = \sum{0 \le i} b_i 2^{8i}$% where %$0 \le b_i < 256$%,
 *		then the array is %$b_0, b_1, \ldots, b_{n-1}$%.
 */

void mp_storel(const mp *m, void *pv, size_t sz)
{
  mpx_storel(m->v, m->vl, pv, sz);
}

/* --- @mp_loadb@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@const void *pv@ = pointer to source data
 *		@size_t sz@ = size of the source data
 *
 * Returns:	Resulting multiprecision number.
 *
 * Use:		Loads a multiprecision number from an array of octets.  The
 *		last byte in the array is the least significant.  More
 *		formally, if the bytes are %$b_{n-1}, b_{n-2}, \ldots, b_0$%
 *		then the result is %$N = \sum_{0 \le i < n} b_i 2^{8i}$%.
 */

mp *mp_loadb(mp *d, const void *pv, size_t sz)
{
  MP_DEST(d, MPW_RQ(sz), MP_UNDEF);
  mpx_loadb(d->v, d->vl, pv, sz);
  d->f &= ~(MP_UNDEF | MP_NEG);
  mp_shrink(d);
  return (d);
}

/* --- @mp_storeb@ --- *
 *
 * Arguments:	@const mp *m@ = source
 *		@void *pv@ = pointer to output array
 *		@size_t sz@ = size of the output array
 *
 * Returns:	---
 *
 * Use:		Stores a multiprecision number in an array of octets.  The
 *		last byte in the array is the least significant.  If the
 *		array is too small to represent the number, high-order bits
 *		are truncated; if the array is too large, high order bytes
 *		are filled with zeros.  More formally, if the number is
 *		%$N = \sum{0 \le i} b_i 2^{8i}$% where %$0 \le b_i < 256$%,
 *		then the array is %$b_{n-1}, b_{n-2}, \ldots, b_0$%.
 */

void mp_storeb(const mp *m, void *pv, size_t sz)
{
  mpx_storeb(m->v, m->vl, pv, sz);
}

/* --- @mp_loadl2c@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@const void *pv@ = pointer to source data
 *		@size_t sz@ = size of the source data
 *
 * Returns:	Resulting multiprecision number.
 *
 * Use:		Loads a multiprecision number from an array of octets as
 *		two's complement.  The first byte in the array is the least
 *		significant.
 */

mp *mp_loadl2c(mp *d, const void *pv, size_t sz)
{
  const octet *ov = pv;
  MP_DEST(d, MPW_RQ(sz), MP_UNDEF);
  if (!sz || !(ov[sz - 1] & 0x80)) {
    mpx_loadl(d->v, d->vl, pv, sz);
    d->f &= ~MP_NEG;
  } else {
    mpx_loadl2cn(d->v, d->vl, pv, sz);
    d->f |= MP_NEG;
  }
  d->f &= ~MP_UNDEF;
  mp_shrink(d);
  return (d);
}

/* --- @mp_storel2c@ --- *
 *
 * Arguments:	@const mp *m@ = source
 *		@void *pv@ = pointer to output array
 *		@size_t sz@ = size of the output array
 *
 * Returns:	---
 *
 * Use:		Stores a multiprecision number in an array of octets as two's
 *		complement.  The first byte in the array is the least
 *		significant.  If the array is too small to represent the
 *		number, high-order bits are truncated; if the array is too
 *		large, high order bytes are sign-extended.
 */

void mp_storel2c(const mp *m, void *pv, size_t sz)
{
  if (MP_NEGP(m))
    mpx_storel2cn(m->v, m->vl, pv, sz);
  else
    mpx_storel(m->v, m->vl, pv, sz);
}

/* --- @mp_loadb2c@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@const void *pv@ = pointer to source data
 *		@size_t sz@ = size of the source data
 *
 * Returns:	Resulting multiprecision number.
 *
 * Use:		Loads a multiprecision number from an array of octets as
 *		two's complement.  The last byte in the array is the least
 *		significant.
 */

mp *mp_loadb2c(mp *d, const void *pv, size_t sz)
{
  const octet *ov = pv;
  MP_DEST(d, MPW_RQ(sz), MP_UNDEF);
  if (!sz || !(ov[0] & 0x80)) {
    mpx_loadb(d->v, d->vl, pv, sz);
    d->f &= ~MP_NEG;
  } else {
    mpx_loadb2cn(d->v, d->vl, pv, sz);
    d->f |= MP_NEG;
  }
  d->f &= ~MP_UNDEF;
  mp_shrink(d);
  return (d);
}

/* --- @mp_storeb2c@ --- *
 *
 * Arguments:	@const mp *m@ = source
 *		@void *pv@ = pointer to output array
 *		@size_t sz@ = size of the output array
 *
 * Returns:	---
 *
 * Use:		Stores a multiprecision number in an array of octets, as
 *		two's complement.  The last byte in the array is the least
 *		significant.  If the array is too small to represent the
 *		number, high-order bits are truncated; if the array is too
 *		large, high order bytes are sign-extended.
 */

void mp_storeb2c(const mp *m, void *pv, size_t sz)
{
  if (MP_NEGP(m))
    mpx_storeb2cn(m->v, m->vl, pv, sz);
  else
    mpx_storeb(m->v, m->vl, pv, sz);
}

/*----- That's all, folks -------------------------------------------------*/
