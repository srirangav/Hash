/* -*-c-*-
 *
 * Modular exponentiation using Barrett reduction
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"
#include "mpbarrett.h"
#include "mpbarrett-exp.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @mpbarrett_exp@ --- *
 *
 * Arguments:	@mpbarrett *mb@ = pointer to Barrett reduction context
 *		@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$a^e \bmod m$%.
 */

mp *mpbarrett_exp(mpbarrett *mb, mp *d, mp *a, mp *e)
{
  mp *x = MP_ONE;
  mp *spare = (e->f & MP_BURN) ? MP_NEWSEC : MP_NEW;

  MP_COPY(a);
  MP_SHRINK(e);
  if (MP_ZEROP(e))
    ;
  else {
    if (MP_NEGP(e))
      a = mp_modinv(a, a, mb->m);
    if (MP_LEN(e) < EXP_THRESH)
      EXP_SIMPLE(x, a, e);
    else
      EXP_WINDOW(x, a, e);
  }
  mp_drop(d);
  mp_drop(spare);
  mp_drop(a);
  return (x);
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

static int vexp(dstr *v)
{
  mp *m = *(mp **)v[0].buf;
  mp *a = *(mp **)v[1].buf;
  mp *b = *(mp **)v[2].buf;
  mp *r = *(mp **)v[3].buf;
  mp *mr;
  int ok = 1;

  mpbarrett mb;
  mpbarrett_create(&mb, m);

  mr = mpbarrett_exp(&mb, MP_NEW, a, b);

  if (!MP_EQ(mr, r)) {
    fputs("\n*** barrett modexp failed", stderr);
    fputs("\n m = ", stderr); mp_writefile(m, stderr, 10);
    fputs("\n a = ", stderr); mp_writefile(a, stderr, 10);
    fputs("\n e = ", stderr); mp_writefile(b, stderr, 10);
    fputs("\n r = ", stderr); mp_writefile(r, stderr, 10);
    fputs("\nmr = ", stderr); mp_writefile(mr, stderr, 10);
    fputc('\n', stderr);
    ok = 0;
  }

  mp_drop(m);
  mp_drop(a);
  mp_drop(b);
  mp_drop(r);
  mp_drop(mr);
  mpbarrett_destroy(&mb);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return ok;
}

static test_chunk tests[] = {
  { "mpbarrett-exp", vexp, { &type_mp, &type_mp, &type_mp, &type_mp, 0 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/mpbarrett");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
