/* -*-c-*-
 *
 * Normal-basis translation for binary fields
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GFN_H
#define CATACOMB_GFN_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include "gf.h"

/*----- Data structures ---------------------------------------------------*/

typedef struct gfn {
  size_t n;				/* Number of rows */
  mp **r;				/* Array of the rows */
} gfn;

/*----- Functions provided ------------------------------------------------*/

/* --- @gfn_copy@ --- *
 *
 * Arguments:	@gfn *d@ = where to put the copy
 *		@const gfn *s@ = where the source is
 *
 * Returns:	---
 *
 * Use:		Makes a copy of a translation matrix.
 */

extern void gfn_copy(gfn */*d*/, const gfn */*s*/);

/* --- @gfn_destroy@ --- *
 *
 * Arguments:	@gfn *m@ = a transformation matrix to free
 *
 * Returns:	---
 *
 * Use:		Frees up a transformation matrix when it's no longer wanted.
 */

extern void gfn_destroy(gfn */*m*/);

/* --- @gfn_identity@ --- *
 *
 * Arguments:	@gfn *m@ = where to put the matrix
 *		@size_t n@ = size of the matrix
 *
 * Returns:	---
 *
 * Use:		Fills @m@ with an identity matrix.
 */

extern void gfn_identity(gfn */*m*/, size_t /*n*/);

/* --- @gfn_invert@ --- *
 *
 * Arguments:	@gfn *m@ = a transformation matrix
 *
 * Returns:	Zero if successful, nonzero if the matrix was singular.
 *
 * Use:		Inverts a transformation matrix.
 */

extern int gfn_invert(gfn */*m*/);

/* --- @gfn_transform@ --- *
 *
 * Arguments:	@gfn *m@ = conversion matrix to apply
 *		@mp *d@ = destination pointer
 *		@mp *x@ = input value
 *
 * Returns:	The transformed element.
 *
 * Use:		Transforms a field element according to the given matrix.
 */

extern mp *gfn_transform(gfn */*m*/, mp */*d*/, mp */*x*/);

/* --- @gfn_create@ --- *
 *
 * Arguments:	@mp *p@ = modulus for polynomial basis
 *		@mp *beta@ = the generator of the normal basis, expressed
 *			relative to the polynomial basis
 *		@gfn *ntop@ = output normal-to-polynomail conversion matrix
 *		@gfn *pton@ = output polynomial-to-normal conversion matrix
 *
 * Returns:	Zero if it worked, nonzero otherwise (e.g., if %$\beta$%
 *		doesn't generate a proper basis).
 *
 * Use:		Constructs conversion matrices between polynomial and normal
 *		basis representations of binary field elements.
 */

extern int gfn_create(mp */*p*/, mp */*beta*/, gfn */*ntop*/, gfn */*pton*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
