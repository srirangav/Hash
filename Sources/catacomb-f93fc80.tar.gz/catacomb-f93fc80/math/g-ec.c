/* -*-c-*-
 *
 * Abstraction for elliptic curve groups
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <ctype.h>

#include <mLib/sub.h>

#define ge ec
#include "group.h"
#include "ec-raw.h"
#include "group-guts.h"

/*----- Main code ---------------------------------------------------------*/

/* --- Group operations --- */

static void gdestroygroup(group *gg) {
  gctx_ec *g = (gctx_ec *)gg;
  EC_DESTROY(&g->gen);
  ec_freeinfo(&g->ei);
  DESTROY(g);
}

static ec *gcreate(group *gg)
  { ec *x = CREATE(ec); EC_CREATE(x); return (x); }

static void gcopy(group *gg, ec *d, ec *x) { EC_COPY(d, x); }

static void gburn(group *gg, ec *x) { if (x->x) (x->x)->f |= MP_BURN; }

static void gdestroy(group *gg, ec *x) { EC_DESTROY(x); DESTROY(x); }

static int gsamep(group *gg, group *hh) {
  gctx_ec *g = (gctx_ec *)gg, *h = (gctx_ec *)hh;
  return (ec_sameinfop(&g->ei, &h->ei));
}

static int geq(group *gg, ec *x, ec *y) {
  gctx_ec *g = (gctx_ec *)gg; EC_FIX(g->ei.c, x, x); EC_FIX(g->ei.c, y, y);
  return (EC_EQ(x, y));
}

static int gidentp(group *gg, ec *x) { return (EC_ATINF(x)); }

static const char *gcheck(group *gg, grand *gr)
  { gctx_ec *g = (gctx_ec *)gg; return (ec_checkinfo(&g->ei, gr)); }

static void gmul(group *gg, ec *d, ec *x, ec *y)
  { gctx_ec *g = (gctx_ec *)gg; EC_ADD(g->ei.c, d, x, y); }

static void gsqr(group *gg, ec *d, ec *x)
  { gctx_ec *g = (gctx_ec *)gg; EC_DBL(g->ei.c, d, x); }

static void ginv(group *gg, ec *d, ec *x)
  { gctx_ec *g = (gctx_ec *)gg; EC_NEG(g->ei.c, d, x); }

static void gdiv(group *gg, ec *d, ec *x, ec *y)
  { gctx_ec *g = (gctx_ec *)gg; EC_SUB(g->ei.c, d, x, y); }

static void gexp(group *gg, ec *d, ec *x, mp *n)
  { gctx_ec *g = (gctx_ec *)gg; ec_imul(g->ei.c, d, x, n); }

static void gmexp(group *gg, ec *d, const group_expfactor *f, size_t n) {
  gctx_ec *g = (gctx_ec *)gg; size_t i;
  ec_mulfactor *ff = xmalloc(n * sizeof(ec_mulfactor));
  for (i = 0; i < n; i++) { ff[i].base = *f[i].base; ff[i].exp = f[i].exp; }
  ec_immul(g->ei.c, d, ff, n); xfree(ff);
}

static int gread(group *gg, ec *d, const mptext_ops *ops, void *p) {
  gctx_ec *g = (gctx_ec *)gg;
  ec t = EC_INIT;
  int rc = -1;
  int ch;

  ch = ops->get(p);
  if (tolower(ch) == 'i') {
    if (tolower(ops->get(p)) != 'n' || tolower(ops->get(p)) != 'f')
      return (-1);
    EC_SETINF(d);
    return (0);
  }
  ops->unget(ch, p);
  if ((t.x = mp_read(MP_NEW, 0, ops, p)) == 0) goto done;
  do ch = ops->get(p); while (ch == ',' || isspace(ch)); ops->unget(ch, p);
  if ((t.y = mp_read(MP_NEW, 0, ops, p)) == 0) goto done;
  EC_IN(g->ei.c, &t, &t);
  if (EC_CHECK(g->ei.c, &t)) goto done;
  EC_COPY(d, &t); rc = 0;
  EC_DESTROY(&t);
done:
  return (rc);
}

static int gwrite(group *gg, ec *x, const mptext_ops *ops, void *p) {
  gctx_ec *g = (gctx_ec *)gg; int rc = -1; ec t = EC_INIT;
  EC_OUT(g->ei.c, &t, x); if (EC_ATINF(&t)) rc = ops->put("inf", 3, p);
  else if (!ops->put("0x", 2, p) && !mp_write(t.x, 16, ops, p) &&
	   !ops->put(", 0x", 4, p) && !mp_write(t.y, 16, ops, p)) rc = 0;
  EC_DESTROY(&t); return (rc);
}

static mp *gtoint(group *gg, mp *d, ec *x) {
  gctx_ec *g = (gctx_ec *)gg; ec t = EC_INIT; mp *i; if (EC_ATINF(x)) i = 0;
  else { EC_OUT(g->ei.c, &t, x); i = MP_COPY(t.x); EC_DESTROY(&t); }
  mp_drop(d); return (i);
}

static int gfromint(group *gg, ec *d, mp *x) {
  gctx_ec *g = (gctx_ec *)gg; ec t = EC_INIT;
  if (!ec_find(g->ei.c, &t, x)) return (-1);
  EC_IN(g->ei.c, d, &t); EC_DESTROY(&t); return (0);
}

static int gtoec(group *gg, ec *d, ec *x)
  { gctx_ec *g = (gctx_ec *)gg; EC_OUT(g->ei.c, d, x); return (0); }

static int gfromec(group *gg, ec *d, const ec *x) {
  gctx_ec *g = (gctx_ec *)gg; ec t = EC_INIT; int rc; EC_IN(g->ei.c, &t, x);
  rc = EC_CHECK(g->ei.c, &t); if (!rc) EC_COPY(d, &t); EC_DESTROY(&t);
  return (rc);
}

static int gtobuf(group *gg, buf *b, ec *x) {
  gctx_ec *g = (gctx_ec *)gg; ec t = EC_INIT; int rc;
  EC_OUT(g->ei.c, &t, x); rc = buf_putec(b, &t); EC_DESTROY(&t); return (rc);
}

static int gfrombuf(group *gg, buf *b, ec *d) {
  gctx_ec *g = (gctx_ec *)gg; ec t = EC_INIT; int rc;
  if (buf_getec(b, &t)) return (-1);
  EC_IN(g->ei.c, &t, &t); rc = EC_CHECK(g->ei.c, &t);
  if (!rc) EC_COPY(d, &t); EC_DESTROY(&t); return (rc);
}

static int gtoraw(group *gg, buf *b, ec *x) {
  gctx_ec *g = (gctx_ec *)gg; ec t = EC_INIT; int rc;
  EC_OUT(g->ei.c, &t, x); rc = ec_putraw(g->ei.c, b, &t);
  EC_DESTROY(&t); return (rc);
}

static int gfromraw(group *gg, buf *b, ec *d) {
  gctx_ec *g = (gctx_ec *)gg; ec t = EC_INIT; int rc;
  if (ec_getraw(g->ei.c, b, &t)) return (-1);
  EC_IN(g->ei.c, &t, &t); rc = EC_CHECK(g->ei.c, &t);
  if (!rc) EC_COPY(d, &t); EC_DESTROY(&t); return (rc);
}

/* --- @group_ec@ --- *
 *
 * Arguments:	@const ec_info *ei@ = elliptic curve parameters
 *
 * Returns:	A pointer to the group.
 *
 * Use:		Constructs an abstract group interface for an elliptic curve
 *		group.  Group elements are @ec@ structures.  The contents of
 *		the @ec_info@ structure becomes the property of the @group@
 *		object; you can (and should) free the structure itself, but
 *		calling @ec_freeinfo@ on it is not allowed.
 */

static const group_ops gops = {
  GTY_EC, "ec",
  gdestroygroup, gcreate, gcopy, gburn, gdestroy,
  gsamep, geq, gidentp,
  gcheck,
  gmul, gsqr, ginv, gdiv, gexp, gmexp,
  gread, gwrite,
  gtoint, gfromint, gtoec, gfromec, gtobuf, gfrombuf, gtoraw, gfromraw
};

group *group_ec(const ec_info *ei)
{
  gctx_ec *g = CREATE(gctx_ec);

  g->g.ops = &gops;
  g->g.nbits = ei->c->f->nbits * 2;
  g->g.noctets = ei->c->f->noctets * 2 + 1;
  g->ei = *ei;
  EC_CREATE(&g->id);
  g->g.i = &g->id;
  EC_CREATE(&g->gen);
  g->g.g = &g->gen;
  EC_IN(g->ei.c, &g->gen, &ei->g);
  g->g.r = ei->r;
  g->g.h = ei->h;
  return (&g->g);
}

/*----- That's all, folks -------------------------------------------------*/
