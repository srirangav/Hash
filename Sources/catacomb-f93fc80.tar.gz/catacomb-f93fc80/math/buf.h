/* -*-c-*-
 *
 * Reading and writing packet buffers
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_BUF_H
#define CATACOMB_BUF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>
#include <mLib/buf.h>

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

#ifndef CATACOMB_EC_H
#  include "ec.h"
#endif

/*----- Functions provided ------------------------------------------------*/

/* --- @buf_getmp@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *
 * Returns:	A multiprecision integer, or null if there wasn't one there.
 *
 * Use:		Gets a multiprecision integer from a buffer.
 */

extern mp *buf_getmp(buf */*b*/);

/* --- @buf_putmp@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@mp *m@ = a multiprecision integer
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts a multiprecision integer to a buffer.
 */

extern int buf_putmp(buf */*b*/, mp */*m*/);

/* --- @buf_getec@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@ec *p@ = where to put the point
 *
 * Returns:	Zero if it worked, nonzero if it failed.
 *
 * Use:		Gets a multiprecision integer from a buffer.  The point must
 *		be initialized.
 */

extern int buf_getec(buf */*b*/, ec */*p*/);

/* --- @buf_putec@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@ec *p@ = an elliptic curve point
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts an elliptic curve point to a buffer.
 */

extern int buf_putec(buf */*b*/, ec */*p*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
