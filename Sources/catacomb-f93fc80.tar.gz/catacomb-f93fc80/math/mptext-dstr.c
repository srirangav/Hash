/* -*-c-*-
 *
 * Reading and writing large integers on strings
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/dstr.h>

#include "mptext.h"

/*----- Main code ---------------------------------------------------------*/

/* --- Operations table --- */

static int get(void *p)
{
  mptext_dstrctx *c = p;
  if (c->i >= c->d->len)
    return (EOF);
  return ((unsigned char)c->d->buf[c->i++]);
}

static void unget(int ch, void *p)
{
  mptext_dstrctx *c = p;
  if (ch == EOF || c->i == 0)
    return;
  c->i--;
}

static int put(const char *s, size_t sz, void *p)
{
  mptext_dstrctx *c = p;
  DPUTM(c->d, s, sz);
  return (0);
}

const mptext_ops mptext_dstrops = { get, unget, put };

/* --- Convenience functions --- */

mp *mp_readdstr(mp *m, dstr *d, size_t *off, int radix)
{
  mptext_dstrctx c;
  c.d = d;
  c.i = off ? *off : 0;
  m = mp_read(m, radix, &mptext_dstrops, &c);
  if (off)
    *off = c.i;
  return (m);
}

int mp_writedstr(mp *m, dstr *d, int radix)
{
  mptext_dstrctx c;
  int rc;
  c.d = d;
  rc = mp_write(m, radix, &mptext_dstrops, &c);
  DPUTZ(d);
  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
