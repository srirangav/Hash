/* -*-c-*-
 *
 * Binary fields with polynomial basis representation
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/sub.h>

#include "field.h"
#include "field-guts.h"
#include "mprand.h"

/*----- Polynomial basis --------------------------------------------------*/

/* --- Field operations --- */

static void fdestroy(field *ff) {
  fctx_binpoly *f = (fctx_binpoly *)ff;
  gfreduce_destroy(&f->r); MP_DROP(f->f.q);
  DESTROY(f);
}

static mp *frand(field *f, mp *d, grand *r) {
  return (mprand(d, f->nbits, r, 0));
}

static int fzerop(field *ff, mp *x) { return (MP_ZEROP(x)); }

static mp *fadd(field *ff, mp *d, mp *x, mp *y) { return (gf_add(d, x, y)); }

static mp *fmul(field *ff, mp *d, mp *x, mp *y) {
  fctx_binpoly *f = (fctx_binpoly *)ff; d = gf_mul(d, x, y);
  return (gfreduce_do(&f->r, d, d));
}

static mp *fsqr(field *ff, mp *d, mp *x) {
  fctx_binpoly *f = (fctx_binpoly *)ff; d = gf_sqr(d, x);
  return (gfreduce_do(&f->r, d, d));
}

static mp *finv(field *ff, mp *d, mp *x) {
  fctx_binpoly *f = (fctx_binpoly *)ff;
  d = gf_modinv(d, x, f->r.p);
  return (d);
}

static mp *freduce(field *ff, mp *d, mp *x) {
  fctx_binpoly *f = (fctx_binpoly *)ff;
  return (gfreduce_do(&f->r, d, x));
}

static mp *fsqrt(field *ff, mp *d, mp *x) {
  fctx_binpoly *f = (fctx_binpoly *)ff;
  return (gfreduce_sqrt(&f->r, d, x));
}

static mp *fquadsolve(field *ff, mp *d, mp *x) {
  fctx_binpoly *f = (fctx_binpoly *)ff;
  return (gfreduce_quadsolve(&f->r, d, x));
}

/* --- Field operations table --- */

static const field_ops fops = {
  FTY_BINARY, "binpoly",
  fdestroy, frand, field_stdsamep,
  freduce, field_id,
  fzerop, field_id, fadd, fadd, fmul, fsqr, finv, freduce, fsqrt,
  fquadsolve,
  0, 0, 0, 0
};

/* --- @field_binpoly@ --- *
 *
 * Arguments:	@mp *p@ = the reduction polynomial
 *
 * Returns:	A pointer to the field.
 *
 * Use:		Creates a field structure for a binary field mod @p@.
 */

field *field_binpoly(mp *p)
{
  fctx_binpoly *f = CREATE(fctx_binpoly);
  f->f.ops = &fops;
  f->f.zero = MP_ZERO;
  f->f.one = MP_ONE;
  f->f.nbits = mp_bits(p) - 1;
  f->f.noctets = (f->f.nbits + 7) >> 3;
  gfreduce_create(&f->r, p);
  f->f.m = f->r.p;
  f->f.q = mp_lsl(MP_NEW, MP_ONE, f->f.nbits);
  return (&f->f);
}

/*----- Normal basis ------------------------------------------------------*/

/* --- Field operations --- */

static void fndestroy(field *ff) {
  fctx_binnorm *f = (fctx_binnorm *)ff; gfreduce_destroy(&f->f.r);
  gfn_destroy(&f->ntop); gfn_destroy(&f->pton); MP_DROP(f->f.f.q);
  DESTROY(f);
}

static int fnsamep(field *ff, field *gg) {
  fctx_binnorm *f = (fctx_binnorm *)ff, *g = (fctx_binnorm *)gg;
  return (MP_EQ(f->ntop.r[0], g->ntop.r[0]) && field_stdsamep(ff, gg));
}

static mp *fnin(field *ff, mp *d, mp *x) {
  fctx_binnorm *f = (fctx_binnorm *)ff;
  return (gfn_transform(&f->ntop, d, x));
}

static mp *fnout(field *ff, mp *d, mp *x) {
  fctx_binnorm *f = (fctx_binnorm *)ff;
  return (gfn_transform(&f->pton, d, x));
}

/* --- Field operations table --- */

static const field_ops fnops = {
  FTY_BINARY, "binnorm",
  fndestroy, frand, fnsamep,
  fnin, fnout,
  fzerop, field_id, fadd, fadd, fmul, fsqr, finv, freduce, fsqrt,
  fquadsolve,
  0, 0, 0, 0
};

/* --- @field_binnorm@ --- *
 *
 * Arguments:	@mp *p@ = the reduction polynomial
 *		@mp *beta@ = representation of normal point
 *
 * Returns:	A pointer to the field.
 *
 * Use:		Creates a field structure for a binary field mod @p@ which
 *		uses a normal basis representation externally.  Computations
 *		are still done on a polynomial-basis representation.
 */

field *field_binnorm(mp *p, mp *beta)
{
  fctx_binnorm *f = CREATE(fctx_binnorm);
  f->f.f.ops = &fnops;
  f->f.f.zero = MP_ZERO;
  f->f.f.one = MP_ONE;
  f->f.f.nbits = mp_bits(p) - 1;
  f->f.f.noctets = (f->f.f.nbits + 7) >> 3;
  gfreduce_create(&f->f.r, p);
  f->f.f.m = f->f.r.p;
  f->f.f.q = mp_lsl(MP_NEW, MP_ONE, f->f.f.nbits);
  gfn_create(p, beta, &f->ntop, &f->pton);
  return (&f->f.f);
}

/*----- That's all, folks -------------------------------------------------*/
