/* -*-c-*-
 *
 * Abstract field operations
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "field.h"
#include "mp.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @field_id@ --- *
 *
 * Arguments:	@field *f@ = pointer to a field
 *		@mp *d@ = a destination element
 *		@mp *x@ = a source element
 *
 * Returns:	The result element.
 *
 * Use:		An identity operation which can be used if your field has no
 *		internal representation.
 */

mp *field_id(field *f, mp *d, mp *x)
  { x = MP_COPY(x); if (d) MP_DROP(d); return (x); }

/* --- @field_samep@ --- *
 *
 * Arguments:	@field *f, *g@ = two fields
 *
 * Returns:	Nonzero if the fields are identical (not just isomorphic).
 *
 * Use:		Checks for sameness of fields.  This function does the full
 *		check, not just the field-type-specific check done by the
 *		@sampep@ field operation.
 */

int field_samep(field *f, field *g)
  { return (f == g || (f->ops == g->ops && F_SAMEP(f, g))); }

/* --- @field_stdsamep@ --- *
 *
 * Arguments:	@field *f, *g@ = two fields
 *
 * Returns:	Nonzero if the fields are identical (not just isomorphic).
 *
 * Use:		Standard sameness check, based on equality of the @m@
 *		member.
 */

int field_stdsamep(field *f, field *g) { return (MP_EQ(f->m, g->m)); }

/*----- That's all, folks -------------------------------------------------*/
