/* -*-c-*-
 *
 * Bit operations by truth table
 *
 * (c) 2002 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_BITOPS_H
#define CATACOMB_BITOPS_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Macros ------------------------------------------------------------*/

#define B0000(x, y) (0u)
#define B0001(x, y) ((x) & (y))
#define B0010(x, y) ((x) & ~(y))
#define B0011(x, y) (x)
#define B0100(x, y) (~(x) & (y))
#define B0101(x, y) (y)
#define B0110(x, y) ((x) ^ (y))
#define B0111(x, y) ((x) | (y))
#define B1000(x, y) (~((x) | (y)))
#define B1001(x, y) (~((x) ^ (y)))
#define B1010(x, y) (~(y))
#define B1011(x, y) ((x) | ~(y))
#define B1100(x, y) (~(x))
#define B1101(x, y) (~(x) | (y))
#define B1110(x, y) (~((x) & (y)))
#define B1111(x, y) (~0u)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
