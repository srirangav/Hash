/* -*-c-*-
 *
 * Elliptic curves over prime fields
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/sub.h>

#include "ec.h"

/*----- Simple prime curves -----------------------------------------------*/

static const ec_ops ec_primeops, ec_primeprojops, ec_primeprojxops;

static ec *ecneg(ec_curve *c, ec *d, const ec *p)
{
  EC_COPY(d, p);
  if (d->y)
    d->y = F_NEG(c->f, d->y, d->y);
  return (d);
}

static ec *ecfind(ec_curve *c, ec *d, mp *x)
{
  mp *p, *q;
  field *f = c->f;

  q = F_SQR(f, MP_NEW, x);
  p = F_MUL(f, MP_NEW, x, q);
  q = F_MUL(f, q, x, c->a);
  p = F_ADD(f, p, p, q);
  p = F_ADD(f, p, p, c->b);
  MP_DROP(q);
  p = F_SQRT(f, p, p);
  if (!p)
    return (0);
  EC_DESTROY(d);
  d->x = MP_COPY(x);
  d->y = p;
  d->z = MP_COPY(f->one);
  return (d);
}

static ec *ecdbl(ec_curve *c, ec *d, const ec *a)
{
  if (EC_ATINF(a) || F_ZEROP(c->f, a->y))
    EC_SETINF(d);
  else {
    field *f = c->f;
    mp *lambda;
    mp *dy, *dx;

    dx = F_SQR(f, MP_NEW, a->x);	/* %$x^2$% */
    dy = F_DBL(f, MP_NEW, a->y);	/* %$2 y$% */
    dx = F_TPL(f, dx, dx);		/* %$3 x^2$% */
    dx = F_ADD(f, dx, dx, c->a);	/* %$3 x^2 + A$% */
    dy = F_INV(f, dy, dy);		/* %$(2 y)^{-1}$% */
    lambda = F_MUL(f, MP_NEW, dx, dy);	/* %$\lambda = (3 x^2 + A)/(2 y)$% */

    dx = F_SQR(f, dx, lambda);		/* %$\lambda^2$% */
    dy = F_DBL(f, dy, a->x);		/* %$2 x$% */
    dx = F_SUB(f, dx, dx, dy);		/* %$x' = \lambda^2 - 2 x */
    dy = F_SUB(f, dy, a->x, dx);	/* %$x - x'$% */
    dy = F_MUL(f, dy, lambda, dy);	/* %$\lambda (x - x')$% */
    dy = F_SUB(f, dy, dy, a->y);	/* %$y' = \lambda (x - x') - y$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = 0;
    MP_DROP(lambda);
  }
  return (d);
}

static ec *ecprojdbl(ec_curve *c, ec *d, const ec *a)
{
  if (EC_ATINF(a) || F_ZEROP(c->f, a->y))
    EC_SETINF(d);
  else {
    field *f = c->f;
    mp *p, *q, *m, *s, *dx, *dy, *dz;

    p = F_SQR(f, MP_NEW, a->z);		/* %$z^2$% */
    q = F_SQR(f, MP_NEW, p);		/* %$z^4$% */
    p = F_MUL(f, p, q, c->a);		/* %$A z^4$% */
    m = F_SQR(f, MP_NEW, a->x);		/* %$x^2$% */
    m = F_TPL(f, m, m);			/* %$3 x^2$% */
    m = F_ADD(f, m, m, p);		/* %$m = 3 x^2 + A z^4$% */

    q = F_DBL(f, q, a->y);		/* %$2 y$% */
    dz = F_MUL(f, MP_NEW, q, a->z);	/* %$z' = 2 y z$% */

    p = F_SQR(f, p, q);			/* %$4 y^2$% */
    s = F_MUL(f, MP_NEW, p, a->x);	/* %$s = 4 x y^2$% */
    q = F_SQR(f, q, p);			/* %$16 y^4$% */
    q = F_HLV(f, q, q);			/* %$t = 8 y^4$% */

    p = F_DBL(f, p, s);			/* %$2 s$% */
    dx = F_SQR(f, MP_NEW, m);		/* %$m^2$% */
    dx = F_SUB(f, dx, dx, p);		/* %$x' = m^2 - 2 s$% */

    s = F_SUB(f, s, s, dx);		/* %$s - x'$% */
    dy = F_MUL(f, p, m, s);		/* %$m (s - x')$% */
    dy = F_SUB(f, dy, dy, q);		/* %$y' = m (s - x') - t$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = dz;
    MP_DROP(m);
    MP_DROP(q);
    MP_DROP(s);
  }
  return (d);
}

static ec *ecprojxdbl(ec_curve *c, ec *d, const ec *a)
{
  if (EC_ATINF(a) || F_ZEROP(c->f, a->y))
    EC_SETINF(d);
  else {
    field *f = c->f;
    mp *p, *q, *m, *s, *dx, *dy, *dz;

    m = F_SQR(f, MP_NEW, a->z);		/* %$z^2$% */
    p = F_SUB(f, MP_NEW, a->x, m);	/* %$x - z^2$% */
    q = F_ADD(f, MP_NEW, a->x, m);	/* %$x + z^2$% */
    m = F_MUL(f, m, p, q);		/* %$x^2 - z^4$% */
    m = F_TPL(f, m, m);			/* %$m = 3 x^2 - 3 z^4$% */

    q = F_DBL(f, q, a->y);		/* %$2 y$% */
    dz = F_MUL(f, MP_NEW, q, a->z);	/* %$z' = 2 y z$% */

    p = F_SQR(f, p, q);			/* %$4 y^2$% */
    s = F_MUL(f, MP_NEW, p, a->x);	/* %$s = 4 x y^2$% */
    q = F_SQR(f, q, p);			/* %$16 y^4$% */
    q = F_HLV(f, q, q);			/* %$t = 8 y^4$% */

    p = F_DBL(f, p, s);			/* %$2 s$% */
    dx = F_SQR(f, MP_NEW, m);		/* %$m^2$% */
    dx = F_SUB(f, dx, dx, p);		/* %$x' = m^2 - 2 s$% */

    s = F_SUB(f, s, s, dx);		/* %$s - x'$% */
    dy = F_MUL(f, p, m, s);		/* %$m (s - x')$% */
    dy = F_SUB(f, dy, dy, q);		/* %$y' = m (s - x') - t$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = dz;
    MP_DROP(m);
    MP_DROP(q);
    MP_DROP(s);
  }
  return (d);
}

static ec *ecadd(ec_curve *c, ec *d, const ec *a, const ec *b)
{
  if (a == b)
    ecdbl(c, d, a);
  else if (EC_ATINF(a))
    EC_COPY(d, b);
  else if (EC_ATINF(b))
    EC_COPY(d, a);
  else {
    field *f = c->f;
    mp *lambda;
    mp *dy, *dx;

    if (!MP_EQ(a->x, b->x)) {
      dy = F_SUB(f, MP_NEW, a->y, b->y); /* %$y_0 - y_1$% */
      dx = F_SUB(f, MP_NEW, a->x, b->x); /* %$x_0 - x_1$% */
      dx = F_INV(f, dx, dx);		/* %$(x_0 - x_1)^{-1}$% */
      lambda = F_MUL(f, MP_NEW, dy, dx);
				   /* %$\lambda = (y_0 - y1)/(x_0 - x_1)$% */
    } else if (F_ZEROP(c->f, a->y) || !MP_EQ(a->y, b->y)) {
      EC_SETINF(d);
      return (d);
    } else {
      dx = F_SQR(f, MP_NEW, a->x);	/* %$x_0^2$% */
      dx = F_TPL(f, dx, dx);		/* %$3 x_0^2$% */
      dx = F_ADD(f, dx, dx, c->a);	/* %$3 x_0^2 + A$% */
      dy = F_DBL(f, MP_NEW, a->y);	/* %$2 y_0$% */
      dy = F_INV(f, dy, dy);		/* %$(2 y_0)^{-1}$% */
      lambda = F_MUL(f, MP_NEW, dx, dy);
				    /* %$\lambda = (3 x_0^2 + A)/(2 y_0)$% */
    }

    dx = F_SQR(f, dx, lambda);		/* %$\lambda^2$% */
    dx = F_SUB(f, dx, dx, a->x);	/* %$\lambda^2 - x_0$% */
    dx = F_SUB(f, dx, dx, b->x);	/* %$x' = \lambda^2 - x_0 - x_1$% */
    dy = F_SUB(f, dy, b->x, dx);	/* %$x_1 - x'$% */
    dy = F_MUL(f, dy, lambda, dy);	/* %$\lambda (x_1 - x')$% */
    dy = F_SUB(f, dy, dy, b->y);      /* %$y' = \lambda (x_1 - x') - y_1$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = 0;
    MP_DROP(lambda);
  }
  return (d);
}

static ec *ecprojadd(ec_curve *c, ec *d, const ec *a, const ec *b)
{
  if (a == b)
    c->ops->dbl(c, d, a);
  else if (EC_ATINF(a))
    EC_COPY(d, b);
  else if (EC_ATINF(b))
    EC_COPY(d, a);
  else {
    field *f = c->f;
    mp *p, *q, *r, *w, *u, *uu, *s, *ss, *dx, *dy, *dz;

    q = F_SQR(f, MP_NEW, a->z);		/* %$z_0^2$% */
    u = F_MUL(f, MP_NEW, q, b->x);	/* %$u = x_1 z_0^2$% */
    p = F_MUL(f, MP_NEW, q, b->y);	/* %$y_1 z_0^2$% */
    s = F_MUL(f, q, p, a->z);		/* %$s = y_1 z_0^3$% */

    q = F_SQR(f, MP_NEW, b->z);		/* %$z_1^2$% */
    uu = F_MUL(f, MP_NEW, q, a->x);	/* %$uu = x_0 z_1^2$%*/
    p = F_MUL(f, p, q, a->y);		/* %$y_0 z_1^2$% */
    ss = F_MUL(f, q, p, b->z);		/* %$ss = y_0 z_1^3$% */

    w = F_SUB(f, p, uu, u);		/* %$w = uu - u$% */
    r = F_SUB(f, MP_NEW, ss, s);	/* %$r = ss - s$% */
    if (F_ZEROP(f, w)) {
      MP_DROP(w);
      MP_DROP(u);
      MP_DROP(s);
      MP_DROP(uu);
      MP_DROP(ss);
      if (F_ZEROP(f, r)) {
	MP_DROP(r);
	return (c->ops->dbl(c, d, a));
      } else {
	MP_DROP(r);
	EC_SETINF(d);
	return (d);
      }
    }
    u = F_ADD(f, u, u, uu);		/* %$t = uu + u$% */
    s = F_ADD(f, s, s, ss);		/* %$m = ss + s$% */

    uu = F_MUL(f, uu, a->z, w);		/* %$z_0 w$% */
    dz = F_MUL(f, ss, uu, b->z);	/* %$z' = z_0 z_1 w$% */

    p = F_SQR(f, uu, w);		/* %$w^2$% */
    q = F_MUL(f, MP_NEW, p, u);		/* %$t w^2$% */
    u = F_MUL(f, u, p, w);		/* %$w^3$% */
    p = F_MUL(f, p, u, s);		/* %$m w^3$% */

    dx = F_SQR(f, u, r);		/* %$r^2$% */
    dx = F_SUB(f, dx, dx, q);		/* %$x' = r^2 - t w^2$% */

    s = F_DBL(f, s, dx);		/* %$2 x'$% */
    q = F_SUB(f, q, q, s);		/* %$v = t w^2 - 2 x'$% */
    dy = F_MUL(f, s, q, r);		/* %$v r$% */
    dy = F_SUB(f, dy, dy, p);		/* %$v r - m w^3$% */
    dy = F_HLV(f, dy, dy);		/* %$y' = (v r - m w^3)/2$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = dz;
    MP_DROP(p);
    MP_DROP(q);
    MP_DROP(r);
    MP_DROP(w);
  }
  return (d);
}

static int eccheck(ec_curve *c, const ec *p)
{
  field *f = c->f;
  mp *l, *x, *r;
  int rc;
  if (EC_ATINF(p)) return (0);
  l = F_SQR(f, MP_NEW, p->y);
  x = F_SQR(f, MP_NEW, p->x);
  r = F_MUL(f, MP_NEW, x, p->x);
  x = F_MUL(f, x, c->a, p->x);
  r = F_ADD(f, r, r, x);
  r = F_ADD(f, r, r, c->b);
  rc = MP_EQ(l, r) ? 0 : -1;
  mp_drop(l);
  mp_drop(x);
  mp_drop(r);
  return (rc);
}

static int ecprojcheck(ec_curve *c, const ec *p)
{
  ec t = EC_INIT;
  int rc;

  c->ops->fix(c, &t, p);
  rc = eccheck(c, &t);
  EC_DESTROY(&t);
  return (rc);
}

static int eccompr(ec_curve *c, const ec *p)
{
  /* --- Just take the LSB of %$y$% ---
   *
   * Since @p@ is odd, either %$y$% or %$-y = p - y$% must be odd, so this
   * disambiguates.
   */

  return (MP_ODDP(p->y));
}

static void ecdestroy(ec_curve *c)
{
  MP_DROP(c->a);
  MP_DROP(c->b);
  DESTROY(c);
}

/* --- @ec_prime@, @ec_primeproj@ --- *
 *
 * Arguments:	@field *f@ = the underlying field for this elliptic curve
 *		@mp *a, *b@ = the coefficients for this curve
 *
 * Returns:	A pointer to the curve, or null.
 *
 * Use:		Creates a curve structure for an elliptic curve defined over
 *		a prime field.  The @primeproj@ variant uses projective
 *		coordinates, which can be a win.
 */

extern ec_curve *ec_prime(field *f, mp *a, mp *b)
{
  ec_curve *c = CREATE(ec_curve);
  c->ops = &ec_primeops;
  c->f = f;
  c->a = F_IN(f, MP_NEW, a);
  c->b = F_IN(f, MP_NEW, b);
  return (c);
}

extern ec_curve *ec_primeproj(field *f, mp *a, mp *b)
{
  ec_curve *c = CREATE(ec_curve);
  mp *ax;

  ax = mp_add(MP_NEW, a, MP_THREE);
  ax = F_IN(f, ax, ax);
  if (F_ZEROP(f, ax))
    c->ops = &ec_primeprojxops;
  else
    c->ops = &ec_primeprojops;
  MP_DROP(ax);
  c->f = f;
  c->a = F_IN(f, MP_NEW, a);
  c->b = F_IN(f, MP_NEW, b);
  return (c);
}

static const ec_ops ec_primeops = {
  "prime",
  ecdestroy, ec_stdsamep, ec_idin, ec_idout, ec_idfix,
  ecfind, ecneg, ecadd, ec_stdsub, ecdbl, eccheck, eccompr
};

static const ec_ops ec_primeprojops = {
  "primeproj",
  ecdestroy, ec_stdsamep, ec_projin, ec_projout, ec_projfix,
  ecfind, ecneg, ecprojadd, ec_stdsub, ecprojdbl, ecprojcheck, eccompr
};

static const ec_ops ec_primeprojxops = {
  "primeproj",
  ecdestroy, ec_stdsamep, ec_projin, ec_projout, ec_projfix,
  ecfind, ecneg, ecprojadd, ec_stdsub, ecprojxdbl, ecprojcheck, eccompr
};

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#define MP(x) mp_readstring(MP_NEW, #x, 0, 0)

int main(int argc, char *argv[])
{
  field *f;
  ec_curve *c;
  ec g = EC_INIT, d = EC_INIT;
  mp *p, *a, *b, *r;
  int i, n = argc == 1 ? 1 : atoi(argv[1]);

  printf("ec-prime: ");
  fflush(stdout);
  a = MP(-3);
  b = MP(0xb3312fa7e23ee7e4988e056be3f82d19181d9c6efe8141120314088f5013875ac656398d8a2ed19d2a85c8edd3ec2aef);
  p = MP(39402006196394479212279040100143613805079739270465446667948293404245721771496870329047266088258938001861606973112319);
  r = MP(39402006196394479212279040100143613805079739270465446667946905279627659399113263569398956308152294913554433653942642);

  f = field_niceprime(p);
  c = ec_primeproj(f, a, b);

  g.x = MP(0xaa87ca22be8b05378eb1c71ef320ad746e1d3b628ba79b9859f741e082542a385502f25dbf55296c3a545e3872760ab7);
  g.y = MP(0x3617de4a96262c6f5d9e98bf9292dc29f8f41dbd289a147ce9da3113b5f0b8c00a60b1ce1d7e819d7a431d7c90ea0e5f);

  for (i = 0; i < n; i++) {
    ec_mul(c, &d, &g, r);
    if (EC_ATINF(&d)) {
      fprintf(stderr, "zero too early\n");
      return (1);
    }
    ec_add(c, &d, &d, &g);
    if (!EC_ATINF(&d)) {
      fprintf(stderr, "didn't reach zero\n");
      MP_EPRINT("d.x", d.x);
      MP_EPRINT("d.y", d.y);
      return (1);
    }
    ec_destroy(&d);
  }
  ec_destroy(&g);
  ec_destroycurve(c);
  F_DESTROY(f);
  MP_DROP(p); MP_DROP(a); MP_DROP(b); MP_DROP(r);
  assert(!mparena_count(&mparena_global));
  printf("ok\n");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
