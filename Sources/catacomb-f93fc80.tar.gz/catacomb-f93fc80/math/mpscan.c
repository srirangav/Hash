/* -*-c-*-
 *
 * Sequential bit scan of multiprecision integers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mpscan.h"

/*----- Right-to-left scanning --------------------------------------------*/

/* --- @mpscan_initx@ --- *
 *
 * Arguments:	@mpscan *m@ = pointer to bitscanner structure
 *		@const mpw *v, *vl@ = vector of words to scan
 *
 * Returns:	---
 *
 * Use:		Initializes a bitscanner from a low-level vector-and-length
 *		representation of an integer.  Initially no bit is ready; you
 *		must call @mpscan_step@ before anything useful will come
 *		out.
 */

void mpscan_initx(mpscan *m, const mpw *v, const mpw *vl)
{
  MPSCAN_INITX(m, v, vl);
}

/* --- @mpscan_step@ --- *
 *
 * Arguments:	@mpscan *m@ = pointer to bitscanner
 *
 * Returns:	Nonzero if there is another bit to read.
 *
 * Use:		Steps on to the next bit in the integer.  The macro version
 *		evaluates its argument multiple times.
 */

int mpscan_step(mpscan *m) { return (MPSCAN_STEP(m)); }

/* --- @mpscan_bit@ --- *
 *
 * Arguments:	@const mpscan *m@ = pointer to bitscanner
 *
 * Returns:	The value of the current bit.
 *
 * Use:		Reads the value of the current bit looked at by a
 *		bitscanner.
 */

int mpscan_bit(const mpscan *m) { return (MPSCAN_BIT(m)); }

/*----- Left-to right-scanning --------------------------------------------*/

/* --- @mpscan_rinitx@ --- *
 *
 * Arguments:	@mpscan *m@ = pointer to bitscanner structure
 *		@const mpw *v, *vl@ = vector of words to scan
 *
 * Returns:	---
 *
 * Use:		Initializes a reverse bitscanner from a low-level
 *		vector-and-length representation of an integer.  Initially no
 *		bit is ready; you must call @mpscan_rstep@ before anything
 *		useful will come out.
 */

void mpscan_rinitx(mpscan *m, const mpw *v, const mpw *vl)
{
  MPSCAN_RINITX(m, v, vl);
}

/* --- @mpscan_rstep@ --- *
 *
 * Arguments:	@mpscan *m@ = pointer to bitscanner
 *
 * Returns:	Nonzero if there is another bit to read.
 *
 * Use:		Steps on to the next bit in the integer.  The macro version
 *		evaluates its argument multiple times.
 */

int mpscan_rstep(mpscan *m) { return (MPSCAN_RSTEP(m)); }

/* --- @mpscan_rbit@ --- *
 *
 * Arguments:	@const mpscan *m@ = pointer to bitscanner
 *
 * Returns:	The value of the current bit.
 *
 * Use:		Reads the value of the current bit looked at by a
 *		reverse bitscanner.
 */

int mpscan_rbit(const mpscan *m) { return (MPSCAN_RBIT(m)); }

/*----- That's all, folks -------------------------------------------------*/
