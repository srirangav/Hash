/* -*-c-*-
 *
 * Standard event handlers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pgen.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @pgen_evspin@ --- *
 *
 * Displays a spinning baton to show progress.
 */

int pgen_evspin(int rq, pgen_event *ev, void *p)
{
  static char spinner[] = "/-\\|";
  static char *q = spinner;

  switch (rq) {
    case PGEN_PASS:
    case PGEN_FAIL:
      putchar(*q++);
      putchar('\b');
      fflush(stdout);
      if (!*q)
	q = spinner;
      break;
    case PGEN_DONE:
    case PGEN_ABORT:
      putchar(' ');
      putchar('\b');
      fflush(stdout);
      break;
  }
  return (0);
}

/* --- @pgen_ev@ --- *
 *
 * Traditional event handler, shows dots for each test.
 */

int pgen_ev(int rq, pgen_event *ev, void *p)
{
  switch (rq) {
    case PGEN_BEGIN:
      printf("Searching for %s: ", ev->name);
      fflush(stdout);
      break;
    case PGEN_FAIL:
      putchar('.');
      fflush(stdout);
      break;
    case PGEN_PASS:
      putchar('+');
      fflush(stdout);
      break;
    case PGEN_DONE:
      puts("+ ok");
      break;
    case PGEN_ABORT:
      puts(" failed");
      break;
  }
  return (0);
}

/* --- @pgen_subev@ --- *
 *
 * Subsidiary event handler, mainly for Lim-Lee searches and so on.
 */

int pgen_subev(int rq, pgen_event *ev, void *p)
{
  switch (rq) {
    case PGEN_BEGIN:
      printf("[%s: ", ev->name);
      fflush(stdout);
      break;
    case PGEN_FAIL:
      putchar('.');
      fflush(stdout);
      break;
    case PGEN_PASS:
      putchar('+');
      fflush(stdout);
      break;
    case PGEN_DONE:
      fputs("+]", stdout);
      fflush(stdout);
      break;
    case PGEN_ABORT:
      fputs(" failed]", stdout);
      fflush(stdout);
      break;
  }
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
