/* -*-c-*-
 *
 * Arithmetic for elliptic curves over binary fields
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/sub.h>

#include "ec.h"
#include "ec-guts.h"

/*----- Main code ---------------------------------------------------------*/

static const ec_ops ec_binops, ec_binprojops;

static ec *ecneg(ec_curve *c, ec *d, const ec *p)
{
  EC_COPY(d, p);
  if (d->x)
    d->y = F_ADD(c->f, d->y, d->y, d->x);
  return (d);
}

static ec *ecprojneg(ec_curve *c, ec *d, const ec *p)
{
  EC_COPY(d, p);
  if (d->x) {
    mp *t = F_MUL(c->f, MP_NEW, d->x, d->z);
    d->y = F_ADD(c->f, d->y, d->y, t);
    MP_DROP(t);
  }
  return (d);
}

static ec *ecfind(ec_curve *c, ec *d, mp *x)
{
  field *f = c->f;
  mp *y, *u, *v;

  if (F_ZEROP(f, x))
    y = F_SQRT(f, MP_NEW, c->b);
  else {
    u = F_SQR(f, MP_NEW, x);		/* %$x^2$% */
    y = F_MUL(f, MP_NEW, u, c->a);	/* %$a x^2$% */
    y = F_ADD(f, y, y, c->b);		/* %$a x^2 + b$% */
    v = F_MUL(f, MP_NEW, u, x);		/* %$x^3$% */
    y = F_ADD(f, y, y, v);		/* %$A = x^3 + a x^2 + b$% */
    if (!F_ZEROP(f, y)) {
      u = F_INV(f, u, u);		/* %$x^{-2}$% */
      v = F_MUL(f, v, u, y);	    /* %$B = A x^{-2} = x + a + b x^{-2}$% */
      y = F_QUADSOLVE(f, y, v);		/* %$z^2 + z = B$% */
      if (y) y = F_MUL(f, y, y, x);	/* %$y = z x$% */
      /* Hence %$y^2 + x y = (z^2 + z) x^2 = A$% */
    }
    MP_DROP(u);
    MP_DROP(v);
  }
  if (!y) return (0);
  EC_DESTROY(d);
  d->x = MP_COPY(x);
  d->y = y;
  d->z = MP_COPY(f->one);
  return (d);
}

static ec *ecdbl(ec_curve *c, ec *d, const ec *a)
{
  if (EC_ATINF(a) || F_ZEROP(c->f, a->x))
    EC_SETINF(d);
  else {
    field *f = c->f;
    mp *lambda;
    mp *dx, *dy;

    dx = F_INV(f, MP_NEW, a->x);	/* %$x^{-1}$% */
    dy = F_MUL(f, MP_NEW, dx, a->y);	/* %$y/x$% */
    lambda = F_ADD(f, dy, dy, a->x);	/* %$\lambda = x + y/x$% */

    dx = F_SQR(f, dx, lambda);		/* %$\lambda^2$% */
    dx = F_ADD(f, dx, dx, lambda);	/* %$\lambda^2 + \lambda$% */
    dx = F_ADD(f, dx, dx, c->a);       /* %$x' = a + \lambda^2 + \lambda$% */

    dy = F_ADD(f, MP_NEW, a->x, dx);	/* %$ x + x' $% */
    dy = F_MUL(f, dy, dy, lambda);	/* %$ (x + x') \lambda$% */
    dy = F_ADD(f, dy, dy, a->y);	/* %$ (x + x') \lambda + y$% */
    dy = F_ADD(f, dy, dy, dx);	    /* %$ y' = (x + x') \lambda + y + x'$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = 0;
    MP_DROP(lambda);
  }
  return (d);
}

static ec *ecprojdbl(ec_curve *c, ec *d, const ec *a)
{
  if (EC_ATINF(a) || F_ZEROP(c->f, a->x))
    EC_SETINF(d);
  else {
    field *f = c->f;
    ecctx_bin *cc = (ecctx_bin *)c;
    mp *dx, *dy, *dz, *u, *v;

    dy = F_SQR(f, MP_NEW, a->z);	/* %$z^2$% */
    dx = F_MUL(f, MP_NEW, dy, cc->bb);	/* %$c z^2$% */
    dx = F_ADD(f, dx, dx, a->x);	/* %$x + c z^2$% */
    dz = F_SQR(f, MP_NEW, dx);		/* %$(x + c z^2)^2$% */
    dx = F_SQR(f, dx, dz);		/* %$x' = (x + c z^2)^4$% */

    dz = F_MUL(f, dz, dy, a->x);	/* %$z' = x z^2$% */

    dy = F_SQR(f, dy, a->x);		/* %$x^2$% */
    u = F_MUL(f, MP_NEW, a->y, a->z);	/* %$y z$% */
    u = F_ADD(f, u, u, dz);		/* %$z' + y z$% */
    u = F_ADD(f, u, u, dy);		/* %$u = z' + x^2 + y z$% */

    v = F_SQR(f, MP_NEW, dy);		/* %$x^4$% */
    dy = F_MUL(f, dy, v, dz);		/* %$x^4 z'$% */
    v = F_MUL(f, v, u, dx);		/* %$u x'$% */
    dy = F_ADD(f, dy, dy, v);		/* %$y' = x^4 z' + u x'$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = dz;
    MP_DROP(u);
    MP_DROP(v);
  }
  return (d);
}

static ec *ecadd(ec_curve *c, ec *d, const ec *a, const ec *b)
{
  if (a == b)
    ecdbl(c, d, a);
  else if (EC_ATINF(a))
    EC_COPY(d, b);
  else if (EC_ATINF(b))
    EC_COPY(d, a);
  else {
    field *f = c->f;
    mp *lambda;
    mp *dx, *dy;

    if (!MP_EQ(a->x, b->x)) {
      dx = F_ADD(f, MP_NEW, a->x, b->x); /* %$x_0 + x_1$% */
      dy = F_INV(f, MP_NEW, dx);	/* %$(x_0 + x_1)^{-1}$% */
      dx = F_ADD(f, dx, a->y, b->y);	/* %$y_0 + y_1$% */
      lambda = F_MUL(f, MP_NEW, dy, dx);
				  /* %$\lambda = (y_0 + y_1)/(x_0 + x_1)$% */

      dx = F_SQR(f, dx, lambda);	/* %$\lambda^2$% */
      dx = F_ADD(f, dx, dx, lambda);	/* %$\lambda^2 + \lambda$% */
      dx = F_ADD(f, dx, dx, c->a);	/* %$a + \lambda^2 + \lambda$% */
      dx = F_ADD(f, dx, dx, a->x);    /* %$a + \lambda^2 + \lambda + x_0$% */
      dx = F_ADD(f, dx, dx, b->x);
			   /* %$x' = a + \lambda^2 + \lambda + x_0 + x_1$% */
    } else if (!MP_EQ(a->y, b->y) || F_ZEROP(f, a->x)) {
      EC_SETINF(d);
      return (d);
    } else {
      dx = F_INV(f, MP_NEW, a->x);	/* %$x^{-1}$% */
      dy = F_MUL(f, MP_NEW, dx, a->y);	/* %$y/x$% */
      lambda = F_ADD(f, dy, dy, a->x);	/* %$\lambda = x + y/x$% */

      dx = F_SQR(f, dx, lambda);	/* %$\lambda^2$% */
      dx = F_ADD(f, dx, dx, lambda);	/* %$\lambda^2 + \lambda$% */
      dx = F_ADD(f, dx, dx, c->a);    /* %$x' = a + \lambda^2 + \lambda$% */
      dy = MP_NEW;
    }

    dy = F_ADD(f, dy, a->x, dx);	/* %$ x + x' $% */
    dy = F_MUL(f, dy, dy, lambda);	/* %$ (x + x') \lambda$% */
    dy = F_ADD(f, dy, dy, a->y);	/* %$ (x + x') \lambda + y$% */
    dy = F_ADD(f, dy, dy, dx);	    /* %$ y' = (x + x') \lambda + y + x'$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = 0;
    MP_DROP(lambda);
  }
  return (d);
}

static ec *ecprojadd(ec_curve *c, ec *d, const ec *a, const ec *b)
{
  if (a == b)
    c->ops->dbl(c, d, a);
  else if (EC_ATINF(a))
    EC_COPY(d, b);
  else if (EC_ATINF(b))
    EC_COPY(d, a);
  else {
    field *f = c->f;
    mp *dx, *dy, *dz, *u, *uu, *v, *t, *s, *ss, *r, *w, *l;

    dz = F_SQR(f, MP_NEW, b->z);	/* %$z_1^2$% */
    u = F_MUL(f, MP_NEW, dz, a->x);	/* %$u_0 = x_0 z_1^2$% */
    t = F_MUL(f, MP_NEW, dz, b->z);	/* %$z_1^3$% */
    s = F_MUL(f, MP_NEW, t, a->y);	/* %$s_0 = y_0 z_1^3$% */

    dz = F_SQR(f, dz, a->z);		/* %$z_0^2$% */
    uu = F_MUL(f, MP_NEW, dz, b->x);	/* %$u_1 = x_1 z_0^2$% */
    t = F_MUL(f, t, dz, a->z);		/* %$z_0^3$% */
    ss = F_MUL(f, MP_NEW, t, b->y);	/* %$s_1 = y_1 z_0^3$% */

    w = F_ADD(f, u, u, uu);		/* %$r = u_0 + u_1$% */
    r = F_ADD(f, s, s, ss);		/* %$w = s_0 + s_1$% */
    if (F_ZEROP(f, w)) {
      MP_DROP(w);
      MP_DROP(uu);
      MP_DROP(ss);
      MP_DROP(t);
      MP_DROP(dz);
      if (F_ZEROP(f, r)) {
	MP_DROP(r);
	return (c->ops->dbl(c, d, a));
      } else {
	MP_DROP(r);
	EC_SETINF(d);
	return (d);
      }
    }

    l = F_MUL(f, t, a->z, w);		/* %$l = z_0 w$% */

    dz = F_MUL(f, dz, l, b->z);		/* %$z' = l z_1$% */

    ss = F_MUL(f, ss, r, b->x);		/* %$r x_1$% */
    t = F_MUL(f, uu, l, b->y);		/* %$l y_1$% */
    v = F_ADD(f, ss, ss, t);		/* %$v = r x_1 + l y_1$% */

    t = F_ADD(f, t, r, dz);		/* %$t = r + z'$% */

    uu = F_SQR(f, MP_NEW, dz);		/* %$z'^2$% */
    dx = F_MUL(f, MP_NEW, uu, c->a);	/* %$a z'^2$% */
    uu = F_MUL(f, uu, t, r);		/* %$t r$% */
    dx = F_ADD(f, dx, dx, uu);		/* %$a z'^2 + t r$% */
    r = F_SQR(f, r, w);			/* %$w^2$% */
    uu = F_MUL(f, uu, r, w);		/* %$w^3$% */
    dx = F_ADD(f, dx, dx, uu);		/* %$x' = a z'^2 + t r + w^3$% */

    r = F_SQR(f, r, l);			/* %$l^2$% */
    dy = F_MUL(f, uu, v, r);		/* %$v l^2$% */
    l = F_MUL(f, l, t, dx);		/* %$t x'$% */
    dy = F_ADD(f, dy, dy, l);		/* %$y' = t x' + v l^2$% */

    EC_DESTROY(d);
    d->x = dx;
    d->y = dy;
    d->z = dz;
    MP_DROP(l);
    MP_DROP(r);
    MP_DROP(w);
    MP_DROP(t);
    MP_DROP(v);
  }
  return (d);
}

static int eccheck(ec_curve *c, const ec *p)
{
  field *f = c->f;
  int rc;
  mp *u, *v;

  if (EC_ATINF(p)) return (0);
  v = F_SQR(f, MP_NEW, p->x);
  u = F_MUL(f, MP_NEW, v, p->x);
  v = F_MUL(f, v, v, c->a);
  u = F_ADD(f, u, u, v);
  u = F_ADD(f, u, u, c->b);
  v = F_MUL(f, v, p->x, p->y);
  u = F_ADD(f, u, u, v);
  v = F_SQR(f, v, p->y);
  u = F_ADD(f, u, u, v);
  rc = F_ZEROP(f, u) ? 0 : -1;
  mp_drop(u);
  mp_drop(v);
  return (rc);
}

static int ecprojcheck(ec_curve *c, const ec *p)
{
  ec t = EC_INIT;
  int rc;

  c->ops->fix(c, &t, p);
  rc = eccheck(c, &t);
  EC_DESTROY(&t);
  return (rc);
}

static int eccompr(ec_curve *c, const ec *p)
{
  /* --- Take the LSB of %$y/x$%, or zero if %$x = 0$% ---
   *
   * The negative of a point has %$y' = y + x$%.  Therefore either %$y/x$% or
   * $%(y + x)/x = y/x + 1$% is odd, and this disambiguates, unless %$x =
   * 0$%; but in that case we must have %$y^2 = b$% which has exactly one
   * solution (because squaring is linear in a binary field).
   */

  int ybit;
  field *f = c->f;
  mp *y, *t;
  if (MP_ZEROP(p->x)) ybit = 0;
  else {
    t = F_IN(f, MP_NEW, p->x);
    y = F_IN(f, MP_NEW, p->y);
    t = F_INV(f, t, t);
    t = F_MUL(f, t, y, t);
    t = F_OUT(f, t, t);
    ybit = MP_ODDP(t);
    MP_DROP(y); MP_DROP(t);
  }
  return (ybit);
}

static void ecdestroy(ec_curve *c)
{
  ecctx_bin *cc = (ecctx_bin *)c;
  MP_DROP(cc->c.a);
  MP_DROP(cc->c.b);
  if (cc->bb) MP_DROP(cc->bb);
  DESTROY(cc);
}

/* --- @ec_bin@, @ec_binproj@ --- *
 *
 * Arguments:	@field *f@ = the underlying field for this elliptic curve
 *		@mp *a, *b@ = the coefficients for this curve
 *
 * Returns:	A pointer to the curve, or null.
 *
 * Use:		Creates a curve structure for an elliptic curve defined over
 *		a binary field.  The @binproj@ variant uses projective
 *		coordinates, which can be a win.
 */

ec_curve *ec_bin(field *f, mp *a, mp *b)
{
  ecctx_bin *cc = CREATE(ecctx_bin);
  cc->c.ops = &ec_binops;
  cc->c.f = f;
  cc->c.a = F_IN(f, MP_NEW, a);
  cc->c.b = F_IN(f, MP_NEW, b);
  cc->bb = 0;
  return (&cc->c);
}

ec_curve *ec_binproj(field *f, mp *a, mp *b)
{
  ecctx_bin *cc = CREATE(ecctx_bin);
  int i;
  mp *c, *d;

  cc->c.ops = &ec_binprojops;
  cc->c.f = f;
  cc->c.a = F_IN(f, MP_NEW, a);
  cc->c.b = F_IN(f, MP_NEW, b);

  c = MP_COPY(cc->c.b);
  for (i = 0; i < f->nbits - 2; i++)
    c = F_SQR(f, c, c);
  d = F_SQR(f, MP_NEW, c); d = F_SQR(f, d, d);
  if (!MP_EQ(d, cc->c.b)) {
    MP_DROP(c);
    MP_DROP(d);
    MP_DROP(cc->c.a);
    MP_DROP(cc->c.b);
    DESTROY(cc);
    return (0);
  }
  cc->bb = c;
  MP_DROP(d);
  return (&cc->c);
}

static const ec_ops ec_binops = {
  "bin",
  ecdestroy, ec_stdsamep, ec_idin, ec_idout, ec_idfix,
  ecfind, ecneg, ecadd, ec_stdsub, ecdbl, eccheck, eccompr
};

static const ec_ops ec_binprojops = {
  "binproj",
  ecdestroy, ec_stdsamep, ec_projin, ec_projout, ec_projfix,
  ecfind, ecprojneg, ecprojadd, ec_stdsub, ecprojdbl, ecprojcheck, eccompr
};

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

#define MP(x) mp_readstring(MP_NEW, #x, 0, 0)

int main(int argc, char *argv[])
{
  field *f;
  ec_curve *c;
  ec g = EC_INIT, d = EC_INIT;
  mp *p, *a, *b, *r, *beta;
  int i, n = argc == 1 ? 1 : atoi(argv[1]);

  printf("ec-bin: ");
  fflush(stdout);
  a = MP(0x7ffffffffffffffffffffffffffffffffffffffff);
  b = MP(0x6645f3cacf1638e139c6cd13ef61734fbc9e3d9fb);
  p = MP(0x800000000000000000000000000000000000000c9);
  beta = MP(0x715169c109c612e390d347c748342bcd3b02a0bef);
  r = MP(0x040000000000000000000292fe77e70c12a4234c32);

  f = field_binnorm(p, beta);
  c = ec_binproj(f, a, b);
  g.x = MP(0x0311103c17167564ace77ccb09c681f886ba54ee8);
  g.y = MP(0x333ac13c6447f2e67613bf7009daf98c87bb50c7f);

  for (i = 0; i < n; i++) {
    ec_mul(c, &d, &g, r);
    if (EC_ATINF(&d)) {
      fprintf(stderr, "zero too early\n");
      return (1);
    }
    ec_add(c, &d, &d, &g);
    if (!EC_ATINF(&d)) {
      fprintf(stderr, "didn't reach zero\n");
      MP_EPRINTX("d.x", d.x);
      MP_EPRINTX("d.y", d.y);
      return (1);
    }
    ec_destroy(&d);
  }

  ec_destroy(&g);
  ec_destroycurve(c);
  F_DESTROY(f);
  MP_DROP(p); MP_DROP(a); MP_DROP(b); MP_DROP(r); MP_DROP(beta);
  assert(!mparena_count(&mparena_global));
  printf("ok\n");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
