/* -*-c-*-
 *
 * Sequential bit scan of multiprecision integers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPSCAN_H
#define CATACOMB_MPSCAN_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MPW_H
#  include "mpw.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct mpscan {
  const mpw *v, *vl;			/* Vector of words to scan */
  mpw w;				/* Current word to scan */
  int bits;				/* Number of bits left in @w@ */
} mpscan;

/*----- Right-to-left scanning --------------------------------------------*/

/* --- @mpscan_initx@ --- *
 *
 * Arguments:	@mpscan *m@ = pointer to bitscanner structure
 *		@const mpw *v, *vl@ = vector of words to scan
 *
 * Returns:	---
 *
 * Use:		Initializes a bitscanner from a low-level base-and-limit
 *		representation of an integer.  Initially no bit is ready; you
 *		must call @mpscan_step@ before anything useful will come
 *		out.
 */

#define MPSCAN_INITX(m_, v_, vl_) do {					\
  mpscan *_m = (m_);							\
  _m->v = (v_);								\
  _m->vl = (vl_);							\
  _m->bits = 0;								\
} while (0)

extern void mpscan_initx(mpscan */*m*/, const mpw */*v*/, const mpw */*vl*/);

/* --- @mpscan_step@ --- *
 *
 * Arguments:	@mpscan *m@ = pointer to bitscanner
 *
 * Returns:	Nonzero if there is another bit to read.
 *
 * Use:		Steps on to the next bit in the integer.  The macro version
 *		evaluates its argument multiple times.
 */

#define MPSCAN_STEP(m)							\
  ((m)->bits ? ((m)->w >>= 1, (m)->bits--, 1) :				\
   (m)->v < (m)->vl ? ((m)->w = *(m)->v++,				\
		       (m)->bits = MPW_BITS - 1, 1) :			\
   0)

extern int mpscan_step(mpscan */*m*/);

/* --- @mpscan_bit@ --- *
 *
 * Arguments:	@const mpscan *m@ = pointer to bitscanner
 *
 * Returns:	The value of the current bit.
 *
 * Use:		Reads the value of the current bit looked at by a
 *		bitscanner.
 */

#define MPSCAN_BIT(m) ((m)->w & 1)

extern int mpscan_bit(const mpscan */*m*/);

/*----- Left-to right-scanning --------------------------------------------*/

/* --- @mpscan_rinitx@ --- *
 *
 * Arguments:	@mpscan *m@ = pointer to bitscanner structure
 *		@const mpw *v, *vl@ = vector of words to scan
 *
 * Returns:	---
 *
 * Use:		Initializes a reverse bitscanner from a low-level
 *		vector-and-length representation of an integer.  Initially no
 *		bit is ready; you must call @mpscan_rstep@ before anything
 *		useful will come out.
 */

#define MPSCAN_RINITX(m_, v_, vl_) do {					\
  mpscan *_m = (m_);							\
  _m->v = (v_);								\
  _m->vl = (vl_);							\
  while (_m->vl > _m->v && !_m->vl[-1])					\
    _m->vl--;								\
  _m->bits = 0;								\
} while (0)

extern void mpscan_rinitx(mpscan */*m*/,
			  const mpw */*v*/, const mpw */*vl*/);

/* --- @mpscan_rstep@ --- *
 *
 * Arguments:	@mpscan *m@ = pointer to bitscanner
 *
 * Returns:	Nonzero if there is another bit to read.
 *
 * Use:		Steps on to the next bit in the integer.  The macro version
 *		evaluates its argument multiple times.
 */

#define MPSCAN_RSTEP(m)							\
  ((m)->bits ? ((m)->w <<= 1, (m)->bits--, 1) :				\
   (m)->vl > (m)->v ? ((m)->w = *--(m)->vl,				\
		       (m)->bits = MPW_BITS - 1, 1) :			\
   0)

extern int mpscan_rstep(mpscan */*m*/);

/* --- @mpscan_rbit@ --- *
 *
 * Arguments:	@const mpscan *m@ = pointer to bitscanner
 *
 * Returns:	The value of the current bit.
 *
 * Use:		Reads the value of the current bit looked at by a
 *		reverse bitscanner.
 */

#define MPSCAN_RBIT(m) (((m)->w >> (MPW_BITS - 1)) & 1)

extern int mpscan_rbit(const mpscan */*m*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
