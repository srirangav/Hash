/* -*-c-*-
 *
 * Standard group operations
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "group.h"
#include "pgen.h"

/*----- Handy functions ---------------------------------------------------*/

/* --- @group_check@ --- *
 *
 * Arguments:	@group *g@ = an abstract group
 *		@ge *x@ = a group element
 *
 * Returns:	Zero on success, nonzero for failure.
 *
 * Use:		Checks that @x@ is a valid group element.  This may take a
 *		while, since it checks that %$x \ne 1$% and %$x^r = 1$%.
 */

int group_check(group *g, ge *x)
{
  ge *d = G_CREATE(g);
  int rc;

  G_EXP(g, d, x, g->r);
  rc = (G_IDENTP(g, d) && !G_IDENTP(g, x));
  G_DESTROY(g, d);
  if (!rc) return (-1);
  return (0);
}

/* --- @group_samep@ --- *
 *
 * Arguments:	@group *g, *h@ = two abstract groups
 *
 * Returns:	Nonzero if the groups are in fact identical (not just
 *		isomorphic).
 *
 * Use:		Checks to see whether two groups are actually the same.  This
 *		function does the full check: the group operatrion @samep@
 *		just does the group-specific details.
 */

int group_samep(group *g, group *h)
{
  return (g == h || (g->ops == h->ops &&
		     MP_EQ(g->r, h->r) && MP_EQ(g->h, h->h) &&
		     G_EQ(g, g->i, h->i) && G_EQ(g, g->g, h->g) &&
		     G_SAMEP(g, h)));
}

/*----- Standard implementations ------------------------------------------*/

/* --- @group_stdidentp@ --- *
 *
 * Arguments:	@group *g@ = abstract group
 *		@ge *x@ = group element
 *
 * Returns:	Nonzero if %$x$% is the group identity.
 */

int group_stdidentp(group *g, ge *x) { return (G_EQ(g, x, g->i)); }

/* --- @group_stdsqr@ --- *
 *
 * Arguments:	@group *g@ = abstract group
 *		@ge *d@ = destination pointer
 *		@ge *x@ = group element
 *
 * Returns:	---
 *
 * Use:		Computes %$d = x^2$% as %$d = x x$%.
 */

void group_stdsqr(group *g, ge *d, ge *x) { G_MUL(g, d, x, x); }

/* --- @group_stddiv@ --- *
 *
 * Arguments:	@group *g@ = abstract group
 *		@ge *d@ = destination pointer
 *		@ge *x@ = dividend
 *		@ge *y@ = divisor
 *
 * Returns:	---
 *
 * Use:		Computes %$d = x/y$% as %$d = x y^{-1}$%.
 */

void group_stddiv(group *g, ge *d, ge *x, ge *y)
  { G_INV(g, d, y); G_MUL(g, d, x, d); }

/* --- @group_stdtoec@ --- *
 *
 * Arguments:	@group *g@ = abstract group
 *		@ec *d@ = destination point
 *		@ge *x@ = group element
 *
 * Returns:	@-1@, indicating failure.
 *
 * Use:		Fails to convert a group element to an elliptic curve point.
 */

int group_stdtoec(group *g, ec *d, ge *x) { return (-1); }

/* --- @group_stdfromec@ --- *
 *
 * Arguments:	@group *g@ = abstract group
 *		@ge *d@ = destination pointer
 *		@const ec *p@ = elliptic curve point
 *
 * Returns:	Zero for success, @-1@ on failure.
 *
 * Use:		Converts %$p$% to a group element by converting its %$x$%-
 *		coordinate.
 */

int group_stdfromec(group *g, ge *d, const ec *p)
  { if (EC_ATINF(p)) return (-1); return (G_FROMINT(g, d, p->x)); }

/* --- @group_stdcheck@ --- *
 *
 * Arguments:	@group *g@ = abstract group
 *		@grand *gr@ = random number source.
 *
 * Returns:	Null on success, or a pointer to an error message.
 */

const char *group_stdcheck(group *g, grand *gr)
{
  ge *t;
  int rc;

  if (!pgen_primep(g->r, gr)) return ("group order not prime");
  t = G_CREATE(g); G_EXP(g, t, g->g, g->r);
  rc = G_IDENTP(g, t); G_DESTROY(g, t);
  if (!rc) return ("generator not in the group");
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
