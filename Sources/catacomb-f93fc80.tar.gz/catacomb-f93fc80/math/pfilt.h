/* -*-c-*-
 *
 * Finding and testing prime numbers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_PFILT_H
#define CATACOMB_PFILT_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

#ifndef CATACOMB_PRIMETAB_H
#  include "primetab.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct pfilt {
  mp *m;
  smallprime r[NPRIME];
} pfilt;

/*----- Functions provided ------------------------------------------------*/

/* --- @pfilt_smallfactor@ --- *
 *
 * Arguments:	@mp *m@ = integer to test
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Tests a number by dividing by a number of small primes.  This
 *		is a useful first step if you're testing random primes; for
 *		sequential searches, @pfilt_create@ works better.
 */

extern int pfilt_smallfactor(mp */*m*/);

/* --- @pfilt_create@ --- *
 *
 * Arguments:	@pfilt *p@ = pointer to prime filtering context
 *		@mp *m@ = pointer to initial number to test
 *
 * Returns:	A @PGEN@ result code.
 *
 * Use:		Tests an initial number for primality by computing its
 *		residue modulo various small prime numbers.  This is fairly
 *		quick, but not particularly certain.  If a @PGEN_TRY@
 *		result is returned, perform Rabin-Miller tests to confirm.
 */

extern int pfilt_create(pfilt */*p*/, mp */*m*/);

/* --- @pfilt_destroy@ --- *
 *
 * Arguments:	@pfilt *p@ = pointer to prime filtering context
 *
 * Returns:	---
 *
 * Use:		Discards a context and all the resources it holds.
 */

extern void pfilt_destroy(pfilt */*p*/);

/* --- @pfilt_step@ --- *
 *
 * Arguments:	@pfilt *p@ = pointer to prime filtering context
 *		@mpw step@ = how much to step the number
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Steps a number by a small amount.  Stepping is much faster
 *		than initializing with a new number.  The test performed is
 *		the same simple one used by @primetab_create@, so @PGEN_TRY@
 *		results should be followed up by a Rabin-Miller test.
 */

extern int pfilt_step(pfilt */*p*/, mpw /*step*/);

/* --- @pfilt_muladd@ --- *
 *
 * Arguments:	@pfilt *p@ = destination prime filtering context
 *		@const pfilt *q@ = source prime filtering context
 *		@mpw m@ = number to multiply by
 *		@mpw a@ = number to add
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Multiplies the number in a prime filtering context by a
 *		small value and then adds a small value.  The destination
 *		should either be uninitialized or the same as the source.
 *
 *		Common things to do include multiplying by 2 and adding 0 to
 *		turn a prime into a jump for finding other primes with @q@ as
 *		a factor of @p - 1@, or multiplying by 2 and adding 1.
 */

extern int pfilt_muladd(pfilt */*p*/, const pfilt */*q*/,
			mpw /*m*/, mpw /*a*/);

/* --- @pfilt_jump@ --- *
 *
 * Arguments:	@pfilt *p@ = pointer to prime filtering context
 *		@const pfilt *j@ = pointer to another filtering context
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Steps a number by a large amount.  Even so, jumping is much
 *		faster than initializing a new number.  The test peformed is
 *		the same simple one used by @primetab_create@, so @PGEN_TRY@
 *		results should be followed up by a Rabin-Miller test.
 *
 *		Note that the number stored in the @j@ context is probably
 *		better off being even than prime.  The important thing is
 *		that all of the residues for the number have already been
 *		computed.
 */

extern int pfilt_jump(pfilt */*p*/, const pfilt */*j*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
