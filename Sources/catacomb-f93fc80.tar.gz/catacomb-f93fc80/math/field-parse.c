/* -*-c-*-
 *
 * Parse field descriptions
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "field.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @field_parse@ --- *
 *
 * Arguments:	@qd_parse *qd@ = parser context
 *
 * Returns:	Field pointer if OK, or null.
 *
 * Use:		Parses a field description, which has the form
 *
 *		  * `prime', `niceprime' or `binpoly'
 *		  * an optional `:'
 *		  * the field modulus
 */

field *field_parse(qd_parse *qd)
{
  field *f = 0;
  mp *m = MP_NEW, *b = MP_NEW;

  switch (qd_enum(qd, "prime,niceprime,binpoly,binnorm")) {
    case 0:
      qd_delim(qd, ':');
      if ((m = qd_getmp(qd)) == 0) goto done;
      f = field_prime(m);
      break;
    case 1:
      qd_delim(qd, ':');
      if ((m = qd_getmp(qd)) == 0) goto done;
      f = field_niceprime(m);
      break;
    case 2:
      qd_delim(qd, ':');
      if ((m = qd_getmp(qd)) == 0) goto done;
      f = field_binpoly(m);
      break;
    case 3:
      qd_delim(qd, ':');
      if ((m = qd_getmp(qd)) == 0) goto done;
      qd_delim(qd, ',');
      if ((b = qd_getmp(qd)) == 0) goto done;
      f = field_binnorm(m, b);
      break;
    default:
      goto done;
  }
  if (!f) qd->e = "bad field parameters";
done:
  mp_drop(m);
  mp_drop(b);
  return (f);
}

/*----- That's all, folks -------------------------------------------------*/
