/* -*-c-*-
 *
 * Efficient reduction modulo nice primes
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPREDUCE_H
#define CATACOMB_MPREDUCE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct mpreduce_instr {
  unsigned op;				/* Instruction opcode */
  size_t argx, argy;			/* Immediate arguments */
} mpreduce_instr;

enum {
  MPRI_ADD,				/* Add @p@ offset by @x@ words */
  MPRI_ADDLSL,				/* Add @p << y@ offset by @x@ */
  MPRI_SUB,				/* Sub @p@ offset by @x@ words */
  MPRI_SUBLSL,				/* Sub @p << y@ offset by @x@ */
  MPRI_MAX
};

typedef struct mpreduce {
  size_t lim;				/* Word containing top bit */
  unsigned s;				/* Shift for top word */
  mp *p;				/* Copy of the modulus */
  size_t in;				/* Number of instruction words */
  mpreduce_instr *iv;			/* Vector of instructions */
} mpreduce;

/*----- Functions provided ------------------------------------------------*/

/* --- @mpreduce_create@ --- *
 *
 * Arguments:	@gfreduce *r@ = structure to fill in
 *		@mp *x@ = an integer
 *
 * Returns:	Zero if successful; nonzero on failure.  The current
 *		algorithm always succeeds when given positive @x@.  Earlier
 *		versions used to fail on particular kinds of integers, but
 *		this is guaranteed not to happen any more.
 *
 * Use:		Initializes a context structure for reduction.
 */

extern int mpreduce_create(mpreduce */*r*/, mp */*p*/);

/* --- @mpreduce_destroy@ --- *
 *
 * Arguments:	@mpreduce *r@ = structure to free
 *
 * Returns:	---
 *
 * Use:		Reclaims the resources from a reduction context.
 */

extern void mpreduce_destroy(mpreduce */*r*/);

/* --- @mpreduce_dump@ --- *
 *
 * Arguments:	@mpreduce *r@ = structure to dump
 *		@FILE *fp@ = file to dump on
 *
 * Returns:	---
 *
 * Use:		Dumps a reduction context.
 */

extern void mpreduce_dump(mpreduce */*r*/, FILE */*fp*/);

/* --- @mpreduce_do@ --- *
 *
 * Arguments:	@mpreduce *r@ = reduction context
 *		@mp *d@ = destination
 *		@mp *x@ = source
 *
 * Returns:	Destination, @x@ reduced modulo the reduction poly.
 */

extern mp *mpreduce_do(mpreduce */*r*/, mp */*d*/, mp */*x*/);

/* --- @mpreduce_exp@ --- *
 *
 * Arguments:	@mpreduce *mr@ = pointer to reduction context
 *		@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$a^e \bmod m$%.
 */

extern mp *mpreduce_exp(mpreduce */*mr*/, mp */*d*/, mp */*a*/, mp */*e*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
