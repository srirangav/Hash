/* -*-c-*-
 *
 * Montgomery reduction
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPMONT_H
#define CATACOMB_MPMONT_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

/*----- Notes on Montgomery reduction -------------------------------------*
 *
 * Given a little bit of precomputation, Montgomery reduction enables modular
 * reductions of products to be calculated rather rapidly, without recourse
 * to annoying things like division.
 *
 * Before starting, you need to do a little work.  In particular, the
 * following things need to be worked out:
 *
 *   * %$m$%, which is the modulus you'll be working with.  This must be odd,
 *     otherwise the whole thing doesn't work.  You're better off using
 *     Barrett reduction if your modulus might be even.
 *
 *   * %$b$%, the radix of the number system you're in (here, it's
 *     @MPW_MAX + 1@).
 *
 *   * %$-m^{-1} \bmod b$%, a useful number for the reduction step.  (This
 *     means that the modulus mustn't be even.  This shouldn't be a problem.)
 *
 *   * %$R = b^n > m > b^{n - 1}$%, or at least %$\log_2 R$%.
 *
 *   * %$R \bmod m$% and %$R^2 \bmod m$%, which are useful when doing
 *     calculations such as exponentiation.
 *
 * The result of a Montgomery reduction of %$x$% is %$x R^{-1} \bmod m$%,
 * which doesn't look ever-so useful.  The trick is to initially apply a
 * factor of %$R$% to all of your numbers so that when you multiply and
 * perform a Montgomery reduction you get %$(x R \cdot y R) R^{-1} \bmod m$%,
 * which is just %$x y R \bmod m$%.  Thanks to distributivity, even additions
 * and subtractions can be performed on numbers in this form -- the extra
 * factor of %$R$% just runs through all the calculations until it's finally
 * stripped out by a final reduction operation.
 */

/*----- Data structures ---------------------------------------------------*/

/* --- A Montgomery reduction context --- */

typedef struct mpmont {
  mp *m;				/* Modulus */
  mp *mi;				/* %$-m^{-1} \bmod R$% */
  size_t n;				/* %$\log_b R$% */
  mp *r, *r2;				/* %$R \bmod m$%, %$R^2 \bmod m$% */
} mpmont;

/*----- Functions provided ------------------------------------------------*/

/* --- @mpmont_create@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *m@ = modulus to use
 *
 * Returns:	Zero on success, nonzero on error.
 *
 * Use:		Initializes a Montgomery reduction context ready for use.
 *		The argument @m@ must be a positive odd integer.
 */

extern int mpmont_create(mpmont */*mm*/, mp */*m*/);

/* --- @mpmont_destroy@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to a Montgomery reduction context
 *
 * Returns:	---
 *
 * Use:		Disposes of a context when it's no longer of any use to
 *		anyone.
 */

extern void mpmont_destroy(mpmont */*mm*/);

/* --- @mpmont_reduce@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *d@ = destination
 *		@mp *a@ = source, assumed positive
 *
 * Returns:	Result, %$a R^{-1} \bmod m$%.
 */

extern mp *mpmont_reduce(mpmont */*mm*/, mp */*d*/, mp */*a*/);

/* --- @mpmont_mul@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *d@ = destination
 *		@mp *a, *b@ = sources, assumed positive
 *
 * Returns:	Result, %$a b R^{-1} \bmod m$%.
 */

extern mp *mpmont_mul(mpmont */*mm*/, mp */*d*/, mp */*a*/, mp */*b*/);

/* --- @mpmont_expr@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$(a R^{-1})^e R \bmod m$%.  This is useful if
 *		further modular arithmetic is to be performed on the result.
 */

extern mp *mpmont_expr(mpmont */*mm*/, mp */*d*/, mp */*a*/, mp */*e*/);

/* --- @mpmont_exp@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$a^e \bmod m$%.
 */

extern mp *mpmont_exp(mpmont */*mm*/, mp */*d*/, mp */*a*/, mp */*e*/);

/* --- @mpmont_mexpr@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *d@ = fake destination
 *		@const mp_expfactor *f@ = pointer to array of factors
 *		@size_t n@ = number of factors supplied
 *
 * Returns:	If the bases are %$g_0, g_1, \ldots, g_{n-1}$% and the
 *		exponents are %$e_0, e_1, \ldots, e_{n-1}$% then the result
 *		is:
 *
 *		%$g_0^{e_0} g_1^{e_1} \ldots g_{n-1}^{e_{n-1}} \bmod m$%
 *
 *
 *		except that the %$g_i$% and result are in Montgomery form.
 */

extern mp *mpmont_mexpr(mpmont */*mm*/, mp */*d*/,
			const mp_expfactor */*f*/, size_t /*n*/);

/* --- @mpmont_mexp@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *d@ = fake destination
 *		@const mp_expfactor *f@ = pointer to array of factors
 *		@size_t n@ = number of factors supplied
 *
 * Returns:	Product of bases raised to exponents, all mod @m@.
 *
 * Use:		Convenient interface over @mpmont_mexpr@.
 */

extern mp *mpmont_mexp(mpmont */*mm*/, mp */*d*/,
		       const mp_expfactor */*f*/, size_t /*n*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
