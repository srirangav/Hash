/* -*-c-*-
 *
 * Exponentiation operations for elliptic curves
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_EC_EXP_H
#define CATACOMB_EC_EXP_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Exponentation definitions -----------------------------------------*/

#define EXP_TYPE ec

#define EXP_COPY(d, p) do {						\
  (d).x = MP_COPY((p).x);						\
  (d).y = MP_COPY((p).y);						\
  (d).z = (p).z ? MP_COPY((p).z) : MP_NEW;				\
} while (0)
#define EXP_DROP(x) EC_DESTROY(&(x))

#define EXP_MUL(a, x) EC_ADD(c, &(a), &(a), &(x))
#define EXP_SQR(a) EC_DBL(c, &(a), &(a))
#define EXP_FIX(x)

#define EXP_SETMUL(d, x, y) do {					\
  EC_CREATE(&(d));							\
  EC_ADD(c, &(d), &(x), &(y));						\
} while (0)
#define EXP_SETSQR(d, x) do {						\
  EC_CREATE(&(d));							\
  EC_DBL(c, &(d), &(x));						\
} while (0)

#include "exp.h"

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
