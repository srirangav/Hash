/* -*-c-*-
 *
 * Finding and testing prime numbers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"
#include "mpint.h"
#include "pfilt.h"
#include "pgen.h"
#include "primetab.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @smallenough@ --- *
 *
 * Arguments:	@mp *m@ = integer to test
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Assuming that @m@ has been tested by trial division on every
 *		prime in the small-primes array, this function will return
 *		@PGEN_DONE@ if the number is less than the square of the
 *		largest small prime.
 */

static int smallenough(mp *m)
{
  static mp *max = 0;
  int rc = PGEN_TRY;

  if (!max) {
    max = mp_fromuint(MP_NEW, MAXPRIME);
    max = mp_sqr(max, max);
    max->a->n--; /* Permanent allocation */
  }
  if (MP_CMP(m, <=, MP_ONE))
    rc = PGEN_FAIL;
  else if (MP_CMP(m, <, max))
    rc = PGEN_DONE;
  return (rc);
}

/* --- @pfilt_smallfactor@ --- *
 *
 * Arguments:	@mp *m@ = integer to test
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Tests a number by dividing by a number of small primes.  This
 *		is a useful first step if you're testing random primes; for
 *		sequential searches, @pfilt_create@ works better.
 */

int pfilt_smallfactor(mp *m)
{
  int rc = PGEN_TRY;
  int i;
  size_t sz = MP_LEN(m);
  mparena *a = m->a ? m->a : MPARENA_GLOBAL;
  mpw *v = mpalloc(a, sz);

  /* --- Fill in the residues --- */

  for (i = 0; i < NPRIME; i++) {
    if (!mpx_udivn(v, v + sz, m->v, m->vl, primetab[i])) {
      if (MP_LEN(m) == 1 && m->v[0] == primetab[i])
	rc = PGEN_DONE;
      else
	rc = PGEN_FAIL;
      break;
    }
  }

  /* --- Check for small primes --- */

  if (rc == PGEN_TRY)
    rc = smallenough(m);

  /* --- Done --- */

  mpfree(a, v);
  return (rc);
}

/* --- @pfilt_create@ --- *
 *
 * Arguments:	@pfilt *p@ = pointer to prime filtering context
 *		@mp *m@ = pointer to initial number to test
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Tests an initial number for primality by computing its
 *		residue modulo various small prime numbers.  This is fairly
 *		quick, but not particularly certain.  If a @PGEN_TRY@
 *		result is returned, perform Rabin-Miller tests to confirm.
 */

int pfilt_create(pfilt *p, mp *m)
{
  int rc = PGEN_TRY;
  int i;
  size_t sz = MP_LEN(m);
  mparena *a = m->a ? m->a : MPARENA_GLOBAL;
  mpw *v = mpalloc(a, sz);

  /* --- Take a copy of the number --- */

  mp_shrink(m);
  p->m = MP_COPY(m);

  /* --- Fill in the residues --- */

  for (i = 0; i < NPRIME; i++) {
    p->r[i] = mpx_udivn(v, v + sz, m->v, m->vl, primetab[i]);
    if (!p->r[i] && rc == PGEN_TRY) {
      if (MP_LEN(m) == 1 && m->v[0] == primetab[i])
	rc = PGEN_DONE;
      else
	rc = PGEN_FAIL;
    }
  }

  /* --- Check for small primes --- */

  if (rc == PGEN_TRY)
    rc = smallenough(m);

  /* --- Done --- */

  mpfree(a, v);
  return (rc);
}

/* --- @pfilt_destroy@ --- *
 *
 * Arguments:	@pfilt *p@ = pointer to prime filtering context
 *
 * Returns:	---
 *
 * Use:		Discards a context and all the resources it holds.
 */

void pfilt_destroy(pfilt *p)
{
  mp_drop(p->m);
}

/* --- @pfilt_step@ --- *
 *
 * Arguments:	@pfilt *p@ = pointer to prime filtering context
 *		@mpw step@ = how much to step the number
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Steps a number by a small amount.  Stepping is much faster
 *		than initializing with a new number.  The test performed is
 *		the same simple one used by @primetab_create@, so @PGEN_TRY@
 *		results should be followed up by a Rabin-Miller test.
 */

int pfilt_step(pfilt *p, mpw step)
{
  int rc = PGEN_TRY;
  int i;

  /* --- Add the step on to the number --- */

  p->m = mp_split(p->m);
  mp_ensure(p->m, MP_LEN(p->m) + 1);
  mpx_uaddn(p->m->v, p->m->vl, step);
  mp_shrink(p->m);

  /* --- Update the residue table --- */

  for (i = 0; i < NPRIME; i++) {
    p->r[i] = (p->r[i] + step) % primetab[i];
    if (!p->r[i] && rc == PGEN_TRY) {
      if (MP_LEN(p->m) == 1 && p->m->v[0] == primetab[i])
	rc = PGEN_DONE;
      else
	rc = PGEN_FAIL;
    }
  }

  /* --- Check for small primes --- */

  if (rc == PGEN_TRY)
    rc = smallenough(p->m);

  /* --- Done --- */

  return (rc);
}

/* --- @pfilt_muladd@ --- *
 *
 * Arguments:	@pfilt *p@ = destination prime filtering context
 *		@const pfilt *q@ = source prime filtering context
 *		@mpw m@ = number to multiply by
 *		@mpw a@ = number to add
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Multiplies the number in a prime filtering context by a
 *		small value and then adds a small value.  The destination
 *		should either be uninitialized or the same as the source.
 *
 *		Common things to do include multiplying by 2 and adding 0 to
 *		turn a prime into a jump for finding other primes with @q@ as
 *		a factor of @p - 1@, or multiplying by 2 and adding 1.
 */

int pfilt_muladd(pfilt *p, const pfilt *q, mpw m, mpw a)
{
  int rc = PGEN_TRY;
  int i;

  /* --- Multiply the big number --- */

  {
    mp *d = mp_new(MP_LEN(q->m) + 2, q->m->f);
    mpx_umuln(d->v, d->vl, q->m->v, q->m->vl, m);
    mpx_uaddn(d->v, d->vl, a);
    if (p == q)
      mp_drop(p->m);
    mp_shrink(d);
    p->m = d;
  }

  /* --- Gallivant through the residue table --- */

  for (i = 0; i < NPRIME; i++) {
    p->r[i] = (q->r[i] * m + a) % primetab[i];
    if (!p->r[i] && rc == PGEN_TRY) {
      if (MP_LEN(p->m) == 1 && p->m->v[0] == primetab[i])
	rc = PGEN_DONE;
      else
	rc = PGEN_FAIL;
    }
  }

  /* --- Check for small primes --- */

  if (rc == PGEN_TRY)
    rc = smallenough(p->m);

  /* --- Finished --- */

  return (rc);
}

/* --- @pfilt_jump@ --- *
 *
 * Arguments:	@pfilt *p@ = pointer to prime filtering context
 *		@const pfilt *j@ = pointer to another filtering context
 *
 * Returns:	One of the @PGEN@ result codes.
 *
 * Use:		Steps a number by a large amount.  Even so, jumping is much
 *		faster than initializing a new number.  The test peformed is
 *		the same simple one used by @primetab_create@, so @PGEN_TRY@
 *		results should be followed up by a Rabin-Miller test.
 *
 *		Note that the number stored in the @j@ context is probably
 *		better off being even than prime.  The important thing is
 *		that all of the residues for the number have already been
 *		computed.
 */

int pfilt_jump(pfilt *p, const pfilt *j)
{
  int rc = PGEN_TRY;
  int i;

  /* --- Add the step on --- */

  p->m = mp_add(p->m, p->m, j->m);

  /* --- Update the residue table --- */

  for (i = 0; i < NPRIME; i++) {
    p->r[i] = p->r[i] + j->r[i];
    if (p->r[i] > primetab[i])
      p->r[i] -= primetab[i];
    if (!p->r[i] && rc == PGEN_TRY) {
      if (MP_LEN(p->m) == 1 && p->m->v[0] == primetab[i])
	rc = PGEN_DONE;
      else
	rc = PGEN_FAIL;
    }
  }

  /* --- Check for small primes --- */

  if (rc == PGEN_TRY)
    rc = smallenough(p->m);

  /* --- Done --- */

  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
