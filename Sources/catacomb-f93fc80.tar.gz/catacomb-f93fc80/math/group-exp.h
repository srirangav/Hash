/* -*-c-*-
 *
 * Exponentiation operations for abstract groups
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GROUP_EXP_H
#define CATACOMB_GROUP_EXP_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Exponentation definitions -----------------------------------------*/

#define EXP_TYPE ge *

#define EXP_COPY(d, p) do {						\
  (d) = G_CREATE(gg);							\
  G_COPY(gg, (d), (p));							\
} while (0)
#define EXP_DROP(x) G_DESTROY(gg, (x))

#define EXP_MUL(a, x) G_MUL(gg, (a), (a), (x))
#define EXP_SQR(a) G_SQR(gg, (a), (a));
#define EXP_FIX(x)

#define EXP_SETMUL(d, x, y) do {					\
  (d) = G_CREATE(gg);							\
  G_MUL(gg, (d), (x), (y));						\
} while (0)
#define EXP_SETSQR(d, x) do {						\
  (d) = G_CREATE(gg);							\
  G_SQR(gg, (d), (x));							\
} while (0)

#include "exp.h"

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
