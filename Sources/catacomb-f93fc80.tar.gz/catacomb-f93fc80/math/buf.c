/* -*-c-*-
 *
 * Buffer handling
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <string.h>

#include "mp.h"
#include "ec.h"
#include "buf.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @buf_getmp@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *
 * Returns:	A multiprecision integer, or null if there wasn't one there.
 *
 * Use:		Gets a multiprecision integer from a buffer.
 */

mp *buf_getmp(buf *b)
{
  uint16 sz;
  size_t n;
  mp *m;
  if (buf_getu16(b, &sz) || buf_ensure(b, sz))
    return (0);
  m = mp_loadb(MP_NEW, BCUR(b), sz);
  n = mp_octets(m);
  if (n != sz && n != 0 && sz != 1) {
    mp_drop(m);
    return (0);
  }
  BSTEP(b, sz);
  return (m);
}

/* --- @buf_putmp@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@mp *m@ = a multiprecision integer
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts a multiprecision integer to a buffer.
 */

int buf_putmp(buf *b, mp *m)
{
  size_t sz = mp_octets(m);
  assert(sz < MASK16);
  if (!sz) sz = 1;
  if (buf_putu16(b, sz) || buf_ensure(b, sz))
    return (-1);
  mp_storeb(m, BCUR(b), sz);
  BSTEP(b, sz);
  return (0);
}

/* --- @buf_getec@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@ec *p@ = where to put the point
 *
 * Returns:	Zero if it worked, nonzero if it failed.
 *
 * Use:		Gets a multiprecision integer from a buffer.  The point must
 *		be initialized.
 */

int buf_getec(buf *b, ec *p)
{
  mp *x = 0, *y = 0;
  uint16 n;
  if (buf_ensure(b, 2)) return (-1);
  n = LOAD16(BCUR(b)); if (!n) { BSTEP(b, 2); EC_SETINF(p); return (0); }
  if ((x = buf_getmp(b)) == 0 || (y = buf_getmp(b)) == 0) {
    mp_drop(x); mp_drop(y); return (-1);
  }
  EC_DESTROY(p); p->x = x; p->y = y; p->z = 0;
  return (0);
}

/* --- @buf_putec@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@ec *p@ = an elliptic curve point
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts an elliptic curve point to a buffer.
 */

int buf_putec(buf *b, ec *p)
{
  if (EC_ATINF(p)) return (buf_putu16(b, 0));
  if (buf_putmp(b, p->x) || buf_putmp(b, p->y)) return (-1);
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
