/* -*-c-*-
 *
 * Arithmetic on binary polynomials
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_GF_H
#define CATACOMB_GF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

#ifndef CATACOMB_GFX_H
#  include "gfx.h"
#endif

/*----- Functions provided ------------------------------------------------*/

/* --- @gf_add@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a, *b@ = sources
 *
 * Returns:	Result, @a@ added to @b@.
 */

extern mp *gf_add(mp */*d*/, mp */*a*/, mp */*b*/);
#define gf_sub gf_add

/* --- @gf_mul@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a, *b@ = sources
 *
 * Returns:	Result, @a@ multiplied by @b@.
 */

extern mp *gf_mul(mp */*d*/, mp */*a*/, mp */*b*/);

/* --- @gf_sqr@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a@ = source
 *
 * Returns:	Result, @a@ squared.
 */

extern mp *gf_sqr(mp */*d*/, mp */*a*/);

/* --- @gf_div@ --- *
 *
 * Arguments:	@mp **qq, **rr@ = destination, quotient and remainder
 *		@mp *a, *b@ = sources
 *
 * Use:		Calculates the quotient and remainder when @a@ is divided by
 *		@b@.  The destinations @*qq@ and @*rr@ must be distinct.
 *		Either of @qq@ or @rr@ may be null to indicate that the
 *		result is irrelevant.  (Discarding both results is silly.)
 *		There is a performance advantage if @a == *rr@.
 */

extern void gf_div(mp **/*qq*/, mp **/*rr*/, mp */*a*/, mp */*b*/);

/* --- @gf_exp@ --- *
 *
 * Arguments:	@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$a^e$%.
 */

extern mp *gf_exp(mp */*d*/, mp */*a*/, mp */*e*/);

/* --- @gf_irreduciblep@ --- *
 *
 * Arguments:	@mp *f@ = a polynomial
 *
 * Returns:	Nonzero if the polynomial is irreducible; otherwise zero.
 */

extern int gf_irreduciblep(mp */*f*/);

/* --- @gf_gcd@ --- *
 *
 * Arguments:	@mp **gcd, **xx, **yy@ = where to write the results
 *		@mp *a, *b@ = sources (must be nonzero)
 *
 *
 * Returns:	---
 *
 * Use:		Calculates @gcd(a, b)@, and two numbers @x@ and @y@ such that
 *		@ax + by = gcd(a, b)@.  This is useful for computing modular
 *		inverses.
 */

extern void gf_gcd(mp **/*gcd*/, mp **/*xx*/, mp **/*yy*/,
		   mp */*a*/, mp */*b*/);

/* -- @gf_modinv@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *x@ = argument
 *		@mp *p@ = modulus
 *
 * Returns:	The inverse %$x^{-1} \bmod p$%.
 *
 * Use:		Computes a modular inverse, the catch being that the
 *		arguments and results are binary polynomials.  An assertion
 *		fails if %$p$% has no inverse.
 */

extern mp *gf_modinv(mp */*d*/, mp */*x*/, mp */*p*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
