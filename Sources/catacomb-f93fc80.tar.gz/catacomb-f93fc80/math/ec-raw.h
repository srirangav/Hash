/* -*-c-*-
 *
 * Raw formatting of elliptic curve points
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_EC_RAW_H
#define CATACOMB_EC_RAW_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_BUF_H
#  include "buf.h"
#endif

#ifndef CATACOMB_EC_H
#  include "ec.h"
#endif

/*----- Data formatting ---------------------------------------------------*/

/* EC2OSP/OS2ECP bit mask. */
#define EC_YBIT 1u			/* The compressed @y@-coordinate */
#define EC_XONLY 1u			/* The @y@-coordinate is absent */
#define EC_CMPR 2u			/* Compressed @y@-coordinate */
#define EC_LSB 2u			/* Use `lsb' compression */
#define EC_EXPLY 4u			/* Explicit @y@-coordinate */
#define EC_SORT 8u			/* Use `sort' rather than `lsb' */

/* --- @ec_ec2osp@ --- *
 *
 * Arguments:	@ec_curve *c@ = elliptic curve
 *		@unsigned f@ = format flags for output
 *		@buf *b@ = pointer to a buffer
 *		@const ec *p@ = an elliptic curve point
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Puts an elliptic curve point to the given buffer using the
 *		standard uncompressed format described in P1363 and SEC1.
 *		This requires at most @1 + 2 * c->f->noctets@ space in the
 *		buffer.
 *
 *		Point compression features are determined by @f@ as follows.
 *		If @EC_CMPR@ is set then point compression is performed and a
 *		compressed form of the %$y$%-coordinate is contained in the
 *		first output byte; if @EC_SORT@ is set then P1363a `SORT'
 *		compression is used, otherwise LSB compression.  If
 *		@EC_EXPLY@ is set, then an explicit %$y$%-coordinate is
 *		output in full.  Otherwise the %$y$%-coordinate is
 *		suppressed.
 *
 *		Returns failure (@-1@) if the flags are invalid, or if there
 *		isn't enough space in the output buffer.
 */

extern int ec_ec2osp(ec_curve */*c*/, unsigned /*f*/,
		     buf */*b*/, const ec */*p*/);

/* --- @ec_os2ecp@ --- *
 *
 * Arguments:	@ec_curve *c = elliptic curve
 *		@unsigned f@ = format flags for input
 *		@buf *b@ = pointer to a buffer
 *		@ec *d@ = an elliptic curve point
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Reads an elliptic curve point from the given buffer using the
 *		standard uncompressed format described in P1363 and SEC1.
 *
 *		Point compression features are determined by @f@ as follows.
 *		If @EC_LSB@ is set, then accept an LSB-compressed %$y$%-
 *		coordinate; if @EC_SORT@ is set, then accept a SORT-
 *		compressed %$y$%-coordinate; if @EC_EXPLY@ is set, then
 *		accept an explicit %$y$%-coordinate; if @EC_XONLY@ is set
 *		then accept a bare %$x$%-coordinate (a correct
 *		%$y$%-coordinate is chosen arbitrarily).  Hybrid forms are
 *		acceptable, and the input is checked to verify that the
 *		redundant representations are consistent.  If no flags are
 *		set in @f@, then no input (other than the point at infinity)
 *		will be acceptable.
 */

extern int ec_os2ecp(ec_curve */*c*/, unsigned /*f*/, buf */*b*/, ec */*d*/);

/* --- @ec_putraw@ --- *
 *
 * Arguments:	@ec_curve *c@ = elliptic curve
 *		@buf *b@ = pointer to a buffer
 *		@const ec *p@ = an elliptic curve point
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Puts an elliptic curve point to the given buffer using the
 *		standard uncompressed format described in P1383 and SEC1.
 *		We don't do point compression.
 */

extern int ec_putraw(ec_curve */*c*/, buf */*b*/, const ec */*p*/);

/* --- @ec_getraw@ --- *
 *
 * Arguments:	@ec_curve *c@ = elliptic curve
 *		@buf *b@ = pointer to a buffer
 *		@ec *d@ = an elliptic curve point
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Reads an elliptic curve point from the given buffer using the
 *		standard uncompressed format described in P1383 and SEC1.
 *		We don't do point compression.
 */

extern int ec_getraw(ec_curve */*c*/, buf */*b*/, ec */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
