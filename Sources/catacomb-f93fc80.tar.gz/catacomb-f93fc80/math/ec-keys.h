/* -*-c-*-
 *
 * Elliptic curve key-fetching
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_EC_KEYS_H
#define CATACOMB_EC_KEYS_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_EC_H
#  include "ec.h"
#endif

#ifndef CATACOMB_KEY_H
#  include "key.h"
#endif

/*----- Key structures ----------------------------------------------------*/

typedef struct ec_param {
  ec_info ei;				/* Curve information */
  char *cstr;				/* Curve definition string */
} ec_param;

typedef struct ec_pub {
  ec_info ei;				/* Curve information */
  char *cstr;				/* Curve definition string */
  ec p;					/* Public point */
} ec_pub;

typedef struct ec_priv {
  ec_info ei;				/* Curve information */
  char *cstr;				/* Curve definition string */
  ec p;					/* Public point */
  mp *x;				/* Secret exponent */
} ec_priv;

extern const key_fetchdef ec_paramfetch[];
#define EC_PARAMFETCHSZ 3

extern const key_fetchdef ec_pubfetch[];
#define EC_PUBFETCHSZ 4

extern const key_fetchdef ec_privfetch[];
#define EC_PRIVFETCHSZ 7

/*----- Functions provided ------------------------------------------------*/

/* --- @ec_paramfree@, @ec_pubfree@, @ec_privfree@ --- *
 *
 * Arguments:	@ec_param *ep@, @ec_pub *ep@, @ec_priv *ep@ = pointer to
 *			key block to free
 *
 * Returns:	---
 *
 * Use:		Frees an elliptic curve key block
 */

extern void ec_paramfree(ec_param */*ep*/);
extern void ec_pubfree(ec_pub */*ep*/);
extern void ec_privfree(ec_priv */*ep*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
