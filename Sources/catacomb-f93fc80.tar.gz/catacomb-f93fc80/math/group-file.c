/* -*-c-*-
 *
 * File I/O for group elements
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "group.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @group_readfile@ --- *
 *
 * Arguments:	@group *g@ = an abstract group
 *		@ge *d@ = destination group element
 *		@FILE *fp@ = the file to read from
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Parses a group element from a file.
 */

int group_readfile(group *g, ge *d, FILE *fp)
  { return (G_READ(g, d, &mptext_fileops, fp)); }

/* --- @group_writefile@ --- *
 *
 * Arguments:	@group *g@ = an abstract group
 *		@ge *x@ = a group element
 *		@FILE *fp@ = the file to write on
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Writes a group element to a file.
 */

int group_writefile(group *g, ge *x, FILE *fp)
  { return (G_WRITE(g, x, &mptext_fileops, fp)); }

/*----- That's all, folks -------------------------------------------------*/
