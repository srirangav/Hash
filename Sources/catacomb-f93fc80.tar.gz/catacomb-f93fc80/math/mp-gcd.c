/* -*-c-*-
 *
 * Extended GCD calculation
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @mp_gcd@ --- *
 *
 * Arguments:	@mp **gcd, **xx, **yy@ = where to write the results
 *		@mp *a, *b@ = sources (must be nonzero)
 *
 * Returns:	---
 *
 * Use:		Calculates @gcd(a, b)@, and two numbers @x@ and @y@ such that
 *		@ax + by = gcd(a, b)@.  This is useful for computing modular
 *		inverses.
 */

void mp_gcd(mp **gcd, mp **xx, mp **yy, mp *a, mp *b)
{
  mp *x = MP_ONE, *X = MP_ZERO;
  mp *y = MP_ZERO, *Y = MP_ONE;
  mp *u, *v;
  mp *q = MP_NEW, *t, *spare = MP_NEW;
  unsigned f = 0;

#define f_swap 1u
#define f_aneg 2u
#define f_bneg 4u
#define f_ext 8u

  /* --- Sort out some initial flags --- */

  if (xx || yy) f |= f_ext;

  if (MP_NEGP(a)) f |= f_aneg;
  if (MP_NEGP(b)) f |= f_bneg;

  /* --- Ensure that @a@ is larger than @b@ --- *
   *
   * Use absolute values here!
   */

  if (MPX_UCMP(a->v, a->vl, <, b->v, b->vl)) {
    t = a; a = b; b = t;
    f |= f_swap;
  }

  /* --- Check for zeroness --- */

  if (MP_ZEROP(b)) {

    /* --- Store %$|a|$% as the GCD --- */

    if (gcd) {
      if (*gcd) MP_DROP(*gcd);
      a = MP_COPY(a);
      if (MP_NEGP(a)) {
	MP_SPLIT(a);
	a->f &= ~MP_NEG;
	f |= f_aneg;
      }
      *gcd = a;
    }

    /* --- Store %$1$% and %$0$% in the appropriate bins --- */

    if (f & f_ext) {
      if (f & f_swap) {
	mp **tt = xx; xx = yy; yy = tt;
      }
      if (xx) {
	if (*xx) MP_DROP(*xx);
	if (MP_EQ(a, MP_ZERO)) *xx = MP_ZERO;
	else if (f & f_aneg) *xx = MP_MONE;
	else *xx = MP_ONE;
      }
      if (yy) {
	if (*yy) MP_DROP(*yy);
	*yy = MP_ZERO;
      }
    }
    return;
  }

  /* --- Force the signs on the arguments and take copies --- */

  a = MP_COPY(a);
  b = MP_COPY(b);

  MP_SPLIT(a); a->f &= ~MP_NEG;
  MP_SPLIT(b); b->f &= ~MP_NEG;

  u = MP_COPY(a);
  v = MP_COPY(b);

  /* --- Main extended Euclidean algorithm --- */

  while (!MP_ZEROP(v)) {
    mp_div(&q, &u, u, v);
    if (f & f_ext) {
      t = mp_mul(spare, X, q);
      t = mp_sub(t, x, t);
      spare = x; x = X; X = t;
      t = mp_mul(spare, Y, q);
      t = mp_sub(t, y, t);
      spare = y; y = Y; Y = t;
    }
    t = u; u = v; v = t;
  }

  MP_DROP(q); if (spare) MP_DROP(spare);
  if (!gcd)
    MP_DROP(u);
  else {
    if (*gcd) MP_DROP(*gcd);
    u->f &= ~MP_NEG;
    *gcd = u;
  }

  /* --- Perform a little normalization --- *
   *
   * Ensure that the coefficient returned is positive, if there is only one.
   * If there are two, favour @y@.  Of course, if the original arguments were
   * negative then I'll need to twiddle their signs as well.
   */

  if (f & f_ext) {

    /* --- If @a@ and @b@ got swapped, swap the coefficients back --- */

    if (f & f_swap) {
      t = x; x = y; y = t;
      t = a; a = b; b = t;
    }

    /* --- Sort out the signs --- *
     *
     * Note that %$ax + by = a(x - b) + b(y + a)$%.
     *
     * This is currently bodgy.  It needs sorting out at some time.
     */

    if (yy) {
      if (MP_NEGP(y)) {
	do {
	  y = mp_add(y, y, a);
	  x = mp_sub(x, x, b);
	} while (MP_NEGP(y));
      } else {
	while (MP_CMP(y, >=, a)) {
	  y = mp_sub(y, y, a);
	  x = mp_add(x, x, b);
	}
      }
    } else {
      if (MP_NEGP(x))
	do x = mp_add(x, x, b); while (MP_NEGP(x));
      else
	while (MP_CMP(x, >=, b)) x = mp_sub(x, x, b);
    }

    /* --- Twiddle the signs --- */

    if (f & f_aneg) { MP_SPLIT(x); x->f ^= MP_NEG; }
    if (f & f_bneg) { MP_SPLIT(y); y->f ^= MP_NEG; }

    /* --- Store the results --- */

    if (!xx)
      MP_DROP(x);
    else {
      if (*xx) MP_DROP(*xx);
      *xx = x;
    }

    if (!yy)
      MP_DROP(y);
    else {
      if (*yy) MP_DROP(*yy);
      *yy = y;
    }
  }

  MP_DROP(v);
  MP_DROP(X); MP_DROP(Y);
  MP_DROP(a); MP_DROP(b);
}

/* -- @mp_modinv@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *x@ = argument
 *		@mp *p@ = modulus
 *
 * Returns:	The inverse %$x^{-1} \bmod p$%.
 *
 * Use:		Computes a modular inverse.    An assertion fails if %$p$%
 *		has no inverse.
 */

mp *mp_modinv(mp *d, mp *x, mp *p)
{
  mp *g = MP_NEW;
  mp_gcd(&g, 0, &d, p, x);
  assert(MP_EQ(g, MP_ONE));
  mp_drop(g);
  return (d);
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

static int modinv(dstr *v)
{
  int ok = 1;
  mp *x = *(mp **)v[0].buf;
  mp *m = *(mp **)v[1].buf;
  mp *r = *(mp **)v[2].buf;

  mp *y = mp_modinv(MP_NEW, x, m);
  if (!MP_EQ(y, r)) {
    fputs("\n*** mp_modinv failed", stderr);
    fputs("\nx	    = ", stderr); mp_writefile(x, stderr, 10);
    fputs("\nm	    = ", stderr); mp_writefile(m, stderr, 10);
    fputs("\nexpect = ", stderr); mp_writefile(r, stderr, 10);
    fputs("\nresult = ", stderr); mp_writefile(y, stderr, 10);
    ok = 0;
  }
  MP_DROP(x); MP_DROP(m); MP_DROP(r); MP_DROP(y);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int gcd(dstr *v)
{
  int ok = 1;
  mp *a = *(mp **)v[0].buf;
  mp *b = *(mp **)v[1].buf;
  mp *g = *(mp **)v[2].buf;
  mp *x = *(mp **)v[3].buf;
  mp *y = *(mp **)v[4].buf;

  mp *gg = MP_NEW, *xx = MP_NEW, *yy = MP_NEW;
  mp_gcd(&gg, &xx, &yy, a, b);
  if (!MP_EQ(x, xx)) {
    fputs("\n*** mp_gcd(x) failed", stderr);
    fputs("\na	    = ", stderr); mp_writefile(a, stderr, 10);
    fputs("\nb	    = ", stderr); mp_writefile(b, stderr, 10);
    fputs("\nexpect = ", stderr); mp_writefile(x, stderr, 10);
    fputs("\nresult = ", stderr); mp_writefile(xx, stderr, 10);
    fputc('\n', stderr);
    ok = 0;
  }
  if (!MP_EQ(y, yy)) {
    fputs("\n*** mp_gcd(y) failed", stderr);
    fputs("\na	    = ", stderr); mp_writefile(a, stderr, 10);
    fputs("\nb	    = ", stderr); mp_writefile(b, stderr, 10);
    fputs("\nexpect = ", stderr); mp_writefile(y, stderr, 10);
    fputs("\nresult = ", stderr); mp_writefile(yy, stderr, 10);
    fputc('\n', stderr);
    ok = 0;
  }

  if (!ok) {
    mp *ax = mp_mul(MP_NEW, a, xx);
    mp *by = mp_mul(MP_NEW, b, yy);
    ax = mp_add(ax, ax, by);
    if (MP_EQ(ax, gg))
      fputs("\n*** (Alternative result found.)\n", stderr);
    MP_DROP(ax);
    MP_DROP(by);
  }

  if (!MP_EQ(g, gg)) {
    fputs("\n*** mp_gcd(gcd) failed", stderr);
    fputs("\na	    = ", stderr); mp_writefile(a, stderr, 10);
    fputs("\nb	    = ", stderr); mp_writefile(b, stderr, 10);
    fputs("\nexpect = ", stderr); mp_writefile(g, stderr, 10);
    fputs("\nresult = ", stderr); mp_writefile(gg, stderr, 10);
    fputc('\n', stderr);
    ok = 0;
  }
  MP_DROP(a); MP_DROP(b); MP_DROP(g); MP_DROP(x); MP_DROP(y);
  MP_DROP(gg); MP_DROP(xx); MP_DROP(yy);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static test_chunk tests[] = {
  { "gcd", gcd, { &type_mp, &type_mp, &type_mp, &type_mp, &type_mp, 0 } },
  { "modinv", modinv, { &type_mp, &type_mp, &type_mp, 0 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/mp");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
