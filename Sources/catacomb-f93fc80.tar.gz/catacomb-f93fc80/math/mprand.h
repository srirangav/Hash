/* -*-c-*-
 *
 * Generate a random multiprecision integer
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPRAND_H
#define CATACOMB_MPRAND_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

/*----- Functions provided ------------------------------------------------*/

/* --- @mprand@ --- *
 *
 * Arguments:	@mp *d@ = destination integer
 *		@unsigned b@ = number of bits
 *		@grand *r@ = pointer to random number source
 *		@mpw or@ = mask to OR with low-order bits
 *
 * Returns:	A random integer with the requested number of bits
 *
 * Use:		Constructs an arbitrarily large pseudorandom integer.
 *		Assuming that the generator @r@ is good, the result is
 *		uniformly distributed in the interval %$[2^{b - 1}, 2^b)$%.
 *		The result is then ORred with the given @or@ value.  This
 *		will often be 1, to make the result odd.
 */

extern mp *mprand(mp */*d*/, unsigned /*b*/, grand */*r*/, mpw /*or*/);

/* --- @mprand_range@ --- *
 *
 * Arguments:	@mp *d@ = destination integer
 *		@mp *l@ = limit for random number
 *		@grand *r@ = random number source
 *		@mpw or@ = mask for low-order bits
 *
 * Returns:	A pseudorandom integer, unformly distributed over the
 *		interval %$[0, l)$%.
 *
 * Use:		Generates a uniformly-distributed pseudorandom number in the
 *		appropriate range.
 */

extern mp *mprand_range(mp */*d*/, mp */*l*/, grand */*r*/, mpw /*or*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
