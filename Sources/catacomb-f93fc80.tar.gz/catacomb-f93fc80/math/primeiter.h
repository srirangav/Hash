/* -*-c-*-
 *
 * Iterate over small primes efficiently
 *
 * (c) 2007 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_PRIMEITER_H
#define CATACOMB_PRIMEITER_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

#ifndef CATACOMB_MP_H
#  include "mp.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct primeiter {
  mpw w;
  mp pp;
  mp *p;
  grand *r;
  unsigned mode;
  int i;
} primeiter;

enum {
  PIMODE_PTAB,
  PIMODE_STALL,
  PIMODE_WHEEL
};

/*----- Functions provided ------------------------------------------------*/

/* --- @primeiter_create@ --- *
 *
 * Arguments:	@primeiter *pi@ = pointer to an iterator structure
 *		@mp *start@ = where to start
 *
 * Returns:	---
 *
 * Use:		Initializes a prime iterator.  The first output will be the
 *		smallest prime not less than @start@.
 */

extern void primeiter_create(primeiter */*pi*/, mp */*start*/);

/* --- @primeiter_destroy@ --- *
 *
 * Arguments:	@primeiter *pi@ = pointer to iterator structure
 *
 * Returns:	---
 *
 * Use:		Frees up an iterator structure when it's no longer wanted.
 */

void primeiter_destroy(primeiter */*pi*/);

/* --- @primeiter_next@ --- *
 *
 * Arguments:	@primeiter *pi@ = pointer to an iterator structure
 *		@mp *d@ = fake destination
 *
 * Returns:	The next prime number from the iterator.
 *
 * Use:		Returns a new prime number.
 */

mp *primeiter_next(primeiter */*pi*/, mp */*d*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
