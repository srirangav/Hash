/* -*-c-*-
 *
 * Abstraction for prime groups
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/sub.h>

#include "mpmont.h"
#include "pgen.h"

#define ge mp *
#include "group.h"
#include "group-guts.h"

/*----- Main code ---------------------------------------------------------*/

/* --- Group operations --- */

static void gdestroygroup(group *gg) {
  gctx_bin *g = (gctx_bin *)gg;
  mp_drop(g->gen); mp_drop(g->g.r); mp_drop(g->g.h);
  gfreduce_destroy(&g->r);
  DESTROY(g);
}

static mp **gcreate(group *gg)
  { mp **x = CREATE(mp *); *x = MP_COPY(*gg->i); return (x); }

static void gcopy(group *gg, mp **d, mp **x)
  { mp *t = MP_COPY(*x); MP_DROP(*d); *d = t; }

static void gburn(group *gg, mp **x) { (*x)->f |= MP_BURN; }

static void gdestroy(group *gg, mp **x) { MP_DROP(*x); DESTROY(x); }

static int gsamep(group *gg, group *hh) {
  gctx_bin *g = (gctx_bin *)gg, *h = (gctx_bin *)hh;
  return (MP_EQ(g->r.p, h->r.p));
}

static int geq(group *gg, mp **x, mp **y) { return (MP_EQ(*x, *y)); }

static const char *gcheck(group *gg, grand *gr) {
  gctx_bin *g = (gctx_bin *)gg; int rc; mp *t, *tt;
  if (!gf_irreduciblep(g->r.p)) return ("p is not irreducible");
  t = mp_mul(MP_NEW, g->g.r, g->g.h); t = mp_add(t, t, MP_ONE);
  tt = mp_lsl(MP_NEW, MP_ONE, g->g.nbits);
  rc = MP_EQ(t, tt); MP_DROP(t); MP_DROP(tt);
  if (!rc) return ("not a subgroup");
  return (group_stdcheck(gg, gr));
}

static void gmul(group *gg, mp **d, mp **x, mp **y) {
  gctx_bin *g = (gctx_bin *)gg; mp *r = gf_mul(*d, *x, *y);
  *d = gfreduce_do(&g->r, r, r);
}

static void gsqr(group *gg, mp **d, mp **x) {
  gctx_bin *g = (gctx_bin *)gg; mp *r = gf_sqr(*d, *x);
  *d = gfreduce_do(&g->r, r, r);
}

static void ginv(group *gg, mp **d, mp **x)
  { gctx_bin *g = (gctx_bin *)gg; *d = gf_modinv(*d, *x, g->r.p); }

static void gexp(group *gg, mp **d, mp **x, mp *n)
  { gctx_bin *g = (gctx_bin *)gg; *d = gfreduce_exp(&g->r, *d, *x, n); }

static int gread(group *gg, mp **d, const mptext_ops *ops, void *p) {
  mp *t; if ((t = mp_read(MP_NEW, 0, ops, p)) == 0) return (-1);
  mp_drop(*d); *d = t; return (0);
}

static int gwrite(group *gg, mp **x, const mptext_ops *ops, void *p) {
  int rc = -1;
  if (!ops->put("0x", 2, p) && !mp_write(*x, 16, ops, p)) rc = 0;
  return (rc);
}

static mp *gtoint(group *gg, mp *d, mp **x) { return MP_COPY(*x); }

static int gfromint(group *gg, mp **d, mp *x) { *d = MP_COPY(x); return 0; }

static int gtobuf(group *gg, buf *b, mp **x)
  { int rc = buf_putmp(b, *x); return (rc); }

static int gfrombuf(group *gg, buf *b, mp **d) {
  gctx_bin *g = (gctx_bin *)gg; mp *x;
  if ((x = buf_getmp(b)) == 0) return (-1);
  MP_DROP(*d); *d = gfreduce_do(&g->r, x, x);
  return (0);
}

static int gtoraw(group *gg, buf *b, mp **x) {
  gctx_bin * g = (gctx_bin *)gg; octet *q;
  if ((q = buf_get(b, g->g.noctets)) == 0) return (-1);
  mp_storeb(*x, q, g->g.noctets); return (0);
}

static int gfromraw(group *gg, buf *b, mp **d) {
  gctx_bin * g = (gctx_bin *)gg; mp *x; octet *q;
  if ((q = buf_get(b, g->g.noctets)) == 0) return (-1);
  x = mp_loadb(MP_NEW, q, g->g.noctets);
  MP_DROP(*d); *d = gfreduce_do(&g->r, x, x);
  return (0);
}

/* --- @group_binary@ --- *
 *
 * Arguments:	@const gbin_param *gb@ = group parameters
 *
 * Returns:	A pointer to the group, or null.
 *
 * Use:		Constructs an abstract group interface for a subgroup of a
 *		prime field.  Group elements are @mp *@ pointers.
 */

static const group_ops gops = {
  GTY_BINARY, "bin",
  gdestroygroup, gcreate, gcopy, gburn, gdestroy,
  gsamep, geq, group_stdidentp,
  gcheck,
  gmul, gsqr, ginv, group_stddiv, gexp, group_stdmexp,
  gread, gwrite,
  gtoint, gfromint, group_stdtoec, group_stdfromec, gtobuf, gfrombuf,
  gtoraw, gfromraw
};

group *group_binary(const gbin_param *gb)
{
  gctx_bin *g;
  mp *t;

  if (!MP_POSP(gb->p))
    return (0);
  g = CREATE(gctx_bin);
  g->g.ops = &gops;
  g->g.nbits = mp_bits(gb->p) - 1;
  g->g.noctets = (g->g.nbits + 7) >> 3;
  gfreduce_create(&g->r, gb->p);
  g->one = MP_ONE;
  g->g.i = &g->one;
  g->gen = MP_COPY(gb->g);
  g->g.g = &g->gen;
  g->g.r = MP_COPY(gb->q);
  t = mp_lsl(MP_NEW, MP_ONE, g->g.nbits);
  t = mp_sub(t, t, MP_ONE);
  g->g.h = MP_NEW; mp_div(&g->g.h, 0, t, gb->q);
  MP_DROP(t);
  return (&g->g);
}

/*----- That's all, folks -------------------------------------------------*/
