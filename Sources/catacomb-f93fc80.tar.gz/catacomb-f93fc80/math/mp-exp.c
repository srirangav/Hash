/* -*-c-*-
 *
 * Exponentiation for large integers
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>

#include "mp.h"
#include "mp-exp.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @mp_exp@ --- *
 *
 * Arguments:	@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$a^e$%.
 */

mp *mp_exp(mp *d, mp *a, mp *e)
{
  mp *x = MP_ONE;
  mp *spare = (e->f & MP_BURN) ? MP_NEWSEC : MP_NEW;
  assert(!MP_NEGP(e));

  MP_COPY(a);
  if (MP_ZEROP(e))
    ;
  else if (MP_LEN(e) < EXP_THRESH)
    EXP_SIMPLE(x, a, e);
  else
    EXP_WINDOW(x, a, e);
  mp_drop(d);
  mp_drop(spare);
  mp_drop(a);
  return (x);
}

/*----- That's all, folks -------------------------------------------------*/
