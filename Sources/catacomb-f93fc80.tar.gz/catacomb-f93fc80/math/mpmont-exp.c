/* -*-c-*-
 *
 * Modular exponentiation with Montgomery reduction
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"
#include "mpmont.h"
#include "mpmont-exp.h"

/*----- Exponentiation ----------------------------------------------------*/

/* --- @mpmont_expr@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$(a R^{-1})^e R \bmod m$%.
 */

mp *mpmont_expr(mpmont *mm, mp *d, mp *a, mp *e)
{
  mp *x = MP_COPY(mm->r);
  mp *spare = (e->f & MP_BURN) ? MP_NEWSEC : MP_NEW;

  MP_COPY(a);
  MP_SHRINK(e);
  if (MP_ZEROP(e))
    ;
  else {
    if (MP_NEGP(e)) {
      a = mpmont_reduce(mm, a, a);
      a = mp_modinv(a, a, mm->m);
      a = mpmont_mul(mm, a, a, mm->r2);
    }
    if (MP_LEN(e) < EXP_THRESH)
      EXP_SIMPLE(x, a, e);
    else
      EXP_WINDOW(x, a, e);
  }
  mp_drop(d);
  mp_drop(spare);
  mp_drop(a);
  return (x);
}

/* --- @mpmont_exp@ --- *
 *
 * Arguments:	@mpmont *mm@ = pointer to Montgomery reduction context
 *		@mp *d@ = fake destination
 *		@mp *a@ = base
 *		@mp *e@ = exponent
 *
 * Returns:	Result, %$a^e \bmod m$%.
 */

mp *mpmont_exp(mpmont *mm, mp *d, mp *a, mp *e)
{
  e = MP_COPY(e);
  d = mpmont_mul(mm, d, a, mm->r2);
  d = mpmont_expr(mm, d, d, e);
  d = mpmont_reduce(mm, d, d);
  MP_DROP(e);
  return (d);
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

static int texp(dstr *v)
{
  mp *m = *(mp **)v[0].buf;
  mp *a = *(mp **)v[1].buf;
  mp *b = *(mp **)v[2].buf;
  mp *r = *(mp **)v[3].buf;
  mp *mr;
  int ok = 1;

  mpmont mm;
  mpmont_create(&mm, m);

  mr = mpmont_exp(&mm, MP_NEW, a, b);

  if (!MP_EQ(mr, r)) {
    fputs("\n*** montgomery modexp failed", stderr);
    fputs("\n m = ", stderr); mp_writefile(m, stderr, 10);
    fputs("\n a = ", stderr); mp_writefile(a, stderr, 10);
    fputs("\n e = ", stderr); mp_writefile(b, stderr, 10);
    fputs("\n r = ", stderr); mp_writefile(r, stderr, 10);
    fputs("\nmr = ", stderr); mp_writefile(mr, stderr, 10);
    fputc('\n', stderr);
    ok = 0;
  }

  MP_DROP(m);
  MP_DROP(a);
  MP_DROP(b);
  MP_DROP(r);
  MP_DROP(mr);
  mpmont_destroy(&mm);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return ok;
}

static test_chunk tests[] = {
  { "exp", texp, { &type_mp, &type_mp, &type_mp, &type_mp, 0 } },
  { 0, 0, { 0 } },
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/mpmont");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
