/* -*-c-*-
 *
 * Allocation and freeing of MP buffers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_MPARENA_H
#define CATACOMB_MPARENA_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/arena.h>

#ifndef CATACOMB_MPW_H
#  include "mpw.h"
#endif

/*----- Data structures ---------------------------------------------------*/

/* --- @mparena_node@ --- *
 *
 * For internal use by the MP arena manager.  The free blocks are held in a
 * binary tree by size, held in the first digit of each vector.
 */

typedef struct mparena_node {
  struct mparena_node *left, *right;
  mpw *v;
} mparena_node;

/* --- @mparena@ --- *
 *
 * The actual arena.
 */

typedef struct mparena {
  mparena_node *root;
  unsigned n;
  arena *a;
} mparena;

/*----- Standard arenas ---------------------------------------------------*/

extern mparena mparena_global;
#define MPARENA_GLOBAL (&mparena_global)

extern mparena mparena_secure;
#define MPARENA_SECURE (&mparena_secure)

/*----- Functions provided ------------------------------------------------*/

/* --- @mparena_create@ --- *
 *
 * Arguments:	@mparena *a@ = pointer to arena block
 *
 * Returns:	---
 *
 * Use:		Initializes an MP arena so that blocks can be allocated from
 *		it.
 */

extern void mparena_create(mparena */*a*/);

#define MPARENA_INIT { 0, 0, &arena_stdlib }

/* --- @mparena_setarena@ --- *
 *
 * Arguments:	@mparena *a@ = pointer to MP arena block
 *		@arena *aa@ = pointer to arena
 *
 * Returns:	---
 *
 * Use:		Sets the underlying arena for an MP arena.
 */

extern void mparena_setarena(mparena */*a*/, arena */*aa*/);

/* --- @mparena_destroy@ --- *
 *
 * Arguments:	@mparena *a@ = pointer to arena block
 *
 * Returns:	---
 *
 * Use:		Frees an MP arena, and all the vectors held within it.  The
 *		blocks which are currently allocated can be freed into some
 *		other MP arena, as long as the underlying arenas are the
 *		same.
 */

extern void mparena_destroy(mparena */*a*/);

/* --- @mparena_count@ --- *
 *
 * Arguments:	@mparena *a@ = pointer to arena block
 *
 * Returns:	Number of allocated blocks from this arena.
 *
 * Use:		Reports the number of blocks allocated from the arena and not
 *		yet freed.
 */

extern unsigned mparena_count(mparena */*a*/);

/* --- @mpalloc@ --- *
 *
 * Arguments:	@mparena *a@ = pointer to arena block
 *		@size_t sz@ = number of digits required
 *
 * Returns:	Pointer to a suitably sized block.
 *
 * Use:		Allocates a lump of data suitable for use as an array of MP
 *		digits.
 */

extern mpw *mpalloc(mparena */*a*/, size_t /*sz*/);

/* --- @mpfree@ --- *
 *
 * Arguments:	@mparena *a@ = pointer to arena block
 *		@mpw *v@ = pointer to allocated vector
 *
 * Returns:	---
 *
 * Use:		Returns an MP vector to an arena.
 */

extern void mpfree(mparena */*a*/, mpw */*v*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
