/* -*-c-*-
 *
 * Basic arithmetic on multiprecision integers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "mp.h"

/*----- Macros ------------------------------------------------------------*/

#define MAX(x, y) ((x) >= (y) ? (x) : (y))

/*----- Main code ---------------------------------------------------------*/

/* --- @mp_lsl@, @mp_lslc@, @mp_lsr@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a@ = source
 *		@size_t n@ = number of bits to move
 *
 * Returns:	Result, @a@ shifted left or right by @n@.
 *
 * Use:		Bitwise shift operators.  @mp_lslc@ fills the bits introduced
 *		on the right with ones instead of zeroes: it's used
 *		internally by @mp_lsl2c@, though it may be useful on its
 *		own.
 */

mp *mp_lsl(mp *d, mp *a, size_t n)
{
  MP_DEST(d, MP_LEN(a) + (n + MPW_BITS - 1) / MPW_BITS, a->f);
  mpx_lsl(d->v, d->vl, a->v, a->vl, n);
  d->f = a->f & (MP_NEG | MP_BURN);
  MP_SHRINK(d);
  return (d);
}

mp *mp_lslc(mp *d, mp *a, size_t n)
{
  MP_DEST(d, MP_LEN(a) + (n + MPW_BITS - 1) / MPW_BITS, a->f);
  mpx_lslc(d->v, d->vl, a->v, a->vl, n);
  d->f = a->f & (MP_NEG | MP_BURN);
  MP_SHRINK(d);
  return (d);
}

mp *mp_lsr(mp *d, mp *a, size_t n)
{
  MP_DEST(d, MP_LEN(a), a->f);
  mpx_lsr(d->v, d->vl, a->v, a->vl, n);
  d->f = a->f & (MP_NEG | MP_BURN);
  MP_SHRINK(d);
  return (d);
}

/* --- @mp_lsl2c@, @mp_lsr2c@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a@ = source
 *		@size_t n@ = number of bits to move
 *
 * Returns:	Result, @a@ shifted left or right by @n@.  Handles the
 *		pretence of sign-extension for negative numbers.
 */

mp *mp_lsl2c(mp *d, mp *a, size_t n)
{
  if (!MP_NEGP(a))
    return (mp_lsl(d, a, n));
  d = mp_not2c(d, a);
  d = mp_lslc(d, d, n);
  d = mp_not2c(d, d);
  return (d);
}

mp *mp_lsr2c(mp *d, mp *a, size_t n)
{
  if (!MP_NEGP(a))
    return (mp_lsr(d, a, n));
  d = mp_not2c(d, a);
  d = mp_lsr(d, d, n);
  d = mp_not2c(d, d);
  return (d);
}

/* --- @mp_testbit@ --- *
 *
 * Arguments:	@mp *x@ = a large integer
 *		@unsigned long n@ = which bit to test
 *
 * Returns:	Nonzero if the bit is set, zero if not.
 */

int mp_testbit(mp *x, unsigned long n)
{
  if (n > MPW_BITS * MP_LEN(x))
    return (0);
  return ((x->v[n/MPW_BITS] >> n%MPW_BITS) & 1u);
}

/* --- @mp_testbit2c@ --- *
 *
 * Arguments:	@mp *x@ = a large integer
 *		@unsigned long n@ = which bit to test
 *
 * Returns:	Nonzero if the bit is set, zero if not.  Fakes up two's
 *		complement representation.
 */

int mp_testbit2c(mp *x, unsigned long n)
{
  int r;
  if (!MP_NEGP(x))
    return (mp_testbit(x, n));
  x = mp_not2c(MP_NEW, x);
  r = !mp_testbit(x, n);
  MP_DROP(x);
  return (r);
}

/* --- @mp_setbit@, @mp_clearbit@ --- *
 *
 * Arguments:	@mp *d@ = a destination
 *		@mp *x@ = a large integer
 *		@unsigned long n@ = which bit to modify
 *
 * Returns:	The argument @x@, with the appropriate bit set or cleared.
 */

mp *mp_setbit(mp *d, mp *x, unsigned long n)
{
  size_t rq;

  rq = n + MPW_BITS; rq -= rq % MPW_BITS;
  if (d != x) {
    if (d) MP_DROP(d);
    d = MP_COPY(x);
  }
  MP_DEST(d, rq, x->f & (MP_NEG | MP_BURN));
  d->v[n/MPW_BITS] |= 1 << n%MPW_BITS;
  return (d);
}

mp *mp_clearbit(mp *d, mp *x, unsigned long n)
{
  size_t rq;

  rq = n + MPW_BITS; rq -= rq % MPW_BITS;
  if (d != x) {
    if (d) MP_DROP(d);
    d = MP_COPY(x);
  }
  MP_DEST(d, rq, x->f & (MP_NEG | MP_BURN));
  d->v[n/MPW_BITS] &= ~(1 << n%MPW_BITS);
  return (d);
}

/* --- @mp_setbit2c@, @mp_clearbit2c@ --- *
 *
 * Arguments:	@mp *d@ = a destination
 *		@mp *x@ = a large integer
 *		@unsigned long n@ = which bit to modify
 *
 * Returns:	The argument @x@, with the appropriate bit set or cleared.
 *		Fakes up two's complement representation.
 */

mp *mp_setbit2c(mp *d, mp *x, unsigned long n)
{
  if (!MP_NEGP(x))
    return mp_setbit(d, x, n);
  d = mp_not2c(d, x);
  d = mp_clearbit(d, d, n);
  d = mp_not2c(d, d);
  return (d);
}

mp *mp_clearbit2c(mp *d, mp *x, unsigned long n)
{
  if (!MP_NEGP(x))
    return mp_clearbit(d, x, n);
  d = mp_not2c(d, x);
  d = mp_setbit(d, d, n);
  d = mp_not2c(d, d);
  return (d);
}

/* --- @mp_eq@ --- *
 *
 * Arguments:	@const mp *a, *b@ = two numbers
 *
 * Returns:	Nonzero if the numbers are equal.
 */

int mp_eq(const mp *a, const mp *b) { return (MP_EQ(a, b)); }

/* --- @mp_cmp@ --- *
 *
 * Arguments:	@const mp *a, *b@ = two numbers
 *
 * Returns:	Less than, equal to or greater than zero, according to
 *		whether @a@ is less than, equal to or greater than @b@.
 */

int mp_cmp(const mp *a, const mp *b)
{
  if (!((a->f ^ b->f) & MP_NEG)) {
    if (a->f & MP_NEG)
      return (-mpx_ucmp(a->v, a->vl, b->v, b->vl));
    else
      return (mpx_ucmp(a->v, a->vl, b->v, b->vl));
  } else if (a->f & MP_NEG)
    return (-1);
  else
    return (+1);
}

/* --- @mp_neg@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a@ = argument
 *
 * Returns:	The negation of the argument.
 *
 * Use:		Negates its argument.
 */

mp *mp_neg(mp *d, mp *a)
{
  /* --- Surprising amounts of messing about required --- */

  MP_SHRINK(a);
  MP_COPY(a);
  if (d)
    MP_DROP(d);
  if (a->v == a->vl)
    return (a);
  MP_DEST(a, MP_LEN(a), a->f);
  a->f ^= MP_NEG;
  return (a);
}

/* --- @mp_bitop@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a, *b@ = sources
 *
 * Returns:	The result of the given bitwise operation.  These functions
 *		don't handle negative numbers at all sensibly.  For that, use
 *		the @...2c@ variants.  The functions are named after the
 *		truth tables they generate:
 *
 *			a:	0011
 *			b:	0101
 *			@mpx_bitXXXX@
 */

#define MP_BITBINOP(string)						\
									\
mp *mp_bit##string(mp *d, mp *a, mp *b)					\
{									\
  MP_DEST(d, MAX(MP_LEN(a), MP_LEN(b)), (a->f | b->f) & ~MP_NEG);	\
  mpx_bit##string(d->v, d->vl, a->v, a->vl, b->v, b->vl);		\
  d->f = (a->f | b->f) & MP_BURN;					\
  MP_SHRINK(d);								\
  return (d);								\
}

MPX_DOBIN(MP_BITBINOP)

/* --- @mp_not@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a@ = source
 *
 * Returns:	The bitwise complement of the source.
 */

mp *mp_not(mp *d, mp *a)
{
  MP_DEST(d, MP_LEN(a), a->f);
  mpx_not(d->v, d->vl, a->v, a->vl);
  d->f = a->f & MP_BURN;
  MP_SHRINK(d);
  return (d);
}

/* --- @mp_bitop2c@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a, *b@ = sources
 *
 * Returns:	The result of the given bitwise operation.  Negative numbers
 *		are treated as two's complement, sign-extended infinitely to
 *		the left.  The functions are named after the truth tables
 *		they generate:
 *
 *			a:	0011
 *			b:	0101
 *			@mpx_bitXXXX@
 */

/* --- How this actually works --- *
 *
 * The two arguments are inverted (with a sign-swap) if they're currently
 * negative.  This means that we end up using a different function (one which
 * reinverts as we go) for the main operation.  Also, if the sign would be
 * negative at the end, we preinvert the output and then invert again with a
 * sign-swap.
 *
 * Start with:			wxyz	  WXYZ
 * If @a@ negative:		yzwx  or  YZWX
 * If @b@ negative:		xwzy	  XWZY
 * If both negative:		zyxw	  ZYXW
 */

#define MP_BIT2CBINOP(n, base, an, bn, abn, p_base, p_an, p_bn, p_abn)	\
									\
mp *mp_bit##n##2c(mp *d, mp *a, mp *b)					\
{									\
  if (!((a->f | b->f) & MP_NEG)) {	/* Both positive */		\
    d = mp_bit##base(d, a, b);						\
    p_base								\
  } else if (!(b->f & MP_NEG)) {	/* Only @b@ positive */		\
    MP_COPY(b);								\
    d = mp_not2c(d, a);							\
    d = mp_bit##an(d, d, b);						\
    MP_DROP(b);								\
    p_an								\
  } else if (!(a->f & MP_NEG)) {	/* Only @a@ positive */		\
    MP_COPY(a);								\
    d = mp_not2c(d, b);							\
    d = mp_bit##bn(d, a, d);						\
    MP_DROP(a);								\
    p_bn								\
  } else {				/* Both negative */		\
    mp *t = mp_not2c(MP_NEW, a);					\
    d = mp_not2c(d, b);							\
    d = mp_bit##abn(d, t, d);						\
    MP_DROP(t);								\
    p_abn								\
  }									\
  return (d);								\
}									\

#define NEG d = mp_not2c(d, d);
#define POS
MP_BIT2CBINOP(0000, 0000, 0000, 0000, 0000, POS, POS, POS, POS)
MP_BIT2CBINOP(0001, 0001, 0100, 0010, 0111, POS, POS, POS, NEG)
MP_BIT2CBINOP(0010, 0010, 0111, 0001, 0100, POS, NEG, POS, POS)
MP_BIT2CBINOP(0011, 0011, 0011, 0011, 0011, POS, NEG, POS, NEG)
MP_BIT2CBINOP(0100, 0100, 0001, 0111, 0010, POS, POS, NEG, POS)
MP_BIT2CBINOP(0101, 0101, 0101, 0101, 0101, POS, POS, NEG, NEG)
MP_BIT2CBINOP(0110, 0110, 0110, 0110, 0110, POS, NEG, NEG, POS)
MP_BIT2CBINOP(0111, 0111, 0010, 0100, 0001, POS, NEG, NEG, NEG)
MP_BIT2CBINOP(1000, 0111, 0010, 0100, 0001, NEG, POS, POS, POS)
MP_BIT2CBINOP(1001, 0110, 0110, 0110, 0110, NEG, POS, POS, NEG)
MP_BIT2CBINOP(1010, 0101, 0101, 0101, 0101, NEG, NEG, POS, POS)
MP_BIT2CBINOP(1011, 0100, 0001, 0111, 0010, NEG, NEG, POS, NEG)
MP_BIT2CBINOP(1100, 0011, 0011, 0011, 0011, NEG, POS, NEG, POS)
MP_BIT2CBINOP(1101, 0010, 0111, 0001, 0100, NEG, POS, NEG, NEG)
MP_BIT2CBINOP(1110, 0001, 0100, 0010, 0111, NEG, NEG, NEG, POS)
MP_BIT2CBINOP(1111, 0000, 0000, 0000, 0000, NEG, NEG, NEG, NEG)
#undef NEG
#undef POS

/* --- @mp_not2c@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a@ = source
 *
 * Returns:	The sign-extended complement of the argument.
 */

mp *mp_not2c(mp *d, mp *a)
{
  mpw one = 1;

  MP_DEST(d, MP_LEN(a) + 1, a->f);
  if (d == a) {
    if (MP_NEGP(a))
      MPX_USUBN(d->v, d->vl, 1);
    else
      MPX_UADDN(d->v, d->vl, 1);
  } else {
    if (MP_NEGP(a))
      mpx_usub(d->v, d->vl, a->v, a->vl, &one, &one + 1);
    else
      mpx_uadd(d->v, d->vl, a->v, a->vl, &one, &one + 1);
  }
  d->f = (a->f & (MP_NEG | MP_BURN)) ^ MP_NEG;
  MP_SHRINK(d);
  return (d);
}

/* --- @mp_add@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a, *b@ = sources
 *
 * Returns:	Result, @a@ added to @b@.
 */

mp *mp_add(mp *d, mp *a, mp *b)
{
  MP_DEST(d, MAX(MP_LEN(a), MP_LEN(b)) + 1, a->f | b->f);
  if (!((a->f ^ b->f) & MP_NEG))
    mpx_uadd(d->v, d->vl, a->v, a->vl, b->v, b->vl);
  else {
    if (MPX_UCMP(a->v, a->vl, <, b->v, b->vl)) {
      mp *t = a; a = b; b = t;
    }
    mpx_usub(d->v, d->vl, a->v, a->vl, b->v, b->vl);
  }
  d->f = ((a->f | b->f) & MP_BURN) | (a->f & MP_NEG);
  MP_SHRINK(d);
  return (d);
}

/* --- @mp_sub@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a, *b@ = sources
 *
 * Returns:	Result, @b@ subtracted from @a@.
 */

mp *mp_sub(mp *d, mp *a, mp *b)
{
  unsigned sgn = 0;
  MP_DEST(d, MAX(MP_LEN(a), MP_LEN(b)) + 1, a->f | b->f);
  if ((a->f ^ b->f) & MP_NEG)
    mpx_uadd(d->v, d->vl, a->v, a->vl, b->v, b->vl);
  else {
    if (MPX_UCMP(a->v, a->vl, <, b->v, b->vl)) {
      mp *t = a; a = b; b = t;
      sgn = MP_NEG;
    }
    mpx_usub(d->v, d->vl, a->v, a->vl, b->v, b->vl);
  }
  d->f = ((a->f | b->f) & MP_BURN) | ((a->f ^ sgn) & MP_NEG);
  MP_SHRINK(d);
  return (d);
}

/* --- @mp_mul@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a, *b@ = sources
 *
 * Returns:	Result, @a@ multiplied by @b@.
 */

mp *mp_mul(mp *d, mp *a, mp *b)
{
  a = MP_COPY(a);
  b = MP_COPY(b);

  if (MP_LEN(a) <= MPK_THRESH || MP_LEN(b) <= MPK_THRESH) {
    MP_DEST(d, MP_LEN(a) + MP_LEN(b), a->f | b->f | MP_UNDEF);
    mpx_umul(d->v, d->vl, a->v, a->vl, b->v, b->vl);
  } else {
    size_t m = MAX(MP_LEN(a), MP_LEN(b));
    mpw *s;
    MP_DEST(d, 3 * m, a->f | b->f | MP_UNDEF);
    s = mpalloc(d->a, 5 * m);
    mpx_kmul(d->v, d->vl, a->v, a->vl, b->v, b->vl, s, s + 5 * m);
    mpfree(d->a, s);
  }

  d->f = ((a->f | b->f) & MP_BURN) | ((a->f ^ b->f) & MP_NEG);
  MP_SHRINK(d);
  MP_DROP(a);
  MP_DROP(b);
  return (d);
}

/* --- @mp_sqr@ --- *
 *
 * Arguments:	@mp *d@ = destination
 *		@mp *a@ = source
 *
 * Returns:	Result, @a@ squared.
 */

mp *mp_sqr(mp *d, mp *a)
{
  size_t m = MP_LEN(a);

  a = MP_COPY(a);
  if (m > MPK_THRESH) {
    mpw *s;
    MP_DEST(d, 3 * m, a->f | MP_UNDEF);
    s = mpalloc(d->a, 5 * m);
    mpx_ksqr(d->v, d->vl, a->v, a->vl, s, s + 5 * m);
    mpfree(d->a, s);
  } else {
    MP_DEST(d, 2 * m + 2, a->f | MP_UNDEF);
    mpx_usqr(d->v, d->vl, a->v, a->vl);
  }
  d->f = a->f & MP_BURN;
  MP_SHRINK(d);
  MP_DROP(a);
  return (d);
}

/* --- @mp_div@ --- *
 *
 * Arguments:	@mp **qq, **rr@ = destination, quotient and remainder
 *		@mp *a, *b@ = sources
 *
 * Use:		Calculates the quotient and remainder when @a@ is divided by
 *		@b@.  The destinations @*qq@ and @*rr@ must be distinct.
 *		Either of @qq@ or @rr@ may be null to indicate that the
 *		result is irrelevant.  (Discarding both results is silly.)
 *		There is a performance advantage if @a == *rr@.
 *
 *		The behaviour when @a@ and @b@ have the same sign is
 *		straightforward.  When the signs differ, this implementation
 *		chooses @r@ to have the same sign as @b@, rather than the
 *		more normal choice that the remainder has the same sign as
 *		the dividend.  This makes modular arithmetic a little more
 *		straightforward.
 */

void mp_div(mp **qq, mp **rr, mp *a, mp *b)
 {
  mp *r = rr ? *rr : MP_NEW;
  mp *q = qq ? *qq : MP_NEW;
  mpw *sv, *svl;

  /* --- Set the remainder up right --- *
   *
   * Just in case the divisor is larger, be able to cope with this.  It's not
   * important in @mpx_udiv@, but it is here because of the sign correction.
   */

  b = MP_COPY(b);
  a = MP_COPY(a);
  if (r)
    MP_DROP(r);
  r = a;
  MP_DEST(r, MAX(MP_LEN(a), MP_LEN(b)) + 2, a->f | b->f);

  /* --- Fix up the quotient too --- */

  r = MP_COPY(r);
  MP_DEST(q, MP_LEN(r), r->f | MP_UNDEF);
  MP_DROP(r);

  /* --- Set up some temporary workspace --- */

  {
    size_t rq = MP_LEN(b) + 1;
    sv = mpalloc(r->a, rq);
    svl = sv + rq;
  }

  /* --- Perform the calculation --- */

  mpx_udiv(q->v, q->vl, r->v, r->vl, b->v, b->vl, sv, svl);

  /* --- Sort out the sign of the results --- *
   *
   * If the signs of the arguments differ, and the remainder is nonzero, I
   * must add one to the absolute value of the quotient and subtract the
   * remainder from @b@.
   */

  q->f = ((r->f | b->f) & MP_BURN) | ((r->f ^ b->f) & MP_NEG);
  if (MP_NEGP(q)) {
    mpw *v;
    for (v = r->v; v < r->vl; v++) {
      if (*v) {
	MPX_UADDN(q->v, q->vl, 1);
	mpx_usub(r->v, r->vl, b->v, b->vl, r->v, r->vl);
	break;
      }
    }
  }

  r->f = ((r->f | b->f) & MP_BURN) | (b->f & MP_NEG);

  /* --- Store the return values --- */

  mpfree(r->a, sv);
  MP_DROP(b);

  if (!qq)
    MP_DROP(q);
  else {
    MP_SHRINK(q);
    *qq = q;
  }

  if (!rr)
    MP_DROP(r);
  else {
    MP_SHRINK(r);
    *rr = r;
  }
}

/* --- @mp_odd@ --- *
 *
 * Arguments:	@mp *d@ = pointer to destination integer
 *		@mp *m@ = pointer to source integer
 *		@size_t *s@ = where to store the power of 2
 *
 * Returns:	An odd integer integer %$t$% such that %$m = 2^s t$%.
 *
 * Use:		Computes a power of two and an odd integer which, when
 *		multiplied, give a specified result.  This sort of thing is
 *		useful in number theory quite often.
 */

mp *mp_odd(mp *d, mp *m, size_t *s)
{
  size_t ss = 0;
  const mpw *v, *vl;

  v = m->v;
  vl = m->vl;
  for (; !*v && v < vl; v++)
    ss += MPW_BITS;
  if (v >= vl)
    ss = 0;
  else {
    mpw x = *v;
    unsigned z = MPW_P2;
    mpw mask = ((mpw)1 << z) - 1;

    while (z) {
      if (!(x & mask)) {
	x >>= z;
	ss += z;
      }
      z >>= 1;
      mask >>= z;
    }
  }

  *s = ss;
  return (mp_lsr(d, m, ss));
}

/*----- Test rig ----------------------------------------------------------*/

#ifdef TEST_RIG

static int verify(const char *op, mp *expect, mp *result, mp *a, mp *b)
{
  if (!MP_EQ(expect, result)) {
    fprintf(stderr, "\n*** %s failed", op);
    fputs("\n*** a	= ", stderr); mp_writefile(a, stderr, 10);
    fputs("\n*** b	= ", stderr); mp_writefile(b, stderr, 10);
    fputs("\n*** result = ", stderr); mp_writefile(result, stderr, 10);
    fputs("\n*** expect = ", stderr); mp_writefile(expect, stderr, 10);
    fputc('\n', stderr);
    return (0);
  }
  return (1);
}

#define RIG(name, op)							\
  static int t##name(dstr *v)						\
  {									\
    mp *a = *(mp **)v[0].buf;						\
    mpw n = *(int *)v[1].buf;						\
    mp b;								\
    mp *r = *(mp **)v[2].buf;						\
    mp *c = op(MP_NEW, a, n);						\
    int ok;								\
    mp_build(&b, &n, &n + 1);						\
    ok = verify(#name, r, c, a, &b);					\
    mp_drop(a); mp_drop(c); mp_drop(r);					\
    assert(mparena_count(MPARENA_GLOBAL) == 0);				\
    return (ok);							\
  }

RIG(lsl, mp_lsl)
RIG(lsr, mp_lsr)
RIG(lsl2c, mp_lsl2c)
RIG(lsr2c, mp_lsr2c)

#undef RIG

#define RIG(name, op)							\
  static int t##name(dstr *v)						\
  {									\
    mp *a = *(mp **)v[0].buf;						\
    mp *b = *(mp **)v[1].buf;						\
    mp *r = *(mp **)v[2].buf;						\
    mp *c = op(MP_NEW, a, b);						\
    int ok = verify(#name, r, c, a, b);					\
    mp_drop(a); mp_drop(b); mp_drop(c); mp_drop(r);			\
    assert(mparena_count(MPARENA_GLOBAL) == 0);				\
    return (ok);							\
  }

RIG(add, mp_add)
RIG(sub, mp_sub)
RIG(mul, mp_mul)
RIG(exp, mp_exp)

#undef RIG

static int tdiv(dstr *v)
{
  mp *a = *(mp **)v[0].buf;
  mp *b = *(mp **)v[1].buf;
  mp *q = *(mp **)v[2].buf;
  mp *r = *(mp **)v[3].buf;
  mp *c = MP_NEW, *d = MP_NEW;
  int ok = 1;
  mp_div(&c, &d, a, b);
  ok &= verify("div(quotient)", q, c, a, b);
  ok &= verify("div(remainder)", r, d, a, b);
  mp_drop(a); mp_drop(b); mp_drop(c); mp_drop(d); mp_drop(r); mp_drop(q);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int tbin(dstr *v)
{
  static mp *(*fn[])(mp *, mp *, mp *) = {
#define DO(string) mp_bit##string##2c,
MPX_DOBIN(DO)
#undef DO
  };
  int ok = 1;
  unsigned op = 0;
  mp *a = *(mp **)v[1].buf;
  mp *b = *(mp **)v[2].buf;
  mp *r = *(mp **)v[3].buf;
  mp *c;

  if (strcmp(v[0].buf, "and") == 0) op = 1;
  else if (strcmp(v[0].buf, "or") == 0) op = 7;
  else if (strcmp(v[0].buf, "nand") == 0) op = 14;
  else if (strcmp(v[0].buf, "nor") == 0) op = 8;
  else if (strcmp(v[0].buf, "xor") == 0) op = 6;
  else {
    char *p = v[0].buf;
    while (*p) {
      op <<= 1;
      if (*p++ == '1')
	op |= 1;
    }
  }

  c = fn[op](MP_NEW, a, b);
  ok = verify(v[0].buf, r, c, a, b);
  mp_drop(a); mp_drop(b); mp_drop(r); mp_drop(c);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int tset(dstr *v)
{
  mp *a = *(mp **)v[0].buf;
  unsigned long n = *(unsigned long *)v[1].buf;
  mp *r = *(mp **)v[2].buf;
  mp *c;
  int ok = 1;

  c = mp_setbit2c(MP_NEW, a, n);
  if (!MP_EQ(c, r)) {
    ok = 0;
    fprintf(stderr, "\n***setbit (set) failed");
    fputs("\n*** a  = ", stderr); mp_writefile(a, stderr, 16);
    fprintf(stderr, "\n*** n  = %lu", n);
    fputs("\n*** r  = ", stderr); mp_writefile(r, stderr, 16);
    fputs("\n*** c = ", stderr); mp_writefile(c, stderr, 16);
    fputc('\n', stderr);
  }
  if (!mp_testbit2c(r, n)) {
    ok = 0;
    fprintf(stderr, "\n***setbit (test) failed");
    fprintf(stderr, "\n*** n  = %lu", n);
    fputs("\n*** r  = ", stderr); mp_writefile(r, stderr, 16);
    fputc('\n', stderr);
  }
  mp_drop(a);
  mp_drop(r);
  mp_drop(c);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int tclr(dstr *v)
{
  mp *a = *(mp **)v[0].buf;
  unsigned long n = *(unsigned long *)v[1].buf;
  mp *r = *(mp **)v[2].buf;
  mp *c;
  int ok = 1;

  c = mp_clearbit2c(MP_NEW, a, n);
  if (!MP_EQ(c, r)) {
    ok = 0;
    fprintf(stderr, "\n***clrbit (set) failed");
    fputs("\n*** a  = ", stderr); mp_writefile(a, stderr, 16);
    fprintf(stderr, "\n*** n  = %lu", n);
    fputs("\n*** r  = ", stderr); mp_writefile(r, stderr, 16);
    fputs("\n*** c = ", stderr); mp_writefile(c, stderr, 16);
    fputc('\n', stderr);
  }
  if (mp_testbit2c(r, n)) {
    ok = 0;
    fprintf(stderr, "\n***clrbit (test) failed");
    fprintf(stderr, "\n*** n  = %lu", n);
    fputs("\n*** r  = ", stderr); mp_writefile(r, stderr, 16);
    fputc('\n', stderr);
  }
  mp_drop(a);
  mp_drop(c);
  mp_drop(r);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int tneg(dstr *v)
{
  mp *a = *(mp **)v[0].buf;
  mp *r = *(mp **)v[1].buf;
  int ok = 1;
  mp *n = mp_neg(MP_NEW, a);
  if (!MP_EQ(r, n)) {
    ok = 0;
    fprintf(stderr, "\n*** neg failed\n");
    fputs("\n*** a  = ", stderr); mp_writefile(a, stderr, 10);
    fputs("\n*** r  = ", stderr); mp_writefile(r, stderr, 10);
    fputs("\n*** n  = ", stderr); mp_writefile(n, stderr, 10);
    fputc('\n', stderr);
  }
  mp_drop(n);
  n = mp_neg(a, a);
  if (!MP_EQ(r, n)) {
    ok = 0;
    fprintf(stderr, "\n*** neg failed\n");
    fputs("\n*** a* = ", stderr); mp_writefile(a, stderr, 10);
    fputs("\n*** r  = ", stderr); mp_writefile(r, stderr, 10);
    fputs("\n*** n  = ", stderr); mp_writefile(n, stderr, 10);
    fputc('\n', stderr);
  }
  mp_drop(a);
  mp_drop(r);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static int todd(dstr *v)
{
  mp *a = *(mp **)v[0].buf;
  size_t rs = *(uint32 *)v[1].buf;
  mp *rt = *(mp **)v[2].buf;
  int ok = 1;
  mp *t;
  size_t s;
  t = mp_odd(MP_NEW, a, &s);
  if (s != rs || !MP_EQ(t, rt)) {
    ok = 0;
    fprintf(stderr, "\n*** odd failed");
    fputs("\n*** a  = ", stderr); mp_writefile(a, stderr, 10);
    fprintf(stderr, "\n*** s  = %lu", (unsigned long)s);
    fputs("\n*** t  = ", stderr); mp_writefile(t, stderr, 10);
    fprintf(stderr, "\n*** rs = %lu", (unsigned long)rs);
    fputs("\n*** rt = ", stderr); mp_writefile(rt, stderr, 10);
    fputc('\n', stderr);
  }
  mp_drop(a);
  mp_drop(rt);
  mp_drop(t);
  assert(mparena_count(MPARENA_GLOBAL) == 0);
  return (ok);
}

static test_chunk tests[] = {
  { "lsl", tlsl, { &type_mp, &type_int, &type_mp, 0 } },
  { "lsr", tlsr, { &type_mp, &type_int, &type_mp, 0 } },
  { "lsl2c", tlsl2c, { &type_mp, &type_int, &type_mp, 0 } },
  { "lsr2c", tlsr2c, { &type_mp, &type_int, &type_mp, 0 } },
  { "setbit", tset, { &type_mp, &type_ulong, &type_mp, 0 } },
  { "clrbit", tclr, { &type_mp, &type_ulong, &type_mp, 0 } },
  { "add", tadd, { &type_mp, &type_mp, &type_mp, 0 } },
  { "sub", tsub, { &type_mp, &type_mp, &type_mp, 0 } },
  { "mul", tmul, { &type_mp, &type_mp, &type_mp, 0 } },
  { "div", tdiv, { &type_mp, &type_mp, &type_mp, &type_mp, 0 } },
  { "exp", texp, { &type_mp, &type_mp, &type_mp, 0 } },
  { "bin2c", tbin, { &type_string, &type_mp, &type_mp, &type_mp, 0 } },
  { "odd", todd, { &type_mp, &type_uint32, &type_mp, 0 } },
  { "neg", tneg, { &type_mp, &type_mp, 0 } },
  { 0, 0, { 0 } },
};

int main(int argc, char *argv[])
{
  sub_init();
  test_run(argc, argv, tests, SRCDIR "/t/mp");
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
