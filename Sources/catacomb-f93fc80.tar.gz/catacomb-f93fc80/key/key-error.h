/* -*-c-*-
 *
 * Key management error codes
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_KEY_ERROR_H
#define CATACOMB_KEY_ERROR_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Error codes -------------------------------------------------------*/

#define KEY_ERRORS(_)							\
  _(OK,		  0, "No error")					\
  _(BADTAG,	 -1, "Bad tag string")					\
  _(BADTYPE,	 -2, "Bad type string")					\
  _(BADCOMMENT,	 -3, "Bad comment string")				\
  _(DUPID,	 -4, "Key id already exists")				\
  _(DUPTAG,	 -5, "Key tag already exists")				\
  _(READONLY,	 -6, "Key file is read-only")				\
  _(WILLEXPIRE,	 -7, "Key will eventually expire")			\
  _(EXPIRED,	 -8, "Key has expired")					\
  _(BADFLAGS,	 -9, "Bad key flags string")				\
  _(BADPASS,	-10, "Failed to unlock key")				\
  _(WRONGTYPE,	-11, "Unexpected key encoding type")			\
  _(NOTFOUND,	-12, "Key not found")					\
  _(BADATTR,	-13, "Bad attribute name")				\
  _(MALFORMED,	-14, "Malformed key data")				\
  _(IO,		-15, "I/O error")					\

enum {
#define ENTRY(tag, num, str) KERR_##tag = num,
  KEY_ERRORS(ENTRY)
#undef ENTRY
  KERR__dummy
};

/*----- Functions provided ------------------------------------------------*/

/* --- @key_strerror@ --- *
 *
 * Arguments:	@int err@ = error code from @key_new@
 *
 * Returns:	Pointer to error string.
 *
 * Use:		Translates a @KERR@ error code into a human-readable string.
 */

extern const char *key_strerror(int /*err*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
