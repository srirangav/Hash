/* -*-c-*-
 *
 * Reading of passphrases (Unix-specific)
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <unistd.h>

#include <mLib/dstr.h>

#include "passphrase.h"
#include "pixie.h"

/*----- Static variables --------------------------------------------------*/

static int fd = -1;
static unsigned flags = 0;

#define f_fail 1u

/*----- Main code ---------------------------------------------------------*/

/* --- @passphrase_connect@ ---
 *
 * Arguments:	@const char *sock@ = socket name to connect to, or null for
 *		default
 *
 * Returns:	Zero if OK, nonzero if it failed
 *
 * Use:		Attempts to connect to the passphrase pixie.
 */

int passphrase_connect(const char *sock)
{
  if (fd != -1)
    close(fd);
  if ((fd = pixie_open(sock)) < 0) {
    flags |= f_fail;
    return (-1);
  }
  flags &= ~f_fail;
  return (0);
}

static int pconn(void)
{
  if (fd != -1)
    return (0);
  if (flags & f_fail)
    return (-1);
  return (passphrase_connect(0));
}

/* --- @passphrase_read@ --- *
 *
 * Arguments:	@const char *tag@ = pointer to passphrase tag string
 *		@unsigned mode@ = reading mode
 *		@char *buf@ = pointer to destination buffer
 *		@size_t sz@ = size of destination buffer
 *
 * Returns:	Zero if successful, nonzero on failure.
 *
 * Use:		Reads a passphrase from the user, using some system-specific
 *		secure mechanism.  The mechanism may keep a cache of
 *		passphrases, so the user may not necessarily be prompted.
 */

int passphrase_read(const char *tag, unsigned mode, char *buf, size_t sz)
{
  dstr d = DSTR_INIT;
  int rc = 1;

  /* --- Try talking to the pixie --- */

  if (!pconn()) {
    rc = pixie_read(fd, tag, mode, buf, sz);
    if (rc < 0) {
      close(fd);
      fd = -1;
      return (-1);
    }
    if (rc == 0)
      return (0);
  }

  /* --- Read from the terminal --- */

  dstr_putf(&d, "%s %s: ",
	    mode == PMODE_READ ? "Passphrase" : "New passphrase",
	    tag);
  if (pixie_getpass(d.buf, buf, sz))
    goto fail;
  if (mode == PMODE_VERIFY) {
    char b[1024];
    DRESET(&d);
    dstr_putf(&d, "Verify passphrase %s: ", tag);
    if (pixie_getpass(d.buf, b, sizeof(b)) || strcmp(b, buf) != 0) {
      memset(b, 0, sizeof(b));
      goto fail;
    }
  }
  dstr_destroy(&d);

  /* --- If the pixie is interested, tell it the new passphrase --- */

  if (fd >= 0)
    pixie_set(fd, tag, buf);
  return (0);

  /* --- Tidy up after a failure --- */

fail:
  dstr_destroy(&d);
  memset(buf, 0, sz);
  return (-1);
}

/* --- @passphrase_cancel@ --- *
 *
 * Arguments:	@const char *tag@ = pointer to passphrase tag string
 *
 * Returns:	---
 *
 * Use:		Attempts to make the passphrase cache forget about a
 *		particular passphrase.  This may be useful if the passphrase
 *		turns out to be wrong, or if the user is attempting to change
 *		the passphrase.
 */

void passphrase_cancel(const char *tag)
{
  if (!pconn())
    pixie_cancel(fd, tag);
}

/*----- That's all, folks -------------------------------------------------*/
