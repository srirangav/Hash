/* -*-c-*-
 *
 * Key binary encoding
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>

#include <mLib/bits.h>
#include <mLib/dstr.h>
#include <mLib/sub.h>
#include <mLib/sym.h>

#include "key-data.h"
#include "mp.h"
#include "mptext.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @key_decode@ --- *
 *
 * Arguments:	@const void *p@ = pointer to buffer to read
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	The newly-read key data, or null if it failed.
 *
 * Use:		Decodes a binary representation of a key.
 */

key_data *key_decode(const void *p, size_t sz)
{
  const octet *q = p;
  size_t psz;
  key_data *kd;
  unsigned e;

  /* --- Parse the header information --- *
   *
   * Make sure the size matches external reality.  Security holes have been
   * known to creep in without this sort of check.  (No, this isn't an after-
   * the-fact patch-up.)
   */

  e = LOAD16(q);
  psz = LOAD16(q + 2);
  if (psz + 4 > sz)
    return (0);

  /* --- Now decide what to do --- */

  switch (e & KF_ENCMASK) {

    /* --- Plain binary data --- */

    case KENC_BINARY:
    case KENC_ENCRYPT:
      kd = key_newbinary(e, q + 4, psz);
      break;

    /* --- Multiprecision integer data --- */

    case KENC_MP:
      kd = key_newmp(e, mp_loadb(e & KF_BURN ? MP_NEWSEC : MP_NEW,
				 q + 4, psz));
      break;

    /* --- String data --- */

    case KENC_STRING:
      kd = key_newraw(e);
      kd->u.p = xmalloc(sz + 1);
      memcpy(kd->u.p, q + 4, sz);
      kd->u.p[sz] = 0;
      break;

    /* --- Elliptic curve point data --- */

    case KENC_EC: {
      size_t xsz, ysz;
      kd = key_newraw(e);
      EC_CREATE(&kd->u.e);
      if (!sz) break;
      if (sz < 2) return (0);
      xsz = LOAD16(q + 4);
      if (sz < xsz + 4) return (0);
      ysz = LOAD16(q + 6 + xsz);
      if (sz < xsz + ysz + 4) return (0);
      kd->u.e.x = mp_loadb(MP_NEW, q + 6, xsz);
      kd->u.e.y = mp_loadb(MP_NEW, q + 8 + xsz, ysz);
    } break;

    /* --- Structured key data --- */

    case KENC_STRUCT: {
      dstr d = DSTR_INIT;
      key_data *nkd;

      if ((e & ~KF_ENCMASK) || (psz & 3))
	return (0);
      q += 4;
      kd = key_newstruct();

      while (psz) {

	/* --- Read the tag string --- */

	DRESET(&d);
	sz = LOAD8(q);
	if (sz >= psz)
	  goto fail;
	DPUTM(&d, q + 1, sz);
	DPUTZ(&d);
	sz = (sz + 4) & ~3;
	q += sz; psz -= sz;

	/* --- Read the encoding and size --- */

	sz = (LOAD16(q + 2) + 7) & ~3;
	if (sz > psz)
	  goto fail;

	/* --- Create a table node and fill it in --- */

	if ((nkd = key_decode(q, sz)) == 0)
	  goto fail;
	key_structsteal(kd, d.buf, nkd);
	psz -= sz;
	q += sz;
      }
      dstr_destroy(&d);
      break;

      /* --- Tidy up after a failure --- */

    fail:
      dstr_destroy(&d);
      key_drop(kd);
      return (0);
    } break;

    /* --- Everything else --- */

    default:
      return (0);
  }

  /* --- OK, that was good --- */

  kd->e = e;
  return (kd);
}

/* --- @key_encode@ --- *
 *
 * Arguments:	@key_data *k@ = pointer to key data block
 *		@dstr *d@ = pointer to destination string
 *		@const key_filter *kf@ = pointer to key selection block
 *
 * Returns:	Nonzero if an item was actually written.
 *
 * Use:		Encodes a key block as binary data.
 */

static int ksbyname(const void *a, const void *b) {
  key_struct *const *x = a, *const *y = b;
  return (strcmp(SYM_NAME(*x), SYM_NAME(*y)));
}

int key_encode(key_data *k, dstr *d, const key_filter *kf)
{
  int rc = 0;
  if (!KEY_MATCH(k, kf))
    return (0);
  switch (k->e & KF_ENCMASK) {
    case KENC_BINARY:
    case KENC_ENCRYPT: {
      char *p;

      DENSURE(d, (k->u.k.sz + 7) & ~3);
      p = d->buf + d->len;
      STORE16(p, k->e);
      STORE16(p + 2, k->u.k.sz);
      d->len += 4;
      DPUTM(d, k->u.k.k, k->u.k.sz);
      rc = 1;
    } break;

    case KENC_MP: {
      char *p;
      size_t sz = mp_octets(k->u.m);

      DENSURE(d, (sz + 7) & ~3);
      p = d->buf + d->len;
      STORE16(p, k->e);
      STORE16(p + 2, sz);
      mp_storeb(k->u.m, p + 4, sz);
      d->len += sz + 4;
      rc = 1;
    } break;

    case KENC_STRING: {
      char *p;
      size_t sz = strlen(k->u.p);

      DENSURE(d, (sz + 7) & ~3);
      p = d->buf + d->len;
      STORE16(p, k->e);
      STORE16(p + 2, sz);
      memcpy(p + 4, k->u.p, sz);
      d->len += sz + 4;
      rc = 1;
    } break;

    case KENC_EC: {
      char *p;
      size_t xsz = 0, ysz = 0;
      size_t sz;

      if (EC_ATINF(&k->u.e))
	sz = 0;
      else {
	xsz = mp_octets(k->u.e.x);
	ysz = mp_octets(k->u.e.y);
	sz = xsz + ysz + 4;
      }
      DENSURE(d, (sz + 7) & ~3);
      p = d->buf + d->len;
      STORE16(p, k->e);
      STORE16(p + 2, sz);
      if (!EC_ATINF(&k->u.e)) {
	STORE16(p + 4, xsz);
	mp_storeb(k->u.e.x, p + 6, xsz);
	STORE16(p + 6 + xsz, ysz);
	mp_storeb(k->u.e.y, p + 8 + xsz, ysz);
      }
      d->len += sz + 4;
      rc = 1;
    } break;

    case KENC_STRUCT: {
      size_t n;
      char *p;
      key_struct *ks, **ksv;
      size_t nks, j;
      sym_iter i;

      n = d->len;
      DENSURE(d, 4);
      p = d->buf + n;
      STORE16(p, k->e & KF_ENCMASK);
      d->len += 4;

      for (nks = 0, sym_mkiter(&i, &k->u.s);
	   (ks = sym_next(&i)) != 0;
	   nks++);
      if (nks) {
	ksv = xmalloc(nks * sizeof(*ksv));
	for (j = 0, sym_mkiter(&i, &k->u.s); (ks = sym_next(&i)) != 0; j++)
	  ksv[j] = ks;
	qsort(ksv, nks, sizeof(*ksv), ksbyname);
	for (j = 0; j < nks; j++) {
	  size_t o = d->len;
	  ks = ksv[j];
	  DENSURE(d, 1);
	  *(octet *)(d->buf + d->len++) = strlen(SYM_NAME(ks));
	  DPUTS(d, SYM_NAME(ks));
	  while (d->len & 3)
	    DPUTC(d, 0);
	  if (key_encode(ks->k, d, kf))
	    rc = 1;
	  else
	    d->len = o;
	}
	xfree(ksv);
      }
      if (!rc)
	d->len = n;
      else {
	p = d->buf + n + 2;
	n = d->len - n - 4;
	STORE16(p,  n);
      }
    } break;
  }
  while (d->len & 3)
    DPUTC(d, 0);
  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
