/* -*-c-*-
 *
 * Translating key error codes into strings
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <mLib/macros.h>
#include "key-error.h"

/*----- Error reporting ---------------------------------------------------*/

/* --- @key_strerror@ --- *
 *
 * Arguments:	@int err@ = error code from @key_new@
 *
 * Returns:	Pointer to error string.
 *
 * Use:		Translates a @KERR@ error code into a human-readable
 *		string.
 */

const char *key_strerror(int err)
{
  static const char *const tab[] = {
#define ENTRY(tag, num, str) str,
    KEY_ERRORS(ENTRY)
#undef ENTRY
    "Unknown error code"
  };

  unsigned e = -err;
  if (e >= N(tab))
    e = N(tab) - 1;
 return (tab[e]);
}

/*----- That's all, folks -------------------------------------------------*/
