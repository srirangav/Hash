/* -*-c-*-
 *
 * Spit out random numbers
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "config.h"

#include <assert.h>
#include <errno.h>
#include <math.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#ifndef PORTABLE
#  include <unistd.h>
#  include <sys/time.h>
#endif

#include <mLib/darray.h>
#include <mLib/dstr.h>
#include <mLib/mdwopt.h>
#include <mLib/quis.h>
#include <mLib/report.h>
#include <mLib/sub.h>

#include "mp.h"
#include "mpint.h"
#include "mplimits.h"
#include "mptext.h"

#include "fipstest.h"
#include "grand.h"
#include "maurer.h"
#include "key.h"

#include "lcrand.h"
#include "fibrand.h"
#include "rand.h"
#include "noise.h"

#include "bbs.h"
#include "mprand.h"

#include "chacha.h"
#include "rc4.h"
#include "salsa20.h"
#include "salsa20-core.h"
#include "seal.h"

#include "des-ofb.h"
#include "des3-ofb.h"
#include "rc2-ofb.h"
#include "rc5-ofb.h"
#include "mars-ofb.h"
#include "skipjack-ofb.h"
#include "tea-ofb.h"
#include "xtea-ofb.h"
#include "blowfish-ofb.h"
#include "twofish-ofb.h"
#include "idea-ofb.h"
#include "cast128-ofb.h"
#include "cast256-ofb.h"
#include "noekeon-ofb.h"
#include "rijndael-ofb.h"
#include "rijndael192-ofb.h"
#include "rijndael256-ofb.h"
#include "safer-ofb.h"
#include "safersk-ofb.h"
#include "square-ofb.h"
#include "serpent-ofb.h"

#include "des-counter.h"
#include "des3-counter.h"
#include "rc2-counter.h"
#include "rc5-counter.h"
#include "mars-counter.h"
#include "skipjack-counter.h"
#include "tea-counter.h"
#include "xtea-counter.h"
#include "blowfish-counter.h"
#include "twofish-counter.h"
#include "idea-counter.h"
#include "cast128-counter.h"
#include "cast256-counter.h"
#include "noekeon-counter.h"
#include "rijndael-counter.h"
#include "rijndael192-counter.h"
#include "rijndael256-counter.h"
#include "safer-counter.h"
#include "safersk-counter.h"
#include "square-counter.h"
#include "serpent-counter.h"

#include "md2-mgf.h"
#include "md4-mgf.h"
#include "md5-mgf.h"
#include "sha-mgf.h"
#include "tiger-mgf.h"
#include "rmd128-mgf.h"
#include "rmd160-mgf.h"
#include "rmd256-mgf.h"
#include "rmd320-mgf.h"

#include "rmd160.h"

/*----- Data structures ---------------------------------------------------*/

typedef struct gen {
  const char *name;
  grand *(*seed)(unsigned /*i*/);
  unsigned i;
  const char *help;
} gen;

extern gen generators[];

#define CIPHERS								\
  E(DES, des)								\
  E(DES3, des3)								\
  E(RC2, rc2)								\
  E(RC5, rc5)								\
  E(MARS, mars)								\
  E(SKIPJACK, skipjack)							\
  E(TEA, tea)								\
  E(XTEA, xtea)								\
  E(BLOWFISH, blowfish)							\
  E(TWOFISH, twofish)							\
  E(IDEA, idea)								\
  E(CAST128, cast128)							\
  E(CAST256, cast256)							\
  E(SQUARE, square)							\
  E(SAFER, safer)							\
  E(SAFERSK, safersk)							\
  E(NOEKEON, noekeon)							\
  E(RIJNDAEL, rijndael)							\
  E(RIJNDAEL192, rijndael192)						\
  E(RIJNDAEL256, rijndael256)						\
  E(SERPENT, serpent)

#define HASHES								\
  E(MD2, md2)								\
  E(MD4, md4)								\
  E(MD5, md5)								\
  E(SHA, sha)								\
  E(TIGER, tiger)							\
  E(RMD128, rmd128)							\
  E(RMD160, rmd160)							\
  E(RMD256, rmd256)							\
  E(RMD320, rmd320)

#define E(PRE, pre) CIPHER_##PRE,
enum { CIPHERS CIPHER__bogus };
#undef E

#define E(PRE, pre) HASH_##PRE,
enum { HASHES HASH__bogus };
#undef E

static const struct {
  const octet *keysz;
  size_t blksz;
  grand *(*ofb)(const void */*k*/, size_t /*sz*/);
  grand *(*counter)(const void */*k*/, size_t /*sz*/);
} ciphertab[] = {
#define E(PRE, pre)							\
  { pre##_keysz, PRE##_BLKSZ, pre##_ofbrand, pre##_counterrand },
  CIPHERS
#undef E
};

static const struct {
  const gchash *h;
  const octet *keysz;
  grand *(*mgf)(const void */*k*/, size_t /*sz*/);
} hashtab[] = {
#define E(PRE, pre)							\
  { &pre, pre##_mgfkeysz, pre##_mgfrand },
  HASHES
#undef E
};

#define SALSAE								\
  E(salsa20, 20,, SALSA20)						\
  E(salsa20, 12,, SALSA20)						\
  E(salsa20, 8,, SALSA20)						\
  E(xsalsa20, 20, X, SALSA20)						\
  E(xsalsa20, 12, X, SALSA20)						\
  E(xsalsa20, 8, X, SALSA20)						\
  E(chacha, 20,, CHACHA)						\
  E(chacha, 12,, CHACHA)						\
  E(chacha, 8,, CHACHA)							\
  E(xchacha, 20, X, CHACHA)						\
  E(xchacha, 12, X, CHACHA)						\
  E(xchacha, 8, X, CHACHA)

#define E(pre, r, x, BASE) pre##_##r##_INDEX,
enum { SALSAE BOGUS_SALSA };
#undef E

#define SALSA20_GEN(pre, r) SALSA20_DECOR(pre, r, _rand)
#define CHACHA_GEN(pre, r) pre##r##_rand

#define SALSA20_NAME(r) SALSA20_NAME_##r
#define XSALSA20_NAME(r) "x" SALSA20_NAME_##r
#define CHACHA_NAME(r) "chacha" #r
#define XCHACHA_NAME(r) "xchacha" #r

static struct {
  size_t noncesz;
  grand *(*gen)(const void *, size_t, const void *);
} salsatab[] = {
#define E(pre, r, x, BASE) { x##BASE##_NONCESZ, BASE##_GEN(pre, r) },
  SALSAE
#undef E
};

/*----- Miscellaneous static data -----------------------------------------*/

static FILE *outfp;
static mp *outsz = 0;
static unsigned maurer_lo = 5, maurer_hi = 8;

static int argc;
static char **argv;

static unsigned flags = 0;

#define f_progress 1u
#define f_file 2u
#define f_fips 4u
#define f_maurer 8u
#define f_timer 16u
#define f_discard 32u

/*----- Help options ------------------------------------------------------*/

static void usage(FILE *fp)
{
  pquis(fp, "Usage: $ generator [options]\n");
}

static void version(FILE *fp)
{
  pquis(fp, "$, Catacomb version " VERSION "\n");
}

static void help(FILE *fp)
{
  version(fp);
  fputc('\n', fp);
  usage(fp);
  pquis(fp, "\n\
Emits a stream of random bytes suitable for, well, all sorts of things.\n\
The primary objective is to be able to generate streams of input for\n\
statistical tests, such as Diehard.\n\
\n\
Options are specific to the particular generator, although there's a\n\
common core set:\n\
\n\
-h, --help		Display this help message.\n\
-v, --version		Display the program's version number.\n\
-u, --usage		Display a useless usage message.\n\
\n\
-l, --list		Show a list of the supported generators, with\n\
			their options.\n\
-f, --fipstest		Run the FIPS 140-1 randomness test.\n\
-m, --maurer[=LO-HI]	Run Maurer's universal statistical test.\n\
-o, --output FILE	Write output to FILE, not stdout.\n\
-z, --size SIZE		Emit SIZE bytes, not an unlimited number.\n\
-p, --progress		Show a little progress meter (on stderr).\n\
-T, --timer		Keep track of the CPU time used by the generator.\n\
-d, --discard		Discard the generated output.\n\
\n\
(A SIZE may be followed by `g' for gigabytes, `m' for megabytes, or\n\
`k' for kilobytes.  If unqualified, an amount in bytes is assumed.)\n\
");
}

/*----- Main options parser -----------------------------------------------*/

static struct option opts[] = {

  /* --- Standard GNU help options --- */

  { "help",	0,		0,	'h' },
  { "version",	0,		0,	'v' },
  { "usage",	0,		0,	'u' },

  /* --- Other useful things --- */

  { "list",	0,		0,	'l' },
  { "fipstest",	0,		0,	'f' },
  { "maurer",	OPTF_ARGOPT,	0,	'm' },
  { "output",	OPTF_ARGREQ,	0,	'o' },
  { "size",	OPTF_ARGREQ,	0,	'z' },
  { "progress",	0,		0,	'p' },
  { "timer",	0,		0,	'T' },
  { "discard",	0,		0,	'd' },

  /* --- End of main table --- */

  { 0,		0,		0,	0 }
};

static const char *sopts = "hvu lfm::o:z:pTd";

#ifndef OPTION_V
   DA_DECL(option_v, struct option);
#  define OPTION_V
#endif

static option_v optv = DA_INIT;
static dstr optd = DSTR_INIT;

/* --- @addopts@ --- *
 *
 * Arguments:	@const char *s@ = pointer to short options
 *		@struct option *l@ = pointer to long options
 *
 * Returns:	---
 *
 * Use:		Adds a collection of options to the table.
 */

static void addopts(const char *s, struct option *l)
{
  dstr_puts(&optd, s);
  if (DA_LEN(&optv))
    DA_SHRINK(&optv, 1);
  while (l->name)
    DA_PUSH(&optv, *l++);
  DA_PUSH(&optv, *l);
}

/* --- @opt@ --- *
 *
 * Arguments:	---
 *
 * Returns:	Next option from argument array.
 *
 * Use:		Fetches options, handling the standard ones.
 */

static int opt(void)
{
  for (;;) {
    int i = mdwopt(argc, argv, optd.buf, DA(&optv), 0, 0, 0);
    switch (i) {
      case 'h':
	help(stdout);
	exit(0);
      case 'v':
	version(stdout);
	exit(0);
      case 'u':
	usage(stdout);
	exit(0);
      case 'l': {
	gen *g;
	puts("Generators supported:");
	for (g = generators; g->name; g++)
	  printf("  %s %s\n", g->name, g->help);
	exit(0);
      } break;
      case 'f':
	flags |= f_fips;
	break;
      case 'm':
	flags |= f_maurer;
	if (optarg) {
	  char *p;
	  unsigned long lo, hi;
	  lo = strtoul(optarg, &p, 0);
	  if (*p == '-' || *p == ',')
	    hi = strtoul(p + 1, &p, 0);
	  else
	    hi = lo;
	  if (*p != 0 || hi < lo || lo == 0)
	    die(EXIT_FAILURE, "bad bit range `%s'", optarg);
	  maurer_lo = lo;
	  maurer_hi = hi;
	}
	break;
      case 'o':
	if (flags & f_file)
	  die(EXIT_FAILURE, "already set an output file");
	if (strcmp(optarg, "-") == 0)
	  outfp = stdout;
	else {
	  outfp = fopen(optarg, "w");
	  if (!outfp) {
	    die(EXIT_FAILURE, "couldn't open output file `%s': %s",
		optarg, strerror(errno));
	  }
	}
	flags |= f_file;
	break;
      case 'z': {
	char *p;
	outsz = mp_readstring(outsz, optarg, &p, 0);
	if (!outsz || MP_NEGP(outsz))
	  die(EXIT_FAILURE, "bad number `%s'", optarg);
	switch (*p) {
	  case 'G': case 'g': outsz = mp_lsl(outsz, outsz, 10);
	  case 'M': case 'm': outsz = mp_lsl(outsz, outsz, 10);
	  case 'K': case 'k': outsz = mp_lsl(outsz, outsz, 10);
	  case 0:
	    break;
	  default:
	    die(EXIT_FAILURE, "bad suffix `%s'", p);
	    break;
	}
	if (*p && p[1] != 0)
	  die(EXIT_FAILURE, "bad suffix `%s'", p);
      } break;
      case 'p':
	flags |= f_progress;
	break;
      case 'T':
	flags |= f_timer;
	break;
      case 'd':
	flags |= f_discard;
	break;
      default:
	return (i);
    }
  }
}

/*----- Manglers for seed strings -----------------------------------------*/

/* --- @unhex@ --- *
 *
 * Arguments:	@const char *p@ = pointer to input string
 *		@char **end@ = where the end goes
 *		@dstr *d@ = output buffer
 *
 * Returns:	---
 *
 * Use:		Transforms a hex string into a chunk of binary data.
 */

static void unhex(const char *p, char **end, dstr *d)
{
  while (p[0] && p[1]) {
    int x = p[0], y = p[1];
    if ('0' <= x && x <= '9') x -= '0';
    else if ('A' <= x && x <= 'F') x -= 'A' - 10;
    else if ('a' <= x && x <= 'f') x -= 'a' - 10;
    else x = 0;
    if ('0' <= y && y <= '9') y -= '0';
    else if ('A' <= y && y <= 'F') y -= 'A' - 10;
    else if ('a' <= y && y <= 'f') y -= 'a' - 10;
    else y = 0;
    DPUTC(d, (x << 4) + y);
    p += 2;
  }
  *end = (char *)p;
}

/* --- Generate a key --- */

static void textkey(dstr *d, const char *p, const octet *ksz)
{
  size_t sz = strlen(p);

  if (!sz)
    die(EXIT_FAILURE, "zero-length key string");
  if (keysz(sz, ksz) != sz)
    DPUTM(d, p, sz);
  else {
    rmd160_mgfctx g;
    rmd160_mgfinit(&g, p, sz);
    sz = keysz(0, ksz);
    dstr_ensure(d, sz);
    rmd160_mgfencrypt(&g, 0, d->buf, sz);
    d->len += sz;
  }
  assert(((void)"I can't seem to choose a good key size",
	  keysz(d->len, ksz) == d->len));
}

static void hexkey(dstr *d, const char *p, const octet *ksz)
{
  char *q;
  unhex(optarg, &q, d);
  if (*q)
    die(EXIT_FAILURE, "bad hex key `%s'", p);
  if (keysz(d->len, ksz) != d->len)
    die(EXIT_FAILURE, "bad key length");
}

static void randkey(dstr *d, const octet *ksz)
{
  size_t sz = keysz(0, ksz);
  dstr_ensure(d, sz);
  rand_get(RAND_GLOBAL, d->buf, sz);
  d->len += sz;
}

/*----- Generators --------------------------------------------------------*/

/* --- Blum-Blum-Shub strong generator --- */

static grand *gen_bbs(unsigned i)
{
  /* --- Default modulus --- *
   *
   * The factors of this number are
   *
   *  @p = 1229936431484295969649886203367009966370895964206162032259292413@
   *	  @7754313537966036459299022912838407755462506416274551744201653277@
   *	  @313130311731673973886822067@
   *
   *  @q = 9798171783943489959487301695884963889684294764514008432498259742@
   *	  @5374320073594018817245784145742769603334292182227671519041431067@
   *	  @61344781426317516045890159@
   *
   * Both %$p$% and %$q$% are prime; %$(p - 1)/2$% and %$(q - 1)/2$% have no
   * common factors.  They were found using this program, with random
   * starting points.
   *
   * I hope that, by publishing these factors, I'll dissuade people from
   * actually using this modulus in an attempt to attain real security.  The
   * program is quite quick at finding Blum numbers, so there's no excuse for
   * not generating your own.
   */

  const char *mt =
    "12051128439013574251357214209433471144307319411973256935382082"
    "84356405274180923922403660880355098909699130818163691602989614"
    "90135716255689660470370755013177656905237112577648090277537209"
    "93607817155427455344810369808478266925293635284364998010510985"
    "0503830397166360721262431179505917248447259735253684659338653";

  /* --- Other things --- */

  grand *r;
  const char *xt = 0;
  unsigned bits = 1024;
  mp *m, *x;
  unsigned show = 0;
  const char *kfile = 0, *id = 0, *ktype = 0;

  /* --- Parse options --- */

  static struct option opts[] = {
    { "modulus",	OPTF_ARGREQ,	0,	'M' },
    { "generate",	0,		0,	'g' },
    { "seed",		OPTF_ARGREQ,	0,	's' },
    { "bits",		OPTF_ARGREQ,	0,	'b' },
    { "show",		0,		0,	'S' },
    { "keyring",	OPTF_ARGREQ,	0,	'k' },
    { "id",		OPTF_ARGREQ,	0,	'i' },
    { "type",		OPTF_ARGREQ,	0,	't' },
    { 0,		0,		0,	0 }
  };

  addopts("M:gs:b:Sk:i:t:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 'M':
	mt = optarg;
	break;
      case 'g':
	mt = 0;
	break;
      case 's':
	xt = optarg;
	break;
      case 'b':
	bits = strtoul(optarg, 0, 0);
	if (bits == 0)
	  die(EXIT_FAILURE, "bad number of bits `%s'", optarg);
	break;
      case 'S':
	show = 1;
	break;
      case 'k':
	kfile = optarg;
	mt = 0;
	break;
      case 'i':
	id = optarg;
	mt = 0;
	break;
      case 't':
	ktype = optarg;
	mt = 0;
	break;
      default:
	return (0);
    }
  }

  /* --- Generate a modulus if one is requested --- */

  if (mt) {
    char *p;
    m = mp_readstring(MP_NEW, mt, &p, 0);
    if (!m || *p || (m->v[0] & 3) != 1)
      die(EXIT_FAILURE, "bad modulus `%s'", mt);
    /* Unfortunately I don't know how to test for a Blum integer */
  } else if (kfile || id || ktype) {
    key_file kf;
    key *kk;
    key_data *kd;

    /* --- Open the key file --- */

    if (!kfile)
      kfile = "keyring";
    if (key_open(&kf, kfile, KOPEN_READ, key_moan, 0)) {
      die(EXIT_FAILURE, "error opening key file `%s': %s",
	  kfile, strerror(errno));
    }

    /* --- Find the key --- */

    if (id) {
      if ((kk = key_bytag(&kf, id)) == 0)
	die(EXIT_FAILURE, "key `%s' not found", id);
    } else {
      if (!ktype)
	ktype = "bbs";
      if ((kk = key_bytype(&kf, ktype)) == 0)
	die(EXIT_FAILURE, "no suitable key with type `%s' found", ktype);
    }

    /* --- Read the key data --- */

    if ((kk->k->e & KF_ENCMASK) != KENC_STRUCT)
      die(EXIT_FAILURE, "key is not structured");
    if ((kd = key_structfind(kk->k, "n")) == 0)
      die(EXIT_FAILURE, "key has no subkey `n'");
    if ((kd->e & KF_ENCMASK) != KENC_MP)
      die(EXIT_FAILURE, "incompatible subkey encoding");
    m = MP_COPY(kd->u.m);
    key_close(&kf);
  } else {
    bbs_priv bp;

    if (bbs_gen(&bp, bits, &rand_global, 0,
		(flags & f_progress) ? pgen_ev : 0, 0))
      die(EXIT_FAILURE, "modulus generation failed");
    m = bp.n;

    if (show) {
      fputs("p = ", stderr);
      mp_writefile(bp.p, stderr, 10);
      fputs("\nq = ", stderr);
      mp_writefile(bp.q, stderr, 10);
      fputs("\nn = ", stderr);
      mp_writefile(bp.n, stderr, 10);
      fputc('\n', stderr);
    }

    mp_drop(bp.p);
    mp_drop(bp.q);
  }

  /* --- Set up a seed --- */

  if (!xt)
    x = mprand(MP_NEW, mp_bits(m) - 1, &rand_global, 1);
  else {
    char *p;
    x = mp_readstring(MP_NEW, xt, &p, 0);
    if (*p)
      die(EXIT_FAILURE, "bad modulus `%s'", xt);
  }

  /* --- Right --- */

  r = bbs_rand(m, x);

  mp_drop(m);
  mp_drop(x);
  return (r);
}

/* --- Catacomb's random number generator --- */

static grand *gen_rand(unsigned i)
{
  grand *r = rand_create();
  dstr d = DSTR_INIT;

  static struct option opts[] = {
    { "key",		OPTF_ARGREQ,	0,	'k' },
    { "text",		OPTF_ARGREQ,	0,	't' },
    { "hex",		OPTF_ARGREQ,	0,	'H' },
    { 0,		0,		0,	0 }
  };

  addopts("k:t:H:n", opts);

  r->ops->misc(r, RAND_NOISESRC, &noise_source);
  r->ops->misc(r, RAND_SEED, 160);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 'k':
	DRESET(&d);
	textkey(&d, optarg, rmd160_hmackeysz);
	r->ops->misc(r, RAND_KEY, d.buf, d.len);
	break;
      case 't':
	r->ops->misc(r, GRAND_SEEDBLOCK, optarg, strlen(optarg));
	break;
      case 'H':
	DRESET(&d);
	hexkey(&d, optarg, rmd160_hmackeysz);
	r->ops->misc(r, GRAND_SEEDBLOCK, d.buf, d.len);
	break;
    }
  }

  dstr_destroy(&d);
  return (r);
}

/* --- RC4 output --- */

static grand *gen_rc4(unsigned i)
{
  grand *r;
  dstr d = DSTR_INIT;

  static struct option opts[] = {
    { "key",		OPTF_ARGREQ,	0,	'k' },
    { "hex",		OPTF_ARGREQ,	0,	'H' },
    { 0,		0,		0,	0 }
  };

  addopts("k:H:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 'k':
	DRESET(&d);
	textkey(&d, optarg, rc4_keysz);
	break;
      case 'H':
	DRESET(&d);
	hexkey(&d, optarg, rc4_keysz);
	break;
      default:
	return (0);
    }
  }

  if (!d.len)
    randkey(&d, rc4_keysz);
  r = rc4_rand(d.buf, d.len);
  dstr_destroy(&d);
  return (r);
}

/* --- SEAL output --- */

static grand *gen_seal(unsigned i)
{
  grand *r;
  dstr d = DSTR_INIT;
  uint32 n = 0;

  static struct option opts[] = {
    { "key",		OPTF_ARGREQ,	0,	'k' },
    { "hex",		OPTF_ARGREQ,	0,	'H' },
    { "sequence",	OPTF_ARGREQ,	0,	'n' },
    { 0,		0,		0,	0 }
  };

  addopts("k:H:n:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 'k':
	DRESET(&d);
	textkey(&d, optarg, seal_keysz);
	break;
      case 'H':
	DRESET(&d);
	hexkey(&d, optarg, seal_keysz);
	break;
      case 'n': {
	char *p;
	n = strtoul(optarg, &p, 0);
	if (*p)
	  die(EXIT_FAILURE, "bad number `%s'", optarg);
      } break;
      default:
	return (0);
    }
  }

  if (!d.len)
    randkey(&d, seal_keysz);
  r = seal_rand(d.buf, d.len, n);
  dstr_destroy(&d);
  return (r);
}

/* --- Salsa20, XSalsa20, ChaCha, and XChaCha --- */

static grand *gen_salsae(unsigned i)
{
  grand *r;
  char *p;
  dstr d = DSTR_INIT;
  dstr n = DSTR_INIT;
  kludge64 pos = { 0 };
  octet posbuf[8];
  mp *x;

  static struct option opts[] = {
    { "key",		OPTF_ARGREQ,	0,	'k' },
    { "hex",		OPTF_ARGREQ,	0,	'H' },
    { "nonce",		OPTF_ARGREQ,	0,	'n' },
    { "seek",		OPTF_ARGREQ,	0,	's' },
    { 0,		0,		0,	0 }
  };

  addopts("k:H:n:s:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 'k':
	DRESET(&d);
	textkey(&d, optarg, salsa20_keysz);
	break;
      case 'H':
	DRESET(&d);
	hexkey(&d, optarg, salsa20_keysz);
	break;
      case 'n':
	DRESET(&n);
	unhex(optarg, &p, &n);
	if (*p)
	  die(EXIT_FAILURE, "bad hex IV `%s'", optarg);
	if (n.len != salsatab[i].noncesz) {
	  die(EXIT_FAILURE, "bad nonce length %lu (must be %lu)",
	      (unsigned long)n.len, (unsigned long)salsatab[i].noncesz);
	}
	break;
      case 's':
	x = mp_readstring(MP_NEW, optarg, &p, 0);
	if (*p || MP_NEGP(x) || mp_bits(x) > 64)
	  die(EXIT_FAILURE, "bad position `%s'", optarg);
	mp_storeb(x, posbuf, sizeof(posbuf));
	mp_drop(x);
	LOAD64_(pos, posbuf);
	break;
      default:
	return (0);
    }
  }

  if (!d.len)
    randkey(&d, salsa20_keysz);
  r = salsatab[i].gen(d.buf, d.len, n.len ? n.buf : 0);
  r->ops->misc(r, SALSA20_SEEKU64, pos);

  dstr_destroy(&d);
  dstr_destroy(&n);

  return (r);
}

/* --- Output feedback generators --- */

static grand *gen_ofb(unsigned i)
{
  grand *r;
  dstr d = DSTR_INIT;
  dstr iv = DSTR_INIT;

  static struct option opts[] = {
    { "key",		OPTF_ARGREQ,	0,	'k' },
    { "hex",		OPTF_ARGREQ,	0,	'H' },
    { "iv",		OPTF_ARGREQ,	0,	'i' },
    { 0,		0,		0,	0 }
  };

  addopts("k:H:i:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 'k':
	DRESET(&d);
	textkey(&d, optarg, ciphertab[i].keysz);
	break;
      case 'H':
	DRESET(&d);
	hexkey(&d, optarg, ciphertab[i].keysz);
	break;
      case 'i': {
	char *p;
	DRESET(&iv);
	unhex(optarg, &p, &iv);
	if (*p)
	  die(EXIT_FAILURE, "bad hex IV `%s'", optarg);
	if (iv.len != ciphertab[i].blksz) {
	  die(EXIT_FAILURE, "bad IV length %lu (must be %lu)",
	      (unsigned long)iv.len, (unsigned long)ciphertab[i].blksz);
	}
      } break;
      default:
	return (0);
    }
  }

  if (!d.len)
    randkey(&d, ciphertab[i].keysz);
  r = ciphertab[i].ofb(d.buf, d.len);
  if (iv.len)
    r->ops->misc(r, GRAND_SEEDBLOCK, iv.buf);

  dstr_destroy(&d);
  dstr_destroy(&iv);
  return (r);
}

/* --- Counter generators --- */

static grand *gen_counter(unsigned i)
{
  grand *r;
  dstr d = DSTR_INIT;
  dstr iv = DSTR_INIT;

  static struct option opts[] = {
    { "key",		OPTF_ARGREQ,	0,	'k' },
    { "hex",		OPTF_ARGREQ,	0,	'H' },
    { "iv",		OPTF_ARGREQ,	0,	'i' },
    { 0,		0,		0,	0 }
  };

  addopts("k:H:i:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 'k':
	DRESET(&d);
	textkey(&d, optarg, ciphertab[i].keysz);
	break;
      case 'H':
	DRESET(&d);
	hexkey(&d, optarg, ciphertab[i].keysz);
	break;
      case 'i': {
	char *p;
	DRESET(&iv);
	unhex(optarg, &p, &iv);
	if (*p)
	  die(EXIT_FAILURE, "bad hex IV `%s'", optarg);
	if (iv.len != ciphertab[i].blksz) {
	  die(EXIT_FAILURE, "bad IV length %lu (must be %lu)",
	      (unsigned long)iv.len, (unsigned long)ciphertab[i].blksz);
	}
      } break;
      default:
	return (0);
    }
  }

  if (!d.len)
    randkey(&d, ciphertab[i].keysz);
  r = ciphertab[i].counter(d.buf, d.len);
  if (iv.len)
    r->ops->misc(r, GRAND_SEEDBLOCK, iv.buf);

  dstr_destroy(&d);
  dstr_destroy(&iv);
  return (r);
}

/* --- Mask generators --- */

static grand *gen_mgf(unsigned i)
{
  grand *r;
  dstr d = DSTR_INIT;
  uint32 c = 0;

  static struct option opts[] = {
    { "key",		OPTF_ARGREQ,	0,	'k' },
    { "hex",		OPTF_ARGREQ,	0,	'H' },
    { "index",		OPTF_ARGREQ,	0,	'i' },
    { 0,		0,		0,	0 }
  };

  addopts("k:H:i:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 'k':
	DRESET(&d);
	textkey(&d, optarg, hashtab[i].keysz);
	break;
      case 'H':
	DRESET(&d);
	hexkey(&d, optarg, hashtab[i].keysz);
	break;
      case 'i': {
	char *p;
	c = strtoul(optarg, &p, 0);
	if (*p)
	  die(EXIT_FAILURE, "bad index `%s'", optarg);
      } break;
      default:
	return (0);
    }
  }

  if (!d.len)
    randkey(&d, hashtab[i].keysz);

  r = hashtab[i].mgf(d.buf, d.len);
  if (c)
    r->ops->misc(r, GRAND_SEEDUINT32, c);

  dstr_destroy(&d);
  return (r);
}

/* --- Fibonacci generator --- */

static grand *gen_fib(unsigned i)
{
  grand *r;
  uint32 s = 0;
  char *p;
  unsigned set = 0;

  static struct option opts[] = {
    { "seed",		OPTF_ARGREQ,	0,	's' },
    { 0,		0,		0,	0 }
  };

  addopts("s:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 's':
	s = strtoul(optarg, &p, 0);
	if (*p)
	  die(EXIT_FAILURE, "bad integer `%s'", optarg);
	set = 1;
	break;
      default:
	return (0);
    }
  }
  r = fibrand_create(s);
  if (!set)
    r->ops->misc(r, GRAND_SEEDRAND, &rand_global);
  return (r);
}

/* --- LC generator --- */

static grand *gen_lc(unsigned i)
{
  uint32 s = 0;
  char *p;
  unsigned set = 0;

  static struct option opts[] = {
    { "seed",		OPTF_ARGREQ,	0,	's' },
    { 0,		0,		0,	0 }
  };

  addopts("s:", opts);

  for (;;) {
    int o = opt();
    if (o < 0)
      break;
    switch (o) {
      case 's':
	s = strtoul(optarg, &p, 0);
	if (*p)
	  die(EXIT_FAILURE, "bad integer `%s'", optarg);
	set = 1;
	break;
      default:
	return (0);
    }
  }
  if (!set) {
    do
      s = rand_global.ops->range(&rand_global, LCRAND_P);
    while (s == LCRAND_FIXEDPT);
  }
  return (lcrand_create(s));
}

/* --- Basic options parser -- can't generate output --- */

static grand *gen_opts(unsigned i)
{
  while (opt() >= 0)
    ;
  return (0);
}

/*----- Generators table --------------------------------------------------*/

gen generators[] = {
  { "fibonacci",	gen_fib,	0,
    "[-s SEED]" },
  { "lc",		gen_lc,		0,
    "[-s SEED]" },
#define E(PRE, pre)							\
  { #pre "-ofb",	gen_ofb,	CIPHER_##PRE,			\
    "[-k KEY-PHRASE] [-H HEX-KEY] [-i HEX-IV]" },
  CIPHERS
#undef E
#define E(PRE, pre)							\
  { #pre "-counter",	gen_counter,	CIPHER_##PRE,			\
    "[-k KEY-PHRASE] [-H HEX-KEY] [-i HEX-IV]" },
  CIPHERS
#undef E
#define E(PRE, pre)							\
  { #pre "-mgf",	gen_mgf,	HASH_##PRE,			\
    "[-k KEY-PHRASE] [-H HEX-KEY] [-i INDEX]" },
  HASHES
#undef E
#define E(pre, r, x, BASE)						\
  { x##BASE##_NAME(r),	gen_salsae,	pre##_##r##_INDEX,		\
    "[-k KEY-PHRASE] [-H HEX-KEY] [-n NONCE]" },
  SALSAE
#undef E
  { "rc4",		gen_rc4,	0,
    "[-k KEY-PHRASE] [-H HEX-KEY]" },
  { "seal",		gen_seal,	0,
    "[-k KEY-PHRASE] [-H HEX-KEY] [-n SEQ]" },
  { "rand",		gen_rand,	0,
    "[-n] [-k KEY-PHRASE] [-t TEXT-BLOCK] [-H HEX-BLOCK]" },
  { "bbs",		gen_bbs,	0,
    "[-gS] [-s SEED] [-M MODULUS] [-b BITS] [-k KEYRING] [-i TAG] [-t TYPE]"
  },
  { 0,			0,		0, 0 },
};

static gen optsg = { "options", gen_opts, 0,
		     "This message shouldn't be printed." };

/*----- Random number generation ------------------------------------------*/

static int genfile(const void *buf, size_t sz, void *p)
{
  FILE *fp = p;
  if (fwrite(buf, 1, sz, fp) != sz)
    die(EXIT_FAILURE, "error writing to file: %s", strerror(errno));
  return (0);
}

static int genbuf(const void *buf, size_t sz, void *p)
{
  octet **pp = p;
  memcpy(*pp, buf, sz);
  *pp += sz;
  return (0);
}

typedef struct genmaurer_ctx {
  size_t n;
  maurer_ctx *m;
} genmaurer_ctx;

static int genmaurer(const void *buf, size_t sz, void *p)
{
  genmaurer_ctx *g = p;
  size_t i;

  for (i = 0; i < g->n; i++)
    maurer_test(&g->m[i], buf, sz);
  return (0);
}

static double doubletime(void)
{
#ifdef PORTABLE
  static time_t start = (time_t)-1;
  time_t now = time(0);

  if (start == (time_t)-1) start = now;
  return difftime(now, start);
#else
  struct timeval tv;

  gettimeofday(&tv, 0);
  return (tv.tv_sec + tv.tv_usec/1000000.0);
#endif
}

static int generate(grand *r, mp *outsz,
		    int (*func)(const void *buf, size_t sz, void *p),
		    void *p)
{
  static char kmg[] = { ' ', 'k', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y', 0 };

  unsigned percent = 0;
  mp *kb = MP_ZERO, *t = MP_NEW;
  dstr d = DSTR_INIT;
  double now, last;
  static char baton[] = "-\\|/";
  char *bp;
  int rc;
  clock_t clk = 0;

  /* --- Spit out random data --- */

  last = doubletime();
  bp = baton;
  if (flags & f_progress) {
    char *errbuf = xmalloc(BUFSIZ);
    setvbuf(stderr, errbuf, _IOLBF, BUFSIZ);
    if (outsz)
      fprintf(stderr, "[%*s]   0%%    0\r[/\b", 50, "");
    else
      fputs("[ ]    0\r[/\b", stderr);
    fflush(stderr);
  }

#ifdef SIGPIPE
  signal(SIGPIPE, SIG_IGN);
#endif

  while (!outsz || MP_CMP(kb, <, outsz)) {
    octet buf[BUFSIZ];
    size_t sz = sizeof(buf), left;
    clock_t c_start, c_stop;

    /* --- Emit a bufferful (or less) of data --- */

    if (outsz) {
      t = mp_sub(t, outsz, kb);
      assert(!MP_NEGP(t));
      if (MP_CMP(t, <=, MP_SIZET_MAX)) {
	left = mp_tosizet(t);
	if (sz > left) sz = left;
      }
    }
    c_start = clock();
    r->ops->fill(r, buf, sz);
    c_stop = clock();
    clk += c_stop - c_start;
    if (func && (rc = func(buf, sz, p)) != 0)
      return (rc);
    t = mp_fromsizet(t, sz);
    kb = mp_add(kb, kb, t);

    /* --- Update the display --- */

    if (flags & f_progress) {
      unsigned up = 0;

      now = doubletime();

      if (percent > 100)
	up = 1;

      if (!outsz) {
	if (now - last > 0.1) {
	  up = 1;
	}
	if (up)
	  fputs(" ] ", stderr);
      } else {
	unsigned pc;
	t = mp_fromulong(t, 100);
	t = mp_mul(t, t, kb);
	mp_div(&t, 0, t, outsz);
	assert(!MP_NEGP(t) && MP_CMP(t, <, MP_UINT_MAX));
	pc = mp_touint(t);
	if (pc > percent || percent > 100 || now - last > 0.1) {
	  if (percent > 100)
	    percent = 0;
	  percent &= ~1;
	  for (; percent < (pc & ~1); percent += 2)
	    putc('.', stderr);
	  percent = pc;
	  for (; pc < 100; pc += 2)
	    putc(' ', stderr);
	  fprintf(stderr, "] %3i%% ", percent);
	  up = 1;
	}
      }

      if (up) {
	char *kk = kmg;
	t = mp_add(t, kb, MP_ZERO);
	while (mp_bits(t) >= 14) {
	  t = mp_lsr(t, t, 10);
	  kk++;
	}
	DRESET(&d);
	mp_writedstr(t, &d, 10);
	fprintf(stderr, "%4s%c\r[", d.buf, *kk);
	if (outsz) {
	  unsigned pc;
	  for (pc = 0; pc < (percent & ~1); pc += 2)
	    putc('.', stderr);
	}
	last = now;
      }

      if (percent > 100)
	percent = 0;

      if (percent < 100 && up) {
	putc(*bp++, stderr);
	putc('\b', stderr);
	if (!*bp)
	  bp = baton;
      }
      fflush(stderr);
    }
  }

  if (flags & f_progress)
    fputc('\n', stderr);
  if (flags & f_timer) {
    DRESET(&d);
    dstr_puts(&d, "generated ");
    mp_writedstr(kb, &d, 10);
    dstr_puts(&d, " bytes ");
    if (!clk)
      dstr_puts(&d, "too quickly to measure\n");
    else {
      char *kk;
      double out;
      double sec = (double)clk/CLOCKS_PER_SEC;
      unsigned long sh;
      double bps;

      MP_SHRINK(kb);
      switch (MP_LEN(kb)) {
	case 0: out = 0; break;
	case 1: out = kb->v[0]; break;
	default:
	  sh = mp_bits(kb) - MPW_BITS;
	  t = mp_lsr(t, kb, sh);
	  out = ldexp(t->v[0], sh);
	  break;
      }
      bps = (8*out)/sec;
      for (kk = kmg; bps > 1024 && kk[1]; kk++, bps /= 1024)
	;
      dstr_putf(&d, "in %g secs (%g %cb/s)\n", sec, bps, *kk);
      fwrite(d.buf, 1, d.len, stderr);
    }
  }

  mp_drop(t);
  DDESTROY(&d);
  return (0);
}

/*----- Main code ---------------------------------------------------------*/

int main(int ac, char *av[])
{
  gen *g = &optsg;
  grand *r;

  /* --- Initialize mLib --- */

  ego(av[0]);
  sub_init();

  /* --- Set up the main Catacomb generator --- */

  rand_noisesrc(RAND_GLOBAL, &noise_source);
  rand_seed(RAND_GLOBAL, 160);

  /* --- Initialize the options table --- */

  addopts(sopts, opts);
  argc = ac;
  argv = av;
  outfp = stdout;

  /* --- Read the generator out of the first argument --- */

  if (argc > 1 && *argv[1] != '-') {
    const char *arg = av[1];
    size_t sz = strlen(arg);
    gen *gg;

    g = 0;
    for (gg = generators; gg->name; gg++) {
      if (strncmp(arg, gg->name, sz) == 0) {
	if (gg->name[sz] == 0) {
	  g = gg;
	  break;
	} else if (g)
	  die(EXIT_FAILURE, "ambiguous generator name `%s'", arg);
	else
	  g = gg;
      }
    }
    if (!g)
      die(EXIT_FAILURE, "unknown generator name `%s'", arg);
    argc--;
    argv++;
  }

  /* --- Get a generic random number generator --- */

  r = g->seed(g->i);
  if (!r || optind != ac - 1) {
    usage(stderr);
    exit(EXIT_FAILURE);
  }

  /* --- Do the FIPS test --- */

  if (flags & f_fips) {
    octet buf[FIPSTEST_BUFSZ];
    unsigned rc;
    mp *t;
    octet *p = buf;

    t = mp_fromsizet(MP_NEW, sizeof(buf));
    generate(r, t, genbuf, &p);
    mp_drop(t);
    rc = fipstest(buf);
    if (rc & FIPSTEST_MONOBIT)
      moan("failed monobit test");
    if (rc & FIPSTEST_POKER)
      moan("failed poker test");
    if (rc & FIPSTEST_RUNS)
      moan("failed runs test");
    if (rc & FIPSTEST_LONGRUNS)
      moan("failed long runs test");
    if (!rc && (flags & f_progress))
      fputs("test passed\n", stderr);
    return (rc ? EXIT_FAILURE : 0);
  }

  /* --- Do Maurer's test --- */

  if (flags & f_maurer) {
    size_t bufsz;
    unsigned i;
    unsigned rc = 0;
    mp *t;
    genmaurer_ctx g;

    static struct { double x; const char *sig; } sigtab[] = {
      { 3.2905, "1e-3" },
      { 3.0902, "2e-3" },
      { 2.8070, "5e-3" },
      { 2.5758, "1e-2" },
      { 0     , 0      }
    };

    g.n = maurer_hi - maurer_lo + 1;
    g.m = xmalloc(g.n * sizeof(maurer_ctx));
    for (i = 0; i < g.n; i++)
      maurer_init(&g.m[i], i + maurer_lo);
    bufsz = (100 * maurer_hi) << maurer_hi;

    t = mp_fromsizet(MP_NEW, bufsz);
    generate(r, t, genmaurer, &g);
    mp_drop(t);

    for (i = maurer_lo; i <= maurer_hi; i++) {
      double z = maurer_done(&g.m[i - maurer_lo]);
      double zz = fabs(z);
      unsigned j;

      for (j = 0; sigtab[j].sig; j++) {
	if (zz > sigtab[j].x) {
	  rc = EXIT_FAILURE;
	  moan("failed, bits = %u, sig = %s, Z_u = %g",
	       i, sigtab[j].sig, z);
	  break;
	}
      }
      if (flags & f_progress)
	fprintf(stderr, "bits = %u, Z_u = %g\n", i, z);
    }

    xfree(g.m);
    return (rc);
  }

  /* --- Discard --- */

  if (flags & f_discard) {
    generate(r, outsz, 0, 0);
    return (0);
  }

  /* --- Write to a file --- */

#ifndef PORTABLE
  if (!(flags & f_file) && isatty(STDOUT_FILENO))
    die(EXIT_FAILURE, "writing output to a terminal is a bad idea");
#endif

  generate(r, outsz, genfile, outfp);

  /* --- Done --- */

  r->ops->destroy(r);
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
