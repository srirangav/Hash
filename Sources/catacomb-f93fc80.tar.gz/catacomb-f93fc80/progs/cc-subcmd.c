/* -*-c-*-
 *
 * Subcommand infrastructure
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#define _FILE_OFFSET_BITS 64

#include <mLib/quis.h>
#include <mLib/report.h>

#include "cc.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @findcmd@ --- *
 *
 * Arguments:	@const cmd *cmds@ = pointer to command table
 *		@const char *name@ = a command name
 *
 * Returns:	Pointer to the command structure.
 *
 * Use:		Looks up a command by name.  If the command isn't found, an
 *		error is reported and the program is terminated.
 */

const cmd *findcmd(const cmd *cmds, const char *name)
{
  const cmd *c, *chosen = 0;
  size_t sz = strlen(name);

  for (c = cmds; c->name; c++) {
    if (strncmp(name, c->name, sz) == 0) {
      if (c->name[sz] == 0) {
	chosen = c;
	break;
      } else if (chosen)
	die(EXIT_FAILURE, "ambiguous command name `%s'", name);
      else
	chosen = c;
    }
  }
  if (!chosen)
    die(EXIT_FAILURE, "unknown command name `%s'", name);
  return (chosen);
}

/* --- @sc_help@ --- *
 *
 * Arguments:	@const cmd *cmds@ = pointer to command table
 *		@FILE *fp@ = output file handle
 *		@char *const *argv@ = remaining arguments
 *
 * Returns:	---
 *
 * Use:		Prints a help message, maybe with help about subcommands.
 */

void sc_help(const cmd *cmds, FILE *fp, char *const *argv)
{
  const cmd *c;

  version(fp);
  fputc('\n', fp);
  if (!*argv) {
    help_global(fp);
    fputs("\n\
The following commands are understood:\n\n",
	  fp);
    for (c = cmds; c->name; c++)
      fprintf(fp, "%s\n", c->usage);
  } else {
    while (*argv) {
      c = findcmd(cmds, *argv);
      fprintf(fp, "Usage: %s [-OPTIONS] %s\n", QUIS, c->usage);
      if (c->help) {
	fputc('\n', fp);
	pquis(fp, c->help);
      }
      argv++;
      if (*argv) fputc('\n', fp);
    }
  }
}

/*----- That's all, folks -------------------------------------------------*/
