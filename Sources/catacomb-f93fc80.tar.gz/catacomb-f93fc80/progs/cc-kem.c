/* -*-c-*-
 *
 * Catcrypt key-encapsulation
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#define _FILE_OFFSET_BITS 64

#include <stdlib.h>

#include <mLib/alloc.h>
#include <mLib/dstr.h>
#include <mLib/report.h>
#include <mLib/sub.h>

#include "mprand.h"
#include "rand.h"

#include "ec.h"
#include "ec-keys.h"
#include "dh.h"
#include "rsa.h"

#include "rmd160.h"
#include "blowfish-cbc.h"

#include "cc.h"

/*----- Key encapsulation -------------------------------------------------*/

/* --- RSA --- */

typedef struct rsa_encctx {
  kem k;
  rsa_pubctx rp;
} rsa_encctx;

static kem *rsa_encinit(key *k, void *kd)
{
  rsa_encctx *re = CREATE(rsa_encctx);
  rsa_pubcreate(&re->rp, kd);
  return (&re->k);
}

static int rsa_encdoit(kem *k, dstr *d, ghash *h)
{
  rsa_encctx *re = (rsa_encctx *)k;
  mp *x = mprand_range(MP_NEW, re->rp.rp->n, &rand_global, 0);
  mp *y = rsa_pubop(&re->rp, MP_NEW, x);
  size_t n = mp_octets(re->rp.rp->n);
  dstr_ensure(d, n);
  mp_storeb(x, d->buf, n);
  GH_HASH(h, d->buf, n);
  mp_storeb(y, d->buf, n);
  d->len += n;
  mp_drop(x);
  mp_drop(y);
  return (0);
}

static const char *rsa_lengthcheck(mp *n)
{
  if (mp_bits(n) < 1020) return ("key too short");
  return (0);
}

static const char *rsa_enccheck(kem *k)
{
  rsa_encctx *re = (rsa_encctx *)k;
  const char *e;
  if ((e = rsa_lengthcheck(re->rp.rp->n)) != 0) return (e);
  return (0);
}

static void rsa_encdestroy(kem *k)
{
  rsa_encctx *re = (rsa_encctx *)k;
  rsa_pubdestroy(&re->rp);
  DESTROY(re);
}

static const kemops rsa_encops = {
  rsa_pubfetch, sizeof(rsa_pub),
  rsa_encinit, rsa_encdoit, rsa_enccheck, rsa_encdestroy
};

typedef struct rsa_decctx {
  kem k;
  rsa_privctx rp;
} rsa_decctx;

static kem *rsa_decinit(key *k, void *kd)
{
  rsa_decctx *rd = CREATE(rsa_decctx);
  rsa_privcreate(&rd->rp, kd, &rand_global);
  return (&rd->k);
}

static int rsa_decdoit(kem *k, dstr *d, ghash *h)
{
  rsa_decctx *rd = (rsa_decctx *)k;
  mp *x = mp_loadb(MP_NEW, d->buf, d->len);
  size_t n;
  char *p;

  if (MP_CMP(x, >=, rd->rp.rp->n)) {
    mp_drop(x);
    return (-1);
  }
  n = mp_octets(rd->rp.rp->n);
  p = xmalloc(n);
  x = rsa_privop(&rd->rp, x, x);
  mp_storeb(x, p, n);
  GH_HASH(h, p, n);
  mp_drop(x);
  xfree(p);
  return (0);
}

static const char *rsa_deccheck(kem *k)
{
  rsa_decctx *rd = (rsa_decctx *)k;
  const char *e;
  if ((e = rsa_lengthcheck(rd->rp.rp->n)) != 0) return (e);
  return (0);
}

static void rsa_decdestroy(kem *k)
{
  rsa_decctx *rd = (rsa_decctx *)k;
  rsa_privdestroy(&rd->rp);
  DESTROY(rd);
}

static const kemops rsa_decops = {
  rsa_privfetch, sizeof(rsa_priv),
  rsa_decinit, rsa_decdoit, rsa_deccheck, rsa_decdestroy
};

/* --- DH and EC --- */

typedef struct dh_encctx {
  kem k;
  group *g;
  mp *x;
  ge *y;
} dh_encctx;

static dh_encctx *dh_doinit(key *k, const gprime_param *gp, mp *y,
			    group *(*makegroup)(const gprime_param *),
			    const char *what)
{
  dh_encctx *de = CREATE(dh_encctx);
  dstr t = DSTR_INIT;

  key_fulltag(k, &t);
  if ((de->g = makegroup(gp)) == 0)
    die(EXIT_FAILURE, "bad %s group in key `%s'", what, t.buf);
  de->x = MP_NEW;
  de->y = G_CREATE(de->g);
  if (G_FROMINT(de->g, de->y, y))
    die(EXIT_FAILURE, "bad public key `%s'", t.buf);
  dstr_destroy(&t);
  return (de);
}

static dh_encctx *ec_doinit(key *k, const char *cstr, const ec *y)
{
  dh_encctx *de = CREATE(dh_encctx);
  ec_info ei;
  const char *e;
  dstr t = DSTR_INIT;

  key_fulltag(k, &t);
  if ((e = ec_getinfo(&ei, cstr)) != 0 ||
      (de->g = group_ec(&ei)) == 0)
    die(EXIT_FAILURE, "bad elliptic curve spec in key `%s': %s", t.buf, e);
  de->x = MP_NEW;
  de->y = G_CREATE(de->g);
  if (G_FROMEC(de->g, de->y, y))
    die(EXIT_FAILURE, "bad public curve point `%s'", t.buf);
  dstr_destroy(&t);
  return (de);
}

static kem *dh_encinit(key *k, void *kd)
{
  dh_pub *dp = kd;
  dh_encctx *de = dh_doinit(k, &dp->dp, dp->y, group_prime, "prime");
  return (&de->k);
}

static kem *bindh_encinit(key *k, void *kd)
{
  dh_pub *dp = kd;
  dh_encctx *de = dh_doinit(k, &dp->dp, dp->y, group_binary, "binary");
  return (&de->k);
}

static kem *ec_encinit(key *k, void *kd)
{
  ec_pub *ep = kd;
  dh_encctx *de = ec_doinit(k, ep->cstr, &ep->p);
  return (&de->k);
}

static int dh_encdoit(kem *k, dstr *d, ghash *h)
{
  dh_encctx *de = (dh_encctx *)k;
  mp *r = mprand_range(MP_NEW, de->g->r, &rand_global, 0);
  ge *x = G_CREATE(de->g);
  ge *y = G_CREATE(de->g);
  size_t n = de->g->noctets;
  buf b;

  G_EXP(de->g, x, de->g->g, r);
  G_EXP(de->g, y, de->y, r);
  dstr_ensure(d, n);
  buf_init(&b, d->buf, n);
  G_TORAW(de->g, &b, y);
  GH_HASH(h, BBASE(&b), BLEN(&b));
  buf_init(&b, d->buf, n);
  G_TORAW(de->g, &b, x);
  GH_HASH(h, BBASE(&b), BLEN(&b));
  d->len += BLEN(&b);
  mp_drop(r);
  G_DESTROY(de->g, x);
  G_DESTROY(de->g, y);
  return (0);
}

static const char *dh_enccheck(kem *k)
{
  dh_encctx *de = (dh_encctx *)k;
  const char *e;
  if ((e = G_CHECK(de->g, &rand_global)) != 0)
    return (0);
  if (group_check(de->g, de->y))
    return ("public key not in subgroup");
  return (0);
}

static void dh_encdestroy(kem *k)
{
  dh_encctx *de = (dh_encctx *)k;
  G_DESTROY(de->g, de->y);
  mp_drop(de->x);
  G_DESTROYGROUP(de->g);
  DESTROY(de);
}

static const kemops dh_encops = {
  dh_pubfetch, sizeof(dh_pub),
  dh_encinit, dh_encdoit, dh_enccheck, dh_encdestroy
};

static const kemops bindh_encops = {
  dh_pubfetch, sizeof(dh_pub),
  bindh_encinit, dh_encdoit, dh_enccheck, dh_encdestroy
};

static const kemops ec_encops = {
  ec_pubfetch, sizeof(ec_pub),
  ec_encinit, dh_encdoit, dh_enccheck, dh_encdestroy
};

static kem *dh_decinit(key *k, void *kd)
{
  dh_priv *dp = kd;
  dh_encctx *de = dh_doinit(k, &dp->dp, dp->y, group_prime, "prime");
  de->x = MP_COPY(dp->x);
  return (&de->k);
}

static kem *bindh_decinit(key *k, void *kd)
{
  dh_priv *dp = kd;
  dh_encctx *de = dh_doinit(k, &dp->dp, dp->y, group_binary, "binary");
  de->x = MP_COPY(dp->x);
  return (&de->k);
}

static kem *ec_decinit(key *k, void *kd)
{
  ec_priv *ep = kd;
  dh_encctx *de = ec_doinit(k, ep->cstr, &ep->p);
  de->x = MP_COPY(ep->x);
  return (&de->k);
}

static int dh_decdoit(kem *k, dstr *d, ghash *h)
{
  dh_encctx *de = (dh_encctx *)k;
  ge *x = G_CREATE(de->g);
  size_t n = de->g->noctets;
  void *p = xmalloc(n);
  buf b;
  int rc = -1;

  buf_init(&b, d->buf, d->len);
  if (G_FROMRAW(de->g, &b, x) || group_check(de->g, x))
    goto done;
  G_EXP(de->g, x, x, de->x);
  buf_init(&b, p, n);
  G_TORAW(de->g, &b, x);
  GH_HASH(h, BBASE(&b), BLEN(&b));
  GH_HASH(h, d->buf, d->len);
  rc = 0;
done:
  G_DESTROY(de->g, x);
  xfree(p);
  return (rc);
}

static const kemops dh_decops = {
  dh_privfetch, sizeof(dh_priv),
  dh_decinit, dh_decdoit, dh_enccheck, dh_encdestroy
};

static const kemops bindh_decops = {
  dh_privfetch, sizeof(dh_priv),
  bindh_decinit, dh_decdoit, dh_enccheck, dh_encdestroy
};

static const kemops ec_decops = {
  ec_privfetch, sizeof(ec_priv),
  ec_decinit, dh_decdoit, dh_enccheck, dh_encdestroy
};

/* --- Symmetric --- */

typedef struct symm_ctx {
  kem k;
  key_packdef kp;
  key_bin kb;
} symm_ctx;

static kem *symm_init(key *k, void *kd)
{
  symm_ctx *s;
  dstr d = DSTR_INIT;
  int err;

  s = CREATE(symm_ctx);

  key_fulltag(k, &d);
  s->kp.e = KENC_BINARY;
  s->kp.p = &s->kb;
  s->kp.kd = 0;

  if ((err = key_unpack(&s->kp, kd, &d)) != 0) {
    die(EXIT_FAILURE, "failed to unpack symmetric key `%s': %s",
	d.buf, key_strerror(err));
  }
  dstr_destroy(&d);
  return (&s->k);
}

static int symm_decdoit(kem *k, dstr *d, ghash *h)
{
  symm_ctx *s = (symm_ctx *)k;

  GH_HASH(h, s->kb.k, s->kb.sz);
  GH_HASH(h, d->buf, d->len);
  return (0);
}

static int symm_encdoit(kem *k, dstr *d, ghash *h)
{
  dstr_ensure(d, h->ops->c->hashsz);
  d->len += h->ops->c->hashsz;
  rand_get(RAND_GLOBAL, d->buf, d->len);
  return (symm_decdoit(k, d, h));
}

static const char *symm_check(kem *k) { return (0); }

static void symm_destroy(kem *k)
  { symm_ctx *s = (symm_ctx *)k; key_unpackdone(&s->kp); }

static const kemops symm_encops = {
  0, 0,
  symm_init, symm_encdoit, symm_check, symm_destroy
};

static const kemops symm_decops = {
  0, 0,
  symm_init, symm_decdoit, symm_check, symm_destroy
};

/* --- The switch table --- */

const struct kemtab kemtab[] = {
  { "rsa",	&rsa_encops,	&rsa_decops },
  { "dh",	&dh_encops,	&dh_decops },
  { "bindh",	&bindh_encops,	&bindh_decops },
  { "ec",	&ec_encops,	&ec_decops },
  { "symm",	&symm_encops,	&symm_decops },
  { 0,		0,		0 }
};

/* --- @getkem@ --- *
 *
 * Arguments:	@key *k@ = the key to load
 *		@const char *app@ = application name
 *		@int wantpriv@ = nonzero if we want to decrypt
 *
 * Returns:	A key-encapsulating thing.
 *
 * Use:		Loads a key.
 */

kem *getkem(key *k, const char *app, int wantpriv)
{
  const char *kalg, *halg = 0, *calg = 0;
  dstr d = DSTR_INIT;
  dstr t = DSTR_INIT;
  size_t n;
  char *p = 0;
  const char *q;
  kem *kk;
  const struct kemtab *kt;
  const kemops *ko;
  void *kd;
  int e;
  key_packdef *kp;

  /* --- Setup stuff --- */

  key_fulltag(k, &t);

  /* --- Get the KEM name --- *
   *
   * Take the attribute if it's there; otherwise use the key type.
   */

  n = strlen(app);
  if ((q = key_getattr(0, k, "kem")) != 0) {
    dstr_puts(&d, q);
    p = d.buf;
  } else if (strncmp(k->type, app, n) == 0 && k->type[n] == '-') {
    dstr_puts(&d, k->type);
    p = d.buf + n + 1;
  } else
    die(EXIT_FAILURE, "no KEM for key `%s'", t.buf);
  kalg = p;

  /* --- Grab the encryption scheme --- *
   *
   * Grab it from the KEM if it's there, but override it from the attribute.
   */

  if (p && (p = strchr(p, '/')) != 0) {
    *p++ = 0;
    calg = p;
  }
  if ((q = key_getattr(0, k, "cipher")) != 0)
    calg = q;

  /* --- Grab the hash function --- */

  if (p && (p = strchr(p, '/')) != 0) {
    *p++ = 0;
    halg = p;
  }
  if ((q = key_getattr(0, k, "hash")) != 0)
    halg = q;

  /* --- Instantiate the KEM --- */

  for (kt = kemtab; kt->name; kt++) {
    if (strcmp(kt->name, kalg) == 0)
      goto k_found;
  }
  die(EXIT_FAILURE, "key encapsulation mechanism `%s' not found in key `%s'",
      kalg, t.buf);
k_found:;
  ko = wantpriv ? kt->decops : kt->encops;
  if (!ko->kf) {
    kd = k->k;
    key_incref(kd);
    kp = 0;
  } else {
    kd = xmalloc(ko->kdsz);
    kp = key_fetchinit(ko->kf, 0, kd);
    if ((e = key_fetch(kp, k)) != 0) {
      die(EXIT_FAILURE, "error fetching key `%s': %s",
	  t.buf, key_strerror(e));
    }
  }
  kk = ko->init(k, kd);
  kk->kp = kp;
  kk->ops = ko;
  kk->kd = kd;

  /* --- Set up the algorithms --- */

  if (!halg)
    kk->h = &rmd160;
  else if ((kk->h = ghash_byname(halg)) == 0) {
    die(EXIT_FAILURE, "hash algorithm `%s' not found in key `%s'",
	halg, t.buf);
  }

  if (!calg)
    kk->c = &blowfish_cbc;
  else if ((kk->c = gcipher_byname(calg)) == 0) {
    die(EXIT_FAILURE, "encryption scheme `%s' not found in key `%s'",
	calg, t.buf);
  }

  dstr_reset(&d);
  if ((q = key_getattr(0, k, "kdf")) == 0) {
    dstr_putf(&d, "%s-mgf", kk->h->name);
    q = d.buf;
  }
  if ((kk->cx = gcipher_byname(q)) == 0) {
    die(EXIT_FAILURE, "encryption scheme (KDF) `%s' not found in key `%s'",
	q, t.buf);
  }

  dstr_reset(&d);
  if ((q = key_getattr(0, k, "mac")) == 0) {
    dstr_putf(&d, "%s-hmac", kk->h->name);
    q = d.buf;
  }
  if ((kk->m = gmac_byname(q)) == 0) {
    die(EXIT_FAILURE,
	"message authentication code `%s' not found in key `%s'",
	q, t.buf);
  }

  /* --- Tidy up --- */

  dstr_destroy(&d);
  dstr_destroy(&t);
  return (kk);
}

/* --- @setupkem@ --- *
 *
 * Arguments:	@kem *k@ = key-encapsulation thing
 *		@dstr *d@ = key-encapsulation data
 *		@gcipher **cx@ = key-expansion function (for IVs)
 *		@gcipher **c@ = where to put initialized encryption scheme
 *		@gmac **m@ = where to put initialized MAC
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Initializes all the various symmetric things from a KEM.
 */

int setupkem(kem *k, dstr *d, gcipher **cx, gcipher **c, gmac **m)
{
  octet *kd;
  size_t n, cn, mn;
  ghash *h;
  int rc = -1;

  h = GH_INIT(k->h);
  if (k->ops->doit(k, d, h))
    goto done;
  n = keysz(GH_CLASS(h)->hashsz, k->cx->keysz);
  if (!n)
    goto done;
  kd = GH_DONE(h, 0);
  *cx = GC_INIT(k->cx, kd, n);

  cn = keysz(0, k->c->keysz); n = cn;
  mn = keysz(0, k->m->keysz); if (mn > n) n = mn;
  kd = xmalloc(n);
  GC_ENCRYPT(*cx, 0, kd, cn);
  *c = GC_INIT(k->c, kd, cn);
  GC_ENCRYPT(*cx, 0, kd, mn);
  *m = GM_KEY(k->m, kd, mn);
  xfree(kd);

  rc = 0;
done:
  GH_DESTROY(h);
  return (rc);
}

/* --- @freekem@ --- *
 *
 * Arguments:	@kem *k@ = key-encapsulation thing
 *
 * Returns:	---
 *
 * Use:		Frees up a key-encapsulation thing.
 */

void freekem(kem *k)
{
  if (!k->ops->kf)
    key_drop(k->kd);
  else {
    key_fetchdone(k->kp);
    xfree(k->kd);
  }
  k->ops->destroy(k);
}

/*----- That's all, folks -------------------------------------------------*/
