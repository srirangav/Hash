/* -*-c-*-
 *
 * Emit lists of things in tables
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#define _FILE_OFFSET_BITS 64

#include <mLib/report.h>

#include "cc.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @displaylists@ --- *
 *
 * Arguments:	@const struct listent *listtab@ = table of lists to show
 *		@char *const argv[]@ = list of lists to show
 *
 * Returns:	Nonzero if anything failed.
 *
 * Use:		Dumps the named lists, or all of them.
 */

int displaylists(const struct listent *listtab, char *const argv[])
{
  const struct listent *li;
  int i;
  int rc = 0;

  if (!argv || !*argv) {
    for (li = listtab; li->name; li++)
      li->list();
  } else {
    for (i = 0; argv[i]; i++) {
      for (li = listtab; li->name; li++) {
	if (strcmp(li->name, argv[i]) == 0) {
	  li->list();
	  goto cool;
	}
      }
      moan("unknown list `%s'", argv[i]);
      rc = 1;
    cool:;
    }
  }
  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
