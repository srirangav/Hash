/* -*-c-*-
 *
 * Simple key manager program
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#define _FILE_OFFSET_BITS 64

#include "config.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <mLib/codec.h>
#include <mLib/base32.h>
#include <mLib/base64.h>
#include <mLib/hex.h>
#include <mLib/mdwopt.h>
#include <mLib/quis.h>
#include <mLib/report.h>
#include <mLib/sub.h>

#include <noise.h>
#include <rand.h>

#include "bintab.h"
#include "bbs.h"
#include "dh.h"
#include "dsa.h"
#include "dsarand.h"
#include "ec.h"
#include "ec-keys.h"
#include "ectab.h"
#include "fibrand.h"
#include "getdate.h"
#include "gfreduce.h"
#include "key.h"
#include "mp.h"
#include "mpmont.h"
#include "mprand.h"
#include "mptext.h"
#include "pgen.h"
#include "ptab.h"
#include "rsa.h"

#include "cc.h"
#include "sha-mgf.h"
#include "sha256-mgf.h"
#include "sha224-mgf.h"
#include "sha384-mgf.h"
#include "sha512-mgf.h"
#include "tiger-mgf.h"
#include "rmd128-mgf.h"
#include "rmd160-mgf.h"
#include "rmd256-mgf.h"
#include "rmd320-mgf.h"
#include "md5-mgf.h"
#include "dsarand.h"

/*----- Handy global state ------------------------------------------------*/

static const char *keyfile = "keyring";

/*----- Useful shared functions -------------------------------------------*/

/* --- @doopen@ --- *
 *
 * Arguments:	@key_file *f@ = pointer to key file block
 *		@unsigned how@ = method to open file with
 *
 * Returns:	---
 *
 * Use:		Opens a key file and handles errors by panicking
 *		appropriately.
 */

static void doopen(key_file *f, unsigned how)
{
  if (key_open(f, keyfile, how, key_moan, 0)){
    die(EXIT_FAILURE, "couldn't open keyring `%s': %s",
	keyfile, strerror(errno));
  }
}

/* --- @doclose@ --- *
 *
 * Arguments:	@key_file *f@ = pointer to key file block
 *
 * Returns:	---
 *
 * Use:		Closes a key file and handles errors by panicking
 *		appropriately.
 */

static void doclose(key_file *f)
{
  switch (key_close(f)) {
    case KWRITE_FAIL:
      die(EXIT_FAILURE, "couldn't write file `%s': %s",
	  keyfile, strerror(errno));
    case KWRITE_BROKEN:
      die(EXIT_FAILURE, "keyring file `%s' broken: %s (repair manually)",
	  keyfile, strerror(errno));
  }
}

/* --- @setattr@ --- *
 *
 * Arguments:	@key_file *f@ = pointer to key file block
 *		@key *k@ = pointer to key block
 *		@char *v[]@ = array of assignments (overwritten!)
 *
 * Returns:	---
 *
 * Use:		Applies the attribute assignments to the key.
 */

static void setattr(key_file *f, key *k, char *v[])
{
  while (*v) {
    int err;
    char *p = *v;
    size_t eq = strcspn(p, "=");
    if (!p[eq]) {
      moan("invalid assignment: `%s' (ignored)", p);
      v++;
      continue;
    }
    p[eq] = 0;
    p += eq + 1;
    if ((err = key_putattr(f, k, *v, *p ? p : 0)) != 0)
      die(EXIT_FAILURE, "couldn't set attributes: %s", key_strerror(err));
    v++;
  }
}

/*----- Seeding -----------------------------------------------------------*/

const struct seedalg { const char *p; grand *(*gen)(const void *, size_t); }
seedtab[] = {
  { "dsarand", dsarand_create },
  { "rmd128-mgf", rmd128_mgfrand },
  { "rmd160-mgf", rmd160_mgfrand },
  { "rmd256-mgf", rmd256_mgfrand },
  { "rmd320-mgf", rmd320_mgfrand },
  { "sha-mgf", sha_mgfrand },
  { "sha224-mgf", sha224_mgfrand },
  { "sha256-mgf", sha256_mgfrand },
  { "sha384-mgf", sha384_mgfrand },
  { "sha512-mgf", sha512_mgfrand },
  { "tiger-mgf", tiger_mgfrand },
  { 0, 0 }
};

#define SEEDALG_DEFAULT (seedtab + 2)

/*----- Key generation ----------------------------------------------------*/

/* --- Key generation parameters --- */

typedef struct keyopts {
  key_file *kf;				/* Pointer to key file */
  key *k;				/* Pointer to the actual key */
  dstr tag;				/* Full tag name for the key */
  unsigned f;				/* Flags for the new key */
  unsigned bits, qbits;			/* Bit length for the new key */
  const char *curve;			/* Elliptic curve name/info */
  grand *r;				/* Random number source */
  key *p;				/* Parameters key-data */
} keyopts;

#define f_bogus 1u			/* Error in parsing */
#define f_lock 2u			/* Passphrase-lock private key */
#define f_quiet 4u			/* Don't show a progress indicator */
#define f_limlee 8u			/* Generate Lim-Lee primes */
#define f_subgroup 16u			/* Generate a subgroup */
#define f_retag 32u			/* Remove any existing tag */
#define f_kcdsa 64u			/* Generate KCDSA primes */

/* --- @dolock@ --- *
 *
 * Arguments:	@keyopts *k@ = key generation options
 *		@key_data **kd@ = pointer to key data to lock
 *		@const char *t@ = tag suffix or null
 *
 * Returns:	---
 *
 * Use:		Does passphrase locking on new keys.
 */

static void dolock(keyopts *k, key_data **kd, const char *t)
{
  if (!(k->f & f_lock))
    return;
  if (t)
    dstr_putf(&k->tag, ".%s", t);
  if (key_plock(kd, 0, k->tag.buf))
    die(EXIT_FAILURE, "couldn't lock key");
}

/* --- @copyparam@ --- *
 *
 * Arguments:	@keyopts *k@ = pointer to key options
 *		@const char **pp@ = checklist of parameters
 *
 * Returns:	Nonzero if parameters copied; zero if you have to generate
 *		them.
 *
 * Use:		Copies parameters from a source key to the current one.
 */

static int copyparam(keyopts *k, const char **pp)
{
  key_filter kf;
  key_attriter i;
  key_data *kd;
  const char *n, *v;

  kf.f = KCAT_SHARE;
  kf.m = KF_CATMASK;

  /* --- Quick check if no parameters supplied --- */

  if (!k->p)
    return (0);

  /* --- Run through the checklist --- */

  while (*pp) {
    key_data *kd = key_structfind(k->p->k, *pp);
    if (!kd)
      die(EXIT_FAILURE, "bad parameter key: parameter `%s' not found", *pp);
    if (!KEY_MATCH(kd, &kf))
      die(EXIT_FAILURE, "bad parameter key: subkey `%s' is not shared", *pp);
    pp++;
  }

  /* --- Copy over the parameters --- */

  kd = key_copydata(k->p->k, &kf);
  assert(kd);
  key_setkeydata(k->kf, k->k, kd);
  key_drop(kd);

  /* --- Copy over attributes --- */

  for (key_mkattriter(&i, k->p); key_nextattr(&i, &n, &v); )
    key_putattr(k->kf, k->k, n, v);

  /* --- Done --- */

  return (1);
}

/* --- @getmp@ --- *
 *
 * Arguments:	@key_data *k@ = pointer to key data block
 *		@const char *tag@ = tag string to use
 *
 * Returns:	Pointer to multiprecision integer key item.
 *
 * Use:		Fetches an MP key component.
 */

static mp *getmp(key_data *k, const char *tag)
{
  k = key_structfind(k, tag);
  if (!k)
    die(EXIT_FAILURE, "unexpected failure looking up subkey `%s'", tag);
  if ((k->e & KF_ENCMASK) != KENC_MP)
    die(EXIT_FAILURE, "subkey `%s' has an incompatible type", tag);
  return (k->u.m);
}

/* --- @keyrand@ --- *
 *
 * Arguments:	@key_file *kf@ = pointer to key file
 *		@const char *id@ = pointer to key id (or null)
 *
 * Returns:	---
 *
 * Use:		Keys the random number generator.
 */

static void keyrand(key_file *kf, const char *id)
{
  key *k;

  /* --- Find the key --- */

  if (id) {
    if ((k = key_bytag(kf, id)) == 0)
      die(EXIT_FAILURE, "key `%s' not found", id);
  } else
    k = key_bytype(kf, "catacomb-rand");

  if (k) {
    key_data *kd = k->k, *kkd;
    key_incref(kd);

  again:
    switch (kd->e & KF_ENCMASK) {
      case KENC_BINARY:
	break;
      case KENC_ENCRYPT: {
	dstr d = DSTR_INIT;
	key_fulltag(k, &d);
	if (key_punlock(&kkd, kd, d.buf))
	  die(EXIT_FAILURE, "error unlocking key `%s'", d.buf);
	dstr_destroy(&d);
	key_drop(kd);
	kd = kkd;
      } goto again;
      default: {
	dstr d = DSTR_INIT;
	key_fulltag(k, &d);
	die(EXIT_FAILURE, "bad encoding type for key `%s'", d.buf);
      } break;
    }

    /* --- Key the generator --- */

    rand_key(RAND_GLOBAL, kd->u.k.k, kd->u.k.sz);
    key_drop(kd);
  }
}

/* --- Key generation algorithms --- */

static void alg_binary(keyopts *k)
{
  unsigned sz;
  unsigned m;
  key_data *kd;
  octet *p;

  if (!k->bits)
    k->bits = 128;
  if (k->p)
    die(EXIT_FAILURE, "no shared parameters for binary keys");

  sz = (k->bits + 7) >> 3;
  p = sub_alloc(sz);
  m = (1 << (((k->bits - 1) & 7) + 1)) - 1;
  k->r->ops->fill(k->r, p, sz);
  *p &= m;
  kd = key_newbinary(KCAT_SYMM | KF_BURN, p, sz);
  memset(p, 0, sz);
  dolock(k, &kd, 0);
  key_setkeydata(k->kf, k->k, kd);
  key_drop(kd);
  sub_free(p, sz);
}

static void alg_des(keyopts *k)
{
  unsigned sz;
  octet *p;
  key_data *kd;
  int i;

  if (!k->bits)
    k->bits = 168;
  if (k->p)
    die(EXIT_FAILURE, "no shared parameters for DES keys");
  if (k->bits % 56 || k->bits > 168)
    die(EXIT_FAILURE, "DES keys must be 56, 112 or 168 bits long");

  sz = k->bits / 7;
  p = sub_alloc(sz);
  k->r->ops->fill(k->r, p, sz);
  for (i = 0; i < sz; i++) {
    octet x = p[i] | 0x01;
    x = x ^ (x >> 4);
    x = x ^ (x >> 2);
    x = x ^ (x >> 1);
    p[i] = (p[i] & 0xfe) | (x & 0x01);
  }
  kd = key_newbinary(KCAT_SYMM | KF_BURN, p, sz);
  memset(p, 0, sz);
  dolock(k, &kd, 0);
  key_setkeydata(k->kf, k->k, kd);
  key_drop(kd);
  sub_free(p, sz);
}

static void alg_rsa(keyopts *k)
{
  rsa_priv rp;
  key_data *kd, *kkd;

  /* --- Sanity checking --- */

  if (k->p)
    die(EXIT_FAILURE, "no shared parameters for RSA keys");
  if (!k->bits)
    k->bits = 1024;

  /* --- Generate the RSA parameters --- */

  if (rsa_gen(&rp, k->bits, k->r, 0,
	      (k->f & f_quiet) ? 0 : pgen_ev, 0))
    die(EXIT_FAILURE, "RSA key generation failed");

  /* --- Run a test encryption --- */

  {
    grand *g = fibrand_create(k->r->ops->word(k->r));
    rsa_pub rpp;
    mp *m = mprand_range(MP_NEW, rp.n, g, 0);
    mp *c;

    rpp.n = rp.n;
    rpp.e = rp.e;
    c = rsa_qpubop(&rpp, MP_NEW, m);
    c = rsa_qprivop(&rp, c, c, g);

    if (!MP_EQ(c, m))
      die(EXIT_FAILURE, "test encryption failed");
    mp_drop(c);
    mp_drop(m);
    g->ops->destroy(g);
  }

  /* --- Allrighty then --- */

  kd = key_newstruct();
  key_structsteal(kd, "n", key_newmp(KCAT_PUB, rp.n));
  key_structsteal(kd, "e", key_newmp(KCAT_PUB, rp.e));

  kkd = key_newstruct();
  key_structsteal(kkd, "d", key_newmp(KCAT_PRIV | KF_BURN, rp.d));
  key_structsteal(kkd, "p", key_newmp(KCAT_PRIV | KF_BURN, rp.p));
  key_structsteal(kkd, "q", key_newmp(KCAT_PRIV | KF_BURN, rp.q));
  key_structsteal(kkd, "q-inv", key_newmp(KCAT_PRIV | KF_BURN, rp.q_inv));
  key_structsteal(kkd, "d-mod-p", key_newmp(KCAT_PRIV | KF_BURN, rp.dp));
  key_structsteal(kkd, "d-mod-q", key_newmp(KCAT_PRIV | KF_BURN, rp.dq));
  dolock(k, &kkd, "private");
  key_structsteal(kd, "private", kkd);
  key_setkeydata(k->kf, k->k, kd);
  key_drop(kd);
  rsa_privfree(&rp);
}

static void alg_dsaparam(keyopts *k)
{
  static const char *pl[] = { "q", "p", "g", 0 };
  if (!copyparam(k, pl)) {
    dsa_param dp;
    octet *p;
    size_t sz;
    dstr d = DSTR_INIT;
    codec *c;
    key_data *kd;
    dsa_seed ds;

    /* --- Choose appropriate bit lengths if necessary --- */

    if (!k->qbits)
      k->qbits = 160;
    if (!k->bits)
      k->bits = 1024;

    /* --- Allocate a seed block --- */

    sz = (k->qbits + 7) >> 3;
    p = sub_alloc(sz);
    k->r->ops->fill(k->r, p, sz);

    /* --- Allocate the parameters --- */

    if (dsa_gen(&dp, k->qbits, k->bits, 0, p, sz, &ds,
		(k->f & f_quiet) ? 0 : pgen_ev, 0))
      die(EXIT_FAILURE, "DSA parameter generation failed");

    /* --- Store the parameters --- */

    kd = key_newstruct();
    key_structsteal(kd, "q", key_newmp(KCAT_SHARE, dp.q));
    key_structsteal(kd, "p", key_newmp(KCAT_SHARE, dp.p));
    key_structsteal(kd, "g", key_newmp(KCAT_SHARE, dp.g));
    mp_drop(dp.q);
    mp_drop(dp.p);
    mp_drop(dp.g);
    key_setkeydata(k->kf, k->k, kd);
    key_drop(kd);

    /* --- Store the seed for future verification --- */

    c = base64_class.encoder(0, "", 0);
    c->ops->code(c, ds.p, ds.sz, &d); c->ops->code(c, 0, 0, &d);
    c->ops->destroy(c);
    DPUTZ(&d);
    key_putattr(k->kf, k->k, "seed", d.buf);
    DRESET(&d);
    dstr_putf(&d, "%u", ds.count);
    key_putattr(k->kf, k->k, "count", d.buf);
    xfree(ds.p);
    sub_free(p, sz);
    dstr_destroy(&d);
  }
}

static void alg_dsa(keyopts *k)
{
  mp *q, *p, *g;
  mp *x, *y;
  mpmont mm;
  key_data *kd, *kkd;

  /* --- Get the shared parameters --- */

  alg_dsaparam(k);
  key_split(&k->k->k); kd = k->k->k;
  q = getmp(kd, "q");
  p = getmp(kd, "p");
  g = getmp(kd, "g");

  /* --- Choose a private key --- */

  x = mprand_range(MP_NEWSEC, q, k->r, 0);
  mpmont_create(&mm, p);
  y = mpmont_exp(&mm, MP_NEW, g, x);

  /* --- Store everything away --- */

  key_structsteal(kd, "y", key_newmp(KCAT_PUB, y));

  kkd = key_newstruct();
  key_structsteal(kkd, "x", key_newmp(KCAT_PRIV | KF_BURN, x));
  dolock(k, &kkd, "private");
  key_structsteal(kd, "private", kkd);

  mp_drop(x); mp_drop(y);
}

static void alg_dhparam(keyopts *k)
{
  static const char *pl[] = { "p", "q", "g", 0 };
  key_data *kd;
  if (!copyparam(k, pl)) {
    dh_param dp;
    int rc;

    if (k->curve) {
      qd_parse qd;
      group *g;
      const char *e;

      if (strcmp(k->curve, "list") == 0) {
	unsigned i, w;
	LIST("Built-in prime fields", stdout, ptab[i].name, ptab[i].name);
	exit(0);
      }
      qd.p = k->curve;
      if (dh_parse(&qd, &dp))
	die(EXIT_FAILURE, "error in field spec: %s", qd.e);
      if (!qd_eofp(&qd))
	die(EXIT_FAILURE, "junk at end of field spec");
      if ((g = group_prime(&dp)) == 0)
	die(EXIT_FAILURE, "invalid prime field");
      if (!(k->f & f_quiet) && (e = G_CHECK(g, &rand_global)) != 0)
	moan("WARNING!	group check failed: %s", e);
      G_DESTROYGROUP(g);
      goto done;
    }

    if (!k->bits)
      k->bits = 1024;

    /* --- Choose a large safe prime number --- */

    if (k->f & f_limlee) {
      mp **f;
      size_t nf;
      if (!k->qbits)
	k->qbits = 256;
      rc = dh_limlee(&dp, k->qbits, k->bits,
		     (k->f & f_subgroup) ? DH_SUBGROUP : 0,
		     0, k->r, (k->f & f_quiet) ? 0 : pgen_ev, 0,
		     (k->f & f_quiet) ? 0 : pgen_evspin, 0, &nf, &f);
      if (!rc) {
	dstr d = DSTR_INIT;
	size_t i;
	for (i = 0; i < nf; i++) {
	  if (i)
	    dstr_puts(&d, ", ");
	  mp_writedstr(f[i], &d, 10);
	  mp_drop(f[i]);
	}
	key_putattr(k->kf, k->k, "factors", d.buf);
	dstr_destroy(&d);
      }
    } else if (k->f & f_kcdsa) {
      if (!k->qbits)
	k->qbits = 256;
      rc = dh_kcdsagen(&dp, k->qbits, k->bits, 0,
		       0, k->r, (k->f & f_quiet) ? 0 : pgen_ev, 0);
      if (!rc) {
	dstr d = DSTR_INIT;
	mp *v = MP_NEW;

	mp_writedstr(dp.q, &d, 10);
	mp_div(&v, 0, dp.p, dp.q);
	v = mp_lsr(v, v, 1);
	dstr_puts(&d, ", ");
	mp_writedstr(v, &d, 10);
	mp_drop(v);
	key_putattr(k->kf, k->k, "factors", d.buf);
	dstr_destroy(&d);
      }
    } else
      rc = dh_gen(&dp, k->qbits, k->bits, 0, k->r,
		  (k->f & f_quiet) ? 0 : pgen_ev, 0);

    if (rc)
      die(EXIT_FAILURE, "Diffie-Hellman parameter generation failed");

  done:
    kd = key_newstruct();
    key_structsteal(kd, "p", key_newmp(KCAT_SHARE, dp.p));
    key_structsteal(kd, "q", key_newmp(KCAT_SHARE, dp.q));
    key_structsteal(kd, "g", key_newmp(KCAT_SHARE, dp.g));
    mp_drop(dp.q);
    mp_drop(dp.p);
    mp_drop(dp.g);
    key_setkeydata(k->kf, k->k, kd);
    key_drop(kd);
  }
}

static void alg_dh(keyopts *k)
{
  mp *x, *y;
  mp *p, *q, *g;
  mpmont mm;
  key_data *kd, *kkd;

  /* --- Get the shared parameters --- */

  alg_dhparam(k);
  key_split(&k->k->k); kd = k->k->k;
  p = getmp(kd, "p");
  q = getmp(kd, "q");
  g = getmp(kd, "g");

  /* --- Choose a suitable private key --- *
   *
   * Since %$g$% has order %$q$%, choose %$x < q$%.
   */

  x = mprand_range(MP_NEWSEC, q, k->r, 0);

  /* --- Compute the public key %$y = g^x \bmod p$% --- */

  mpmont_create(&mm, p);
  y = mpmont_exp(&mm, MP_NEW, g, x);
  mpmont_destroy(&mm);

  /* --- Store everything away --- */

  key_structsteal(kd, "y", key_newmp(KCAT_PUB, y));

  kkd = key_newstruct();
  key_structsteal(kkd, "x", key_newmp(KCAT_PRIV | KF_BURN, x));
  dolock(k, &kkd, "private");
  key_structsteal(kd, "private", kkd);

  mp_drop(x); mp_drop(y);
}

static void alg_bbs(keyopts *k)
{
  bbs_priv bp;
  key_data *kd, *kkd;

  /* --- Sanity checking --- */

  if (k->p)
    die(EXIT_FAILURE, "no shared parameters for Blum-Blum-Shub keys");
  if (!k->bits)
    k->bits = 1024;

  /* --- Generate the BBS parameters --- */

  if (bbs_gen(&bp, k->bits, k->r, 0,
	      (k->f & f_quiet) ? 0 : pgen_ev, 0))
    die(EXIT_FAILURE, "Blum-Blum-Shub key generation failed");

  /* --- Allrighty then --- */

  kd = key_newstruct();
  key_structsteal(kd, "n", key_newmp(KCAT_PUB, bp.n));

  kkd = key_newstruct();
  key_structsteal(kkd, "p", key_newmp(KCAT_PRIV | KF_BURN, bp.p));
  key_structsteal(kkd, "q", key_newmp(KCAT_PRIV | KF_BURN, bp.q));
  dolock(k, &kkd, "private");
  key_structsteal(kd, "private", kkd);
  key_setkeydata(k->kf, k->k, kd);
  key_drop(kd);

  bbs_privfree(&bp);
}

static void alg_binparam(keyopts *k)
{
  static const char *pl[] = { "p", "q", "g", 0 };
  if (!copyparam(k, pl)) {
    gbin_param gb;
    qd_parse qd;
    group *g;
    const char *e;
    key_data *kd;

    /* --- Decide on a field --- */

    if (!k->bits) k->bits = 128;
    if (k->curve && strcmp(k->curve, "list") == 0) {
      unsigned i, w;
      LIST("Built-in binary fields", stdout,
	   bintab[i].name, bintab[i].name);
      exit(0);
    }
    if (!k->curve) {
      if (k->bits <= 40) k->curve = "p1363-40";
      else if (k->bits <= 56) k->curve = "p1363-56";
      else if (k->bits <= 64) k->curve = "p1363-64";
      else if (k->bits <= 80) k->curve = "p1363-80";
      else if (k->bits <= 112) k->curve = "p1363-112";
      else if (k->bits <= 128) k->curve = "p1363-128";
      else {
	die(EXIT_FAILURE,
	    "no built-in binary fields provide %u-bit security",
	    k->bits);
      }
    }

    /* --- Check it --- */

    qd.e = 0;
    qd.p = k->curve;
    if (dhbin_parse(&qd, &gb))
      die(EXIT_FAILURE, "error in field spec: %s", qd.e);
    if (!qd_eofp(&qd))
      die(EXIT_FAILURE, "junk at end of field spec");
    if ((g = group_binary(&gb)) == 0)
      die(EXIT_FAILURE, "invalid binary field");
    if (!(k->f & f_quiet) && (e = G_CHECK(g, &rand_global)) != 0)
      moan("WARNING!  group check failed: %s", e);
    G_DESTROYGROUP(g);

    /* --- Write out the answer --- */

    kd = key_newstruct();
    key_structsteal(kd, "p", key_newmp(KCAT_SHARE, gb.p));
    key_structsteal(kd, "q", key_newmp(KCAT_SHARE, gb.q));
    key_structsteal(kd, "g", key_newmp(KCAT_SHARE, gb.g));
    mp_drop(gb.q);
    mp_drop(gb.p);
    mp_drop(gb.g);
    key_setkeydata(k->kf, k->k, kd);
    key_drop(kd);
  }
}

static void alg_bin(keyopts *k)
{
  mp *x, *y;
  mp *p, *q, *g;
  gfreduce r;
  key_data *kd, *kkd;

  /* --- Get the shared parameters --- */

  alg_binparam(k);
  key_split(&k->k->k); kd = k->k->k;
  p = getmp(kd, "p");
  q = getmp(kd, "q");
  g = getmp(kd, "g");

  /* --- Choose a suitable private key --- *
   *
   * Since %$g$% has order %$q$%, choose %$x < q$%.
   */

  x = mprand_range(MP_NEWSEC, q, k->r, 0);

  /* --- Compute the public key %$y = g^x \bmod p$% --- */

  gfreduce_create(&r, p);
  y = gfreduce_exp(&r, MP_NEW, g, x);
  gfreduce_destroy(&r);

  /* --- Store everything away --- */

  key_structsteal(kd, "y", key_newmp(KCAT_PUB, y));

  kkd = key_newstruct();
  key_structsteal(kkd, "x", key_newmp(KCAT_PRIV | KF_BURN, x));
  dolock(k, &kkd, "private");
  key_structsteal(kd, "private", kkd);

  mp_drop(x); mp_drop(y);
}

static void alg_ecparam(keyopts *k)
{
  static const char *pl[] = { "curve", 0 };
  if (!copyparam(k, pl)) {
    ec_info ei;
    const char *e;
    key_data *kd;

    /* --- Decide on a curve --- */

    if (!k->bits) k->bits = 256;
    if (k->curve && strcmp(k->curve, "list") == 0) {
      unsigned i, w;
      LIST("Built-in elliptic curves", stdout,
	   ectab[i].name, ectab[i].name);
      exit(0);
    }
    if (!k->curve) {
      if (k->bits <= 56) k->curve = "secp112r1";
      else if (k->bits <= 64) k->curve = "secp128r1";
      else if (k->bits <= 80) k->curve = "secp160r1";
      else if (k->bits <= 96) k->curve = "secp192r1";
      else if (k->bits <= 112) k->curve = "secp224r1";
      else if (k->bits <= 128) k->curve = "secp256r1";
      else if (k->bits <= 192) k->curve = "secp384r1";
      else if (k->bits <= 256) k->curve = "secp521r1";
      else
	die(EXIT_FAILURE, "no built-in curves provide %u-bit security",
	    k->bits);
    }

    /* --- Check it --- */

    if ((e = ec_getinfo(&ei, k->curve)) != 0)
      die(EXIT_FAILURE, "error in curve spec: %s", e);
    if (!(k->f & f_quiet) && (e = ec_checkinfo(&ei, k->r)) != 0)
      moan("WARNING!  curve check failed: %s", e);
    ec_freeinfo(&ei);

    /* --- Write out the answer --- */

    kd = key_newstruct();
    key_structsteal(kd, "curve", key_newstring(KCAT_SHARE, k->curve));
    key_setkeydata(k->kf, k->k, kd);
    key_drop(kd);
  }
}

static void alg_ec(keyopts *k)
{
  key_data *kd;
  key_data *kkd;
  mp *x = MP_NEW;
  ec p = EC_INIT;
  const char *e;
  ec_info ei;

  /* --- Get the curve --- */

  alg_ecparam(k);
  key_split(&k->k->k); kd = k->k->k;
  if ((kkd = key_structfind(kd, "curve")) == 0)
    die(EXIT_FAILURE, "unexpected failure looking up subkey `curve')");
  if ((kkd->e & KF_ENCMASK) != KENC_STRING)
    die(EXIT_FAILURE, "subkey `curve' is not a string");
  if ((e = ec_getinfo(&ei, kkd->u.p)) != 0)
    die(EXIT_FAILURE, "error in curve spec: %s", e);

  /* --- Invent a private exponent and compute the public key --- */

  x = mprand_range(MP_NEWSEC, ei.r, k->r, 0);
  ec_mul(ei.c, &p, &ei.g, x);

  /* --- Store everything away --- */

  key_structsteal(kd, "p", key_newec(KCAT_PUB, &p));

  kkd = key_newstruct();
  key_structsteal(kkd, "x", key_newmp(KCAT_PRIV | KF_BURN, x));
  dolock(k, &kkd, "private");
  key_structsteal(kd, "private", kkd);

  /* --- Done --- */

  ec_freeinfo(&ei);
  mp_drop(x);
}

/* --- The algorithm tables --- */

typedef struct keyalg {
  const char *name;
  void (*proc)(keyopts *o);
  const char *help;
} keyalg;

static keyalg algtab[] = {
  { "binary",		alg_binary,	"Plain binary data" },
  { "des",		alg_des,	"Binary with DES-style parity" },
  { "rsa",		alg_rsa,	"RSA public-key encryption" },
  { "bbs",		alg_bbs,	"Blum-Blum-Shub generator" },
  { "dsa",		alg_dsa,	"DSA digital signatures" },
  { "dsa-param",	alg_dsaparam,	"DSA shared parameters" },
  { "dh",		alg_dh,		"Diffie-Hellman key exchange" },
  { "dh-param",		alg_dhparam,	"Diffie-Hellman parameters" },
  { "bindh",		alg_bin,	"DH over a binary field" },
  { "bindh-param",	alg_binparam,	"Binary-field DH parameters" },
  { "ec-param",		alg_ecparam,	"Elliptic curve parameters" },
  { "ec",		alg_ec,		"Elliptic curve crypto" },
  { 0,			0 }
};

/* --- @cmd_add@ --- */

static int cmd_add(int argc, char *argv[])
{
  key_file f;
  time_t exp = KEXP_EXPIRE;
  uint32 kid = rand_global.ops->word(&rand_global);
  const char *tag = 0, *ptag = 0;
  const char *c = 0;
  keyalg *alg = algtab;
  const char *rtag = 0;
  const struct seedalg *sa = SEEDALG_DEFAULT;
  keyopts k = { 0, 0, DSTR_INIT, 0, 0, 0, 0, 0 };
  const char *seed = 0;
  k.r = &rand_global;

  /* --- Parse options for the subcommand --- */

  for (;;) {
    static struct option opt[] = {
      { "algorithm",	OPTF_ARGREQ,	0,	'a' },
      { "bits",		OPTF_ARGREQ,	0,	'b' },
      { "qbits",	OPTF_ARGREQ,	0,	'B' },
      { "parameters",	OPTF_ARGREQ,	0,	'p' },
      { "expire",	OPTF_ARGREQ,	0,	'e' },
      { "comment",	OPTF_ARGREQ,	0,	'c' },
      { "tag",		OPTF_ARGREQ,	0,	't' },
      { "rand-id",	OPTF_ARGREQ,	0,	'R' },
      { "key-id",	OPTF_ARGREQ,	0,	'I' },
      { "curve",	OPTF_ARGREQ,	0,	'C' },
      { "seedalg",	OPTF_ARGREQ,	0,	'A' },
      { "seed",		OPTF_ARGREQ,	0,	's' },
      { "newseed",	OPTF_ARGREQ,	0,	'n' },
      { "lock",		0,		0,	'l' },
      { "quiet",	0,		0,	'q' },
      { "lim-lee",	0,		0,	'L' },
      { "subgroup",	0,		0,	'S' },
      { "kcdsa",	0,		0,	'K' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+a:b:B:p:e:c:t:R:I:C:A:s:n:lqrLKS",
		   opt, 0, 0, 0);
    if (i < 0)
      break;

    /* --- Handle the various options --- */

    switch (i) {

      /* --- Read an algorithm name --- */

      case 'a': {
	keyalg *a;
	size_t sz = strlen(optarg);

	if (strcmp(optarg, "list") == 0) {
	  for (a = algtab; a->name; a++)
	    printf("%-10s %s\n", a->name, a->help);
	  return (0);
	}

	alg = 0;
	for (a = algtab; a->name; a++) {
	  if (strncmp(optarg, a->name, sz) == 0) {
	    if (a->name[sz] == 0) {
	      alg = a;
	      break;
	    } else if (alg)
	      die(EXIT_FAILURE, "ambiguous algorithm name `%s'", optarg);
	    else
	      alg = a;
	  }
	}
	if (!alg)
	  die(EXIT_FAILURE, "unknown algorithm name `%s'", optarg);
      } break;

      /* --- Bits must be nonzero and a multiple of 8 --- */

      case 'b': {
	char *p;
	k.bits = strtoul(optarg, &p, 0);
	if (k.bits == 0 || *p != 0)
	  die(EXIT_FAILURE, "bad bitlength `%s'", optarg);
      } break;

      case 'B': {
	char *p;
	k.qbits = strtoul(optarg, &p, 0);
	if (k.qbits == 0 || *p != 0)
	  die(EXIT_FAILURE, "bad bitlength `%s'", optarg);
      } break;

      /* --- Parameter selection --- */

      case 'p':
	ptag = optarg;
	break;

      /* --- Expiry dates get passed to @get_date@ for parsing --- */

      case 'e':
	if (strcmp(optarg, "forever") == 0)
	  exp = KEXP_FOREVER;
	else {
	  exp = get_date(optarg, 0);
	  if (exp == -1)
	    die(EXIT_FAILURE, "bad expiry date `%s'", optarg);
	}
	break;

      /* --- Store comments without interpretation --- */

      case 'c':
	if (key_chkcomment(optarg))
	  die(EXIT_FAILURE, "bad comment string `%s'", optarg);
	c = optarg;
	break;

      /* --- Elliptic curve parameters --- */

      case 'C':
	k.curve = optarg;
	break;

      /* --- Store tags --- */

      case 't':
	if (key_chkident(optarg))
	  die(EXIT_FAILURE, "bad tag string `%s'", optarg);
	tag = optarg;
	break;
      case 'r':
	k.f |= f_retag;
	break;

      /* --- Seeding --- */

      case 'A': {
	const struct seedalg *ss;
	if (strcmp(optarg, "list") == 0) {
	  printf("Seed algorithms:\n");
	  for (ss = seedtab; ss->p; ss++)
	    printf("  %s\n", ss->p);
	  exit(0);
	}
	if (seed) die(EXIT_FAILURE, "seed already set -- put -A first");
	sa = 0;
	for (ss = seedtab; ss->p; ss++) {
	  if (strcmp(optarg, ss->p) == 0)
	    sa = ss;
	}
	if (!sa)
	  die(EXIT_FAILURE, "seed algorithm `%s' not known", optarg);
      } break;

      case 's': {
	codec *c;
	int rc;
	dstr d = DSTR_INIT;
	if (seed) die(EXIT_FAILURE, "seed already set");
	c = base64_class.decoder(CDCF_IGNEQPAD);
	if ((rc = c->ops->code(c, optarg, strlen(optarg), &d)) != 0 ||
	    (rc = c->ops->code(c, 0, 0, &d)) != 0)
	  die(EXIT_FAILURE, "invalid seed base64: %s", codec_strerror(rc));
	c->ops->destroy(c);
	k.r = sa->gen(d.buf, d.len);
	seed = optarg;
	dstr_destroy(&d);
      } break;

      case 'n': {
	codec *c;
	dstr d = DSTR_INIT;
	char *p;
	unsigned n = strtoul(optarg, &p, 0);
	if (n == 0 || *p != 0 || n % 8 != 0)
	  die(EXIT_FAILURE, "bad seed length `%s'", optarg);
	if (seed) die(EXIT_FAILURE, "seed already set");
	n /= 8;
	p = xmalloc(n);
	rand_get(RAND_GLOBAL, p, n);
	c = base64_class.encoder(0, "", 0);
	c->ops->code(c, p, n, &d); c->ops->code(c, 0, 0, &d);
	c->ops->destroy(c);
	seed = d.buf;
	k.r = sa->gen(p, n);
      } break;

      /* --- Key id --- */

      case 'I': {
	char *p;
	unsigned long id;

	errno = 0;
	id = strtoul(optarg, &p, 16);
	if (errno || *p || id > MASK32)
	  die(EXIT_FAILURE, "bad key-id `%s'", optarg);
	kid = id;
      } break;

      /* --- Other flags --- */

      case 'R':
	rtag = optarg;
	break;
      case 'l':
	k.f |= f_lock;
	break;
      case 'q':
	k.f |= f_quiet;
	break;
      case 'L':
	k.f |= f_limlee;
	break;
      case 'K':
	k.f |= f_kcdsa;
	break;
      case 'S':
	k.f |= f_subgroup;
	break;

      /* --- Other things are bogus --- */

      default:
	k.f |= f_bogus;
	break;
    }
  }

  /* --- Various sorts of bogosity --- */

  if ((k.f & f_bogus) || optind + 1 > argc) {
    die(EXIT_FAILURE,
	"Usage: add [OPTIONS] TYPE [ATTR...]");
  }
  if (key_chkident(argv[optind]))
    die(EXIT_FAILURE, "bad key type `%s'", argv[optind]);

  /* --- Set up various bits of the state --- */

  if (exp == KEXP_EXPIRE)
    exp = time(0) + 14 * 24 * 60 * 60;

  /* --- Open the file and create the basic key block --- *
   *
   * Keep on generating keyids until one of them doesn't collide.
   */

  doopen(&f, KOPEN_WRITE);
  k.kf = &f;

  /* --- Key the generator --- */

  keyrand(&f, rtag);

  for (;;) {
    int err;
    if ((err = key_new(&f, kid, argv[optind], exp, &k.k)) == 0)
      break;
    else if (err != KERR_DUPID)
      die(EXIT_FAILURE, "error adding new key: %s", key_strerror(err));
  }

  /* --- Set various simple attributes --- */

  if (tag) {
    int err;
    key *kk;
    if (k.f & f_retag) {
      if ((kk = key_bytag(&f, tag)) != 0 &&
	  kk->tag &&
	  strcmp(kk->tag, tag) == 0)
	key_settag(&f, kk, 0);
    }
    if ((err = key_settag(&f, k.k, tag)) != 0)
      die(EXIT_FAILURE, "error setting key tag: %s", key_strerror(err));
  }

  if (c) {
    int err = key_setcomment(&f, k.k, c);
    if (err)
      die(EXIT_FAILURE, "error setting key comment: %s", key_strerror(err));
  }

  setattr(&f, k.k, argv + optind + 1);
  if (seed) {
    key_putattr(&f, k.k, "genseed", seed);
    key_putattr(&f, k.k, "seedalg", sa->p);
  }

  key_fulltag(k.k, &k.tag);

  /* --- Find the parameter key --- */

  if (ptag) {
    if ((k.p = key_bytag(&f, ptag)) == 0)
      die(EXIT_FAILURE, "parameter key `%s' not found", ptag);
    if ((k.p->k->e & KF_ENCMASK) != KENC_STRUCT)
      die(EXIT_FAILURE, "parameter key `%s' is not structured", ptag);
  }

  /* --- Now generate the actual key data --- */

  alg->proc(&k);

  /* --- Done --- */

  dstr_destroy(&k.tag);
  doclose(&f);
  return (0);
}

/*----- Key listing -------------------------------------------------------*/

/* --- Listing options --- */

typedef struct listopts {
  const char *tfmt;			/* Date format (@strftime@-style) */
  int v;				/* Verbosity level */
  unsigned f;				/* Various flags */
  time_t t;				/* Time now (for key expiry) */
  key_filter kf;			/* Filter for matching keys */
} listopts;

/* --- Listing flags --- */

#define f_newline 2u			/* Write newline before next entry */
#define f_attr 4u			/* Written at least one attribute */
#define f_utc 8u			/* Emit UTC time, not local time */

/* --- @showkeydata@ --- *
 *
 * Arguments:	@key_data *k@ = pointer to key to write
 *		@int ind@ = indentation level
 *		@listopts *o@ = listing options
 *		@dstr *d@ = tag string for this subkey
 *
 * Returns:	---
 *
 * Use:		Emits a piece of key data in a human-readable format.
 */

static void showkeydata(key_data *k, int ind, listopts *o, dstr *d)
{
#define INDENT(i) do {							\
  int _i;								\
  for (_i = 0; _i < (i); _i++) {					\
    putchar(' ');							\
  }									\
} while (0)

  switch (k->e & KF_ENCMASK) {

    /* --- Binary key data --- *
     *
     * Emit as a simple hex dump.
     */

    case KENC_BINARY: {
      const octet *p = k->u.k.k;
      const octet *l = p + k->u.k.sz;
      size_t sz = 0;

      fputs(" {", stdout);
      while (p < l) {
	if (sz % 16 == 0) {
	  putchar('\n');
	  INDENT(ind + 2);
	} else if (sz % 8 == 0)
	  fputs("  ", stdout);
	else
	  putc(' ', stdout);
	printf("%02x", *p++);
	sz++;
      }
      putchar('\n');
      INDENT(ind);
      fputs("}\n", stdout);
    } break;

    /* --- Encrypted data --- *
     *
     * If the user is sufficiently keen, ask for a passphrase and decrypt the
     * key.  Otherwise just say that it's encrypted and move on.
     */

    case KENC_ENCRYPT:
      if (o->v <= 3)
	fputs(" encrypted\n", stdout);
      else {
	key_data *kd;
	if (key_punlock(&kd, k, d->buf))
	  printf(" <failed to unlock %s>\n", d->buf);
	else {
	  fputs(" encrypted", stdout);
	  showkeydata(kd, ind, o, d);
	  key_drop(kd);
	}
      }
      break;

    /* --- Integer keys --- *
     *
     * Emit as a large integer in decimal.  This makes using the key in
     * `calc' or whatever easier.
     */

    case KENC_MP:
      putchar(' ');
      mp_writefile(k->u.m, stdout, 10);
      putchar('\n');
      break;

    /* --- Strings --- */

    case KENC_STRING:
      printf(" `%s'\n", k->u.p);
      break;

    /* --- Elliptic curve points --- */

    case KENC_EC:
      if (EC_ATINF(&k->u.e))
	fputs(" inf\n", stdout);
      else {
	fputs(" 0x", stdout); mp_writefile(k->u.e.x, stdout, 16);
	fputs(", 0x", stdout); mp_writefile(k->u.e.y, stdout, 16);
	putchar('\n');
      }
      break;

    /* --- Structured keys --- *
     *
     * Just iterate over the subkeys.
     */

    case KENC_STRUCT: {
      key_subkeyiter i;
      const char *tag;
      size_t n = d->len;

      fputs(" {\n", stdout);
      for (key_mksubkeyiter(&i, k); key_nextsubkey(&i, &tag, &k); ) {
	if (!key_match(k, &o->kf))
	  continue;
	INDENT(ind + 2);
	printf("%s =", tag);
	d->len = n;
	dstr_putf(d, ".%s", tag);
	showkeydata(k, ind + 2, o, d);
      }
      INDENT(ind);
      fputs("}\n", stdout);
    } break;
  }

#undef INDENT
}

/* --- @showkey@ --- *
 *
 * Arguments:	@key *k@ = pointer to key to show
 *		@listopts *o@ = pointer to listing options
 *
 * Returns:	---
 *
 * Use:		Emits a listing of a particular key.
 */

static void showkey(key *k, listopts *o)
{
  char ebuf[24], dbuf[24];
  struct tm *tm;

  /* --- Skip the key if the filter doesn't match --- */

  if (!key_match(k->k, &o->kf))
    return;

  /* --- Sort out the expiry and deletion times --- */

  if (KEY_EXPIRED(o->t, k->exp))
    strcpy(ebuf, "expired");
  else if (k->exp == KEXP_FOREVER)
    strcpy(ebuf, "forever");
  else {
    tm = (o->f & f_utc) ? gmtime(&k->exp) : localtime(&k->exp);
    strftime(ebuf, sizeof(ebuf), o->tfmt, tm);
  }

  if (KEY_EXPIRED(o->t, k->del))
    strcpy(dbuf, "deleted");
  else if (k->del == KEXP_FOREVER)
    strcpy(dbuf, "forever");
  else {
    tm = (o->f & f_utc) ? gmtime(&k->del) : localtime(&k->del);
    strftime(dbuf, sizeof(dbuf), o->tfmt, tm);
  }

  /* --- If in compact format, just display and quit --- */

  if (!o->v) {
    if (!(o->f & f_newline)) {
      printf("%8s  %-20s  %-20s  %-10s  %s\n",
	     "Id", "Tag", "Type", "Expire", "Delete");
    }
    printf("%08lx  %-20s  %-20s  %-10s  %s\n",
	   (unsigned long)k->id, k->tag ? k->tag : "<none>",
	   k->type, ebuf, dbuf);
    o->f |= f_newline;
    return;
  }

  /* --- Display the standard header --- */

  if (o->f & f_newline)
    fputc('\n', stdout);
  printf("keyid: %08lx\n", (unsigned long)k->id);
  printf("tag: %s\n", k->tag ? k->tag : "<none>");
  printf("type: %s\n", k->type);
  printf("expiry: %s\n", ebuf);
  printf("delete: %s\n", dbuf);
  printf("comment: %s\n", k->c ? k->c : "<none>");

  /* --- Display the attributes --- */

  if (o->v > 1) {
    key_attriter i;
    const char *av, *an;

    o->f &= ~f_attr;
    printf("attributes:");
    for (key_mkattriter(&i, k); key_nextattr(&i, &an, &av); ) {
      printf("\n  %s = %s", an, av);
      o->f |= f_attr;
    }
    if (o->f & f_attr)
      fputc('\n', stdout);
    else
      puts(" <none>");
  }

  /* --- If dumping requested, dump the raw key data --- */

  if (o->v > 2) {
    dstr d = DSTR_INIT;
    fputs("key:", stdout);
    key_fulltag(k, &d);
    showkeydata(k->k, 0, o, &d);
    dstr_destroy(&d);
  }

  o->f |= f_newline;
}

/* --- @cmd_list@ --- */

static int cmd_list(int argc, char *argv[])
{
  key_file f;
  key *k;
  listopts o = { 0, 0, 0, 0, { 0, 0 } };

  /* --- Parse subcommand options --- */

  for (;;) {
    static struct option opt[] = {
      { "quiet",	0,		0,	'q' },
      { "verbose",	0,		0,	'v' },
      { "utc",		0,		0,	'u' },
      { "filter",	OPTF_ARGREQ,	0,	'f' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+uqvf:", opt, 0, 0, 0);
    if (i < 0)
      break;

    switch (i) {
      case 'u':
	o.f |= f_utc;
	break;
      case 'q':
	if (o.v)
	  o.v--;
	break;
      case 'v':
	o.v++;
	break;
      case 'f': {
	char *p;
	int e = key_readflags(optarg, &p, &o.kf.f, &o.kf.m);
	if (e || *p)
	  die(EXIT_FAILURE, "bad filter string `%s'", optarg);
      } break;
      default:
	o.f |= f_bogus;
	break;
    }
  }

  if (o.f & f_bogus)
    die(EXIT_FAILURE, "Usage: list [-uqv] [-f FILTER] [TAG...]");

  /* --- Open the key file --- */

  doopen(&f, KOPEN_READ);
  o.t = time(0);

  /* --- Set up the time format --- */

  if (!o.v)
    o.tfmt = "%Y-%m-%d";
  else if (o.f & f_utc)
    o.tfmt = "%Y-%m-%d %H:%M:%S UTC";
  else
    o.tfmt = "%Y-%m-%d %H:%M:%S %Z";

  /* --- If specific keys were requested use them, otherwise do all --- *
   *
   * Some day, this might turn into a wildcard match.
   */

  if (optind < argc) {
    do {
      if ((k = key_bytag(&f, argv[optind])) != 0)
	showkey(k, &o);
      else {
	moan("key `%s' not found", argv[optind]);
	o.f |= f_bogus;
      }
      optind++;
    } while (optind < argc);
  } else {
    key_iter i;
    for (key_mkiter(&i, &f); (k = key_next(&i)) != 0; )
      showkey(k, &o);
  }

  /* --- Done --- */

  doclose(&f);
  if (o.f & f_bogus)
    return (EXIT_FAILURE);
  else
    return (0);
}

/*----- Command implementation --------------------------------------------*/

/* --- @cmd_expire@ --- */

static int cmd_expire(int argc, char *argv[])
{
  key_file f;
  key *k;
  int i;
  int rc = 0;

  if (argc < 2)
    die(EXIT_FAILURE, "Usage: expire TAG...");
  doopen(&f, KOPEN_WRITE);
  for (i = 1; i < argc; i++) {
    if ((k = key_bytag(&f, argv[i])) != 0)
      key_expire(&f, k);
    else {
      moan("key `%s' not found", argv[i]);
      rc = 1;
    }
  }
  doclose(&f);
  return (rc);
}

/* --- @cmd_delete@ --- */

static int cmd_delete(int argc, char *argv[])
{
  key_file f;
  key *k;
  int i;
  int rc = 0;

  if (argc < 2)
    die(EXIT_FAILURE, "Usage: delete TAG...");
  doopen(&f, KOPEN_WRITE);
  for (i = 1; i < argc; i++) {
    if ((k = key_bytag(&f, argv[i])) != 0)
      key_delete(&f, k);
    else {
      moan("key `%s' not found", argv[i]);
      rc = 1;
    }
  }
  doclose(&f);
  return (rc);
}

/* --- @cmd_setattr@ --- */

static int cmd_setattr(int argc, char *argv[])
{
  key_file f;
  key *k;

  if (argc < 3)
    die(EXIT_FAILURE, "Usage: setattr TAG ATTR...");
  doopen(&f, KOPEN_WRITE);
  if ((k = key_bytag(&f, argv[1])) == 0)
    die(EXIT_FAILURE, "key `%s' not found", argv[1]);
  setattr(&f, k, argv + 2);
  doclose(&f);
  return (0);
}

/* --- @cmd_getattr@ --- */

static int cmd_getattr(int argc, char *argv[])
{
  key_file f;
  key *k;
  dstr d = DSTR_INIT;
  const char *p;

  if (argc != 3)
    die(EXIT_FAILURE, "Usage: getattr TAG ATTR");
  doopen(&f, KOPEN_READ);
  if ((k = key_bytag(&f, argv[1])) == 0)
    die(EXIT_FAILURE, "key `%s' not found", argv[1]);
  key_fulltag(k, &d);
  if ((p = key_getattr(&f, k, argv[2])) == 0)
    die(EXIT_FAILURE, "no attribute `%s' for key `%s'", argv[2], d.buf);
  puts(p);
  dstr_destroy(&d);
  doclose(&f);
  return (0);
}

/* --- @cmd_finger@ --- */

static const struct fpres {
  const char *name;
  const codec_class *cdc;
  unsigned short ival;
  const char *sep;
} fprestab[] = {
  { "hex", &hex_class, 8, "-:" },
  { "base32", &base32_class, 6, ":" },
  { 0, 0 }
};

static void fingerprint(key *k, const struct fpres *fpres,
			const gchash *ch, const key_filter *kf)
{
  ghash *h;
  dstr d = DSTR_INIT, dd = DSTR_INIT;
  const octet *p;
  size_t i;
  codec *c;

  h = GH_INIT(ch);
  if (key_fingerprint(k, h, kf)) {
    p = GH_DONE(h, 0);
    c = fpres->cdc->encoder(CDCF_LOWERC | CDCF_NOEQPAD, "", 0);
    c->ops->code(c, p, ch->hashsz, &dd); c->ops->code(c, 0, 0, &dd);
    c->ops->destroy(c);
    for (i = 0; i < dd.len; i++) {
      if (i && i%fpres->ival == 0) dstr_putc(&d, fpres->sep[0]);
      dstr_putc(&d, dd.buf[i]);
    }
    dstr_putc(&d, ' '); key_fulltag(k, &d); dstr_putc(&d, '\n');
    dstr_write(&d, stdout);
  }
  dstr_destroy(&d); dstr_destroy(&dd);
  GH_DESTROY(h);
}

static const struct fpres *lookup_fpres(const char *name)
{
  const struct fpres *fpres;
  for (fpres = fprestab; fpres->name; fpres++)
    if (strcmp(fpres->name, name) == 0) return (fpres);
  die(EXIT_FAILURE, "unknown presentation syle `%s'", name);
}

static int cmd_finger(int argc, char *argv[])
{
  key_file f;
  int rc = 0;
  const struct fpres *fpres = fprestab;
  const gchash *ch = &rmd160;
  key_filter kf = { KF_NONSECRET, KF_NONSECRET };

  for (;;) {
    static struct option opt[] = {
      { "filter",	OPTF_ARGREQ,	0,	'f' },
      { "presentation",	OPTF_ARGREQ,	0,	'p' },
      { "algorithm",	OPTF_ARGREQ,	0,	'a' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+f:a:p:", opt, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case 'f': {
	char *p;
	int err = key_readflags(optarg, &p, &kf.f, &kf.m);
	if (err || *p)
	  die(EXIT_FAILURE, "bad filter string `%s'", optarg);
      } break;
      case 'p':
	fpres = lookup_fpres(optarg);
	break;
      case 'a':
	if ((ch = ghash_byname(optarg)) == 0)
	  die(EXIT_FAILURE, "unknown hash algorithm `%s'", optarg);
	break;
      default:
	rc = 1;
	break;
    }
  }

  argv += optind; argc -= optind;
  if (rc) {
    die(EXIT_FAILURE,
	"Usage: fingerprint [-a HASHALG] [-p STYLE] [-f FILTER] [TAG...]");
  }

  doopen(&f, KOPEN_READ);

  if (argc) {
    int i;
    for (i = 0; i < argc; i++) {
      key *k = key_bytag(&f, argv[i]);
      if (k)
	fingerprint(k, fpres, ch, &kf);
      else {
	rc = 1;
	moan("key `%s' not found", argv[i]);
      }
    }
  } else {
    key_iter i;
    key *k;
    for (key_mkiter(&i, &f); (k = key_next(&i)) != 0; )
      fingerprint(k, fpres, ch, &kf);
  }
  return (rc);
}

/* --- @cmd_verify@ --- */

static int cmd_verify(int argc, char *argv[])
{
  key_file f;
  int rc = 0;
  const gchash *ch = &rmd160;
  ghash *h;
  key *k;
  const octet *fpr;
  dstr d = DSTR_INIT, dd = DSTR_INIT;
  codec *c;
  const char *p;
  const struct fpres *fpres = fprestab;
  key_filter kf = { KF_NONSECRET, KF_NONSECRET };

  for (;;) {
    static struct option opt[] = {
      { "filter",	OPTF_ARGREQ,	0,	'f' },
      { "presentation",	OPTF_ARGREQ,	0,	'p' },
      { "algorithm",	OPTF_ARGREQ,	0,	'a' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+f:a:p:", opt, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case 'f': {
	char *p;
	int err = key_readflags(optarg, &p, &kf.f, &kf.m);
	if (err || *p)
	  die(EXIT_FAILURE, "bad filter string `%s'", optarg);
      } break;
      case 'p':
	fpres = lookup_fpres(optarg);
	break;
      case 'a':
	if ((ch = ghash_byname(optarg)) == 0)
	  die(EXIT_FAILURE, "unknown hash algorithm `%s'", optarg);
	break;
      default:
	rc = 1;
	break;
    }
  }

  argv += optind; argc -= optind;
  if (rc || argc != 2) {
    die(EXIT_FAILURE,
	"Usage: verify [-a HASHALG] [-p STYLE] [-f FILTER] TAG FINGERPRINT");
  }

  doopen(&f, KOPEN_READ);

  if ((k = key_bytag(&f, argv[0])) == 0)
    die(EXIT_FAILURE, "key `%s' not found", argv[0]);
  for (p = argv[1]; *p; p++) {
    if (strchr(fpres->sep, *p)) continue;
    dstr_putc(&dd, *p);
  }
  c = fpres->cdc->decoder(CDCF_IGNCASE | CDCF_IGNEQPAD |
			  CDCF_IGNSPC | CDCF_IGNNEWL);
  if ((rc = c->ops->code(c, dd.buf, dd.len, &d)) != 0 ||
      (rc = c->ops->code(c, 0, 0, &d)) != 0)
    die(EXIT_FAILURE, "invalid fingerprint: %s", codec_strerror(rc));
  c->ops->destroy(c);
  if (d.len != ch->hashsz) {
    die(EXIT_FAILURE, "incorrect fingerprint length (%lu != %lu)",
	(unsigned long)d.len, (unsigned long)ch->hashsz);
  }
  h = GH_INIT(ch);
  if (!key_fingerprint(k, h, &kf))
    die(EXIT_FAILURE, "key has no fingerprintable components (as filtered)");
  fpr = GH_DONE(h, 0);
  if (memcmp(fpr, d.buf, ch->hashsz) != 0)
    die(EXIT_FAILURE, "key fingerprint mismatch");
  dstr_destroy(&d); dstr_destroy(&dd);
  doclose(&f);
  return (0);
}

/* --- @cmd_comment@ --- */

static int cmd_comment(int argc, char *argv[])
{
  key_file f;
  key *k;
  int err;

  if (argc < 2 || argc > 3)
    die(EXIT_FAILURE, "Usage: comment TAG [COMMENT]");
  doopen(&f, KOPEN_WRITE);
  if ((k = key_bytag(&f, argv[1])) == 0)
    die(EXIT_FAILURE, "key `%s' not found", argv[1]);
  if ((err = key_setcomment(&f, k, argv[2])) != 0)
    die(EXIT_FAILURE, "bad comment `%s': %s", argv[2], key_strerror(err));
  doclose(&f);
  return (0);
}

/* --- @cmd_tag@ --- */

static int cmd_tag(int argc, char *argv[])
{
  key_file f;
  key *k;
  int err;
  unsigned flags = 0;
  int rc = 0;

  for (;;) {
    static struct option opt[] = {
      { "retag",	0,		0,	'r' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+r", opt, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case 'r':
	flags |= f_retag;
	break;
      default:
	rc = 1;
	break;
    }
  }

  argv += optind; argc -= optind;
  if (argc < 1 || argc > 2 || rc)
    die(EXIT_FAILURE, "Usage: tag [-r] TAG [NEW-TAG]");
  doopen(&f, KOPEN_WRITE);
  if (flags & f_retag) {
    if ((k = key_bytag(&f, argv[1])) != 0 && strcmp(k->tag, argv[1]) == 0)
      key_settag(&f, k, 0);
  }
  if ((k = key_bytag(&f, argv[0])) == 0)
    die(EXIT_FAILURE, "key `%s' not found", argv[0]);
  if ((err = key_settag(&f, k, argv[1])) != 0)
    die(EXIT_FAILURE, "bad tag `%s': %s", argv[1], key_strerror(err));
  doclose(&f);
  return (0);
}

/* --- @cmd_lock@ --- */

static int cmd_lock(int argc, char *argv[])
{
  key_file f;
  key *k;
  key_data **kd;
  dstr d = DSTR_INIT;

  if (argc != 2)
    die(EXIT_FAILURE, "Usage: lock QTAG");
  doopen(&f, KOPEN_WRITE);
  if (key_qtag(&f, argv[1], &d, &k, &kd))
    die(EXIT_FAILURE, "key `%s' not found", argv[1]);
  if ((*kd)->e == KENC_ENCRYPT && key_punlock(kd, 0, d.buf))
    die(EXIT_FAILURE, "couldn't unlock key `%s'", d.buf);
  if (key_plock(kd, 0, d.buf))
    die(EXIT_FAILURE, "failed to lock key `%s'", d.buf);
  f.f |= KF_MODIFIED;
  doclose(&f);
  return (0);
}

/* --- @cmd_unlock@ --- */

static int cmd_unlock(int argc, char *argv[])
{
  key_file f;
  key *k;
  key_data **kd;
  dstr d = DSTR_INIT;

  if (argc != 2)
    die(EXIT_FAILURE, "Usage: unlock QTAG");
  doopen(&f, KOPEN_WRITE);
  if (key_qtag(&f, argv[1], &d, &k, &kd))
    die(EXIT_FAILURE, "key `%s' not found", argv[1]);
  if ((*kd)->e != KENC_ENCRYPT)
    die(EXIT_FAILURE, "key `%s' is not encrypted", d.buf);
  if (key_punlock(kd, 0, d.buf))
    die(EXIT_FAILURE, "couldn't unlock key `%s'", d.buf);
  f.f |= KF_MODIFIED;
  doclose(&f);
  return (0);
}

/* --- @cmd_extract@ --- */

static int cmd_extract(int argc, char *argv[])
{
  key_file f;
  key *k;
  int i;
  int rc = 0;
  key_filter kf = { 0, 0 };
  dstr d = DSTR_INIT;
  const char *outfile = 0;
  FILE *fp;

  for (;;) {
    static struct option opt[] = {
      { "filter",	OPTF_ARGREQ,	0,	'f' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "f:", opt, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case 'f': {
	char *p;
	int err = key_readflags(optarg, &p, &kf.f, &kf.m);
	if (err || *p)
	  die(EXIT_FAILURE, "bad filter string `%s'", optarg);
      } break;
      default:
	rc = 1;
	break;
    }
  }

  argv += optind; argc -= optind;
  if (rc || argc < 1)
    die(EXIT_FAILURE, "Usage: extract [-f FILTER] FILE [TAG...]");
  if (strcmp(*argv, "-") == 0)
    fp = stdout;
  else {
    outfile = *argv;
    dstr_putf(&d, "%s.new", outfile);
    if (!(fp = fopen(d.buf, "w"))) {
      die(EXIT_FAILURE, "couldn't open `%s' for writing: %s",
	  d.buf, strerror(errno));
    }
  }

  doopen(&f, KOPEN_READ);
  if (argc < 2) {
    key_iter i;
    key *k;
    for (key_mkiter(&i, &f); (k = key_next(&i)) != 0; )
      key_extract(&f, k, fp, &kf);
  } else {
    for (i = 1; i < argc; i++) {
      if ((k = key_bytag(&f, argv[i])) != 0)
	key_extract(&f, k, fp, &kf);
      else {
	moan("key `%s' not found", argv[i]);
	rc = 1;
      }
    }
  }
  if (fclose(fp) || (outfile && rename(d.buf, outfile)))
    die(EXIT_FAILURE, "error writing file: %s", strerror(errno));
  dstr_destroy(&d);
  doclose(&f);
  return (rc);
}

/* --- @cmd_tidy@ --- */

static int cmd_tidy(int argc, char *argv[])
{
  key_file f;
  if (argc != 1)
    die(EXIT_FAILURE, "Usage: tidy");
  doopen(&f, KOPEN_WRITE);
  f.f |= KF_MODIFIED; /* Nasty hack */
  doclose(&f);
  return (0);
}

/* --- @cmd_merge@ --- */

static int cmd_merge(int argc, char *argv[])
{
  key_file f;
  FILE *fp;

  if (argc != 2)
    die(EXIT_FAILURE, "Usage: merge FILE");
  if (strcmp(argv[1], "-") == 0)
    fp = stdin;
  else if (!(fp = fopen(argv[1], "r"))) {
    die(EXIT_FAILURE, "couldn't open `%s' for reading: %s",
	argv[1], strerror(errno));
  }

  doopen(&f, KOPEN_WRITE);
  key_merge(&f, argv[1], fp, key_moan, 0);
  doclose(&f);
  return (0);
}

/* --- @cmd_show@ --- */

#define LISTS(LI)							\
  LI("Lists", list,							\
     listtab[i].name, listtab[i].name)					\
  LI("Hash functions", hash,						\
     ghashtab[i], ghashtab[i]->name)					\
  LI("Elliptic curves", ec,						\
     ectab[i].name, ectab[i].name)					\
  LI("Prime Diffie-Hellman groups", dh,					\
     ptab[i].name, ptab[i].name)					\
  LI("Binary Diffie-Hellman groups", bindh,				\
     bintab[i].name, bintab[i].name)					\
  LI("Key-generation algorithms", keygen,				\
     algtab[i].name, algtab[i].name)					\
  LI("Random seeding algorithms", seed,					\
     seedtab[i].p, seedtab[i].p)					\
  LI("Fingerprint presentation styles", fpres,				\
     fprestab[i].name, fprestab[i].name)

MAKELISTTAB(listtab, LISTS)

static int cmd_show(int argc, char *argv[])
{
  return (displaylists(listtab, argv + 1));
}

/*----- Main command table ------------------------------------------------*/

static int cmd_help(int argc, char *argv[]);

static cmd cmds[] = {
  { "help", cmd_help, "help [COMMAND...]" },
  { "show", cmd_show, "show [ITEM...]" },
  { "list", cmd_list, "list [-uqv] [-f FILTER] [TAG...]", "\
Options:\n\
\n\
-u, --utc		Display expiry times etc. in UTC, not local time.\n\
-q, --quiet		Show less information.\n\
-v, --verbose		Show more information.\n\
" },
  { "fingerprint", cmd_finger,
    "fingerprint [-a HASHALG] [-p STYLE] [-f FILTER] [TAG...]", "\
Options:\n\
\n\
-f, --filter=FILT	Only hash key components matching FILT.\n\
-p, --presentation=STYLE Use STYLE for presenting fingerprints.\n\
-a, --algorithm=HASH	Use the named HASH algorithm.\n\
			  ($ show hash for list.)\n\
" },
  { "verify", cmd_verify,
    "verify [-a HASH] [-p STYLE] [-f FILTER] TAG FINGERPRINT", "\
Options:\n\
\n\
-f, --filter=FILT	Only hash key components matching FILT.\n\
-p, --presentation=STYLE Expect FINGERPRINT in the given STYLE.\n\
-a, --algorithm=HASH	Use the named HASH algorithm.\n\
			  ($ show hash for list.)\n\
" },
  { "extract", cmd_extract, "extract [-f FILTER] FILE [TAG...]", "\
Options:\n\
\n\
-f, --filter=FILT	Only extract key components matching FILT.\n\
" },
  { "merge", cmd_merge, "merge FILE" },
  { "expire", cmd_expire, "expire TAG..." },
  { "delete", cmd_delete, "delete TAG..." },
  { "setattr", cmd_setattr, "setattr TAG ATTR..." },
  { "getattr", cmd_getattr, "getattr TAG ATTR" },
  { "comment", cmd_comment, "comment TAG [COMMENT]" },
  { "lock", cmd_lock, "lock QTAG" },
  { "unlock", cmd_unlock, "unlock QTAG" },
  { "tag", cmd_tag, "tag [-r] TAG [NEW-TAG]", "\
Options:\n\
\n\
-r, --retag		Untag any key currently called new-tag.\n\
" },
  { "tidy", cmd_tidy, "tidy" },
  { "add", cmd_add,
    "add [-OPTIONS] TYPE [ATTR...]\n\
	Options: [-lqrLKS] [-a ALG] [-bB BITS] [-p PARAM] [-R TAG]\n\
		 [-A SEEDALG] [-s SEED] [-n BITS] [-I KEYID]\n\
		 [-e EXPIRE] [-t TAG] [-c COMMENT]", "\
Options:\n\
\n\
-a, --algorithm=ALG	Generate keys suitable for ALG.\n\
			  ($ show keygen for list.)\n\
-b, --bits=N		Generate an N-bit key.\n\
-B, --qbits=N		Use an N-bit subgroup or factors.\n\
-p, --parameters=TAG	Get group parameters from TAG.\n\
-C, --curve=NAME	Use elliptic curve or DH group NAME.\n\
			  ($ show ec or $ show dh for list.)\n\
-A, --seedalg=ALG	Use pseudorandom generator ALG to generate key.\n\
			  ($ show seed for list.)\n\
-s, --seed=BASE64	Use Base64-encoded string BASE64 as seed.\n\
-n, --newseed=COUNT	Generate new COUNT-bit seed.\n\
-e, --expire=TIME	Make the key expire after TIME.\n\
-c, --comment=STRING	Attach the command STRING to the key.\n\
-t, --tag=TAG		Tag the key with the name TAG.\n\
-r, --retag		Untag any key currently with that tag.\n\
-R, --rand-id=TAG	Use key named TAG for the random number generator.\n\
-I, --key-id=ID		Force the key-id for the new key.\n\
-l, --lock		Lock the generated key with a passphrase.\n\
-q, --quiet		Don't give progress indicators while working.\n\
-L, --lim-lee		Generate Lim-Lee primes for Diffie-Hellman groups.\n\
-K, --kcdsa		Generate KCDSA-style Lim-Lee primes for DH groups.\n\
-S, --subgroup		Use a prime-order subgroup for Diffie-Hellman.\n\
" },
  { 0, 0, 0 }
};

static int cmd_help(int argc, char *argv[])
{
  sc_help(cmds, stdout, argv + 1);
  return (0);
}

/*----- Main code ---------------------------------------------------------*/

/* --- Helpful GNUy functions --- */

static void usage(FILE *fp)
{
  pquis(fp, "Usage: $ [-k KEYRING] COMMAND [ARGS]\n");
}

void version(FILE *fp)
{
  pquis(fp, "$, Catacomb version " VERSION "\n");
}

void help_global(FILE *fp)
{
  usage(fp);
  fputs("\n\
Performs various simple key management operations.\n\
\n\
Global command line options:\n\
\n\
-h, --help [COMMAND...]	Display this help text (or help for COMMANDs).\n\
-v, --version		Display version number.\n\
-u, --usage		Display short usage summary.\n\
\n\
-k, --keyring=FILE	Read and write keys in FILE.\n",
	fp);
}

/* --- @main@ --- *
 *
 * Arguments:	@int argc@ = number of command line arguments
 *		@char *argv[]@ = array of command line arguments
 *
 * Returns:	Nonzero on failure.
 *
 * Use:		Main program.  Performs simple key management functions.
 */

int main(int argc, char *argv[])
{
  unsigned f = 0;

#define f_bogus 1u

  /* --- Initialization --- */

  ego(argv[0]);
  sub_init();

  /* --- Parse command line options --- */

  for (;;) {
    static struct option opt[] = {

      /* --- Standard GNUy help options --- */

      { "help",		0,		0,	'h' },
      { "version",	0,		0,	'v' },
      { "usage",	0,		0,	'u' },

      /* --- Real live useful options --- */

      { "keyring",	OPTF_ARGREQ,	0,	'k' },

      /* --- Magic terminator --- */

      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+hvu k:", opt, 0, 0, 0);

    if (i < 0)
      break;
    switch (i) {

      /* --- GNU help options --- */

      case 'h':
	sc_help(cmds, stdout, argv + optind);
	exit(0);
      case 'v':
	version(stdout);
	exit(0);
      case 'u':
	usage(stdout);
	exit(0);

      /* --- Real useful options --- */

      case 'k':
	keyfile = optarg;
	break;

      /* --- Bogosity --- */

      default:
	f |= f_bogus;
	break;
    }
  }

  /* --- Complain about excessive bogons --- */

  if (f & f_bogus || optind == argc) {
    usage(stderr);
    exit(1);
  }

  /* --- Initialize the Catacomb random number generator --- */

  rand_noisesrc(RAND_GLOBAL, &noise_source);
  rand_seed(RAND_GLOBAL, 160);

  /* --- Dispatch to appropriate command handler --- */

  argc -= optind;
  argv += optind;
  optind = 0;
  return (findcmd(cmds, argv[0])->cmd(argc, argv));
}

/*----- That's all, folks -------------------------------------------------*/
