/* -*-c-*-
 *
 * Example Fibonacci number computation
 *
 * (c) 2013 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "config.h"

#include <ctype.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

#include <mLib/mdwopt.h>
#include <mLib/quis.h>
#include <mLib/report.h>

#include "mpint.h"
#include "mptext.h"

#include "mp-fibonacci.h"

/*----- Main code ---------------------------------------------------------*/

static void usage(FILE *fp)
  { pquis(fp, "Usage: $ [-r RADIX] INTEGER\n"); }

static void version(FILE *fp)
  { pquis(fp, "$, Catacomb version " VERSION "\n"); }

static void help(FILE *fp)
{
  version(fp);
  putc('\n', fp);
  usage(fp);
  fputs("\n\
Prints the Nth Fibonacci number for a given inteer N.  Input may be in\n\
decimal (the default), octal with preceding zero, hex with preceding `0x',\n\
or any base N between 2 and 62 inclusive with preceding `N_'.  Output\n\
may be in any base between 2 and 62; the default is base 10.  For bases\n\
between 11 and 36 inclusive, lowercase letters of either case are used as\n\
additional digits with values 10 upwards; lowercase is always used for\n\
output.  For bases between 37 and 62 inclusive, lowercase letters have\n\
lower value than uppercase; hence `a' has the value 10, while `A' has the\n\
value 36.\n\
\n\
Options provided:\n\
\n\
-h, --help		Display this help message.\n\
-v, --version		Display the version number.\n\
-u, --usage		Display a usage message.\n\
\n\
-r, --radix=N		Write output in base N.\n\
", fp);
}

int main(int argc, char *argv[])
{
  long n;
  int r = 10;
  char *p;
  mp *f, *lmin, *lmax, *nn;
  unsigned fl = 0;

#define f_bogus 1u

  ego(argv[0]);

  for (;;) {
    static const struct option opt[] = {
      { "help",		0,		0,	'h' },
      { "version",	0,		0,	'v' },
      { "usage",	0,		0,	'u' },
      { "radix",	OPTF_ARGREQ,	0,	'r' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "hvur:", opt, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case 'h':
	help(stdout);
	exit(0);
      case 'v':
	version(stdout);
	exit(0);
      case 'u':
	usage(stdout);
	exit(0);
      case 'r':
	r = atoi(optarg);
	if (r < 2 || r > 62)
	  die(EXIT_FAILURE, "bad radix `%s'", optarg);
	break;
      default:
	fl |= f_bogus;
	break;
    }
  }

  if (optind + 1 != argc || (fl & f_bogus)) {
    usage(stderr);
    exit(EXIT_FAILURE);
  }
  lmin = mp_fromlong(MP_NEW, LONG_MIN);
  lmax = mp_fromlong(MP_NEW, LONG_MAX);
  p = argv[optind];
  while (isspace((unsigned char)*p)) p++;
  nn = mp_readstring(MP_NEW, argv[optind], &p, 0);
  while (isspace((unsigned char)*p)) p++;
  if (!nn || *p || MP_CMP(lmin, >, nn) || MP_CMP(nn, >, lmax))
    die(EXIT_FAILURE, "bad integer `%s'", argv[optind]);
  n = mp_tolong(nn);
  mp_drop(nn); mp_drop(lmin); mp_drop(lmax);
  f = mp_fibonacci(n);
  mp_writefile(f, stdout, r);
  fputc('\n', stdout);
  mp_drop(f);
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
