/* -*-c-*-
 *
 * Verify signatures on distribuitions of files
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#define _FILE_OFFSET_BITS 64

#include "config.h"

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/alloc.h>
#include <mLib/base64.h>
#include <mLib/mdwopt.h>
#include <mLib/quis.h>
#include <mLib/report.h>
#include <mLib/sub.h>

#include "getdate.h"
#include "rand.h"
#include "ghash.h"
#include "key.h"
#include "key-data.h"
#include "noise.h"
#include "cc.h"

/*----- Data formatting ---------------------------------------------------*/

/* --- Binary data structure --- *
 *
 * The binary format, which is used for hashing and for the optional binary
 * output, consists of a sequence of tagged blocks.  The tag describes the
 * format and meaining of the following data.
 */

enum {
  /* --- Block tags --- */

  T_IDENT = 0,				/* An identifying marker */
  T_KEYID,				/* Key identifier */
  T_BEGIN,				/* Begin hashing here */
  T_COMMENT = T_BEGIN,			/* A textual comment */
  T_DATE,				/* Creation date of signature */
  T_EXPIRE,				/* Expiry date of signature */
  T_FILE,				/* File and corresponding hash */
  T_SIGNATURE,				/* Final signature block */

  /* --- Error messages --- */

  E_EOF = -1,
  E_BIN = -2,
  E_TAG = -3,
  E_DATE = -4
};

/* --- Name translation table --- */

static const char *tagtab[] = {
  "ident:", "keyid:",
  "comment:", "date:", "expires:", "file:",
  "signature:",
  0
};

static const char *errtab[] = {
  "Off-by-one bug",
  "Unexpected end-of-file",
  "Binary object too large",
  "Unrecognized tag",
  "Bad date string"
};

/* --- Memory representation of block types --- */

typedef struct block {
  int tag;				/* Type tag */
  dstr d;				/* String data */
  dstr b;				/* Binary data */
  time_t t;				/* Timestamp */
  uint32 k;				/* Keyid */
} block;

/* --- @timestring@ --- *
 *
 * Arguments:	@time_t t@ = a timestamp
 *		@dstr *d@ = a string to write on
 *
 * Returns:	---
 *
 * Use:		Writes a textual representation of the timestamp to the
 *		string.
 */

static void timestring(time_t t, dstr *d)
{
  if (t == KEXP_FOREVER)
    DPUTS(d, "forever");
  else {
    struct tm *tm = localtime(&t);
    DENSURE(d, 32);
    d->len += strftime(d->buf + d->len, 32, "%Y-%m-%d %H:%M:%S %Z", tm);
    DPUTZ(d);
  }
}

/* --- @breset@ --- *
 *
 * Arguments:	@block *b@ = block to reset
 *
 * Returns:	---
 *
 * Use:		Resets a block so that more stuff can be put in it.
 */

static void breset(block *b)
{
  b->tag = 0;
  DRESET(&b->d);
  DRESET(&b->b);
  b->k = 0;
  b->t = KEXP_EXPIRE;
}

/* --- @binit@ --- *
 *
 * Arguments:	@block *b@ = block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a block as something to read into.
 */

static void binit(block *b)
{
  dstr_create(&b->d);
  dstr_create(&b->b);
  breset(b);
}

/* --- @bdestroy@ --- *
 *
 * Arguments:	@block *b@ = block to destroy
 *
 * Returns:	---
 *
 * Use:		Destroys a block's contents.
 */

static void bdestroy(block *b)
{
  dstr_destroy(&b->d);
  dstr_destroy(&b->b);
}

/* --- @bget@ --- *
 *
 * Arguments:	@block *b@ = pointer to block
 *		@FILE *fp@ = stream to read from
 *		@unsigned bin@ = binary switch
 *
 * Returns:	Tag of block, or an error tag.
 *
 * Use:		Reads a block from a stream.
 */

static int bget(block *b, FILE *fp, unsigned bin)
{
  int tag;

  /* --- Read the tag --- */

  if (bin)
    tag = getc(fp);
  else {
    dstr d = DSTR_INIT;
    if (getstring(fp, &d, GSF_FILE))
      return (E_EOF);
    for (tag = 0; tagtab[tag]; tag++) {
      if (strcmp(tagtab[tag], d.buf) == 0)
	goto done;
    }
    return (E_TAG);
  done:;
  }

  /* --- Decide what to do next --- */

  breset(b);
  b->tag = tag;
  switch (tag) {

    /* --- Reading of strings --- */

    case T_IDENT:
    case T_COMMENT:
      if (getstring(fp, &b->d, GSF_FILE | (bin ? GSF_RAW : 0)))
	return (E_EOF);
      break;

    /* --- Timestamps --- */

    case T_DATE:
    case T_EXPIRE:
      if (bin) {
	octet buf[8];
	if (fread(buf, sizeof(buf), 1, fp) < 1)
	  return (E_EOF);
	b->t = ((time_t)(((LOAD32(buf + 0) << 16) << 16) & ~MASK32) |
		(time_t)LOAD32(buf + 4));
      } else {
	if (getstring(fp, &b->d, GSF_FILE))
	  return (E_EOF);
	if (strcmp(b->d.buf, "forever") == 0)
	  b->t = KEXP_FOREVER;
	else if ((b->t = get_date(b->d.buf, 0)) == -1)
	  return (E_DATE);
      }
      break;

    /* --- Key ids --- */

    case T_KEYID:
      if (bin) {
	octet buf[4];
	if (fread(buf, sizeof(buf), 1, fp) < 1)
	  return (E_EOF);
	b->k = LOAD32(buf);
      } else {
	if (getstring(fp, &b->d, GSF_FILE))
	  return (E_EOF);
	b->k = strtoul(b->d.buf, 0, 16);
      }
      break;

    /* --- Reading of binary data --- */

    case T_FILE:
    case T_SIGNATURE:
      if (bin) {
	octet buf[2];
	uint32 sz;
	if (fread(buf, sizeof(buf), 1, fp) < 1)
	  return (E_EOF);
	sz = LOAD16(buf);
	if (sz > 4096)
	  return (E_BIN);
	DENSURE(&b->b, sz);
	if (fread(b->b.buf + b->b.len, 1, sz, fp) < sz)
	  return (E_EOF);
	b->b.len += sz;
      } else {
	base64_ctx b64;
	if (getstring(fp, &b->d, GSF_FILE))
	  return (E_EOF);
	base64_init(&b64);
	base64_decode(&b64, b->d.buf, b->d.len, &b->b);
	base64_decode(&b64, 0, 0, &b->b);
	DRESET(&b->d);
      }
      if (tag == T_FILE &&
	  getstring(fp, &b->d, GSF_FILE | (bin ? GSF_RAW : 0)))
	return (E_EOF);
      break;

      /* --- Anything else --- */

    default:
      return (E_TAG);
  }

  return (tag);
}

/* --- @blob@ --- *
 *
 * Arguments:	@block *b@ = pointer to block to emit
 *		@dstr *d@ = output buffer
 *
 * Returns:	---
 *
 * Use:		Encodes a block in a binary format.
 */

static void blob(block *b, dstr *d)
{
  DPUTC(d, b->tag);
  switch (b->tag) {
    case T_IDENT:
    case T_COMMENT:
      DPUTD(d, &b->d);
      DPUTC(d, 0);
      break;
    case T_DATE:
    case T_EXPIRE:
      DENSURE(d, 8);
      if (b->t == KEXP_FOREVER) {
	STORE32(d->buf + d->len, 0xffffffff);
	STORE32(d->buf + d->len + 4, 0xffffffff);
      } else {
	STORE32(d->buf + d->len, ((b->t & ~MASK32) >> 16) >> 16);
	STORE32(d->buf + d->len + 4, b->t);
      }
      d->len += 8;
      break;
    case T_KEYID:
      DENSURE(d, 4);
      STORE32(d->buf + d->len, b->k);
      d->len += 4;
      break;
    case T_FILE:
    case T_SIGNATURE:
      DENSURE(d, 2);
      STORE16(d->buf + d->len, b->b.len);
      d->len += 2;
      DPUTD(d, &b->b);
      if (b->tag == T_FILE) {
	DPUTD(d, &b->d);
	DPUTC(d, 0);
      }
      break;
  }
}

/* --- @bwrite@ --- *
 *
 * Arguments:	@block *b@ = pointer to block to write
 *		@FILE *fp@ = stream to write on
 *
 * Returns:	---
 *
 * Use:		Writes a block on a stream in a textual format.
 */

static void bwrite(block *b, FILE *fp)
{
  fputs(tagtab[b->tag], fp);
  putc(' ', fp);
  switch (b->tag) {
    case T_IDENT:
    case T_COMMENT:
      putstring(fp, b->d.buf, 0);
      break;
    case T_DATE:
    case T_EXPIRE: {
      dstr d = DSTR_INIT;
      timestring(b->t, &d);
      putstring(fp, d.buf, 0);
      dstr_destroy(&d);
    } break;
    case T_KEYID:
      fprintf(fp, "%08lx", (unsigned long)b->k);
      break;
    case T_FILE:
    case T_SIGNATURE: {
      dstr d = DSTR_INIT;
      base64_ctx b64;
      base64_init(&b64);
      b64.maxline = 0;
      base64_encode(&b64, b->b.buf, b->b.len, &d);
      base64_encode(&b64, 0, 0, &d);
      dstr_write(&d, fp);
      if (b->tag == T_FILE) {
	putc(' ', fp);
	putstring(fp, b->d.buf, 0);
      }
    } break;
  }
  putc('\n', fp);
}

/* --- @bemit@ --- *
 *
 * Arguments:	@block *b@ = pointer to block to write
 *		@FILE *fp@ = file to write on
 *		@ghash *h@ = pointer to hash function
 *		@unsigned bin@ = binary/text flag
 *
 * Returns:	---
 *
 * Use:		Spits out a block properly.
 */

static void bemit(block *b, FILE *fp, ghash *h, unsigned bin)
{
  if (h || (fp && bin)) {
    dstr d = DSTR_INIT;
    blob(b, &d);
    if (h)
      GH_HASH(h, d.buf, d.len);
    if (fp && bin)
      fwrite(d.buf, d.len, 1, fp);
  }
  if (fp && !bin)
    bwrite(b, fp);
}

/*----- Static variables --------------------------------------------------*/

static const char *keyring = "keyring";

/*----- Other shared functions --------------------------------------------*/

/* --- @fhex@ --- *
 *
 * Arguments:	@FILE *fp@ = file to write on
 *		@const void *p@ = pointer to data to be written
 *		@size_t sz@ = size of the data to write
 *
 * Returns:	---
 *
 * Use:		Emits a hex dump to a stream.
 */

static void fhex(FILE *fp, const void *p, size_t sz)
{
  const octet *q = p;
  if (!sz)
    return;
  for (;;) {
    fprintf(fp, "%02x", *q++);
    sz--;
    if (!sz)
      break;
  }
}

/*----- Signature generation ----------------------------------------------*/

static int sign(int argc, char *argv[])
{
#define f_bogus 1u
#define f_bin 2u
#define f_nocheck 4u

  unsigned f = 0;
  const char *ki = "dsig";
  key_file kf;
  key *k;
  sig *s;
  fhashstate fh;
  time_t exp = KEXP_EXPIRE;
  unsigned verb = 0;
  const char *ifile = 0, *hfile = 0;
  const char *ofile = 0;
  const char *c = 0;
  const char *err;
  FILE *ifp, *ofp;
  dstr d = DSTR_INIT;
  hfpctx hfp;
  block b;
  int e, hf, n;

  for (;;) {
    static struct option opts[] = {
      { "null",		0,		0,	'0' },
      { "binary",	0,		0,	'b' },
      { "verbose",	0,		0,	'v' },
      { "progress",	0,		0,	'p' },
      { "quiet",	0,		0,	'q' },
      { "comment",	OPTF_ARGREQ,	0,	'c' },
      { "file",		OPTF_ARGREQ,	0,	'f' },
      { "hashes",	OPTF_ARGREQ,	0,	'h' },
      { "output",	OPTF_ARGREQ,	0,	'o' },
      { "key",		OPTF_ARGREQ,	0,	'k' },
      { "expire",	OPTF_ARGREQ,	0,	'e' },
      { "nocheck",	OPTF_ARGREQ,	0,	'C' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+0vpqbC" "c:" "f:h:o:" "k:e:",
		   opts, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case '0':
	f |= GSF_RAW;
	break;
      case 'b':
	f |= f_bin;
	break;
      case 'v':
	verb++;
	break;
      case 'p':
	f |= FHF_PROGRESS;
	break;
      case 'q':
	if (verb > 0)
	  verb--;
	break;
      case 'C':
	f |= f_nocheck;
	break;
      case 'c':
	c = optarg;
	break;
      case 'f':
	ifile = optarg;
	break;
      case 'h':
	hfile = optarg;
	break;
      case 'o':
	ofile = optarg;
	break;
      case 'k':
	ki = optarg;
	break;
      case 'e':
	if (strcmp(optarg, "forever") == 0)
	  exp = KEXP_FOREVER;
	else if ((exp = get_date(optarg, 0)) == -1)
	  die(EXIT_FAILURE, "bad expiry time");
	break;
      default:
	f |= f_bogus;
	break;
    }
  }
  if (optind != argc || (f & f_bogus))
    die(EXIT_FAILURE, "Usage: sign [-OPTIONS]");
  if (hfile && ifile)
    die(EXIT_FAILURE, "Inconsistent options `-h' and `-f'");

  /* --- Locate the signing key --- */

  if (key_open(&kf, keyring, KOPEN_WRITE, key_moan, 0))
    die(EXIT_FAILURE, "couldn't open keyring `%s'", keyring);
  if ((k = key_bytag(&kf, ki)) == 0)
    die(EXIT_FAILURE, "couldn't find key `%s'", ki);
  key_fulltag(k, &d);
  if (exp == KEXP_FOREVER && k->exp != KEXP_FOREVER) {
    die(EXIT_FAILURE, "key `%s' expires: can't create nonexpiring signature",
	d.buf);
  }
  s = getsig(k, "dsig", 1);

  /* --- Check the key --- */

  if (!(f & f_nocheck) && (err = s->ops->check(s)) != 0)
    moan("key `%s' fails check: %s", d.buf, err);

  /* --- Open files --- */

  if (hfile) ifile = hfile;
  if (!ifile || strcmp(ifile, "-") == 0)
    ifp = stdin;
  else if ((ifp = fopen(ifile, (f & f_bin) ? "rb" : "r")) == 0) {
    die(EXIT_FAILURE, "couldn't open input file `%s': %s",
	ifile, strerror(errno));
  }

  if (!ofile || strcmp(ofile, "-") == 0)
    ofp = stdout;
  else if ((ofp = fopen(ofile, (f & f_bin) ? "wb" : "w")) == 0) {
    die(EXIT_FAILURE, "couldn't open output file `%s': %s",
	ofile, strerror(errno));
  }

  /* --- Emit the start of the output --- */

  binit(&b); b.tag = T_IDENT;
  dstr_putf(&b.d, "%s, Catacomb version " VERSION, QUIS);
  bemit(&b, ofp, 0, f & f_bin);

  breset(&b); b.tag = T_KEYID; b.k = k->id;
  bemit(&b, ofp, 0, f & f_bin);

  /* --- Start hashing, and emit the datestamps and things --- */

  {
    time_t now = time(0);

    breset(&b); b.tag = T_DATE; b.t = now; bemit(&b, ofp, s->h, f & f_bin);
    if (exp == KEXP_EXPIRE)
      exp = now + 86400 * 28;
    breset(&b); b.tag = T_EXPIRE; b.t = exp; bemit(&b, ofp, s->h, f & f_bin);
    if (c) {
      breset(&b); b.tag = T_COMMENT; DPUTS(&b.d, c);
      bemit(&b, ofp, s->h, f & f_bin);
    }

    if (!(f & f_bin))
      putc('\n', ofp);
  }

  /* --- Now hash the various files --- */

  if (hfile) {
    hfp.f = f;
    hfp.fp = ifp;
    hfp.ee = &encodingtab[ENC_HEX];
    hfp.gch = GH_CLASS(s->h);
    hfp.dline = &d;
    hfp.dfile = &b.d;

    n = 0;
    for (;;) {
      breset(&b);
      DENSURE(&b.b, hfp.gch->hashsz);
      hfp.hbuf = (octet *)b.b.buf;
      if (ferror(ofp)) { f |= f_bogus; break; }
      if ((hf = hfparse(&hfp)) == HF_EOF) break;
      n++;

      switch (hf) {
	case HF_HASH:
	  if (hfp.gch != GH_CLASS(s->h)) {
	    moan("%s:%d: incorrect hash function `%s' (should be `%s')",
		 hfile, n, hfp.gch->name, GH_CLASS(s->h)->name);
	    f |= f_bogus;
	  }
	  break;
	case HF_BAD:
	  moan("%s:%d: invalid hash-file line", hfile, n);
	  f |= f_bogus;
	  break;
	case HF_FILE:
	  b.tag = T_FILE;
	  b.b.len += hfp.gch->hashsz;
	  bemit(&b, ofp, s->h, f & f_bin);
	  break;
      }
    }
  } else {
    for (;;) {

      /* --- Stop on an output error --- */

      if (ferror(ofp)) {
	f |= f_bogus;
	break;
      }

      /* --- Read the next filename to hash --- */

      fhash_init(&fh, GH_CLASS(s->h), f | FHF_BINARY);
      breset(&b);
      if (getstring(ifp, &b.d, GSF_FILE | f))
	break;
      b.tag = T_FILE;
      DENSURE(&b.b, GH_CLASS(s->h)->hashsz);
      if (fhash(&fh, b.d.buf, b.b.buf)) {
	moan("error reading `%s': %s", b.d.buf, strerror(errno));
	f |= f_bogus;
      } else {
	b.b.len += GH_CLASS(s->h)->hashsz;
	if (verb) {
	  fhex(stderr, b.b.buf, b.b.len);
	  fprintf(stderr, " %s\n", b.d.buf);
	}
	bemit(&b, ofp, s->h, f & f_bin);
      }
      fhash_free(&fh);
    }
  }

  /* --- Create the signature --- */

  if (!(f & f_bogus)) {
    breset(&b);
    b.tag = T_SIGNATURE;
    if ((e = s->ops->doit(s, &b.b)) != 0) {
      moan("error creating signature: %s", key_strerror(e));
      f |= f_bogus;
    }
    if (!(f & f_bogus)) {
      bemit(&b, ofp, 0, f & f_bin);
      key_used(&kf, k, exp);
    }
  }

  /* --- Tidy up at the end --- */

  freesig(s);
  bdestroy(&b);
  if (ifile)
    fclose(ifp);
  if (ofile) {
    if (fclose(ofp))
      f |= f_bogus;
  } else {
    if (fflush(ofp))
      f |= f_bogus;
  }
  if ((e = key_close(&kf)) != 0) {
    switch (e) {
      case KWRITE_FAIL:
	die(EXIT_FAILURE, "couldn't write file `%s': %s",
	    keyring, strerror(errno));
      case KWRITE_BROKEN:
	die(EXIT_FAILURE, "keyring file `%s' broken: %s (repair manually)",
	    keyring, strerror(errno));
    }
  }
  if (f & f_bogus)
    die(EXIT_FAILURE, "error(s) occurred while creating signature");
  return (EXIT_SUCCESS);

#undef f_bin
#undef f_bogus
#undef f_nocheck
}

/*----- Signature verification --------------------------------------------*/

static int checkjunk(const char *path, const struct stat *st, void *p)
{
  if (!st) printf("JUNK (error %s) %s\n", strerror(errno), path);
  else printf("JUNK %s %s\n", describefile(st), path);
  return (0);
}

static int verify(int argc, char *argv[])
{
#define f_bogus 1u
#define f_bin 2u
#define f_ok 4u
#define f_nocheck 8u

  unsigned f = 0;
  unsigned verb = 1;
  key_file kf;
  key *k = 0;
  sig *s;
  dstr d = DSTR_INIT;
  const char *err;
  fhashstate fh;
  FILE *fp;
  block b;
  int e;

  /* --- Parse the options --- */

  for (;;) {
    static struct option opts[] = {
      { "verbose",	0,		0,	'v' },
      { "progress",	0,		0,	'p' },
      { "quiet",	0,		0,	'q' },
      { "nocheck",	0,		0,	'C' },
      { "junk",		0,		0,	'j' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+vpqCj", opts, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case 'v':
	verb++;
	break;
      case 'p':
	f |= FHF_PROGRESS;
	break;
      case 'q':
	if (verb)
	  verb--;
	break;
      case 'C':
	f |= f_nocheck;
	break;
      case 'j':
	f |= FHF_JUNK;
	break;
      default:
	f |= f_bogus;
	break;
    }
  }
  argc -= optind;
  argv += optind;
  if ((f & f_bogus) || argc > 1)
    die(EXIT_FAILURE, "Usage: verify [-qvC] [FILE]");

  /* --- Open the key file, and start reading the input file --- */

  if (key_open(&kf, keyring, KOPEN_READ, key_moan, 0))
    die(EXIT_FAILURE, "couldn't open keyring `%s'\n", keyring);
  if (argc < 1)
    fp = stdin;
  else {
    if ((fp = fopen(argv[0], "rb")) == 0) {
      die(EXIT_FAILURE, "couldn't open file `%s': %s\n",
	      argv[0], strerror(errno));
    }
    if (getc(fp) == 0) {
      ungetc(0, fp);
      f |= f_bin;
    } else {
      fclose(fp);
      if ((fp = fopen(argv[0], "r")) == 0) {
	die(EXIT_FAILURE, "couldn't open file `%s': %s\n",
		argv[0], strerror(errno));
      }
    }
  }

  /* --- Read the introductory matter --- */

  binit(&b);
  for (;;) {
    breset(&b);
    e = bget(&b, fp, f & f_bin);
    if (e < 0)
      die(EXIT_FAILURE, "error reading packet: %s", errtab[-e]);
    if (e >= T_BEGIN)
      break;
    switch (e) {
      case T_IDENT:
	if (verb > 2)
	  printf("INFO ident: `%s'\n", b.d.buf);
	break;
      case T_KEYID:
	if ((k = key_byid(&kf, b.k)) == 0) {
	  if (verb)
	    printf("FAIL key %08lx not found\n", (unsigned long)b.k);
	  exit(EXIT_FAILURE);
	}
	if (verb > 2) {
	  DRESET(&b.d);
	  key_fulltag(k, &b.d);
	  printf("INFO key: %s\n", b.d.buf);
	}
	break;
      default:
	die(EXIT_FAILURE, "(internal) unknown packet type\n");
	break;
    }
  }

  /* --- Initialize the hash function and start reading hashed packets --- */

  if (!k) {
    if (verb)
      puts("FAIL no keyid packet found");
    exit(EXIT_FAILURE);
  }

  s = getsig(k, "dsig", 0);
  if (!(f & f_nocheck) && verb && (err = s->ops->check(s)) != 0)
    printf("WARN public key fails check: %s", err);

  fhash_init(&fh, GH_CLASS(s->h), f | FHF_BINARY);
  for (;;) {
    switch (e) {
      case T_COMMENT:
	if (verb > 1)
	  printf("INFO comment: `%s'\n", b.d.buf);
	bemit(&b, 0, s->h, 0);
	break;
      case T_DATE:
	if (verb > 2) {
	  DRESET(&b.d);
	  timestring(b.t, &b.d);
	  printf("INFO date: %s\n", b.d.buf);
	}
	bemit(&b, 0, s->h, 0);
	break;
      case T_EXPIRE: {
	time_t now = time(0);
	if (b.t != KEXP_FOREVER && b.t < now) {
	  if (verb > 1)
	    puts("BAD signature has expired");
	  f |= f_bogus;
	}
	if (verb > 2) {
	  DRESET(&b.d);
	  timestring(b.t, &b.d);
	  printf("INFO expires: %s\n", b.d.buf);
	}
	bemit(&b, 0, s->h, 0);
      }	break;
      case T_FILE:
	DRESET(&d);
	DENSURE(&d, GH_CLASS(s->h)->hashsz);
	if (fhash(&fh, b.d.buf, d.buf)) {
	  if (verb > 1) {
	    printf("BAD error reading file `%s': %s\n",
		    b.d.buf, strerror(errno));
	  }
	  f |= f_bogus;
	} else if (b.b.len != GH_CLASS(s->h)->hashsz ||
		   memcmp(d.buf, b.b.buf, b.b.len) != 0) {
	  if (verb > 1)
	    printf("BAD file `%s' has incorrect hash\n", b.d.buf);
	  f |= f_bogus;
	} else if (verb > 3) {
	  fputs("INFO hash: ", stdout);
	  fhex(stdout, b.b.buf, b.b.len);
	  printf(" %s\n", b.d.buf);
	}
	bemit(&b, 0, s->h, 0);
	break;
      case T_SIGNATURE:
	if (s->ops->doit(s, &b.b)) {
	  if (verb > 1)
	    puts("BAD bad signature");
	  f |= f_bogus;
	} else if (verb > 2)
	  puts("INFO good signature");
	goto done;
      default:
	if (verb)
	  printf("FAIL invalid packet type %i\n", e);
	exit(EXIT_FAILURE);
	break;
    }
    breset(&b);
    e = bget(&b, fp, f & f_bin);
    if (e < 0) {
      if (verb)
	printf("FAIL error reading packet: %s\n", errtab[-e]);
      exit(EXIT_FAILURE);
    }
  }
done:
  if ((f & FHF_JUNK) && fhash_junk(&fh, checkjunk, 0))
    f |= f_bogus;
  fhash_free(&fh);
  bdestroy(&b);
  dstr_destroy(&d);
  freesig(s);
  key_close(&kf);
  if (fp != stdin)
    fclose(fp);
  if (verb) {
    if (f & f_bogus)
      puts("FAIL signature invalid");
    else
      puts("OK signature verified");
  }
  return (f & f_bogus ? EXIT_FAILURE : EXIT_SUCCESS);

#undef f_bogus
#undef f_bin
#undef f_ok
#undef f_nocheck
}

/*----- Main code ---------------------------------------------------------*/

#define LISTS(LI)							\
  LI("Lists", list,							\
     listtab[i].name, listtab[i].name)					\
  LI("Signature schemes", sig,						\
     sigtab[i].name, sigtab[i].name)					\
  LI("Hash functions", hash,						\
     ghashtab[i], ghashtab[i]->name)

MAKELISTTAB(listtab, LISTS)

int cmd_show(int argc, char *argv[])
{
  return (displaylists(listtab, argv + 1));
}

static int cmd_help(int, char **);

static cmd cmdtab[] = {
  { "help", cmd_help, "help [COMMAND...]" },
  { "show", cmd_show, "show [ITEM...]" },
  { "sign", sign,
    "sign [-0bpqvC] [-c COMMENT] [-k TAG] [-e EXPIRE]\n\t\
[-f FILE] [-h FILE] [-o OUTPUT]",
    "\
Options:\n\
\n\
-0, --null		Read null-terminated filenames from stdin.\n\
-b, --binary		Produce a binary output file.\n\
-q, --quiet		Produce fewer messages while working.\n\
-v, --verbose		Produce more messages while working.\n\
-p, --progress		Show progress on large files.\n\
-C, --nocheck		Don't check the private key.\n\
-c, --comment=COMMENT	Include COMMENT in the output file.\n\
-f, --file=FILE		Read filenames to hash from FILE.\n\
-h, --hashes=FILE	Read precomputed hashes from FILE.\n\
-o, --output=FILE	Write the signed result to FILE.\n\
-k, --key=TAG		Use a key named by TAG.\n\
-e, --expire=TIME	The signature should expire after TIME.\n\
" },
  { "verify", verify,
    "verify [-pqvC] [FILE]", "\
Options:\n\
\n\
-q, --quiet		Produce fewer messages while working.\n\
-v, --verbose		Produce more messages while working.\n\
-p, --progress		Show progress on large files.\n\
-C, --nocheck		Don't check the public key.\n\
" },
  { 0, 0, 0 }
};

static int cmd_help(int argc, char **argv)
{
  sc_help(cmdtab, stdout, argv + 1);
  return (0);
}

void version(FILE *fp)
{
  pquis(fp, "$, Catacomb version " VERSION "\n");
}

static void usage(FILE *fp)
{
  pquis(fp, "Usage: $ [-k KEYRING] COMMAND [ARGS]\n");
}

void help_global(FILE *fp)
{
  usage(fp);
  fputs("\n\
Create and verify signatures on lists of files.\n\
\n\
Global command-line options:\n\
\n\
-h, --help [COMMAND...]	Show this help message, or help for COMMANDs.\n\
-v, --version		Show program version number.\n\
-u, --usage		Show a terse usage message.\n\
\n\
-k, --keyring=FILE	Read keys from FILE.\n",
	fp);
}

/* --- @main@ --- *
 *
 * Arguments:	@int argc@ = number of command line arguments
 *		@char *argv[]@ = vector of command line arguments
 *
 * Returns:	Zero if successful, nonzero otherwise.
 *
 * Use:		Signs or verifies signatures on lists of files.  Useful for
 *		ensuring that a distribution is unmolested.
 */

int main(int argc, char *argv[])
{
  unsigned f = 0;

#define f_bogus 1u

  /* --- Initialize the library --- */

  ego(argv[0]);
  sub_init();
  rand_noisesrc(RAND_GLOBAL, &noise_source);
  rand_seed(RAND_GLOBAL, 160);

  /* --- Parse options --- */

  for (;;) {
    static struct option opts[] = {
      { "help",		0,		0,	'h' },
      { "version",	0,		0,	'v' },
      { "usage",	0,		0,	'u' },
      { "keyring",	OPTF_ARGREQ,	0,	'k' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+hvu k:", opts, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case 'h':
	sc_help(cmdtab, stdout, argv + optind);
	exit(0);
	break;
      case 'v':
	version(stdout);
	exit(0);
	break;
      case 'u':
	usage(stdout);
	exit(0);
      case 'k':
	keyring = optarg;
	break;
      default:
	f |= f_bogus;
	break;
    }
  }

  argc -= optind;
  argv += optind;
  optind = 0;
  if (f & f_bogus || argc < 1) {
    usage(stderr);
    exit(EXIT_FAILURE);
  }

  /* --- Dispatch to the correct subcommand handler --- */

  return (findcmd(cmdtab, argv[0])->cmd(argc, argv));

#undef f_bogus
}

/*----- That's all, folks -------------------------------------------------*/
