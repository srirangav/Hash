/* -*-c-*-
 *
 * Hash files using some secure hash function
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#define _FILE_OFFSET_BITS 64

#include "config.h"

#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/alloc.h>
#include <mLib/dstr.h>
#include <mLib/mdwopt.h>
#include <mLib/quis.h>
#include <mLib/report.h>
#include <mLib/sub.h>

#include "ghash.h"
#include "cc.h"

/*----- Static variables --------------------------------------------------*/

#define f_bogus 1u
#define f_verbose 2u
#define f_check 4u
#define f_files 8u
#define f_oddhash 16u
#define f_escape 32u
#define f_oddenc 64u

/*----- Guts --------------------------------------------------------------*/

static int checkjunk(const char *path, const struct stat *st, void *p)
{
  const char *what;
  fhashstate *fh = p;

  if (!st) {
    if (fh->f & f_verbose)
      fprintf(stderr, "JUNK (error %s) %s\n", strerror(errno), path);
    else
      moan("couldn't stat junk file `%s': %s", path, strerror(errno));
  } else {
    what = describefile(st);
    if (fh->f & f_verbose)
      fprintf(stderr, "JUNK %s %s\n", what, path);
    else
      moan("found junk %s `%s'", what, path);
  }
  return (0);
}

static int warnjunk(const char *path, const struct stat *st, void *p)
{
  if (st)
    moan("unexpected %s `%s'", describefile(st), path);
  else
    moan("couldn't stat unexpected file `%s': %s", path, strerror(errno));
  return (0);
}

static int checkhash(fhashstate *fh, const char *file, const encodeops *e)
{
  int rc = 0;
  hfpctx hfp;
  dstr dl = DSTR_INIT;
  dstr df = DSTR_INIT;
  unsigned long n = 0, nfail = 0;
  int hf;

  if (!file || strcmp(file, "-") == 0)
    hfp.fp = stdin;
  else if ((hfp.fp = fopen(file, fh->f & GSF_RAW ? "r" : "rb")) == 0) {
    moan("couldn't open `%s': %s", file, strerror(errno));
    return (EXIT_FAILURE);
  }

  hfp.dline = &dl;
  hfp.dfile = &df;
  hfp.hbuf = xmalloc(2 * fh->gch->hashsz);
  hfp.gch = fh->gch;
  hfp.ee = e;
  hfp.f = fh->f;

  while ((hf = hfparse(&hfp)) != HF_EOF) {
    switch (hf) {
      case HF_HASH:
	xfree(hfp.hbuf);
	hfp.hbuf = xmalloc(2 * hfp.gch->hashsz);
	fh->gch = hfp.gch;
	break;
      case HF_FILE:
	if (fhash(fh, df.buf, hfp.hbuf + hfp.gch->hashsz)) {
	  moan("couldn't read `%s': %s", df.buf, strerror(errno));
	  rc = EXIT_FAILURE;
	  continue;
	}
	if (memcmp(hfp.hbuf, hfp.hbuf + hfp.gch->hashsz,
		   hfp.gch->hashsz) != 0) {
	  if (hfp.f & f_verbose)
	    fprintf(stderr, "FAIL %s\n", df.buf);
	  else
	    moan("%s check failed for `%s'", hfp.gch->name, df.buf);
	  nfail++;
	  rc = EXIT_FAILURE;
	} else {
	  if (hfp.f & f_verbose)
	    fprintf(stderr, "OK %s\n", df.buf);
	}
	n++;
    }
  }

  if (ferror(hfp.fp)) {
    moan("error reading input `%s': %s",
	 file ? file : "<stdin>", strerror(errno));
    rc = EXIT_FAILURE;
  }
  dstr_destroy(&dl);
  dstr_destroy(&df);
  xfree(hfp.hbuf);
  if ((fh->f & f_verbose) && nfail)
    moan("%lu of %lu file(s) failed %s check", nfail, n, hfp.gch->name);
  else if (!n)
    moan("no files checked");
  return (rc);
}

static int dohash(fhashstate *fh, const char *file, const encodeops *e)
{
  int rc = 0;
  octet *p = xmalloc(fh->gch->hashsz);

  if (fhash(fh, file, p)) {
    moan("couldn't read `%s': %s", file ? file : "<stdin>", strerror(errno));
    rc = EXIT_FAILURE;
  } else {
    e->put(p, fh->gch->hashsz, stdout);
    if (file) {
      fputc(' ', stdout);
      fputc(fh->f & FHF_BINARY ? '*' : ' ', stdout);
      if (fh->f & f_escape)
	putstring(stdout, file, 0);
      else
	fputs(file, stdout);
    }
    fputc('\n', stdout);
  }

  xfree(p);
  return (rc);
}

static int dofile(fhashstate *fh, const char *file, const encodeops *e)
  { return (fh->f & f_check ? checkhash : dohash)(fh, file, e); }

static int hashfiles(fhashstate *fh, const char *file, const encodeops *e)
{
  FILE *fp;
  dstr d = DSTR_INIT;
  int rc = 0;
  int rrc;

  if (!file || strcmp(file, "-") == 0)
    fp = stdin;
  else if ((fp = fopen(file, fh->f & GSF_RAW ? "r" : "rb")) == 0) {
    moan("couldn't open `%s': %s", file, strerror(errno));
    return (EXIT_FAILURE);
  }

  for (;;) {
    DRESET(&d);
    if (getstring(fp, &d, GSF_FILE | fh->f))
      break;
    if ((rrc = dofile(fh, d.buf, e)) != 0)
      rc = rrc;
  }

  return (rc);
}

static int hashsum(fhashstate *fh, const char *file, const encodeops *e)
  { return (fh->f & f_files ? hashfiles : dofile)(fh, file, e); }

/*----- Main driver -------------------------------------------------------*/

void version(FILE *fp)
{
  pquis(fp, "$, Catacomb version " VERSION "\n");
}

static void usage(FILE *fp)
{
  pquis(fp, "Usage: $ [-f0ebcv] [-a ALGORITHM] [-E ENC] [FILES...]\n");
}

static void help(FILE *fp, const gchash *gch)
{
  version(fp);
  fputc('\n', fp);
  usage(fp);
  pquis(fp, "\n\
Generates or checks message digests on files.  Options available:\n\
\n\
-h, --help		Display this help message.\n\
-V, --version		Display program's version number.\n\
-u, --usage		Display a terse usage message.\n\
-l, --list [ITEM...]	Show known hash functions and/or encodings.\n\
\n\
-a, --algorithm=ALG	Use the message digest algorithm ALG.\n\
-E, --encoding=ENC	Represent hashes using encoding ENC.\n\
\n\
-f, --files		Read a list of file names from standard input.\n\
-0, --null		File names are null terminated, not plain text.\n\
\n\
-e, --escape		Escape funny characters in filenames.\n\
-c, --check		Check message digests rather than emitting them.\n\
-b, --binary		When reading files, treat them as binary.\n\
-p, --progress		Show a progress indicator for large files.\n\
-v, --verbose		Be verbose when checking digests.\n\
\n\
For a list of hashing algorithms and encodings, type `$ --list'.\n\
");
  if (gch)
    fprintf(fp, "The default message digest algorithm is %s.\n", gch->name);
}

#define LISTS(LI)							\
  LI("Lists", list, listtab[i].name, listtab[i].name)			\
  LI("Hash functions", hash, ghashtab[i], ghashtab[i]->name)		\
  LI("Encodings", enc, encodingtab[i].name, encodingtab[i].name)

MAKELISTTAB(listtab, LISTS)

int main(int argc, char *argv[])
{
  fhashstate fh;
  const encodeops *e = &encodingtab[ENC_HEX];
  int rc;

  /* --- Initialization --- */

  ego(argv[0]);
  sub_init();
  fhash_init(&fh, 0, 0);

  /* --- Choose a hash function from the name --- */

  {
    char *q = xstrdup(QUIS);
    size_t len = strlen(q);
    if (len > 3 && strcmp(q + len - 3, "sum") == 0) {
      q[len - 3] = 0;
      fh.gch = gethash(q);
    }
    if (!fh.gch)
      fh.gch = gethash("md5");
    xfree(q);
  }

  /* --- Read options --- */

  for (;;) {
    static struct option opts[] = {
      { "help",		0,		0,	'h' },
      { "verbose",	0,		0,	'V' },
      { "usage",	0,		0,	'u' },

      { "algorithm",	OPTF_ARGREQ,	0,	'a' },
      { "hash",		OPTF_ARGREQ,	0,	'a' },
      { "encoding",	OPTF_ARGREQ,	0,	'E' },
      { "list",		0,		0,	'l' },

      { "files",	0,		0,	'f' },
      { "find",		0,		0,	'f' },
      { "null",		0,		0,	'0' },

      { "escape",	0,		0,	'e' },
      { "check",	0,		0,	'c' },
      { "junk",		0,		0,	'j' },
      { "binary",	0,		0,	'b' },
      { "verbose",	0,		0,	'v' },
      { "progress",	0,		0,	'p' },

      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "hVu a:E:l f0 ecjbvp", opts, 0, 0, 0);
    if (i < 0)
      break;

    switch (i) {
      case 'h':
	help(stdout, fh.gch);
	exit(0);
      case 'V':
	version(stdout);
	exit(0);
      case 'u':
	usage(stdout);
	exit(0);
      case 'l':
	exit(displaylists(listtab, argv + optind));
      case 'a':
	if ((fh.gch = gethash(optarg)) == 0)
	  die(EXIT_FAILURE, "unknown hash algorithm `%s'", optarg);
	fh.f |= f_oddhash;
	break;
      case 'E':
	if ((e = getencoding(optarg)) == 0)
	  die(EXIT_FAILURE, "unknown encoding `%s'", optarg);
	fh.f |= f_oddenc;
	break;
      case 'f':
	fh.f |= f_files;
	break;
      case '0':
	fh.f |= GSF_RAW;
	break;
      case 'e':
	fh.f |= f_escape;
	break;
      case 'c':
	fh.f |= f_check;
	break;
      case 'j':
	fh.f |= FHF_JUNK;
	break;
      case 'b':
	fh.f |= FHF_BINARY;
	break;
      case 'v':
	fh.f |= f_verbose;
	break;
      case 'p':
	fh.f |= FHF_PROGRESS;
	break;
      default:
	fh.f |= f_bogus;
	break;
    }
  }

  if (fh.f & f_bogus) {
    usage(stderr);
    exit(EXIT_FAILURE);
  }
  argv += optind;
  argc -= optind;

  /* --- Generate output --- */

  if (!(fh.f & f_check) && (argc || (fh.f & f_files))) {
    if (fh.f & f_oddhash) printf("#hash %s\n", fh.gch->name);
    if (fh.f & f_oddenc) printf("#encoding %s\n", e->name);
    if (fh.f & f_escape) fputs("#escape\n", stdout);
  }
  if (!argc)
    rc = hashsum(&fh, 0, e);
  else {
    int i;
    int rrc;

    rc = 0;
    for (i = 0; i < argc; i++) {
      if ((rrc = hashsum(&fh, argv[i], e)) != 0)
	rc = rrc;
    }
  }

  if (fh.f & FHF_JUNK) {
    if (fh.f & f_check) {
      if (fhash_junk(&fh, checkjunk, &fh)) rc = EXIT_FAILURE;
    } else {
      if (fhash_junk(&fh, warnjunk, 0) < 0) rc = EXIT_FAILURE;
    }
  }
  fhash_free(&fh);

  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
