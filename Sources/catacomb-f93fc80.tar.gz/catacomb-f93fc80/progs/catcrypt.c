/* -*-c-*-
 *
 * Command-line encryption tool
 *
 * (c) 2004 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#define _FILE_OFFSET_BITS 64

#include "config.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <mLib/base64.h>
#include <mLib/dstr.h>
#include <mLib/mdwopt.h>
#include <mLib/quis.h>
#include <mLib/report.h>
#include <mLib/sub.h>

#include "buf.h"
#include "rand.h"
#include "noise.h"
#include "mprand.h"
#include "key.h"
#include "cc.h"

#include "ectab.h"
#include "ptab.h"

/*----- Static variables --------------------------------------------------*/

static const char *keyring = "keyring";

/*----- Data format -------------------------------------------------------*/

/* --- Overview --- *
 *
 * The encrypted message is divided into chunks, each preceded by a two-octet
 * length.  The chunks don't need to be large -- the idea is that we can
 * stream the chunks in and out.
 *
 * The first chunk is a header.  It contains the decryption key-id, and maybe
 * the verification key-id if the message is signed.
 *
 * Next comes the key-encapsulation chunk.  This is decrypted in some
 * KEM-specific way to yield a secret hash.  The hash is expanded using an
 * MGF (or similar) to make a symmetric encryption and MAC key.
 *
 * If the message is signed, there comes a signature chunk.  The signature is
 * on the header and key-encapsulation chunks, and further output of the MGF.
 * This means that the recipient can modify the message and still have a
 * valid signature, so it's not useful for proving things to other people;
 * but it also means that the recipient knows that the message is from
 * someone who knows the hash, which limits the possiblities to (a) whoever
 * encrypted the message (good!) and (b) whoever knows the recipient's
 * private key.
 *
 * Then come message chunks.  Each one begins with a MAC over an implicit
 * sequence number and the ciphertext.  The final chunk's ciphertext is
 * empty; no other chunk is empty.  Thus can the correct end-of-file be
 * discerned.
 */

/*----- Chunk I/O ---------------------------------------------------------*/

static void chunk_write(enc *e, buf *b)
{
  octet l[2];
  size_t n = BLEN(b);
  assert(n <= MASK16);
  STORE16(l, n);
  if (e->ops->write(e, l, 2) ||
      e->ops->write(e, BBASE(b), BLEN(b)))
    die(EXIT_FAILURE, "error writing output: %s", strerror(errno));
}

static void chunk_read(enc *e, dstr *d, buf *b)
{
  octet l[2];
  size_t n;

  dstr_reset(d);
  errno = 0;
  if (e->ops->read(e, l, 2) != 2)
    goto err;
  n = LOAD16(l);
  dstr_ensure(d, n);
  if (e->ops->read(e, d->buf, n) != n)
    goto err;
  d->len = n;
  buf_init(b, d->buf, d->len);
  return;

err:
  if (!errno) die(EXIT_FAILURE, "unexpected end-of-file on input");
  else die(EXIT_FAILURE, "error reading input: %s", strerror(errno));
}

/*----- Encryption --------------------------------------------------------*/

static int encrypt(int argc, char *argv[])
{
  const char *fn, *of = 0, *kn = "ccrypt", *skn = 0;
  FILE *ofp = 0;
  FILE *fp = 0;
  const char *ef = "binary";
  fprogress ff;
  const char *err;
  int i;
  int en;
  size_t n, chsz;
  dstr d = DSTR_INIT;
  octet *tag, *ct;
  buf b;
  size_t seq;
  char bb[65536];
  unsigned f = 0;
  key_file kf;
  key *k;
  key *sk = 0;
  kem *km;
  sig *s = 0;
  gcipher *cx, *c;
  gmac *m;
  ghash *h;
  const encops *eo;
  enc *e;

#define f_bogus 1u
#define f_nocheck 2u
#define f_progress 4u

  for (;;) {
    static const struct option opt[] = {
      { "key",		OPTF_ARGREQ,	0,	'k' },
      { "sign-key",	OPTF_ARGREQ,	0,	's' },
      { "armour",	0,		0,	'a' },
      { "armor",	0,		0,	'a' },
      { "format",	OPTF_ARGREQ,	0,	'f' },
      { "output",	OPTF_ARGREQ,	0,	'o' },
      { "progress",	0,		0,	'p' },
      { "nocheck",	0,		0,	'C' },
      { 0,		0,		0,	0 }
    };
    i = mdwopt(argc, argv, "k:s:af:o:pC", opt, 0, 0, 0);
    if (i < 0) break;
    switch (i) {
      case 'k': kn = optarg; break;
      case 's': skn = optarg; break;
      case 'a': ef = "pem"; break;
      case 'f': ef = optarg; break;
      case 'o': of = optarg; break;
      case 'p': f |= f_progress; break;
      case 'C': f |= f_nocheck; break;
      default: f |= f_bogus; break;
    }
  }
  if (argc - optind > 1 || (f & f_bogus))
    die(EXIT_FAILURE, "Usage: encrypt [-OPTIONS] [FILE]");

  if (key_open(&kf, keyring, KOPEN_READ, key_moan, 0))
    die(EXIT_FAILURE, "can't open keyring `%s'", keyring);
  if ((k = key_bytag(&kf, kn)) == 0)
    die(EXIT_FAILURE, "key `%s' not found", kn);
  if (skn && (sk = key_bytag(&kf, skn)) == 0)
    die(EXIT_FAILURE, "key `%s' not found", skn);

  if ((eo = getenc(ef)) == 0)
    die(EXIT_FAILURE, "encoding `%s' not found", ef);

  fn = optind < argc ? argv[optind++] : "-";
  if (strcmp(fn, "-") == 0)
    fp = stdin;
  else if ((fp = fopen(fn, "rb")) == 0) {
    die(EXIT_FAILURE, "couldn't open file `%s': %s",
	fn, strerror(errno));
  }

  if (!of || strcmp(of, "-") == 0)
    ofp = stdout;
  else if ((ofp = fopen(of, eo->wmode)) == 0) {
    die(EXIT_FAILURE, "couldn't open file `%s' for output: %s",
	of, strerror(errno));
  }

  dstr_reset(&d);
  key_fulltag(k, &d);
  e = initenc(eo, ofp, "CATCRYPT ENCRYPTED MESSAGE");
  km = getkem(k, "cckem", 0);
  if (!(f & f_nocheck) && (err = km->ops->check(km)) != 0)
    moan("key %s fails check: %s", d.buf, err);
  if (sk) {
    dstr_reset(&d);
    key_fulltag(sk, &d);
    s = getsig(sk, "ccsig", 1);
    if ((err = s->ops->check(s)) != 0)
      moan("key %s fails check: %s", d.buf, err);
  }

  /* --- Build the header chunk --- */

  dstr_reset(&d);
  dstr_ensure(&d, 256);
  buf_init(&b, d.buf, 256);
  buf_putu32(&b, k->id);
  if (sk) buf_putu32(&b, sk->id);
  assert(BOK(&b));
  if (s) GH_HASHBUF16(s->h, BBASE(&b), BLEN(&b));
  chunk_write(e, &b);

  /* --- Build the KEM chunk --- */

  dstr_reset(&d);
  if (setupkem(km, &d, &cx, &c, &m))
    die(EXIT_FAILURE, "failed to encapsulate key");
  buf_init(&b, d.buf, d.len);
  BSTEP(&b, d.len);
  if (s) GH_HASHBUF16(s->h, BBASE(&b), BLEN(&b));
  chunk_write(e, &b);

  /* --- Write the signature chunk --- */

  if (s) {
    GC_ENCRYPT(cx, 0, bb, 1024);
    GH_HASH(s->h, bb, 1024);
    dstr_reset(&d);
    if ((en = s->ops->doit(s, &d)) != 0)
      die(EXIT_FAILURE, "error creating signature: %s", key_strerror(en));
    buf_init(&b, d.buf, d.len);
    BSTEP(&b, d.len);
    chunk_write(e, &b);
  }

  /* --- Now do the main crypto --- */

  if (f & f_progress) {
    if (fprogress_init(&ff, fn, fp)) {
      die(EXIT_FAILURE, "failed to initialize progress display: %s",
	  strerror(errno));
    }
  }

  assert(GC_CLASS(c)->blksz <= sizeof(bb));
  dstr_ensure(&d, sizeof(bb) + GM_CLASS(m)->hashsz);
  seq = 0;
  chsz = MASK16 - GM_CLASS(m)->hashsz;
  for (;;) {
    h = GM_INIT(m);
    GH_HASHU32(h, seq);
    seq++;
    if (GC_CLASS(c)->blksz) {
      GC_ENCRYPT(cx, 0, bb, GC_CLASS(c)->blksz);
      GC_SETIV(c, bb);
    }
    n = fread(bb, 1, chsz, fp);
    if (!n) break;
    if (f & f_progress) fprogress_update(&ff, n);
    buf_init(&b, d.buf, d.sz);
    tag = buf_get(&b, GM_CLASS(m)->hashsz);
    ct = buf_get(&b, n);
    assert(tag); assert(ct);
    GC_ENCRYPT(c, bb, ct, n);
    GH_HASH(h, ct, n);
    GH_DONE(h, tag);
    GH_DESTROY(h);
    chunk_write(e, &b);
  }

  /* --- Final terminator packet --- */

  buf_init(&b, d.buf, d.sz);
  tag = buf_get(&b, GM_CLASS(m)->hashsz);
  assert(tag);
  GH_DONE(h, tag);
  GH_DESTROY(h);
  chunk_write(e, &b);

  /* --- All done --- */

  if (f & f_progress) fprogress_done(&ff);
  e->ops->encdone(e);
  GM_DESTROY(m);
  GC_DESTROY(c);
  GC_DESTROY(cx);
  freeenc(e);
  if (s) freesig(s);
  freekem(km);
  if (fp != stdin) fclose(fp);
  if (of) fclose(ofp);
  key_close(&kf);
  dstr_destroy(&d);
  return (0);

#undef f_bogus
#undef f_nocheck
#undef f_progress
}

/*---- Decryption ---------------------------------------------------------*/

static int decrypt(int argc, char *argv[])
{
  const char *fn, *of = 0;
  FILE *ofp = 0, *rfp = 0;
  FILE *fp = 0;
  const char *ef = "binary";
  fprogress ff;
  int i;
  size_t n;
  dstr d = DSTR_INIT;
  buf b;
  key_file kf;
  size_t seq;
  uint32 id;
  key *k;
  key *sk = 0;
  kem *km;
  sig *s = 0;
  gcipher *cx;
  gcipher *c;
  ghash *h;
  gmac *m;
  octet *tag;
  unsigned f = 0;
  const encops *eo;
  const char *err;
  int verb = 1;
  enc *e;

#define f_bogus 1u
#define f_buffer 2u
#define f_nocheck 4u
#define f_progress 8u

  for (;;) {
    static const struct option opt[] = {
      { "armour",	0,		0,	'a' },
      { "armor",	0,		0,	'a' },
      { "buffer",	0,		0,	'b' },
      { "verbose",	0,		0,	'v' },
      { "quiet",	0,		0,	'q' },
      { "nocheck",	0,		0,	'C' },
      { "format",	OPTF_ARGREQ,	0,	'f' },
      { "output",	OPTF_ARGREQ,	0,	'o' },
      { "progress",	0,		0,	'p' },
      { 0,		0,		0,	0 }
    };
    i = mdwopt(argc, argv, "abf:o:pqvC", opt, 0, 0, 0);
    if (i < 0) break;
    switch (i) {
      case 'a': ef = "pem"; break;
      case 'b': f |= f_buffer; break;
      case 'v': verb++; break;
      case 'q': if (verb) verb--; break;
      case 'C': f |= f_nocheck; break;
      case 'f': ef = optarg; break;
      case 'o': of = optarg; break;
      case 'p': f |= f_progress; break;
      default: f |= f_bogus; break;
    }
  }
  if (argc - optind > 1 || (f & f_bogus))
    die(EXIT_FAILURE, "Usage: decrypt [-OPTIONS] [FILE]");

  if ((eo = getenc(ef)) == 0)
    die(EXIT_FAILURE, "encoding `%s' not found", ef);

  fn = optind < argc ? argv[optind++] : "-";
  if (strcmp(fn, "-") == 0)
    fp = stdin;
  else if ((fp = fopen(fn, eo->rmode)) == 0) {
    die(EXIT_FAILURE, "couldn't open file `%s': %s",
	fn, strerror(errno));
  }

  if (key_open(&kf, keyring, KOPEN_READ, key_moan, 0))
    die(EXIT_FAILURE, "can't open keyring `%s'", keyring);

  e = initdec(eo, fp, checkbdry, "CATCRYPT ENCRYPTED MESSAGE");

  if (f & f_progress) {
    if (fprogress_init(&ff, fn, fp)) {
      die(EXIT_FAILURE, "failed to initialize progress display: %s",
	  strerror(errno));
    }
  }

  /* --- Read the header chunk --- */

  chunk_read(e, &d, &b);
  if (f & f_progress)
    fprogress_update(&ff, BLEFT(&b)*e->ops->ncook/e->ops->nraw);
  if (buf_getu32(&b, &id)) {
    if (f & f_progress) fprogress_done(&ff);
    if (verb) printf("FAIL malformed header: missing keyid\n");
    exit(EXIT_FAILURE);
  }
  if ((k = key_byid(&kf, id)) == 0) {
    if (f & f_progress) fprogress_done(&ff);
    if (verb) printf("FAIL key id %08lx not found\n", (unsigned long)id);
    exit(EXIT_FAILURE);
  }
  if (BLEFT(&b)) {
    if (buf_getu32(&b, &id)) {
      if (f & f_progress) fprogress_done(&ff);
      if (verb) printf("FAIL malformed header: missing signature keyid\n");
      exit(EXIT_FAILURE);
    }
    if ((sk = key_byid(&kf, id)) == 0) {
      if (f & f_progress) fprogress_done(&ff);
      if (verb) printf("FAIL key id %08lx not found\n", (unsigned long)id);
      exit(EXIT_FAILURE);
    }
  }
  if (BLEFT(&b)) {
    if (f & f_progress) fprogress_done(&ff);
    if (verb) printf("FAIL malformed header: junk at end\n");
    exit(EXIT_FAILURE);
  }
  if (sk) {
    s = getsig(sk, "ccsig", 0);
    if (!(f & f_nocheck) && verb && (err = s->ops->check(s)) != 0) {
      dstr_reset(&d);
      key_fulltag(sk, &d);
      printf("WARN verification key %s fails check: %s\n", d.buf, err);
    }
    GH_HASHBUF16(s->h, BBASE(&b), BSZ(&b));
  }

  /* --- Find the key --- */

  km = getkem(k, "cckem", 1);

  /* --- Read the KEM chunk --- */

  chunk_read(e, &d, &b);
  if (f & f_progress)
    fprogress_update(&ff, BLEFT(&b)*e->ops->ncook/e->ops->nraw);
  if (setupkem(km, &d, &cx, &c, &m)) {
    if (f & f_progress) fprogress_done(&ff);
    if (verb) printf("FAIL failed to decapsulate key\n");
    exit(EXIT_FAILURE);
  }
  if (s) GH_HASHBUF16(s->h, d.buf, d.len);

  /* --- Verify the signature, if there is one --- */

  if (sk) {
    dstr_reset(&d);
    dstr_ensure(&d, 1024);
    GC_ENCRYPT(cx, 0, d.buf, 1024);
    GH_HASH(s->h, d.buf, 1024);
    chunk_read(e, &d, &b);
    if (f & f_progress)
      fprogress_update(&ff, BLEFT(&b)*e->ops->ncook/e->ops->nraw);
    if (s->ops->doit(s, &d)) {
      if (f & f_progress) fprogress_done(&ff);
      if (verb) printf("FAIL signature verification failed\n");
      exit(EXIT_FAILURE);
    }
    if (verb) {
      dstr_reset(&d);
      key_fulltag(sk, &d);
      if (f & f_progress) fprogress_clear(&ff);
      printf("INFO good-signature %s\n", d.buf);
    }
    freesig(s);
  } else if (verb) {
    if (f & f_progress) fprogress_clear(&ff);
    printf("INFO no-signature\n");
  }

  /* --- Now decrypt the main body --- */

  if (!of || strcmp(of, "-") == 0) {
    ofp = stdout;
    f |= f_buffer;
  }
  if (!(f & f_buffer)) {
    if ((ofp = fopen(of, "wb")) == 0) {
      if (f & f_progress) fprogress_done(&ff);
      die(EXIT_FAILURE, "couldn't open file `%s' for output: %s",
	  of, strerror(errno));
    }
    rfp = ofp;
  } else if ((rfp = tmpfile()) == 0) {
    if (f & f_progress) fprogress_done(&ff);
    die(EXIT_FAILURE, "couldn't create temporary file: %s", strerror(errno));
  }

  seq = 0;
  dstr_ensure(&d, GC_CLASS(c)->blksz);
  dstr_ensure(&d, 4);
  for (;;) {
    if (GC_CLASS(c)->blksz) {
      GC_ENCRYPT(cx, 0, d.buf, GC_CLASS(c)->blksz);
      GC_SETIV(c, d.buf);
    }
    h = GM_INIT(m);
    GH_HASHU32(h, seq);
    seq++;
    chunk_read(e, &d, &b);
    if (f & f_progress)
      fprogress_update(&ff, BLEFT(&b)*e->ops->ncook/e->ops->nraw);
    if ((tag = buf_get(&b, GM_CLASS(m)->hashsz)) == 0) {
      if (f & f_progress) fprogress_done(&ff);
      if (verb) printf("FAIL bad ciphertext chunk: no tag\n");
      exit(EXIT_FAILURE);
    }
    GH_HASH(h, BCUR(&b), BLEFT(&b));
    if (memcmp(tag, GH_DONE(h, 0), GM_CLASS(m)->hashsz) != 0) {
      if (f & f_progress) fprogress_done(&ff);
      if (verb)
	printf("FAIL bad ciphertext chunk: authentication failure\n");
      exit(EXIT_FAILURE);
    }
    GH_DESTROY(h);
    if (!BLEFT(&b))
      break;
    GC_DECRYPT(c, BCUR(&b), BCUR(&b), BLEFT(&b));
    if (fwrite(BCUR(&b), 1, BLEFT(&b), rfp) != BLEFT(&b)) {
      if (f & f_progress) fprogress_done(&ff);
      if (verb) printf("FAIL error writing output: %s\n", strerror(errno));
      exit(EXIT_FAILURE);
    }
  }

  if (f & f_progress) fprogress_done(&ff);
  if (fflush(rfp) || ferror(rfp)) {
    if (verb) printf("FAIL error writing output: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  if (f & f_buffer) {
    if (!ofp && (ofp = fopen(of, "wb")) == 0) {
      die(EXIT_FAILURE, "couldn't open file `%s' for output: %s",
	  of, strerror(errno));
    }
    rewind(rfp);
    if (f & f_progress) fprogress_init(&ff, "copying buffer", rfp);
    dstr_reset(&d);
    dstr_ensure(&d, 65536);
    if (verb && ofp == stdout) printf("DATA\n");
    for (;;) {
      n = fread(d.buf, 1, d.sz, rfp);
      if (!n) break;
      if (f & f_progress) fprogress_update(&ff, n);
      if (fwrite(d.buf, 1, n, ofp) < n) {
	if (f & f_progress) fprogress_done(&ff);
	die(EXIT_FAILURE, "error writing output: %s", strerror(errno));
      }
    }
    if (f & f_progress) fprogress_done(&ff);
    if (ferror(rfp) || fclose(rfp))
      die(EXIT_FAILURE, "error unbuffering output: %s", strerror(errno));
  }

  e->ops->decdone(e);
  if (verb && ofp != stdout)
    printf("OK decrypted successfully\n");
  if (ofp && (fflush(ofp) || ferror(ofp) || fclose(ofp)))
      die(EXIT_FAILURE, "error writing output: %s", strerror(errno));
  freeenc(e);
  GC_DESTROY(c);
  GC_DESTROY(cx);
  GM_DESTROY(m);
  freekem(km);
  if (fp != stdin) fclose(fp);
  key_close(&kf);
  dstr_destroy(&d);
  return (0);

#undef f_bogus
#undef f_buffer
#undef f_nocheck
#undef f_progress
}

/*----- Main code ---------------------------------------------------------*/

#define LISTS(LI)							\
  LI("Lists", list,							\
     listtab[i].name, listtab[i].name)					\
  LI("Key-encapsulation mechanisms", kem,				\
     kemtab[i].name, kemtab[i].name)					\
  LI("Signature schemes", sig,						\
     sigtab[i].name, sigtab[i].name)					\
  LI("Encodings", enc,							\
     enctab[i].name, enctab[i].name)					\
  LI("Symmetric encryption algorithms", cipher,				\
     gciphertab[i], gciphertab[i]->name)				\
  LI("Hash functions", hash,						\
     ghashtab[i], ghashtab[i]->name)					\
  LI("Message authentication codes", mac,				\
     gmactab[i], gmactab[i]->name)

MAKELISTTAB(listtab, LISTS)

int cmd_show(int argc, char *argv[])
{
  return (displaylists(listtab, argv + 1));
}

static int cmd_help(int, char **);

static cmd cmdtab[] = {
  { "help", cmd_help, "help [COMMAND...]" },
  { "show", cmd_show, "show [ITEM...]" },
  CMD_ENCODE,
  CMD_DECODE,
  { "encrypt", encrypt,
    "encrypt [-apC] [-k TAG] [-s TAG] [-f FORMAT]\n\t\
[-o OUTPUT] [FILE]", "\
Options:\n\
\n\
-a, --armour		Same as `-f pem'.\n\
-f, --format=FORMAT	Encode as FORMAT.\n\
-k, --key=TAG		Use public encryption key named by TAG.\n\
-s, --sign-key=TAG	Use private signature key named by TAG.\n\
-o, --output=FILE	Write output to FILE.\n\
-p, --progress		Show progress on large files.\n\
-C, --nocheck		Don't check the public key.\n\
" },
  { "decrypt", decrypt,
    "decrypt [-abpqvC] [-f FORMAT] [-o OUTPUT] [FILE]", "\
Options:\n\
\n\
-a, --armour		Same as `-f pem'.\n\
-b, --buffer		Buffer output until we're sure we have it all.\n\
-f, --format=FORMAT	Decode as FORMAT.\n\
-o, --output=FILE	Write output to FILE.\n\
-p, --progress		Show progress on large files.\n\
-q, --quiet		Produce fewer messages.\n\
-v, --verbose		Produce more verbose messages.\n\
-C, --nocheck		Don't check the private key.\n\
" },
  { 0, 0, 0 }
};

static int cmd_help(int argc, char **argv)
{
  sc_help(cmdtab, stdout, argv + 1);
  return (0);
}

void version(FILE *fp)
{
  pquis(fp, "$, Catacomb version " VERSION "\n");
}

static void usage(FILE *fp)
{
  pquis(fp, "Usage: $ [-k KEYRING] COMMAND [ARGS]\n");
}

void help_global(FILE *fp)
{
  usage(fp);
  fputs("\n\
Encrypt and decrypt files.\n\
\n\
Global command-line options:\n\
\n\
-h, --help [COMMAND...]	Show this help message, or help for COMMANDs.\n\
-v, --version		Show program version number.\n\
-u, --usage		Show a terse usage message.\n\
\n\
-k, --keyring=FILE	Read keys from FILE.\n",
	fp);
}

/* --- @main@ --- *
 *
 * Arguments:	@int argc@ = number of command line arguments
 *		@char *argv[]@ = vector of command line arguments
 *
 * Returns:	Zero if successful, nonzero otherwise.
 *
 * Use:		Encrypts or decrypts files.
 */

int main(int argc, char *argv[])
{
  unsigned f = 0;

#define f_bogus 1u

  /* --- Initialize the library --- */

  ego(argv[0]);
  sub_init();
  rand_noisesrc(RAND_GLOBAL, &noise_source);
  rand_seed(RAND_GLOBAL, 160);

  /* --- Parse options --- */

  for (;;) {
    static struct option opts[] = {
      { "help",		0,		0,	'h' },
      { "version",	0,		0,	'v' },
      { "usage",	0,		0,	'u' },
      { "keyring",	OPTF_ARGREQ,	0,	'k' },
      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "+hvu k:", opts, 0, 0, 0);
    if (i < 0)
      break;
    switch (i) {
      case 'h':
	sc_help(cmdtab, stdout, argv + optind);
	exit(0);
	break;
      case 'v':
	version(stdout);
	exit(0);
	break;
      case 'u':
	usage(stdout);
	exit(0);
      case 'k':
	keyring = optarg;
	break;
      default:
	f |= f_bogus;
	break;
    }
  }

  argc -= optind;
  argv += optind;
  optind = 0;
  if (f & f_bogus || argc < 1) {
    usage(stderr);
    exit(EXIT_FAILURE);
  }

  /* --- Dispatch to the correct subcommand handler --- */

  return (findcmd(cmdtab, argv[0])->cmd(argc, argv));

#undef f_bogus
}

/*----- That's all, folks -------------------------------------------------*/
