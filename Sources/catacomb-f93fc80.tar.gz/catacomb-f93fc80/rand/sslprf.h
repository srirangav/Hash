/* -*-c-*-
 *
 * The SSL pseudo-random function
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_SSLPRF_H
#define CATACOMB_SSLPRF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GMAC_H
#  include "gmac.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct sslprf_ctx {
  const gchash *co, *ci;		/* Outer and inner hash functions */
  size_t ohashsz, ihashsz;		/* Size of the hash outputs */
  ghash *h;				/* Hash context from last time */
  const octet *k;			/* Pointer to the secret */
  size_t ksz;				/* Size of the secret buffer */
  const octet *sd;			/* Pointer to the seed */
  size_t sdsz;				/* Size of the seed buffer */
  unsigned i;				/* Which iteration this is */
  octet *p;				/* Pointer to output buffer */
  size_t sz;				/* How many bytes are left */
} sslprf_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @sslprf_init@ --- *
 *
 * Arguments:	@sslprf_ctx *c@ = pointer to a context structure
 *		@const gchash *hco, *hci@ = outer and inner hash functions
 *		@const void *k@ = pointer to secret buffer
 *		@size_t ksz@ = size of the secret
 *		@const void *sd@ = pointer to seed buffer
 *		@size_t sdsz@ = size of the seed
 *
 * Returns:	---
 *
 * Use:		Initializes an SSL generator context.
 */

extern void sslprf_init(sslprf_ctx */*c*/,
			const gchash */*hco*/, const gchash */*hci*/,
			const void */*k*/, size_t /*ksz*/,
			const void */*sd*/, size_t /*sdsz*/);

/* --- @sslprf_encrypt@ --- *
 *
 * Arguments:	@sslprf_ctx *c@ = pointer to a context structure
 *		@const void *src@ = pointer to source buffer
 *		@void *dest@ = pointer to destination buffer
 *		@size_t sz@ = size of the buffers
 *
 * Returns:	---
 *
 * Use:		Encrypts data using the SSL pseudo-random function.  If the
 *		destination pointer is null, the generator is spun and no
 *		output is produced; if the source pointer is null, raw output
 *		from the generator is written; otherwise, the source data is
 *		XORed with the generator output.
 */

extern void sslprf_encrypt(sslprf_ctx */*c*/,
			   const void */*src*/, void */*dest*/,
			   size_t /*sz*/);

/* --- @sslprf_free@ --- *
 *
 * Arguments:	@sslprf_ctx@ = pointer to a context
 *
 * Returns:	---
 *
 * Use:		Frees resources held in an SSL generator context.
 */

extern void sslprf_free(sslprf_ctx */*c*/);

/* ---@sslprf_rand@ --- *
 *
 * Arguments:	@const gchash *hco, const gchash *hci@ = hash functions
 *		@const void *k@ = pointer to the key material
 *		@size_t ksz@ = size of the key material
 *		@const void *sd@ = pointer to the seed material
 *		@size_t sdsz@ = size of the seed material
 *
 * Returns:	Pointer to generic random number generator interface.
 *
 * Use:		Creates a generic generator which does TLS data expansion.
 */

extern grand *sslprf_rand(const gchash */*hco*/, const gchash */*hci*/,
			  const void */*k*/, size_t /*ksz*/,
			  const void */*sd*/, size_t /*sdsz*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
