/* -*-c-*-
 *
 * Simple linear congruential generator
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Notes on the linear congruential generator ------------------------*
 *
 * This pseudorandom number generator is simple, but has absolutely no
 * cryptographic strength whatever.  It may be used whenever random numbers
 * are required but cryptographic strength is not, for example when
 * generating numbers for use in primality tests.  To be honest, it's not
 * even particularly fast, although a certain amount of effort has been
 * expended on making it better than awfully slow.  To put things in
 * perspective, it can't quite spit bytes out as fast as OFB DES.  (Then
 * again, bytes aren't its natural output format.)  Its main use is probably
 * seeding a Fibonacci generator.
 *
 * There exists a fixed-point input @LCRAND_FIXEDPT@ -- when fed to the
 * generator it comes straight back out again.  All other inputs less than
 * the modulus are part of the same sequence of period %$p - 1$%.
 *
 * The generator has been tested for its statistical properties.  George
 * Marsaglia's Diehard tests give it a reasonably clean bill of health.
 *
 * The modulus %$p$% is chosen as the largest prime number less than
 * %$2^{32}$%.  The multiplier %$a$% and additive constant %$c$% are based on
 * the decimal expansions of %$\pi$% and %$e$%, with the additional
 * restriction that the multiplier must be a primitive element modulo %$p$%.
 * The fixed point value is determined as %$c / (1 - a) \bmod p$%.
 */

#ifndef CATACOMB_LCRAND_H
#define CATACOMB_LCRAND_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Constants ---------------------------------------------------------*/

#define LCRAND_P 4294967291u		/* Modulus for the generator */
#define LCRAND_A 314159265u		/* Multiplier (primitive mod @p@) */
#define LCRAND_C 271828183u		/* Additive constant */

#define LCRAND_FIXEDPT 3223959250u	/* Fixed point (only bad input) */

/*----- Functions provided ------------------------------------------------*/

/* --- @lcrand@ --- *
 *
 * Arguments:	@uint32 x@ = seed value
 *
 * Returns:	New state of the generator.
 *
 * Use:		Steps the generator.  Returns %$ax + c \bmod p$%.
 */

extern uint32 lcrand(uint32 /*x*/);

/* --- @lcrand_range@ --- *
 *
 * Arguments:	@uint32 *x@ = pointer to seed value (updated)
 *		@uint32 m@ = limit allowable
 *
 * Returns:	A uniformly distributed pseudorandom integer in the interval
 *		%$[0, m)$%.
 */

extern uint32 lcrand_range(uint32 */*x*/, uint32 /*m*/);

/* --- @lcrand_create@ --- *
 *
 * Arguments:	@uint32 x@ = initial seed
 *
 * Returns:	Pointer to a generic generator.
 *
 * Use:		Constructs a generic generator interface over a linear
 *		congruential generator.
 */

extern grand *lcrand_create(uint32 /*x*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
