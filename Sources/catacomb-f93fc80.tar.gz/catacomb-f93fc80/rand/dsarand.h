/* -*-c-*-
 *
 * Random number generator for DSA
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_DSARAND_H
#define CATACOMB_DSARAND_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <mLib/bits.h>

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

#ifndef CATACOMB_SHA_H
#  include "sha.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct dsarand {
  octet *p;				/* Pointer to seed (modified) */
  size_t sz;				/* Size of the seed buffer */
  unsigned passes;			/* Number of passes to make */
} dsarand;

/*----- Functions provided ------------------------------------------------*/

/* --- @dsarand_init@ --- *
 *
 * Arguments:	@dsarand *d@ = pointer to context
 *		@const void *p@ = pointer to seed buffer
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	---
 *
 * Use:		Initializes a DSA random number generator.
 */

extern void dsarand_init(dsarand */*d*/, const void */*p*/, size_t /*sz*/);

/* --- @dsarand_reseed@ --- *
 *
 * Arguments:	@dsarand *d@ = pointer to context
 *		@const void *p@ = pointer to seed buffer
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	---
 *
 * Use:		Initializes a DSA random number generator.
 */

extern void dsarand_reseed(dsarand */*d*/, const void */*p*/, size_t /*sz*/);

/* --- @dsarand_destroy@ --- *
 *
 * Arguments:	@dsarand *d@ = pointer to context
 *
 * Returns:	---
 *
 * Use:		Disposes of a DSA random number generation context.
 */

extern void dsarand_destroy(dsarand */*d*/);

/* --- @dsarand_fill@ --- *
 *
 * Arguments:	@dsarand *d@ = pointer to context
 *		@void *p@ = pointer to output buffer
 *		@size_t sz@ = size of output buffer
 *
 * Returns:	---
 *
 * Use:		Fills an output buffer with pseudorandom data.
 *
 *		Let %$p$% be the numerical value of the input buffer, and let
 *		%$b$% be the number of bytes required.  Let
 *		%$z = \lceil b / 20 \rceil$% be the number of SHA outputs
 *		required.  Then the output of pass %$n$% is
 *
 *		  %$P_n = \sum_{0 \le i < z} 2^{160i} SHA(p + nz + i)$%
 *							%${} \bmod 2^{8b}$%
 *
 *		and the actual result in the output buffer is the XOR of all
 *		of the output passes.
 *
 *		The DSA procedure for choosing @q@ involves two passes with
 *		%$z = 1$%; the procedure for choosing @p@ involves one pass
 *		with larger %$z$%.  This generalization of the DSA generation
 *		procedure is my own invention but it seems relatively sound.
 */

extern void dsarand_fill(dsarand */*d*/, void */*p*/, size_t /*sz*/);

/*----- Generic pseudorandom-number generator interface -------------------*/

/* --- Miscellaneous operations --- */

enum {
  DSARAND_PASSES = GRAND_SPECIFIC('D'),	/* @unsigned n@ */
  DSARAND_SEEDSZ,			/* No args */
  DSARAND_GETSEED			/* @void *buf@ */
};

/* --- @dsarand_create@ --- *
 *
 * Arguments:	@const void *p@ = pointer to seed buffer
 *		@size_t sz@ = size of seed buffer
 *
 * Returns:	Pointer to a generic generator.
 *
 * Use:		Constructs a generic generator interface to a DSA generator.
 */

extern grand *dsarand_create(const void */*p*/, size_t /*sz*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
