/* -*-c-*-
 *
 * The TLS pseudo-random function
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef CATACOMB_TLSPRF_H
#define CATACOMB_TLSPRF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef CATACOMB_GMAC_H
#  include "gmac.h"
#endif

#ifndef CATACOMB_GRAND_H
#  include "grand.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct tlsdx_ctx {
  gmac *k;				/* The MAC key to use */
  size_t hashsz;			/* Size of hash outputs */
  ghash *i, *o;				/* Inner and outer hash contexts */
  const octet *sd;			/* Pointer to seed buffer */
  size_t sdsz;				/* Size of the seed buffer */
  octet *p;				/* Pointer to buffered output */
  size_t sz;				/* Bytes remaining in buffer */
  octet *ai;				/* Pointer to inner result */
} tlsdx_ctx;

typedef struct tlsprf_ctx {
  tlsdx_ctx px, py;
} tlsprf_ctx;

/*----- The data expansion function ---------------------------------------*/

/* --- @tlsdx_init@ --- *
 *
 * Arguments:	@tlsdx_ctx *c@ = pointer to a context
 *		@gmac *m@ = pointer to a generic MAC instance
 *		@const void *sd@ = pointer to the seed block
 *		@size_t sdsz@ = size of the seed block
 *
 * Returns:	---
 *
 * Use:		Initializes a context for the TLS data expansion function.
 *		This doesn't take ownership of the MAC instance or the seed
 *		memory, nor does it allocate copies.
 */

extern void tlsdx_init(tlsdx_ctx */*c*/, gmac */*m*/,
		       const void */*sd*/, size_t /*sdsz*/);

/* --- @tlsdx_encrypt@ --- *
 *
 * Arguments:	@tlsdx_ctx *c@ = pointer to a context
 *		@const void *src@ = pointer to source data
 *		@void *dest@ = pointer to destination buffer
 *		@size_t sz@ = size of buffer
 *
 * Returns:	---
 *
 * Use:		Encrypts data using the TLS data expansion function.  If the
 *		destination pointer is null, the generator is spun and no
 *		output is produced; if the source pointer is null, raw output
 *		from the generator is written; otherwise, the source data is
 *		XORed with the generator output.
 */

extern void tlsdx_encrypt(tlsdx_ctx */*c*/, const void */*src*/,
			  void */*dest*/, size_t /*sz*/);

/* --- @tlsdx_free@ --- *
 *
 * Arguments:	@tlsdx_ctx *c@ = pointer to the context block
 *
 * Returns:	---
 *
 * Use:		Frees a context for the TLS data expansion function
 */

extern void tlsdx_free(tlsdx_ctx */*c*/);

/* ---@tlsdx_rand@ --- *
 *
 * Arguments:	@const gcmac *mc@ = MAC function to use
 *		@const void *k@ = pointer to the key material
 *		@size_t ksz@ = size of the key material
 *		@const void *sd@ = pointer to the seed material
 *		@size_t sdsz@ = size of the seed material
 *
 * Returns:	Pointer to generic random number generator interface.
 *
 * Use:		Creates a generic generator which does TLS data expansion.
 */

extern grand *tlsdx_rand(const gcmac */*mc*/,
			 const void */*k*/, size_t /*ksz*/,
			 const void */*sd*/, size_t /*sdsz*/);

/* --- The actual very paranoid PRF ---------------------------------------*/

/* --- @tlsprf_init@ --- *
 *
 * Arguments:	@tlsprf_ctx *c@ = pointer to context block
 *		@const gcmac *mcx, *mcy@ = left and right MAC functions
 *		@const void *k@ = pointer to the key material
 *		@size_t ksz@ = size of the key material
 *		@const void *sd@ = pointer to the seed material
 *		@size_t sdsz@ = size of the seed material
 *
 * Returns:	---
 *
 * Use:		Initializes a TLS PRF context.
 */

extern void tlsprf_init(tlsprf_ctx */*c*/,
			const gcmac */*mcx*/, const gcmac */*mcy*/,
			const void */*k*/, size_t /*ksz*/,
			const void */*sd*/, size_t /*sdsz*/);

/* --- @tlsprf_encrypt@ --- *
 *
 * Arguments:	@tlsprf_ctx *c@ = pointer to a context
 *		@const void *src@ = pointer to source data
 *		@void *dest@ = pointer to destination buffer
 *		@size_t sz@ = size of buffer
 *
 * Returns:	---
 *
 * Use:		Encrypts data using the TLS pseudo-random function.  If the
 *		destination pointer is null, the generator is spun and no
 *		output is produced; if the source pointer is null, raw output
 *		from the generator is written; otherwise, the source data is
 *		XORed with the generator output.
 */

extern void tlsprf_encrypt(tlsprf_ctx */*c*/,
			   const void */*src*/, void */*dest*/,
			   size_t /*sz*/);

/* --- @tlsprf_free@ --- *
 *
 * Arguments:	@tlsprf_ctx *c@ = pointer to a context
 *
 * Returns:	---
 *
 * Use:		Frees a TLS PRF context.
 */

extern void tlsprf_free(tlsprf_ctx */*c*/);

/* ---@tlsprf_rand@ --- *
 *
 * Arguments:	@const gcmac *mcx, *mcy@ = MAC function to use
 *		@const void *k@ = pointer to the key material
 *		@size_t ksz@ = size of the key material
 *		@const void *sd@ = pointer to the seed material
 *		@size_t sdsz@ = size of the seed material
 *
 * Returns:	Pointer to generic random number generator interface.
 *
 * Use:		Creates a generic generator which does TLS data expansion.
 */

extern grand *tlsprf_rand(const gcmac */*mcx*/, const gcmac */*mcy*/,
			  const void */*k*/, size_t /*ksz*/,
			  const void */*sd*/, size_t /*sdsz*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
