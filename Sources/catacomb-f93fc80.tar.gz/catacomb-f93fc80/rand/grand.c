/* -*-c-*-
 *
 * Generic interface to random number generators
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of Catacomb.
 *
 * Catacomb is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * Catacomb is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with Catacomb; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#include <mLib/bits.h>

#include "grand.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @grand_byte@ --- *
 *
 * Arguments:	@grand *r@ = pointet to generic generator
 *
 * Returns:	A uniformly-distributed pseudorandom integer in the interval
 *		%$[0, 256)$%.
 */

octet grand_byte(grand *r)
{
  if (r->ops->byte != grand_byte)
    return (r->ops->byte(r));
  else if (r->ops->word != grand_word)
    return (r->ops->word(r) & 0xff);
  else if (r->ops->fill != grand_fill) {
    octet o;
    r->ops->fill(r, &o, 1);
    return (o);
  } else
    return (grand_range(r, 256));
}

/* --- @grand_word@ --- *
 *
 * Arguments:	@grand *r@ = pointet to generic generator
 *
 * Returns:	A uniformly-distributed pseudorandom integer in the interval
 *		%$[0, 2^{32})$%.
 */

uint32 grand_word(grand *r)
{
  if (r->ops->word != grand_word)
    return (r->ops->word(r));
  else {
    octet b[4];
    grand_fill(r, b, sizeof(b));
    return (LOAD32(b));
  }
}

/* --- @grand_range@ --- *
 *
 * Arguments:	@grand *r@ = pointet to generic generator
 *		@uint32 l@ = limit for acceptable results
 *
 * Returns:	A uniformly-distributed pseudorandom integer in the interval
 *		%$[0, l)$%.
 */

uint32 grand_range(grand *r, uint32 l)
{
  if (r->ops->range != grand_range)
    return (r->ops->range(r, l));
  else {
    uint32 m, z;
    uint32 (*w)(grand */*r*/);
    uint32 x;

    /* --- Decide where to get data from --- *
     *
     * The choice of %$2^{32} - 1$% as a limit when using @grand_word@ isn't
     * wonderful, but working with %$2^{32}$% is awkward and the loss of a
     * few return values isn't significant.  The algorithm below still
     * successfully returns uniformly distributed results.
     */

    if (r->ops->max) {
      w = r->ops->raw;
      m = r->ops->max;
    } else {
      w = grand_word;
      m = 0xffffffff;
    }

    /* --- Work out maximum acceptable return value --- *
     *
     * This will be the highest multiple of @l@ less than @m@.
     */

    z = m - (m % l);

    /* --- Generate numbers until something acceptable is found --- *
     *
     * This will require an expected number of attempts less than 2.
     */

    do x = w(r); while (x >= z);
    return (x % l);
  }
}

/* --- @grand_fill@ --- *
 *
 * Arguments:	@grand *r@ = pointet to generic generator
 *		@void *p@ = pointer to a buffer
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	---
 *
 * Use:		Fills a buffer with uniformly distributed pseudorandom bytes
 *		(see @grand_byte@).
 */

void grand_fill(grand *r, void *p, size_t sz)
{
  if (r->ops->fill != grand_fill)
    r->ops->fill(r, p, sz);
  else {
    octet *q = p;
    while (sz) {
      *q++ = r->ops->byte(r);
      sz--;
    }
  }
}

/*----- That's all, folks -------------------------------------------------*/
