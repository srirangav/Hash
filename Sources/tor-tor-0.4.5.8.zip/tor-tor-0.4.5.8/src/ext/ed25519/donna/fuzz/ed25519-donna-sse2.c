#define ED25519_SUFFIX _sse2
#define ED25519_SSE2
#include "../ed25519.c"
