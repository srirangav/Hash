/* Added for Tor. */
#include "lib/cc/torint.h"
#define crypto_uint32 uint32_t
