@dir /core/proto
@brief core/proto: Protocol encoding/decoding

These functions should (but do not always) exist at a lower level than most
of the rest of core.

