Filename:	README_Reference.txt
Author:		Ronald L. Rivest
Date:		8/31/08

This directory (Reference_Implementation) contains the
required reference implementation for our NIST SHA-3
submission, "MD6".

The files included here are:
    md6.h
    md6_compress.c
    md6_mode.c
    md6_nist.h
    md6_nist.c
    inttypes.h
    stdint.h
