/* -*-c-*-
 *
 * Calculating cyclic redundancy values (non-cryptographic!)
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_CRC32_H
#define MLIB_CRC32_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_BITS_H
#  include "bits.h"
#endif

/*----- External values ---------------------------------------------------*/

extern uint32 crc32_table[256];

/*----- Macros ------------------------------------------------------------*/

/* --- @CRC32@ --- *
 *
 * Arguments:	@uint32 result@ = where to put the result
 *		@uint32 crc@ = carryover from previous call, or zero
 *		@void *buf@ = pointer to buffer to check
 *		@size_t sz@ = size of the buffer
 *
 * Use:		A restartable CRC calculator wrapped up in a macro.
 */

#define CRC32(result, crc, buf, sz) do {				\
  const octet *_p = (const octet *)(buf);				\
  const octet *_l = _p + (sz);						\
  uint32 _crc = U32(~(crc));						\
									\
  while (_p < _l)							\
    _crc = (_crc >> 8) ^ crc32_table[U8(*_p++ ^ _crc)];			\
  (result) = U32(~_crc);						\
} while (0)

/*----- Functions provided ------------------------------------------------*/

/* --- @crc32@ --- *
 *
 * Arguments:	@uint32 crc@ = carryover from previous call, or zero
 *		@const void *buf@ = pointer to buffer to check
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	The CRC updated by the new buffer.
 *
 * Use:		A restartable CRC calculator.  This is just a function
 *		wrapper for the macro version.
 */

extern uint32 crc32(uint32 /*crc*/, const void */*buf*/, size_t /*sz*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
