#! /usr/bin/python
### -*-python-*-
###
### Generate test vectors for universal hashing.

MOD = 0x104c11db7

def gfmul(x, y):
  a = 0
  while y > 0:
    if y & 1: a ^= x
    if x & 0x80000000: x = (x << 1) ^ MOD
    else: x <<= 1
    y >>= 1
  return a

def hashtest(k, m):
  h = k
  for ch in m: h = gfmul(h ^ ord(ch), k)
  print '  0x%08x "%s" 0x%08x;' % (k, m, h)

print '''\
### Test vectors for universal hashing
###   [generated]

hash {'''

for k, m in [(0x00000000, 'anything you like'),
             (0x12345678, 'an exaple test string'),
             (0xb8a171f0, 'The quick brown fox jumps over the lazy dog.'),
             (0x2940521b, 'A man, a plan, a canal: Panama!')]:
  hashtest(k, m)

k, m = 0x94b22a73, 0xbb7b1fef
for i in xrange(48):
  hashtest(k, "If we don't succeed, we run the risk of failure.")
  k = gfmul(k, m)

print '}'
