/* -*-c-*-
 *
 * Test driver for universal hashing
 *
 * (c) 2009 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>

#include "unihash.h"
#include "testrig.h"

/*----- Main code ---------------------------------------------------------*/

static int verify(dstr *v)
{
  unihash_info ui;
  uint32 k;
  uint32 h, hh;
  size_t n;
  int i, c;
  const char *p;
  int ok = 1;

  static const int step[] = { 0, 1, 5, 6, 7, 8, 23, -1 };

  /* --- Set up for using this key --- */

  k = *(uint32 *)v[0].buf;
  h = *(uint32 *)v[2].buf;
  unihash_setkey(&ui, k);

  /* --- Hash the data a lot --- */

  for (i = 0; step[i] >= 0; i++) {
    c = step[i];
    if (!c)
      hh = unihash(&ui, v[1].buf, v[1].len);
    else {
      hh = UNIHASH_INIT(&ui);
      p = v[1].buf;
      n = v[1].len;
      while (n) {
	if (c > n) c = n;
	hh = unihash_hash(&ui, hh, p, c);
	p += c;
	n -= c;
      }
    }
    if (h != hh) {
      ok = 0;
      fprintf(stderr, "\nunihash failed\n");
      fprintf(stderr, "	 key = %08lx\n", (unsigned long)k);
      fprintf(stderr, "	 data = %s\n", v[1].buf);
      fprintf(stderr, "	 step = %d\n", step[i]);
      fprintf(stderr, "	 expected = %08lx\n", (unsigned long)h);
      fprintf(stderr, "	 computed = %08lx\n", (unsigned long)hh);
    }
  }
  return (ok);
}

static const test_chunk tests[] = {
  { "hash", verify, { &type_uint32, &type_string, &type_uint32 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  test_run(argc, argv, tests, "unihash.in");
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
