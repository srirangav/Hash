/* -*-c-*-
 *
 * Calculating cyclic redundancy values (non-cryptographic!)
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

/* --- ANSI headers --- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* --- Local headers --- */

#include "bits.h"
#include "crc32.h"

/*----- Functionc provided ------------------------------------------------*/

/* --- @crc32@ --- *
 *
 * Arguments:	@uint32 crc@ = carryover from previous call, or zero
 *		@const void *buf@ = pointer to buffer to check
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	The CRC updated by the new buffer.
 *
 * Use:		A restartable CRC calculator.  This is just a function
 *		wrapper for the macro version.
 */

uint32 crc32(uint32 crc, const void *buf, size_t sz)
{
  uint32 c;
  CRC32(c, crc, buf, sz);
  return (c);
}

/*----- Test driver -------------------------------------------------------*/

#ifdef TEST_RIG

#include <stdio.h>

int main(void)
{
  uint32 crc = 0;
  char buf[BUFSIZ];
  int r;

  do {
    r = fread(buf, 1, sizeof(buf), stdin);
    if (r > 0)
      crc = crc32(crc, buf, r);
  } while (r == sizeof(buf));

  printf("crc32(stdin) = %08lx\n", (unsigned long)crc);
  return (0);
}

#endif

/*----- That's all, folks -------------------------------------------------*/
