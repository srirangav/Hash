/* -*-c-*-
 *
 * Build CRC tables
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "config.h"

#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mdwopt.h"
#include "quis.h"
#include "report.h"

/*----- Static variables --------------------------------------------------*/

static unsigned long poly = 0;
static const char *guard = 0;
static unsigned bits = 0;
static unsigned chunk = 8;
static const char *file = 0;
static unsigned flags = 0;
static const char *sym = 0;
static const char *type = 0;
static const char *inc = 0;
static FILE *fp;

#define f_bogus 1u
#define f_ctab 2u
#define f_reverse 4u

#define BSCOL 72

/*----- Main code ---------------------------------------------------------*/

static unsigned long getint(const char *p, unsigned long max,
			    const char *what)
{
  char *pp;
  unsigned long x = strtoul(p, &pp, 0);
  if (*pp || (max && x > max))
    die(EXIT_FAILURE, "bad %s `%s'", what, p);
  return (x);
}

static void version(FILE *fp)
{
  pquis(fp, "$, mLib version " VERSION "\n");
}

static void usage(FILE *fp)
{
  pquis(fp, "Usage: $ [-cr] [-o FILE] [-g GUARD] [-s SYM] [-i HEADER]\n\
	[-t TYPE] [-b BITS] [-B BITS] [-p POLY]\n");
}

static void help(FILE *fp)
{
  version(fp);
  putc('\n', stdout);
  usage(fp);
  fputs("\n\
Emits a table containing precomuted values for CRC algorithms.  A number\n\
of options are provided:\n\
\n\
-h, --help		Show this help text.\n\
-v, --version		Show the program's version number.\n\
-u, --usage		Show a terse usage message.\n\
\n\
-c, --c-source		Emit a C source file rather than a header.\n\
-b, --bits=BITS		Emit a table for a BITS bits-wide CRC.\n\
-B, --bit-chunk=BITS	Emit a table to process BITS bits at a time.\n\
-p, --polynomial=POLY	Use the POLY as the dividing polynomial.\n\
-r, --reverse		Create a `reversed' CRC table.\n\
-g, --guard=GUARD	Use GUARD as a multiple-inclusion guard constant.\n\
-i, --include=HEADER	Include HEADER at top of C source file.\n\
-s, --symbol=SYM	Name the generated table SYM.\n\
-t, --type=TYPE		Give the table entries type TYPE in C source.\n\
-o, --output=FILE	Write the output to FILE.\n\
", stdout);
}

unsigned long reflect(unsigned long x, unsigned b)
{
  unsigned long y = 0;
  unsigned long xm, ym;
  unsigned i;
  if (!(flags & f_reverse))
    return (x);
  xm = 1;
  ym = 1u << (b - 1);
  for (i = 0; i < b; i++) {
    if (x & xm)
      y |= ym;
    xm <<= 1;
    ym >>= 1;
  }
  return (y);
}

int main(int argc, char *argv[])
{
  unsigned n, t, nw;
  unsigned max, i;
  unsigned long mask;

  ego(argv[0]);

  for (;;) {
    static struct option opts[] = {
      { "help",		0,		0,	'h' },
      { "version",	0,		0,	'v' },
      { "usage",	0,		0,	'u' },

      { "output",	OPTF_ARGREQ,	0,	'o' },
      { "c-source",	0,		0,	'c' },
      { "symbol",	OPTF_ARGREQ,	0,	's' },
      { "type",		OPTF_ARGREQ,	0,	't' },
      { "include",	OPTF_ARGREQ,	0,	'i' },
      { "guard",	OPTF_ARGREQ,	0,	'g' },

      { "bits",		OPTF_ARGREQ,	0,	'b' },
      { "bit-chunk",	OPTF_ARGREQ,	0,	'B' },
      { "polynomial",	OPTF_ARGREQ,	0,	'p' },
      { "reverse",	0,		0,	'r' },

      { 0,		0,		0,	0 }
    };
    int i = mdwopt(argc, argv, "hvu o:cs:t:i:g: b:B:p:r", opts, 0, 0, 0);

    if (i < 0)
      break;
    switch (i) {
      case 'h':
	help(stdout);
	exit(0);
      case 'v':
	version(stdout);
	exit(0);
      case 'u':
	usage(stdout);
	exit(0);

      case 'o':
	file = optarg;
	break;
      case 'c':
	flags |= f_ctab;
	break;
      case 's':
	sym = optarg;
	break;
      case 't':
	type = optarg;
	break;
      case 'i':
	inc = optarg;
	break;
      case 'g':
	guard = optarg;
	break;

      case 'b':
	bits = getint(optarg, 32, "CRC width");
	break;
      case 'B':
	chunk = getint(optarg, 32, "chunk size");
	break;
      case 'p':
	poly = getint(optarg, 0xffffffff, "CRC poly");
	break;
      case 'r':
	flags |= f_reverse;
	break;

      default:
	flags |= f_bogus;
	break;
    }
  }
  if ((flags & f_bogus) || optind != argc) {
    usage(stderr);
    exit(EXIT_FAILURE);
  }

  /* --- Sort out the various parameters --- */

  if (!poly) {
    switch (bits) {
      case 16:
	if (flags & f_reverse)
	  poly = 0x8408;
	else
	  poly = 0x1021;
	break;
      case 32:
	poly = 0x04c11db7;
	flags |= f_reverse;
	bits = 32;
	break;
      case 0:
	die(EXIT_FAILURE, "no polynomial or bit width set");
	break;
      default:
	die(EXIT_FAILURE, "no standard polynomials for %u bits", bits);
	break;
    }
  }

  if (!bits) {
    unsigned long x = poly;
    while (x > 1) {
      x >>= 8;
      bits += 8;
    }
  }
  nw = (bits + 3)/4;

  if ((flags & f_ctab) && !type)
    type = bits > 16 ? "unsigned long" : "unsigned short";

  /* --- Start output --- */

  if (!file)
    fp = stdout;
  else {
    if (!(flags & f_ctab) && !guard) {
      char *p;
      const char *q;
      if ((p = malloc(strlen(file) + 1)) == 0)
	die(EXIT_FAILURE, "not enough memory");
      guard = p;
      for (q = file; *q; p++, q++) {
	if (isalnum((unsigned char)*q))
	  *p = toupper((unsigned char)*q);
	else
	  *p = '_';
      }
      *p++ = 0;
    }
    if ((fp = fopen(file, "w")) == 0)
      die(EXIT_FAILURE, "couldn't write `%s': %s", file, strerror(errno));
  }

  if (!sym)
    sym = (flags & f_ctab) ? "crctab" : "CRC_TAB";

  /* --- Dump out the first chunk of the file --- */

  fprintf(fp, "\
/* -*-c-*-\n\
 *\n\
 * CRC table (poly = %0*lx%s) [generated]\n\
 */\n\
\n",
	  nw, poly, flags & f_reverse ? "; reversed" : "");

  if (flags & f_ctab) {
    if (inc)
      fprintf(fp, "#include \"%s\"\n\n", inc);
    fprintf(fp, "%s %s[] = {\n", type, sym);
  } else {
    int n;
    if (guard)
      fprintf(fp, "#ifndef %s\n#define %s\n\n", guard, guard);
    n = fprintf(fp, "#define %s {", sym);
    while (n < BSCOL) {
      fputc('\t', fp);
      n = (n + 8) & ~7;
    }
    fputc('\n', fp);
  }

  /* --- Sort out the line width --- */

  n = 1;
  while (2 + n * (nw + 4) < BSCOL)
    n <<= 1;
  n >>= 1;
  max = 1 << chunk;
  if (n > max)
    n = max;
  t = 0;
  while (((1 + n * (nw + 4)) & ~7) + 8 * t < BSCOL)
    t++;

  /* --- Start grinding --- */

  mask = 0xffffffff >> (32 - bits);
  fputc(' ', fp);
  for (i = 0; i < max; i++) {
    unsigned long x, y, z;
    unsigned j;
    unsigned ni, nn;

    x = reflect(i, chunk);
    y = 0;
    nn = chunk;
    while (nn) {
      ni = bits;
      if (ni > nn)
	ni = nn;
      z = (x >> (nn - ni)) & (0xffffffff >> (32 - ni));
      y ^= z << (bits - ni);
      for (j = 0; j < ni; j++)
	y = ((y << 1) ^ (y & (1 << (bits - 1)) ? poly : 0)) & mask;
      nn -= ni;
    }
    x = reflect(y, bits);

    fprintf(fp, " 0x%0*lx", nw, x);
    if (i == max - 1) {
      if (!(flags & f_ctab) && ((2 + n * (nw + 4)) & ~7) + 8 * t < BSCOL)
	fputc('\t', fp);
    } else
      fputc(',', fp);
    if (i + 1 == max || (i + 1)%n == 0) {
      if (!(flags & f_ctab)) {
	for (j = 0; j < t; j++)
	  fputc('\t', fp);
	fputc('\\', fp);
      }
      fputc('\n', fp);
      if (i + 1 != max)
	fputc(' ', fp);
    }
  }

  /* --- Done --- */

  fputs(flags & f_ctab ? "};\n" : "}\n", fp);
  if (!(flags & f_ctab) && guard)
    fputs("\n#endif\n", fp);

  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
