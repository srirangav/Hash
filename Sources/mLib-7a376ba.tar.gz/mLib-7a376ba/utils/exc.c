/* -*-c-*-
 *
 * Structured exception handling in C
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>

#include "exc.h"

/*----- Global variables --------------------------------------------------*/

__exc_hnd *__exc_list = 0;

/*----- Functions ---------------------------------------------------------*/

/* --- @duff@ --- *
 *
 * Arguments:	@exc_extype type@ = type of duff exception
 *		@exc_exval val@ = extra data supplied
 *
 * Returns:	Doesn't
 *
 * Use:		Default handler when everything goes wrong.
 */

static void duff(exc_extype type, exc_exval val)
{
  fprintf(stderr, "fatal error: uncaught exception (type = %lx)\n", type);
  abort();
}

/* --- @duffproc@ --- *
 *
 * Current handler when there are no more exceptions left.
 */

static exc__uncaught duffproc = duff;

/* --- @exc_uncaught@ --- *
 *
 * Arguments:	@void (*proc)(exc_extype type, exc_exval val) = new handler
 *
 * Returns:	Pointer to the old handler value.
 *
 * Use:		Sets the handler for uncaught exceptions.
 */

exc__uncaught exc_uncaught(exc__uncaught proc)
{
  exc__uncaught p = duffproc;
  if (proc)
    duffproc = proc;
  return (p);
}

/* --- @__exc_throw@ --- *
 *
 * Arguments:	@exc_extype type@ = type of exception to throw
 *
 * Returns:	Doesn't
 *
 * Use:		NOT FOR USER CONSUMPTION.  Reads an appropriate exception
 *		value and throws an exception.
 */

void __exc_throw(exc_extype type, ...)
{
  va_list ap;
  exc_exval v;

  va_start(ap, type);
  switch (type & 0xC0) {
    case EXC_NOVAL:
      v.i = 0;
      break;
    case EXC_INTVAL:
      v.i = va_arg(ap, int);
      break;
    case EXC_PTRVAL:
      v.p = va_arg(ap, void *);
      break;
    case EXC_STRVAL:
      v.s = va_arg(ap, char *);
      break;
  }
  va_end(ap);
  __exc_rethrow(type, v);
}

/* --- @__exc_rethrow@ --- *
 *
 * Arguments:	@exc_extype type@ = type of exception to throw
 *		@exc_exval val@ = value of exception to throw
 *
 * Returns:	Doesn't
 *
 * Use:		NOT FOR USER CONSUMPTION.  Does the donkey-work of raising
 *		an exception.
 */

void __exc_rethrow(exc_extype type, exc_exval val)
{
  __exc_hnd *p = __exc_list;
  if (!p)
    duffproc(type, val);
  p->type = type;
  p->val = val;
  __exc_list = p->next;
  longjmp(p->buf, type);
}

/*----- That's all, folks -------------------------------------------------*/
