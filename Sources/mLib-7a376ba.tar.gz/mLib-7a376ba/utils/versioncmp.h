/* -*-c-*-
 *
 * Compare version numbers using the Debian algorithm
 *
 * (c) 2007 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_VERSIONCMP_H
#define MLIB_VERSIONCMP_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Functions provided ------------------------------------------------*/

/* --- @versioncmp@ --- *
 *
 * Arguments:	@const char *va, *vb@ = two version strings
 *
 * Returns:	Less than, equal to, or greater than zero, according to
 *		whether @va@ is less than, equal to, or greater than @vb@.
 *
 * Use:		Compares version number strings.
 *
 *		The algorithm is an extension of the Debian version
 *		comparison algorithm.  A version number consists of three
 *		components:
 *
 *		  [EPOCH :] MAIN [- SUB]
 *
 *		The MAIN part may contain colons or hyphens if there is an
 *		EPOCH or SUB, respectively.  Version strings are compared
 *		componentwise: first epochs, then main parts, and finally
 *		subparts.
 *
 *		The component comparison is done as follows.  First, the
 *		initial subsequence of nondigit characters is extracted from
 *		each string, and these are compared lexicographically, using
 *		ASCII ordering, except that letters precede non-letters.  If
 *		both are the same, an initial sequence of digits is extracted
 *		from the remaining parts of the version strings, and these
 *		are compared numerically (an empty sequence being considered
 *		to have the value zero).  This process is repeated until we
 *		have a winner or until both strings are exhausted.
 */

extern int versioncmp(const char */*va*/, const char */*vb*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
