/* -*-c-*-
 *
 * Functions for hacking with strings
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_STR_H
#define MLIB_STR_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

/*----- Functions provided ------------------------------------------------*/

/* --- @str_qword@ --- *
 *
 * Arguments:	@char **pp@ = address of pointer into string
 *		@unsigned f@ = various flags
 *
 * Returns:	Pointer to the next space-separated possibly-quoted word from
 *		the string, or null.
 *
 * Use:		Fetches the next word from a string.  If the flag
 *		@STRF_QUOTE@ is set, the `\' character acts as an escape, and
 *		single and double quotes protect whitespace.
 */

#define STRF_QUOTE 1u

extern char *str_qword(char **/*pp*/, unsigned /*f*/);

/* --- @str_qsplit@ --- *
 *
 * Arguments:	@char *p@ = pointer to string
 *		@char *v[]@ = pointer to array to fill in
 *		@size_t c@ = count of strings to fill in
 *		@char **rest@ = where to store the remainder of the string
 *		@unsigned f@ = flags for @str_qword@
 *
 * Returns:	Number of strings filled in.
 *
 * Use:		Fills an array with pointers to the individual words of a
 *		string.  The string is modified in place to contain zero
 *		bytes at the word boundaries, and the words have leading
 *		and trailing space stripped off.  No more than @c@ words
 *		are read; the actual number is returned as the value of the
 *		function.  Unused slots in the array are populated with
 *		null bytes.  If there's any string left, the address of the
 *		remainder is stored in @rest@ (if it's non-null); otherwise
 *		@rest@ is set to a null pointer.
 */

extern size_t str_qsplit(char */*p*/, char */*v*/[], size_t /*c*/,
			 char **/*rest*/, unsigned /*f*/);

/* --- @str_getword@ --- *
 *
 * Arguments:	@char **pp@ = address of pointer into string
 *
 * Returns:	Pointer to the next space-separated word from the string,
 *		or null.
 *
 * Use:		Parses off space-separated words from a string.  This is a
 *		compatibility veneer over @str_qword@.
 */

extern char *str_getword(char **/*pp*/);

/* --- @str_split@ --- *
 *
 * Arguments:	@char *p@ = pointer to string
 *		@char *v[]@ = pointer to array to fill in
 *		@size_t c@ = count of strings to fill in
 *		@char **rest@ = where to store the remainder of the string
 *
 * Returns:	Number of strings filled in.
 *
 * Use:		Fills an array with pointers to the individual words of a
 *		string.  This is a compatibility veneer over @str_qsplit@.
 */

extern size_t str_split(char */*p*/, char */*v*/[],
			size_t /*c*/, char **/*rest*/);

/* --- @str_matchx@ --- *
 *
 * Arguments:	@const char *p@ = pointer to pattern string
 *		@const char *s@ = string to compare with
 *		@unsigned f@ = various flags
 *
 * Returns:	Nonzero if the pattern matches the string.
 *
 * Use:		Does simple wildcard matching.  This is quite nasty and more
 *		than a little slow.  Supports metacharacters `*', `?' and
 *		'['.
 */

#define STRF_PREFIX 1u			/* Accept if @s@ is exhausted during
					 *   the attempted match */

extern int str_matchx(const char */*p*/, const char */*s*/, unsigned /*f*/);

/* --- @str_match@ --- *
 *
 * Arguments:	@const char *p@ = pointer to pattern string
 *		@const char *s@ = string to compare with
 *
 * Returns:	Nonzero if the pattern matches the string.
 *
 * Use:		Does simple wildcard matching.  Equivalent to @str_matchx@
 *		with zero flags word.
 */

extern int str_match(const char */*p*/, const char */*s*/);

/* --- @str_sanitize@ --- *
 *
 * Arguments:	@char *d@ = destination buffer
 *		@const char *p@ = pointer to source string
 *		@size_t sz@ = size of destination buffer
 *
 * Returns:	---
 *
 * Use:		Writes a string into a buffer, being careful not to overflow
 *		the buffer, to null terminate the result, and to prevent
 *		nasty nonprintable characters ending up in the buffer.
 */

extern void str_sanitize(char */*d*/, const char */*p*/, size_t /*sz*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
