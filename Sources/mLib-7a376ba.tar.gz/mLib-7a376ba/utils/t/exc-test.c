#include <stdio.h>
#include "exc.h"

void func(void)
{
  printf("cabbage\n");
  TRY {
    printf("dibble\n");
    THROW(EXC_FAIL, "excession");
    printf("can't see me\n");
  } CATCH switch (exc_type) {
    case 1:
      printf("exc type 1 (not possible)\n");
      break;
    case EXC_FAIL:
      printf("exc type 2 (%s)\n", exc_s);
      break;
    default:
      RETHROW;
  } END_TRY;

  printf("fennel\n");
  THROW(EXC_ERRNO, 53);
}

int main(void)
{
  printf("apple\n");
  TRY {
    printf("banana\n");
    func();
    printf("can't see me\n");
  } CATCH switch (exc_type) {
    default:
      printf("%lu exception (val = %i)\n", exc_type, exc_i);
      break;
  } END_TRY;
  printf("hello! __exc_list = %p\n", (void *)__exc_list);

  return (0);
}
