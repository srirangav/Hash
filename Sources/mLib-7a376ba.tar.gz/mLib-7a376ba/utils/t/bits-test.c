/* -*-c-*-
 *
 * Test rig for bits header
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "bits.h"
#include "testrig.h"

/*----- Main code ---------------------------------------------------------*/

#define TSHIFT(OP)							\
									\
static int t##OP(dstr *v)						\
{									\
  kludge64 x, xx, y;							\
  unsigned s = *(unsigned *)v[1].buf;					\
  int ok = 1;								\
									\
  LOAD64_(x, v[0].buf);							\
  LOAD64_(xx, v[2].buf);						\
  y = x;								\
  OP##64_(y, y, s);							\
  if (CMP64(y, !=, xx)) {						\
    ok = 0;								\
    fprintf(stderr,							\
	    "\nbad: %08x:%08x " #OP " %u != %08x:%08x [%08x:%08x]\n",	\
	    HI64(x), LO64(x), s, HI64(y), LO64(y), HI64(xx), LO64(xx));	\
  }									\
  return (ok);								\
}

#define TARITH(OP)							\
									\
static int t##OP(dstr *v)						\
{									\
  kludge64 x, y, xx, yy;						\
  int ok = 1;								\
									\
  LOAD64_(x, v[0].buf);							\
  LOAD64_(y, v[1].buf);							\
  LOAD64_(xx, v[2].buf);						\
  yy = x;								\
  OP##64(yy, yy, y);							\
  if (CMP64(yy, !=, xx)) {						\
    ok = 0;								\
    fprintf(stderr,							\
	    "\nbad: %08x:%08x " #OP " %08x:%08x != %08x:%08x "		\
	    "[%08x:%08x]\n",						\
	    HI64(x), LO64(x), HI64(y), LO64(y),				\
	    HI64(yy), LO64(yy), HI64(xx), LO64(xx));			\
  }									\
  return (ok);								\
}

TSHIFT(LSL)
TSHIFT(LSR)
TSHIFT(ROL)
TSHIFT(ROR)
TARITH(ADD)
TARITH(SUB)

static test_chunk tests[] = {
  { "lsl64", tLSL, { &type_hex, &type_int, &type_hex, 0 } },
  { "lsr64", tLSR, { &type_hex, &type_int, &type_hex, 0 } },
  { "rol64", tROL, { &type_hex, &type_int, &type_hex, 0 } },
  { "ror64", tROR, { &type_hex, &type_int, &type_hex, 0 } },
  { "add64", tADD, { &type_hex, &type_hex, &type_hex, 0 } },
  { "sub64", tSUB, { &type_hex, &type_hex, &type_hex, 0 } },
  { 0, 0, { 0 } }
};

int main(int argc, char *argv[])
{
  test_run(argc, argv, tests, SRCDIR "/t/bits.tests");
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
