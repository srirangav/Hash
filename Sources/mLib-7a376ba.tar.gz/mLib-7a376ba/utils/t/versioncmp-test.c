/* -*-c-*-
 *
 * Test rig for versioncmp
 *
 * (c) 2008 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#include "testrig.h"
#include "versioncmp.h"

static int t_vcmp(dstr *v)
{
  int ok = 1;
  int rc = versioncmp(v[0].buf, v[1].buf);
  if (rc != *(int *)v[2].buf) {
    fprintf(stderr, "\nversioncmp(%s, %s) returns %d != %d\n",
	    v[0].buf, v[1].buf, rc, *(int *)v[2].buf);
    ok = 0;
  }
  return (ok);
}

static const test_chunk tests[] = {
  { "versioncmp", t_vcmp, { &type_string, &type_string, &type_int } },
  { 0 }
};

int main(int argc, char *argv[])
  { test_run(argc, argv, tests, SRCDIR "/versioncmp.in"); return (1); }

/*----- That's all, folks -------------------------------------------------*/
