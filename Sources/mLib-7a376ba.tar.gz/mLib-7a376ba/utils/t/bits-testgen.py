#! /usr/bin/python
### -*-python-*-
###
### Generate input script and expected output for bit manipulation,
### particularly 64-bit arithmetic.

import sys as SYS
import random as R

NVEC = 64
WD = 64
LIMIT = 1 << WD
MASK = LIMIT - 1

SYS.argv.pop()
def arg(default = None):
  if len(SYS.argv):
    return SYS.argv.pop()
  else:
    return default

R.seed(None)
SEED = int(arg(R.randrange(0, 1 << 32)))
R.seed(SEED)

print '### Test vectors for 64-bit arithmetic macros'
print '###   [generated; seed = 0x%08x]' % SEED

def rol(x, n): return ((x << n) | (x >> (WD - n))) & MASK
def ror(x, n): return ((x >> n) | (x << (WD - n))) & MASK
def put(x): return '%0*x' % (WD/4, x)

for name, func in [('lsl', lambda x, n: x << n),
                   ('lsr', lambda x, n: x >> n),
                   ('rol', rol),
                   ('ror', ror)]:
  print '\n%s64 {' % name
  for i in xrange(NVEC):
    x = R.randrange(LIMIT)
    sh = R.randrange(0, 70) & 63
    print '  %s %2d %s;' % (put(x), sh, put(func(x, sh) & MASK))
  for i in xrange(4):
    x = R.randrange(LIMIT)
    sh = 32
    print '  %s %2d %s;' % (put(x), sh, put(func(x, sh) & MASK))
  print '}'

for name, func in [('add', lambda x, y: x + y),
                   ('sub', lambda x, y: x - y)]:
  print '\n%s64 {' % name
  for i in xrange(NVEC):
    x = R.randrange(LIMIT)
    y = R.randrange(LIMIT)
    print '  %s %s %s;' % (put(x), put(y), put(func(x, y) & MASK))
  print '}'
