/* -*-c-*-
 *
 * Generic test driver
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_TESTER_H
#define MLIB_TESTER_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#ifndef MLIB_BITS_H
#  include "bits.h"
#endif

#ifndef MLIB_DSTR_H
#  include "dstr.h"
#endif

#ifndef MLIB_MACROS_H
#  include "macros.h"
#endif

/*----- Magical numbers ---------------------------------------------------*/

#define TEST_FIELDMAX 16		/* Maximum fields in a line */

/*----- Data structures ---------------------------------------------------*/

typedef struct test_results {
  unsigned tests, failed;
} test_results;

/* --- Test field definition --- */

typedef struct test_type {
  void (*cvt)(const char *buf, dstr *d); /* Conversion function */
  void (*dump)(dstr *d, FILE *fp);	/* Dump function */
} test_type;

/* --- Test chunk definition --- */

typedef struct test_chunk {
  const char *name;			/* Name of this chunk */
  int (*test)(dstr /*dv*/[]);		/* Test verification function */
  const test_type *f[TEST_FIELDMAX];	/* Field definitions */
} test_chunk;

typedef struct test_suite {
  const char *name;			/* Name of this suite */
  const test_chunk *chunks;		/* Chunks contained in this suite */
} test_suite;

/*----- Predefined data types ---------------------------------------------*/

extern const test_type type_hex;
extern const test_type type_string;
extern const test_type type_int;
extern const test_type type_long;
extern const test_type type_ulong;
extern const test_type type_uint32;

/*----- Functions provided ------------------------------------------------*/

/* --- @test_do@ --- *
 *
 * Arguments:	@const test_suite suites[]@ = pointer to suite definitions
 *		@FILE *fp@ = test vector file, ready opened
 *		@test_results *results@ = where to put results
 *
 * Returns:	Negative if something bad happened, or the number of
 *		failures.
 *
 * Use:		Runs a collection of tests against a file of test vectors and
 *		reports the results.
 */

extern int test_do(const test_suite /*suite*/[],
		   FILE */*fp*/,
		   test_results */*results*/);

/* --- @test_run@ --- *
 *
 * Arguments:	@int argc@ = number of command line arguments
 *		@char *argv[]@ = pointer to command line arguments
 *		@const test_chunk chunk[]@ = pointer to chunk definitions
 *		@const char *def@ = name of default test vector file
 *
 * Returns:	Doesn't.
 *
 * Use:		Runs a set of test vectors to ensure that a component is
 *		working properly.
 */

extern void NORETURN
  test_run(int /*argc*/, char */*argv*/[],
	   const test_chunk /*chunk*/[],
	   const char */*def*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
