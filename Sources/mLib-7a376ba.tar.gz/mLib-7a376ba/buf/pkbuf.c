/* -*-c-*-
 *
 * Simple packet buffering
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "alloc.h"
#include "arena.h"
#include "pkbuf.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @pkbuf_flush@ --- *
 *
 * Arguments:	@pkbuf *pk@ = pointer to buffer block
 *		@octet *p@ = pointer to where to start searching
 *		@size_t len@ = length of new material added
 *
 * Returns:	---
 *
 * Use:		Flushes any complete packets in a packet buffer.  New
 *		material is assumed to have been added starting at @p@.  If
 *		@p@ is null, then the scan starts at the beginning of the
 *		buffer, and the size of data already in the buffer is used in
 *		place of @len@.
 *
 *		It is assumed that the buffer is initially enabled.  You
 *		shouldn't be contributing data to a disabled buffer anyway.
 *		However, the buffer handler may at some point disable itself,
 *		and @pkbuf_flush@ can cope with this eventuality.  Any
 *		pending data is left at the start of the buffer and can be
 *		flushed out by calling @pkbuf_flush(b, 0, 0)@ if the buffer
 *		is ever re-enabled.
 */

void pkbuf_flush(pkbuf *pk, octet *p, size_t len)
{
  size_t l;
  size_t o, keep;

  if (pk->f & PKBUF_CLOSE) {
    pk->func(0, 0, pk, 0, pk->p);
    return;
  }

  /* --- Initialize variables as necessary --- */

  if (!p) {
    p = pk->buf;
    len = pk->len;
  }
  l = p + len - pk->buf;
  o = 0;

  /* --- Now grind through any packets which have accumulated --- */

  pk->len = l;
  while (l >= pk->want) {
    size_t sz = pk->want;

    /* --- Pass a packet to the user handler --- */

    keep = 0;
    pk->func(pk->buf + o, sz, pk, &keep, pk->p);

    /* --- Adjust all the pointers for the next packet --- */

    sz -= keep;
    o += sz;
    l -= sz;

    /* --- Abort here if disabled --- */

    if (!(pk->f & PKBUF_ENABLE))
      break;
  }

  /* --- Shunt data around in the buffer --- */

  if (o > 0 && l != 0)
    memmove(pk->buf, pk->buf + o, l);
  pk->len = l;
}

/* --- @pkbuf_close@ --- *
 *
 * Arguments:	@pkbuf *pk@ = pointer to buffer block
 *
 * Returns:	---
 *
 * Use:		Informs the client that no more data is likely to arrive.  If
 *		there is a partial packet in the buffer, it is discarded.
 */

void pkbuf_close(pkbuf *pk)
{
  if (pk->buf) {
    x_free(pk->a, pk->buf);
    pk->buf = 0;
  }
  pk->f |= PKBUF_CLOSE;
  if (pk->f & PKBUF_ENABLE)
    pk->func(0, 0, pk, 0, pk->p);
}

/* --- @pkbuf_free@ --- *
 *
 * Arguments:	@pkbuf *pk@ = pointer to buffer block
 *		@octet **p@ = output pointer to free space
 *
 * Returns:	Free buffer size.
 *
 * Use:		Returns the free portion of a packet buffer.  Data can then
 *		be written to this portion, and split out into packets by
 *		calling @pkbuf_flush@.  A buffer is allocated if none
 *		currently exists.
 */

size_t pkbuf_free(pkbuf *pk, octet **p)
{
  if (!pk->buf)
    pk->buf = x_alloc(pk->a, pk->sz);
  *p = pk->buf + pk->len;
  return (pk->sz - pk->len);
}

/* --- @pkbuf_snarf@ --- *
 *
 * Arguments:	@pkbuf *pk@ = pointer to buffer block
 *		@const void *p@ = pointer to input data buffer
 *		@size_t sz@ = size of data in input buffer
 *
 * Returns:	---
 *
 * Use:		Snarfs the data from the input buffer and spits it out as
 *		packets.  This interface ignores the complexities of dealing
 *		with disablement: you should be using @pkbuf_free@ to
 *		contribute data if you want to cope with that.
 */

void pkbuf_snarf(pkbuf *pk, const void *p, size_t sz)
{
  const octet *pp = p;
  while (sz && (pk->f & PKBUF_ENABLE)) {
    size_t bsz;
    octet *bp;

    bsz = pkbuf_free(pk, &bp);
    if (bsz > sz)
      bsz = sz;
    memcpy(bp, pp, bsz);
    pkbuf_flush(pk, bp, bsz);
    pp += bsz;
    sz -= bsz;
  }
}

/* --- @pkbuf_want@ --- *
 *
 * Arguments:	@pkbuf *pk@ = pointer to buffer block
 *		@size_t want@ = how many octets wanted for next packet
 *
 * Returns:	---
 *
 * Use:		Sets the desired size for the next packet to be read.  If
 *		it's larger than the current buffer, the buffer is extended.
 */

void pkbuf_want(pkbuf *pk, size_t want)
{
  pk->want = want;
  if (want > pk->sz) {
    do pk->sz <<= 1; while (want > pk->sz);
    if (pk->buf) {
      if (pk->len)
	pk->buf = x_realloc(pk->a, pk->buf, pk->sz, pk->len);
      else {
	x_free(pk->a, pk->buf);
	pk->buf = 0;
      }
    }
  }
}

/* --- @pkbuf_init@ --- *
 *
 * Arguments:	@pkbuf *pk@ = pointer to buffer block
 *		@pkbuf *func@ = handler function
 *		@void *p@ = argument pointer for @func@
 *
 * Returns:	---
 *
 * Use:		Initializes a packet buffer block.  Any packets are passed to
 *		the provided function for handling.
 */

void pkbuf_init(pkbuf *pk, pkbuf_func *func, void *p)
{
  pk->func = func;
  pk->p = p;
  pk->len = 0;
  pk->f = PKBUF_ENABLE;
  pk->buf = 0;
  pk->sz = 256;
  pk->want = 1;
  pk->a = arena_global;
}

/* --- @pkbuf_destroy@ --- *
 *
 * Arguments:	@pkbuf *pk@ = pointer to buffer block
 *
 * Returns:	---
 *
 * Use:		Deallocates a line buffer and frees any resources it owned.
 */

void pkbuf_destroy(pkbuf *pk)
{
  if (pk->buf) {
    x_free(pk->a, pk->buf);
    pk->buf = 0;
  }
}

/*----- That's all, folks -------------------------------------------------*/
