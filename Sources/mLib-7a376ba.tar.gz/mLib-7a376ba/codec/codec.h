/* -*-c-*-
 *
 * Abstract interface to codecs
 *
 * (c) 2009 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_CODEC_H
#define MLIB_CODEC_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_DSTR_H
#  include "dstr.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct codec {
  const struct codec_ops *ops;
} codec;

typedef struct codec_class {
  const char *name;
  codec *(*encoder)(unsigned /*flags*/,
		    const char */*indent*/, unsigned /*maxline*/);
  codec *(*decoder)(unsigned /*flags*/);

#define CDCF_LOWERC 1u			/* Prefer lower case */
#define CDCF_IGNCASE 2u			/* Ignore case on input */
#define CDCF_NOEQPAD 4u			/* No `=' padding */
#define CDCF_IGNEQPAD 8u		/* Ignore `=' pad errors on input */
#define CDCF_IGNEQMID 16u		/* Ignore pad chars on input */
#define CDCF_IGNZPAD 32u		/* Ignore zero padding on input */
#define CDCF_IGNNEWL 64u		/* Ignore newlines on input */
#define CDCF_IGNINVCH 128u		/* Ignore invalid chars on input */
#define CDCF_IGNSPC 256u		/* Ignore whitespace on input */

#define CDCF_IGNJUNK			/* Ignore all bad things */	\
  (CDCF_IGNEQMID | CDCF_IGNZPAD |					\
   CDCF_IGNCASE | CDCF_IGNNEWL | CDCF_IGNSPC | CDCF_IGNINVCH)

} codec_class;

#define CODEC_ERRORS(_)							\
  _(OK,		"No error")						\
  _(INVCH,	"Invalid character")					\
  _(INVEQPAD,	"Invalid padding character")				\
  _(INVZPAD,	"Nonzero padding bits")
enum {
#define DECLERR(name, text) CDCERR_##name,
  CODEC_ERRORS(DECLERR)
#undef DECLERR
  CDCERR__LIMIT
};

typedef struct codec_ops {
  const codec_class *c;
  int (*code)(codec */*c*/, const void */*p*/, size_t /*sz*/, dstr */*d*/);
  void (*destroy)(codec */*c*/);
} codec_ops;

/*----- Functions provided ------------------------------------------------*/

/* --- @codec_strerror@ --- *
 *
 * Arguments:	@int err@ = error code from codec
 *
 * Returns:	Pointer to error text.
 *
 * Use:		Converts error codes to human-readable strings.
 */

const char *codec_strerror(int /*err*/);

/*----- Null codec --------------------------------------------------------*/

extern const codec_class null_codec_class;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
