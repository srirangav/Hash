/* -*-c-*-
 *
 * Base32 encoding and decoding
 *
 * (c) 1997 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_BASE32_H
#define MLIB_BASE32_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_CODEC_H
#  include "codec.h"
#endif

#ifndef MLIB_DSTR_H
#  include "dstr.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct base32_ctx {
  unsigned long accl, acch;		/* Accumulator for output data */
  unsigned qsz;				/* Length of data queued */
  unsigned lnlen;			/* Length of the current line */
  const char *indent;			/* Newline-and-indent string */
  unsigned maxline;			/* Maximum permitted line length */
} base32_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @base32_encode@ --- *
 *
 * Arguments:	@base32_ctx *ctx@ = pointer to a context block
 *		@const void *p@ = pointer to a source buffer
 *		@size_t sz@ = size of the source buffer
 *		@dstr *d@ = pointer to destination string
 *
 * Returns:	---
 *
 * Use:		Encodes a binary string in base32.  To flush out the final
 *		few characters (if necessary), pass a null source pointer.
 */

extern void base32_encode(base32_ctx */*ctx*/,
			  const void */*p*/, size_t /*sz*/,
			  dstr */*d*/);

/* --- @base32_decode@ --- *
 *
 * Arguments:	@base32_ctx *ctx@ = pointer to a context block
 *		@const void *p@ = pointer to a source buffer
 *		@size_t sz@ = size of the source buffer
 *		@dstr *d@ = pointer to destination string
 *
 * Returns:	---
 *
 * Use:		Decodes a binary string in base32.  To flush out the final
 *		few characters (if necessary), pass a null source pointer.
 */

extern void base32_decode(base32_ctx */*ctx*/,
			  const void */*p*/, size_t /*sz*/,
			  dstr */*d*/);

/* --- @base32_init@ --- *
 *
 * Arguments:	@base32_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a base32 context properly.
 */

extern void base32_init(base32_ctx */*ctx*/);

/*----- Codec object interface --------------------------------------------*/

extern const codec_class base32_class, base32hex_class;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
