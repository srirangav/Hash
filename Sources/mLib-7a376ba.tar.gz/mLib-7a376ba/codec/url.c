/* -*-c-*-
 *
 * Parsing and construction of url-encoded name/value pairs
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dstr.h"
#include "url.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @url_initenc@ --- *
 *
 * Arguments:	@url_ectx *ctx@ = pointer to context block
 *
 * Returns:	---
 *
 * Use:		Initializes a URL encoding context.
 */

void url_initenc(url_ectx *ctx) { ctx->f = 0; }

/* --- @encode@ --- *
 *
 * Arguments:	@url_ectx *ctx@ = encoding context
 *		@dstr *d@ = pointer to output string
 *		@const char *p@ = pointer to thing to encode
 *
 * Returns:	---
 *
 * Use:		Encodes the input string into the output string.
 */

static void encode(url_ectx *ctx, dstr *d, const char *p)
{
  while (*p) {
    switch (*p) {
      case ' ':
	DPUTC(d, '+');
	break;
      default:
	if ((ctx->f & URLF_LAX) || isalnum((unsigned char)*p))
	  goto safe;
	else
	  goto unsafe;
      case '/':
      case '~':
	if (ctx->f & URLF_STRICT)
	  goto unsafe;
      case '-':
      case '.':
      case '_':
      safe:
	DPUTC(d, *p);
	break;
      unsafe:
      case '+':
      case '%':
      case '=':
      case '&':
      case ';':
	dstr_putf(d, "%%%02x", *p);
	break;
    }
    p++;
  }
}

/* --- @url_enc@ --- *
 *
 * Arguments:	@url_ectx *ctx@ = pointer to encoding context
 *		@dstr *d@ = pointer to output string
 *		@const char *name@ = pointer to name
 *		@const char *value@ = pointer to value
 *
 * Returns:	---
 *
 * Use:		Writes an assignment between @name@ and @value@ to the
 *		output string, encoding the values properly.
 */

void url_enc(url_ectx *ctx, dstr *d, const char *name, const char *value)
{
  if (ctx->f & URLF_SEP)
    DPUTC(d, (ctx->f & URLF_SEMI) ? ';' : '&');
  encode(ctx, d, name);
  DPUTC(d, '=');
  encode(ctx, d, value);
  DPUTZ(d);
  ctx->f |= URLF_SEP;
}

/* --- @url_initdec@ --- *
 *
 * Arguments:	@url_dctx *ctx@ = pointer to context block
 *		@const char *p@ = string to read data from
 *
 * Returns:	---
 *
 * Use:		Initializes a URL decoding context.
 */

void url_initdec(url_dctx *ctx, const char *p) { ctx->p = p; ctx->f = 0; }

/* --- @decode@ --- *
 *
 * Arguments:	@url_dctx *ctx@ = pointer to the context
 *		@dstr *d@ = pointer to output string
 *		@const char *p@ = pointer to input data
 *		@int eq@ = whether to stop at `=' characters
 *
 * Returns:	Pointer to next available character.
 *
 * Use:		Does a URL decode.
 */

static const char *decode(url_dctx *ctx, dstr *d, const char *p, int eq)
{
  if (!*p)
    return (0);
  for (;;) {
    switch (*p) {
      case '=':
	if (eq)
	  return (p);
	goto boring;
      case ';':
	if (ctx->f & URLF_SEMI)
	  return (p);
	goto boring;
      case 0:
      case '&':
	return (p);
      case '+':
	DPUTC(d, ' ');
	break;
      case '%': {
	unsigned int ch;
	int n;
	int x = sscanf(p + 1, "%2x%n", &ch, &n);
	if (x == 1) {
	  DPUTC(d, ch);
	  p += n;
	  break;
	}
      }
      default:
      boring:
	DPUTC(d, *p);
	break;
    }
    p++;
  }
}

/* --- @url_dec@ --- *
 *
 * Arguments:	@url_dctx *ctx@ = pointer to decode context
 *		@dstr *n@ = pointer to output string for name
 *		@dstr *v@ = pointer to output string for value
 *
 * Returns:	Nonzero if it read something, zero if there's nothing left
 *
 * Use:		Decodes the next name/value pair from a urlencoded string.
 */

int url_dec(url_dctx *ctx, dstr *n, dstr *v)
{
  const char *p = ctx->p;
  size_t l = n->len;

again:
  if ((p = decode(ctx, n, p, 1)) == 0 || *p == 0)
    return (0);
  if (*p != '=') {
    p++;
    n->len = l;
    goto again;
  }
  p++;
  if ((p = decode(ctx, v, p, 0)) == 0)
    return (0);
  DPUTZ(n);
  DPUTZ(v);
  ctx->p = p;
  return (1);
}

/*----- That's all, folks -------------------------------------------------*/
