/* -*-c-*-
 *
 * Binary codec utilities
 *
 * (c) 2009 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "codec.h"
#include "macros.h"

/*----- Static variables --------------------------------------------------*/

static const char *errtab[] = {
#define ERR(name, text) text,
  CODEC_ERRORS(ERR)
};

/*----- Main code ---------------------------------------------------------*/

/* --- @codec_strerror@ --- *
 *
 * Arguments:	@int err@ = error code from codec
 *
 * Returns:	Pointer to error text.
 *
 * Use:		Converts error codes to human-readable strings.
 */

const char *codec_strerror(int err)
{
  if (err < 0 || err >= N(errtab))
    return ("Error code out of range");
  return (errtab[err]);
}

/*----- That's all, folks -------------------------------------------------*/
