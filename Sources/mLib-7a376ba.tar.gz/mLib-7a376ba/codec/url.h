/* -*-c-*-
 *
 * Parsing and construction of url-encoded name/value pairs
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_URL_H
#define MLIB_URL_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_DSTR_H
#  include "dstr.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct url_ectx {
  unsigned f;
} url_ectx;


typedef struct url_dctx {
  const char *p;
  unsigned f;
} url_dctx;

#define URLF_SEP 1u
#define URLF_STRICT 2u
#define URLF_LAX 4u
#define URLF_SEMI 8u

/*----- Functions provided ------------------------------------------------*/

/* --- @url_initenc@ --- *
 *
 * Arguments:	@url_ectx *ctx@ = pointer to context block
 *
 * Returns:	---
 *
 * Use:		Initializes a URL encoding context.
 */

extern void url_initenc(url_ectx */*ctx*/);

/* --- @url_enc@ --- *
 *
 * Arguments:	@url_ectx *ctx@ = pointer to encoding context
 *		@dstr *d@ = pointer to output string
 *		@const char *name@ = pointer to name
 *		@const char *value@ = pointer to value
 *
 * Returns:	---
 *
 * Use:		Writes an assignment between @name@ and @value@ to the
 *		output string, encoding the values properly.
 */

extern void url_enc(url_ectx */*ctx*/, dstr */*d*/,
		    const char */*name*/, const char */*value*/);

/* --- @url_initdec@ --- *
 *
 * Arguments:	@url_dctx *ctx@ = pointer to context block
 *		@const char *p@ = string to read data from
 *
 * Returns:	---
 *
 * Use:		Initializes a URL decoding context.
 */

extern void url_initdec(url_dctx */*ctx*/, const char */*p*/);

/* --- @url_dec@ --- *
 *
 * Arguments:	@url_dctx *ctx@ = pointer to decode context
 *		@dstr *n@ = pointer to output string for name
 *		@dstr *v@ = pointer to output string for value
 *
 * Returns:	Nonzero if it read something, zero if there's nothing left
 *
 * Use:		Decodes the next name/value pair from a urlencoded string.
 */

extern int url_dec(url_dctx */*ctx*/, dstr */*n*/, dstr */*v*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
