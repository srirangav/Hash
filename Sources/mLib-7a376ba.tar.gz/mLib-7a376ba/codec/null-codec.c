/* -*-c-*-
 *
 * Null codec implementation
 *
 * (c) 2009 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <string.h>

#include "codec.h"
#include "sub.h"

/*----- Data structures ---------------------------------------------------*/

typedef struct null_codec {
  codec c;
} null_codec;

/*----- Main code ---------------------------------------------------------*/

static int encdec(codec *c, const void *p, size_t sz, dstr *d)
  { DPUTM(d, p, sz); return (0); }

static void destroy(codec *c)
  { null_codec *nc = (null_codec *)c; DESTROY(nc); }

static const codec_ops ops = { &null_codec_class, encdec, destroy };

static codec *encoder(unsigned flags, const char *indent, unsigned maxlen)
{
  null_codec *nc = CREATE(null_codec);
  nc->c.ops = &ops;
  return (&nc->c);
}

static codec *decoder(unsigned flags)
{
  null_codec *nc = CREATE(null_codec);
  nc->c.ops = &ops;
  return (&nc->c);
}

const codec_class null_codec_class = { "null", encoder, decoder };

/*----- That's all, folks -------------------------------------------------*/
