/* -*-c-*-
 *
 * Hexadecimal encoding and decoding
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_HEX_H
#define MLIB_HEX_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_CODEC_H
#  include "codec.h"
#endif

#ifndef MLIB_DSTR_H
#  include "dstr.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct hex_ctx {
  unsigned long acc;			/* Accumulator for output data */
  unsigned qsz;				/* Length of data queued */
  unsigned lnlen;			/* Length of the current line */
  const char *indent;			/* Newline-and-indent string */
  unsigned maxline;			/* Maximum permitted line length */
} hex_ctx;

/*----- Functions provided ------------------------------------------------*/

/* --- @hex_encode@ --- *
 *
 * Arguments:	@hex_ctx *ctx@ = pointer to a context block
 *		@const void *p@ = pointer to a source buffer
 *		@size_t sz@ = size of the source buffer
 *		@dstr *d@ = pointer to destination string
 *
 * Returns:	---
 *
 * Use:		Encodes a binary string in hex.
 */

extern void hex_encode(hex_ctx */*ctx*/, const void */*p*/, size_t /*sz*/,
		       dstr */*d*/);

/* --- @hex_decode@ --- *
 *
 * Arguments:	@hex_ctx *ctx@ = pointer to a context block
 *		@const void *p@ = pointer to a source buffer
 *		@size_t sz@ = size of the source buffer
 *		@dstr *d@ = pointer to destination string
 *
 * Returns:	---
 *
 * Use:		Decodes a binary string in hex.  Pass in a null source
 *		pointer when you thing you've finished.
 */

extern void hex_decode(hex_ctx */*ctx*/, const void */*p*/, size_t /*sz*/,
		       dstr */*d*/);

/* --- @hex_init@ --- *
 *
 * Arguments:	@hex_ctx *ctx@ = pointer to context block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a hex context properly.
 */

extern void hex_init(hex_ctx */*ctx*/);

/*----- Codec object interface --------------------------------------------*/

extern const codec_class hex_class;

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
