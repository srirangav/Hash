/* -*-c-*-
 *
 * Reporting errors and things
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "quis.h"
#include "report.h"

/*----- Functions provided ------------------------------------------------*/

/* --- @moan@ --- *
 *
 * Arguments:	@const char *f@ = a @printf@-style format string
 *		@...@ = other arguments
 *
 * Returns:	---
 *
 * Use:		Reports an error.
 */

void moan(const char *f, ...)
{
  va_list ap;
  va_start(ap, f);
  fprintf(stderr, "%s: ", QUIS);
  vfprintf(stderr, f, ap);
  va_end(ap);
  putc('\n', stderr);
}

/* --- @die@ --- *
 *
 * Arguments:	@int status@ = exit status to return
 *		@const char *f@ = a @printf@-style format string
 *		@...@ = other arguments
 *
 * Returns:	Never.
 *
 * Use:		Reports an error and exits.  Like @moan@ above, only more
 *		permanent.
 */

void die(int status, const char *f, ...)
{
  va_list ap;
  va_start(ap, f);
  fprintf(stderr, "%s: ", QUIS);
  vfprintf(stderr, f, ap);
  va_end(ap);
  putc('\n', stderr);
  exit(status);
}

/*----- That's all, folks -------------------------------------------------*/
