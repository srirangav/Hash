/* -*-c-*-
 *
 * Reporting errors and things
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_REPORT_H
#define MLIB_REPORT_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_MACROS_H
#  include "macros.h"
#endif

/*----- Functions provided ------------------------------------------------*/

/* --- @moan@ --- *
 *
 * Arguments:	@const char *f@ = a @printf@-style format string
 *		@...@ = other arguments
 *
 * Returns:	---
 *
 * Use:		Reports an error.
 */

extern void PRINTF_LIKE(1, 2)
  moan(const char *f, ...);

/* --- @die@ --- *
 *
 * Arguments:	@int status@ = exit status to return
 *		@const char *f@ = a @printf@-style format string
 *		@...@ = other arguments
 *
 * Returns:	Never.
 *
 * Use:		Reports an error and exits.  Like @moan@ above, only more
 *		permanent.
 */

extern void PRINTF_LIKE(2, 3) NORETURN
  die(int status, const char *f, ...);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
