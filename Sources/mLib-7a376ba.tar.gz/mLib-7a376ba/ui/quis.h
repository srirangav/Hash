/* -*-c-*-
 *
 * Setting the program name
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_PROGNAME_H
#define MLIB_PROGNAME_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>

/*----- Global variables --------------------------------------------------*/

extern const char *pn__name;

/*----- Functions provided ------------------------------------------------*/

/* --- @quis@ --- *
 *
 * Arguments:	---
 *
 * Returns:	Pointer to the program name.
 *
 * Use:		Returns the program name.
 */

extern const char *quis(void);
#define QUIS (pn__name)

/* --- @ego@ --- *
 *
 * Arguments:	@const char *p@ = pointer to program name
 *
 * Returns:	---
 *
 * Use:		Tells mLib what the program's name is.
 */

extern void ego(const char */*p*/);

/* --- @pquis@ --- *
 *
 * Arguments:	@FILE *fp@ = output stream to write on
 *		@const char *p@ = pointer to string to write
 *
 * Returns:	Zero if everything worked, EOF if not.
 *
 * Use:		Writes the string @p@ to the output stream @fp@.  Occurrences
 *		of the character `$' in @p@ are replaced by the program name
 *		as reported by @quis@.  A `$$' is replaced by a single `$'
 *		sign.
 */

extern int pquis(FILE */*fp*/, const char */*p*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
