/* -*-c-*-
 *
 * Nonblocking connect handling
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/socket.h>

#include <unistd.h>
#include <fcntl.h>

#include "conn.h"
#include "sel.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @conn_connect@ --- *
 *
 * Arguments:	@int fd@ = file descriptor to try to connect
 *		@unsigned mode@ = what we can do to the file
 *		@void *p@ = pointer to connection context
 *
 * Returns:	---
 *
 * Use:		Handles select results for pending connections.
 */

static void conn_connect(int fd, unsigned mode, void *p)
{
#ifndef PATH_MAX
#  define PATH_MAX 1024
#endif

  conn *c = p;
  char buf[PATH_MAX + 8]; /* Big enough */
  socklen_t sinsz;

  sinsz = sizeof(buf);
  sel_rmfile(&c->writer);
  if (getpeername(fd, (struct sockaddr *)buf, &sinsz) < 0) {
    int err;
    socklen_t errsz = sizeof(err);
    if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &errsz) == 0)
      errno = err;
    close(fd);
    c->func(-1, c->p);
  } else
    c->func(fd, c->p);
}

/* --- @conn_fd@ --- *
 *
 * Arguments:	@conn *c@ = pointer to connection block
 *		@sel_state *s@ = pointer to select state to attach to
 *		@int fd@ = file descriptor of socket
 *		@void (*func)(int fd, void *p) = handler function
 *		@void *p@ = argument for the handler function
 *
 * Returns:	---
 *
 * Use:		Sets up a nonblocking connect job.  The socket should have a
 *		connect pending for it already.
 */

void conn_fd(conn *c, sel_state *s, int fd,
	     void (*func)(int /*fd*/, void */*p*/),
	     void *p)
{
  c->func = func;
  c->p = p;
  sel_initfile(s, &c->writer, fd, SEL_WRITE, conn_connect, c);
  sel_addfile(&c->writer);
}

/* --- @conn_init@ --- *
 *
 * Arguments:	@conn *c@ = pointer to connection block
 *		@sel_state *s@ = pointer to select state to attach to
 *		@int fd@ = file descriptor of socket to connect
 *		@struct sockaddr *dst@ = destination address
 *		@int dsz@ = size of destination address
 *		@void (*func)(int fd, void *p) = handler function
 *		@void *p@ = argument for the handler function
 *
 * Returns:	Zero on success, nonzero on failure.
 *
 * Use:		Sets up a nonblocking connect job.  The socket should already
 *		be bound if you care about that sort of thing.  When the
 *		connection completes, the handler function is called with the
 *		connected socket as an argument.  If the connect fails rather
 *		than completes, the socket is closed, and the handler is
 *		informed of this by being passed a negative file descriptor.
 *		In either case, the select job is then removed.
 */

int conn_init(conn *c, sel_state *s, int fd,
	      struct sockaddr *dst, int dsz,
	      void (*func)(int /*fd*/, void */*p*/),
	      void *p)
{
  int f;

  if ((f = fcntl(fd, F_GETFL)) < 0 || fcntl(fd, F_SETFL, f | O_NONBLOCK))
    goto fail;

  if (!connect(fd, dst, dsz))
    func(fd, p);
  else if (errno != EINPROGRESS)
    goto fail;
  else
    conn_fd(c, s, fd, func, p);
  return (0);

fail:
  close(fd);
  return (-1);
}

/* --- @conn_kill@ --- *
 *
 * Arguments:	@conn *c@ = pointer to connection to dispose of
 *
 * Returns:	---
 *
 * Use:		Disposes of a connection when it's not wanted any more.
 */

void conn_kill(conn *c)
{
  if (c->writer.fd != -1) {
    close(c->writer.fd);
    sel_rmfile(&c->writer);
    c->writer.fd = -1;
  }
}

/*----- That's all, folks -------------------------------------------------*/
