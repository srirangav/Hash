/* -*-c-*-
 *
 * Line-buffering select handler
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

#include "lbuf.h"
#include "sel.h"
#include "selbuf.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @selbuf_enable@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to buffer block
 *
 * Returns:	---
 *
 * Use:		Enables a buffer for reading, and emits any queued lines
 *		to the buffer's owner.
 */

void selbuf_enable(selbuf *b)
{
  if (!(b->b.f & LBUF_ENABLE)) {
    b->b.f |= LBUF_ENABLE;
    sel_addfile(&b->reader);
    lbuf_flush(&b->b, 0, 0);
  }
}

/* --- @selbuf_disable@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to a buffer block
 *
 * Returns:	---
 *
 * Use:		Disables a buffer.  It won't be read from until it's
 *		enabled again.
 */

void selbuf_disable(selbuf *b)
{
  if (b->b.f & LBUF_ENABLE) {
    b->b.f &= ~LBUF_ENABLE;
    sel_rmfile(&b->reader);
  }
}

/* --- @selbuf_read@ --- *
 *
 * Arguments:	@int fd@ = file descriptor to read from
 *		@int mode@ = what we can do to the file
 *		@void *vp@ = pointer to buffer context
 *
 * Returns:	---
 *
 * Use:		Acts on the result of a @select@ call.
 */

static void selbuf_read(int fd, unsigned mode, void *vp)
{
  selbuf *b = vp;
  char *p;
  size_t sz;
  int n;

  sz = lbuf_free(&b->b, &p);
  n = read(fd, p, sz);
  if (n == 0)
    lbuf_close(&b->b);
  else if (n > 0)
    lbuf_flush(&b->b, p, n);
  else switch (errno) {
    case EINTR:
    case EAGAIN:
#if EAGAIN != EWOULDBLOCK
    case EWOULDBLOCK:
#endif
      return;
    default:
      lbuf_close(&b->b);
  }
}

/* --- @selbuf_setsize@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to buffer block
 *		@size_t sz@ = size of buffer
 *
 * Returns:	---
 *
 * Use:		Sets the size of the buffer used for reading lines.
 */

void selbuf_setsize(selbuf *b, size_t sz)
{
  lbuf_setsize(&b->b, sz);
}

/* --- @selbuf_init@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to buffer block
 *		@sel_state *s@ = pointer to select state to attach to
 *		@int fd@ = file descriptor to listen to
 *		@lbuf_func *func@ = function to call
 *		@void *p@ = argument for function
 *
 * Returns:	---
 *
 * Use:		Initializes a buffer block.
 */

void selbuf_init(selbuf *b, sel_state *s, int fd, lbuf_func *func, void *p)
{
  lbuf_init(&b->b, func, p);
  b->b.f &= ~LBUF_ENABLE;
  sel_initfile(s, &b->reader, fd, SEL_READ, selbuf_read, b);
  selbuf_enable(b);
}

/* --- @selbuf_destroy@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to buffer block
 *
 * Returns:	---
 *
 * Use:		Deallocates a line buffer and frees any resources it owned.
 */

void selbuf_destroy(selbuf *b)
{
  selbuf_disable(b);
  lbuf_destroy(&b->b);
}

/*----- That's all, folks -------------------------------------------------*/
