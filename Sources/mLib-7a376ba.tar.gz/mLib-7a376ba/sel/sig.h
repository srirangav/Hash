/* -*-c-*-
 *
 * Signal handling
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_SIG_H
#define MLIB_SIG_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <signal.h>

#ifndef MLIB_SEL_H
#  include "sel.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct sig {
  struct sig *next;
  struct sig *prev;
  int sig;
  void (*proc)(int /*n*/, void */*p*/);
  void *p;
} sig;

/*----- Functions provided ------------------------------------------------*/

/* --- @sig_add@ --- *
 *
 * Arguments:	@sig *s@ = pointer to signal handler block
 *		@int n@ = number of the signal
 *		@void (*proc)(int n, void *p)@ = signal handler function
 *		@void *p@ = argument to pass to handler
 *
 * Returns:	---
 *
 * Use:		Adds a signal handler.
 */

extern void sig_add(sig */*s*/, int /*n*/,
		    void (*/*proc*/)(int /*n*/, void */*p*/), void */*p*/);

/* --- @sig_remove@ --- *
 *
 * Arguments:	@sig *s@ = pointer to signal handler block
 *
 * Returns:	---
 *
 * Use:		Removes the signal handler from the list.
 */

extern void sig_remove(sig */*s*/);

/* --- @sig_init@ --- *
 *
 * Arguments:	@sel_state *s@ = pointer to select state
 *
 * Returns:	---
 *
 * Use:		Initializes the signal handling system ready for use.
 */

extern void sig_init(sel_state */*s*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
