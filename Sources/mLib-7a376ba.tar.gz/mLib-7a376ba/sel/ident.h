/* -*-c-*-
 *
 * Nonblocking RFC931 client
 *
 * (c) 1999 Mark Wooding
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_IDENT_H
#define MLIB_IDENT_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#ifndef MLIB_CONN_H
#  include "conn.h"
#endif

#ifndef MLIB_SEL_H
#  include "sel.h"
#endif

#ifndef MLIB_SELBUF_H
#  include "selbuf.h"
#endif

/*----- Data structures ---------------------------------------------------*/

/* --- Parsed response from ident server --- */

typedef struct ident_reply {
  unsigned short sport, dport;		/* Source and destination ports */
  unsigned type;			/* Type of reply from server */
  union {
    struct {
      char *os;				/* Operating system name */
      char *user;			/* User name */
    } userid;
    char *error;			/* Error message from server */
  } u;
} ident_reply;

/* --- Response type codes --- */

enum {
  IDENT_USERID,
  IDENT_ERROR,
  IDENT_BAD
};

/* --- Request structure --- */

typedef struct ident_request {
  struct sockaddr_in local, remote;
  unsigned state;
  void (*func)(ident_reply */*i*/, void */*p*/);
  void *p;
  sel_state *s;
  conn c;
  selbuf b;
} ident_request;

enum {
  IDENT_CONN,
  IDENT_READ,
  IDENT_DONE
};

/*----- Functions provided ------------------------------------------------*/

/* --- @ident_abort@ --- *
 *
 * Arguments:	@ident_request *rq@ = pointer to request block
 *
 * Returns:	---
 *
 * Use:		Cancels an ident request in progress.
 */

extern void ident_abort(ident_request */*rq*/);

/* --- @ident@ --- *
 *
 * Arguments:	@ident_request *rq@ = pointer to request block
 *		@sel_state *s@ = I/O multiplexor
 *		@const struct sockaddr_in *local, *remote@ = addresses
 *		@void (*func)(ident_reply *i, void *p)@ = handler function
 *		@void *p@ = argument for handler
 *
 * Returns:	---
 *
 * Use:		Initializes an ident request.
 */

extern void ident(ident_request */*rq*/, sel_state */*s*/,
		  const struct sockaddr_in */*local*/,
		  const struct sockaddr_in */*remote*/,
		  void (*/*func*/)(ident_reply */*i*/, void */*p*/),
		  void */*p*/);

/* --- @ident_socket@ --- *
 *
 * Arguments:	@ident_request *rq@ = pointer to request block
 *		@sel_state *s@ = I/O multiplexor
 *		@int sk@ = connected socket file descriptor
 *		@void (*func)(ident_reply *i, void *p)@ = handler function
 *		@void *p@ = argument for handler
 *
 * Returns:	---
 *
 * Use:		An alternative interface to @ident@.  Initializes an ident
 *		request from a connected socket, rather than from an explicit
 *		address.  This will call @getsockname@ and @getpeername@ to
 *		find out what the socket is actually connected to, which adds
 *		convenience but wastes time.
 */

extern void ident_socket(ident_request */*rq*/, sel_state */*s*/, int /*sk*/,
			 void (*/*func*/)(ident_reply */*i*/, void */*p*/),
			 void */*p*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
