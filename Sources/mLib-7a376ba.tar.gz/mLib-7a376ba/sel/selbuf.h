/* -*-c-*-
 *
 * Line-buffering select handler
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_SELBUF_H
#define MLIB_SELBUF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_LBUF_H
#  include "lbuf.h"
#endif

#ifndef MLIB_SEL_H
#  include "sel.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct selbuf {
  sel_file reader;			/* File selection object */
  lbuf b;				/* Line buffering object */
} selbuf;

/*----- Functions provided ------------------------------------------------*/

/* --- @selbuf_enable@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to buffer block
 *
 * Returns:	---
 *
 * Use:		Enables a buffer for reading, and emits any queued lines
 *		to the buffer's owner.
 */

extern void selbuf_enable(selbuf */*b*/);

/* --- @selbuf_disable@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to a buffer block
 *
 * Returns:	---
 *
 * Use:		Disables a buffer.  It won't be read from until it's
 *		enabled again.
 */

extern void selbuf_disable(selbuf */*b*/);

/* --- @selbuf_setsize@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to buffer block
 *		@size_t sz@ = size of buffer
 *
 * Returns:	---
 *
 * Use:		Sets the size of the buffer used for reading lines.
 */

extern void selbuf_setsize(selbuf */*b*/, size_t /*sz*/);

/* --- @selbuf_init@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to buffer block
 *		@sel_state *s@ = pointer to select state to attach to
 *		@int fd@ = file descriptor to listen to
 *		@lbuf_func *func@ = function to call
 *		@void *p@ = argument for function
 *
 * Returns:	---
 *
 * Use:		Initializes a buffer block.
 */

extern void selbuf_init(selbuf */*b*/, sel_state */*s*/, int /*fd*/,
			lbuf_func */*func*/, void */*p*/);

/* --- @selbuf_destroy@ --- *
 *
 * Arguments:	@selbuf *b@ = pointer to buffer block
 *
 * Returns:	---
 *
 * Use:		Deallocates a line buffer and frees any resources it owned.
 */

extern void selbuf_destroy(selbuf */*b*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
