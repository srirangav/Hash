/* -*-c-*-
 *
 * Packet-buffering select handler
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

#include "pkbuf.h"
#include "sel.h"
#include "selpk.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @selpk_enable@ --- *
 *
 * Arguments:	@selpk *pk@ = pointer to buffer block
 *
 * Returns:	---
 *
 * Use:		Enables a buffer for reading, and emits any queued packets
 *		to the buffer's owner.
 */

void selpk_enable(selpk *pk)
{
  if (!(pk->pk.f & PKBUF_ENABLE)) {
    pk->pk.f |= PKBUF_ENABLE;
    sel_addfile(&pk->reader);
    pkbuf_flush(&pk->pk, 0, 0);
  }
}

/* --- @selpk_disable@ --- *
 *
 * Arguments:	@selpk *pk@ = pointer to a buffer block
 *
 * Returns:	---
 *
 * Use:		Disables a buffer.  It won't be read from until it's
 *		enabled again.
 */

void selpk_disable(selpk *pk)
{
  if (pk->pk.f & PKBUF_ENABLE) {
    pk->pk.f &= ~PKBUF_ENABLE;
    sel_rmfile(&pk->reader);
  }
}

/* --- @selpk_read@ --- *
 *
 * Arguments:	@int fd@ = file descriptor to read from
 *		@int mode@ = what we can do to the file
 *		@void *vp@ = pointer to buffer context
 *
 * Returns:	---
 *
 * Use:		Acts on the result of a @select@ call.
 */

static void selpk_read(int fd, unsigned mode, void *vp)
{
  selpk *pk = vp;
  octet *p;
  size_t sz;
  int n;

  sz = pkbuf_free(&pk->pk, &p);
  n = read(fd, p, sz);
  if (n == 0)
    pkbuf_close(&pk->pk);
  else if (n > 0)
    pkbuf_flush(&pk->pk, p, n);
  else switch (errno) {
    case EINTR:
    case EAGAIN:
#if EAGAIN != EWOULDBLOCK
    case EWOULDBLOCK:
#endif
      return;
    default:
      pkbuf_close(&pk->pk);
  }
}

/* --- @selpk_want@ --- *
 *
 * Arguments:	@selpk *pk@ = pointer to buffer block
 *		@size_t sz@ = size of buffer
 *
 * Returns:	---
 *
 * Use:		Sets the size of the packet to be read next.
 */

void selpk_want(selpk *pk, size_t sz)
{
  pkbuf_want(&pk->pk, sz);
}

/* --- @selpk_init@ --- *
 *
 * Arguments:	@selpk *pk@ = pointer to buffer block
 *		@sel_state *s@ = pointer to select state to attach to
 *		@int fd@ = file descriptor to listen to
 *		@pkbuf_func *func@ = function to call
 *		@void *p@ = argument for function
 *
 * Returns:	---
 *
 * Use:		Initializes a buffer block.
 */

void selpk_init(selpk *pk, sel_state *s, int fd, pkbuf_func *func, void *p)
{
  pkbuf_init(&pk->pk, func, p);
  pk->pk.f &= ~PKBUF_ENABLE;
  sel_initfile(s, &pk->reader, fd, SEL_READ, selpk_read, pk);
  selpk_enable(pk);
}

/* --- @selpk_destroy@ --- *
 *
 * Arguments:	@selpk *pk@ = pointer to buffer block
 *
 * Returns:	---
 *
 * Use:		Deallocates a packet buffer and frees any resources it owned.
 */

void selpk_destroy(selpk *pk)
{
  selpk_disable(pk);
  pkbuf_destroy(&pk->pk);
}

/*----- That's all, folks -------------------------------------------------*/
