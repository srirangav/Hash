/* -*-c-*-
 *
 * Background reverse name resolution
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_BRES_H
#define MLIB_BRES_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <sys/types.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#ifdef HAVE_ADNS
#  include <adns.h>
#endif

#ifndef MLIB_SEL_H
#  include "sel.h"
#endif

#ifndef MLIB_SELBUF_H
#  include "selbuf.h"
#endif

/*----- Data structures ---------------------------------------------------*/

/* --- Client allocated request block --- */

typedef struct bres_client {
#ifdef HAVE_ADNS
  adns_query aq;			/* ADNS query handle */
  adns_answer *a;			/* Answer for reverse resolution */
  struct _unused *_pad1;		/* And a spare slot */
#else
  struct bres_client *next, *prev;	/* Queue of waiting resolve jobs */
  struct bres_server *rs;		/* Pointer to attached server */
#endif
  int q;				/* Query type (name or address) */
  union {
    struct in_addr addr;		/* Address to resolve */
    char *name;				/* Name to resolve */
  } u;
  void (*func)(struct hostent */*h*/, void */*p*/); /* Handler function */
  void *p;				/* Argument for handler function */
} bres_client;

/* --- Server maintained resolver blocks --- */

typedef struct bres_server {
  struct bres_server *next, *prev;	/* Doubly-linked list of servers */
  pid_t kid;				/* Process id of server process */
  int fd;				/* File descriptors */
  struct bres_client *rc;		/* Pointer to attached client */
  sel_timer t;				/* Timeout for idle servers */
  sel_file f;				/* Read selector for server */
} bres_server;

/*----- Functions provided ------------------------------------------------*/

/* --- @bres_abort@ --- *
 *
 * Arguments:	@bres_client *rc@ = pointer to client block
 *
 * Returns:	---
 *
 * Use:		Removes a queued job.
 */

extern void bres_abort(bres_client */*rc*/);

/* --- @bres_byaddr@ --- *
 *
 * Arguments:	@bres_client *rc@ = pointer to client block
 *		@struct in_addr addr@ = address to resolve
 *		@void (*func)(struct hostent *h, void *p)@ = handler function
 *		@void *p@ = argument for handler function
 *
 * Returns:	---
 *
 * Use:		Adds an address lookup job to the queue.  The job will be
 *		processed when there's a spare resolver process to deal with
 *		it.
 */

extern void bres_byaddr(bres_client */*rc*/, struct in_addr /*addr*/,
			void (*/*func*/)(struct hostent */*h*/, void */*p*/),
			void */*p*/);

/* --- @bres_byname@ --- *
 *
 * Arguments:	@bres_client *rc@ = pointer to client block
 *		@const char *name@ = name to resolve
 *		@void (*func)(struct hostent *h, void *p)@ = handler function
 *		@void *p@ = argument for handler function
 *
 * Returns:	---
 *
 * Use:		Adds a name lookup job to the queue.  The job will be
 *		processed when there's a spare resolver process to deal with
 *		it.
 */

extern void bres_byname(bres_client */*rc*/, const char */*name*/,
			void (*/*func*/)(struct hostent */*h*/, void */*p*/),
			void */*p*/);

/* --- @bres_exec@ --- *
 *
 * Arguments:	@const char *file@ = file containing server code or null
 *
 * Returns:	---
 *
 * Use:		Makes `bres' use a standalone server rather than copies of
 *		the current process.  This can reduce memory consumption for
 *		large processes, at the expense of startup time (which
 *		shouldn't be too bad anyway, because of the resolver design).
 *		If the filename is null, a default set up at install time is
 *		used.  It's probably a good idea to leave it alone.
 */

extern void bres_exec(const char */*file*/);

/* --- @bres_init@ --- *
 *
 * Arguments:	@sel_state *s@ = pointer to select multiplexor
 *
 * Returns:	---
 *
 * Use:		Initializes the background resolver for use.
 */

extern void bres_init(sel_state */*s*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
