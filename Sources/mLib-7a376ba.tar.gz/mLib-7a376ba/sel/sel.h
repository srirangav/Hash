/* -*-c-*-
 *
 * I/O multiplexing support
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_SEL_H
#define MLIB_SEL_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Theory lesson -----------------------------------------------------*
 *
 * Things which are expecting to do I/O or go off at a certain time are
 * called `selectors'.  There are two types of selectors: `file selectors'
 * wait patiently for a file to become readable or writable; `timeout
 * selectors' wait for a certain amount of time to elapse.  There is also a
 * `multiplexor' which copes with managing all of this stuff.
 *
 * Multiplexors aren't actually very interesting.  You initialize them with
 * @sel_init@, and then add and remove selectors as you go.  When you want to
 * wait for something to happen, call @sel_select@.
 *
 * A file selector can *either* read *or* write.  It can't do both.  This is
 * because you quite often want to read a socket but not write it; during
 * those times you don't want to write, you just don't install a write
 * selector.
 *
 * File selectors are called when their files are available for reading or
 * writing as appropriate, and given their file descriptor, the state of the
 * file, and a pointer that was registered along with the selector.
 *
 * File selectors are set up in two phases.  First, they're `initialized'
 * with @sel_initfile@.  An initialized file selector doesn't do anything.
 * It needs to be added to a multiplexor using `sel_addfile'.  It can later
 * be removed using `sel_rmfile'.  You can carry on adding and removing as
 * you wish.  Just don't try adding it twice in a row.
 *
 * Timeout selectors are called at a certain time.  (Actually, they're called
 * *after* a certain time.)  There's no separate initialization step with
 * timouts: you just add them and they work.  If you decide you don't want a
 * timeout to go off, then you just remove it.  (Adding and removing the
 * *same* timeout isn't something you do very often.  You usually use a
 * different expiry time each time.)
 */

/*----- Header files ------------------------------------------------------*/

#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>

/*----- Data structures ---------------------------------------------------*/

/* --- A multiplexor --- *
 *
 * The files are sorted in reverse order of file descriptor number; the
 * timers are in normal order of occurrence.  Thus, the interesting one
 * is always at the front of the list.
 */

enum {
  SEL_READ,				/* File is ready to read */
  SEL_WRITE,				/* File is ready to write */
  SEL_EXC,				/* Something odd has happened */
  SEL_MODES				/* Number of modes available */
};

typedef struct sel_state {
  struct sel_file *files[SEL_MODES];	/* Lists of interesting files */
  struct sel_timer *timers;		/* List of timers */
  struct sel_hook *hooks;		/* List of hook functions applied */
  fd_set fd[SEL_MODES];			/* Quick reference table for files */
  struct sel_args *args;		/* Pointer to arguments */
} sel_state;

/* --- Listening for a file --- */

typedef struct sel_file {
  struct sel_file *next;		/* Next file in the list */
  struct sel_file **prev;		/* Previous file in the list */
  struct sel_state *s;			/* Pointer to select multiplexor */
  int fd;				/* File descriptor */
  unsigned mode;			/* Interesting event for file */
  void (*func)(int /*fd*/, unsigned /*mode*/, void */*p*/); /* Handler */
  void *p;				/* Argument for the handler */
  struct sel_pendfile *pend;		/* Pending file information */
} sel_file;

/* --- Waiting for a timeout --- */

typedef struct sel_timer {
  struct sel_timer *next;		/* Next timer in the list */
  struct sel_timer **prev;		/* Previous timer in the list */
  struct timeval tv;			/* Real time when timer should go */
  void (*func)(struct timeval */*tv*/, void */*p*/); /* Handler function */
  void *p;				/* Argument for the handler */
  struct sel_pendtimer *pend;		/* Pending timer information */
} sel_timer;

/* --- A select argument block --- */

typedef struct sel_args {
  int maxfd;				/* Highest-numbered file */
  fd_set fd[SEL_MODES];			/* Bit flags for all the files */
  struct timeval tv, *tvp;		/* Time to return */
  struct timeval now;			/* Current time */
} sel_args;

/* --- A selector hook --- *
 *
 * The hooks are called (in arbitrary order) on each select.
 */

typedef void (*sel_hookfn)(sel_state */*s*/,
			   sel_args */*a*/,
			   void */*p*/);

typedef struct sel_hook {
  struct sel_hook *next;		/* Next hook in the list */
  struct sel_hook **prev;		/* Previous hook in the list */
  sel_hookfn before, after;		/* Hook functions */
  void *p;				/* Argument for the hook functions */
} sel_hook;

/*----- Functions provided ------------------------------------------------*/

/* --- @sel_init@ --- *
 *
 * Arguments:	@sel_state *s@ = pointer to a state block to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes a select state block.
 */

extern void sel_init(sel_state */*s*/);

/* --- @sel_initfile@ --- *
 *
 * Arguments:	@sel_state *s@ = select state to attach to
 *		@sel_file *f@ = pointer to a file block to initialize
 *		@int fd@ = the file descriptor to listen to
 *		@unsigned mode@ = what to listen for
 *		@void (*func)(int fd, unsigned mode, void *p)@ = handler
 *		@void *p@ = argument to pass to handler
 *
 * Returns:	---
 *
 * Use:		Initializes a file block ready for use.  The file block
 *		isn't added to the list of things to do until a call to
 *		@sel_addfile@.
 */

extern void sel_initfile(sel_state */*s*/, sel_file */*f*/,
			 int /*fd*/, unsigned /*mode*/,
			 void (*/*func*/)(int /*fd*/,
					  unsigned /*mode*/,
					  void */*p*/),
			 void */*p*/);

/* --- @sel_addfile@ --- *
 *
 * Arguments:	@sel_file *f@ = pointer to a file block
 *
 * Returns:	---
 *
 * Use:		Adds a file block into the list of things to listen to.
 */

extern void sel_addfile(sel_file */*f*/);

/* --- @sel_rmfile@ --- *
 *
 * Arguments:	@sel_file *f@ = pointer to a file block
 *
 * Returns:	---
 *
 * Use:		Removes a file block from the list of things to listen to.
 */

extern void sel_rmfile(sel_file */*f*/);

/* --- @sel_force@ --- *
 *
 * Arguments:	@sel_file *f@ = pointer to file selector
 *
 * Returns:	---
 *
 * Use:		Forces a file selector to be considered ready.  This is only
 *		useful during a call to @sel_select@.  Of particular use is
 *		forcing a write selector when there's something interesting
 *		ready for it.
 */

extern void sel_force(sel_file */*f*/);

/* --- @sel_addtimer@ --- *
 *
 * Arguments:	@sel_state *s@ = pointer to a state block
 *		@sel_timer *t@ = pointer to a timer block
 *		@struct timeval *tv@ = pointer to time to activate
 *		@void *p@ = argument for handler function
 *
 * Returns:	---
 *
 * Use:		Registers and sets up a timer.
 */

extern void sel_addtimer(sel_state */*s*/, sel_timer */*t*/,
			 struct timeval */*tv*/,
			 void (*/*func*/)(struct timeval */*tv*/,
					  void */*p*/),
			 void */*p*/);

/* --- @sel_rmtimer@ --- *
 *
 * Arguments:	@sel_timer *t@ = pointer to timer block
 *
 * Returns:	---
 *
 * Use:		Removes a timer from the list of timers.
 */

extern void sel_rmtimer(sel_timer */*t*/);

/* --- @sel_addhook@ --- *
 *
 * Arguments:	@sel_state *s@ = pointer to state block
 *		@sel_hook *h@ = pointer to hook block
 *		@sel_hookfn before, after@ = hook functions
 *		@void *p@ = pointer argument to pass to hook functions
 *
 * Returns:	---
 *
 * Use:		Registers hook functions to be called on each select call.
 */

extern void sel_addhook(sel_state */*s*/, sel_hook */*h*/,
			sel_hookfn /*before*/, sel_hookfn /*after*/,
			void */*p*/);

/* --- @sel_rmhook@ --- *
 *
 * Arguments:	@sel_hook *h@ = pointer to hook block
 *
 * Returns:	---
 *
 * Use:		Removes hook functions.
 */

extern void sel_rmhook(sel_hook */*h*/);

/* --- @sel_fdmerge@ --- *
 *
 * Arguments:	@fd_set *dest@ = destination FD set
 *		@fd_set *fd@ = pointer to set to merge
 *		@int maxfd@ = highest numbered descriptor in @fd@ + 1
 *
 * Returns:	Actual highest numbered descriptor.
 *
 * Use:		Merges file descriptor sets, and returns an accurate @maxfd@
 *		value.
 */

extern int sel_fdmerge(fd_set */*dest*/, fd_set */*fd*/, int /*maxfd*/);

/* --- @sel_select@ --- *
 *
 * Arguments:	@sel_state *s@ = pointer to state block
 *
 * Returns:	Zero if all OK, -1 on error.
 *
 * Use:		Does a @select@ call (or equivalent @poll@).
 */

extern int sel_select(sel_state */*s*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
