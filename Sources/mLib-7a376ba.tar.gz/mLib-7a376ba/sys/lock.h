/* -*-c-*-
 *
 * Simplified POSIX locking interface
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_LOCK_H
#define MLIB_LOCK_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Magic constants ---------------------------------------------------*/

enum {
  LOCK_UNLOCK,				/* Release a lock I obtained */
  LOCK_EXCL,				/* Obtain an exclusive lock */
  LOCK_NONEXCL				/* Obtain a nonexclusive lock */
};

/*----- Functions provided ------------------------------------------------*/

/* --- @lock_file@ --- *
 *
 * Arguments:	@int fd@ = file descriptor to lock
 *		@unsigned how@ = type of lock required
 *
 * Returns:	0 if OK, -1 if it failed.
 *
 * Use:		Acquires a lock on the given file.  The value @how@
 *		specifies the type of lock to acquire: @LOCK_EXCL@ gets
 *		an exclusive (write) lock; @LOCK_NONEXCL@ gets a non-
 *		exclusive (read) lock and @LOCK_UNLOCK@ releases any locks.
 *		Acquiring a lock gets timed out after a while with an
 *		error.
 */

extern int lock_file(int /*fd*/, unsigned /*how*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
