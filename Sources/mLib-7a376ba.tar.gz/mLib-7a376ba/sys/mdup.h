/* -*-c-*-
 *
 * Duplicate multiple files
 *
 * (c) 2008 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MDUP_H
#define MDUP_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct mdup_fd {
  int cur;				/* Current file descriptor */
  int want;				/* File descriptor wanted */
} mdup_fd;

/*----- Functions provided ------------------------------------------------*/

/* --- @mdup@ --- *
 *
 * Arguments:	@mdup_fd *v@ = pointer to @mdup_fd@ vector
 *		@size_t n@ = size of vector
 *
 * Returns:	Zero if successful, @-1@ on failure.
 *
 * Use:		Rearranges file descriptors.
 *
 *		The vector @v@ consists of a number of @mdup_fd@ structures.
 *		Each `slot' in the table represents a file.  The slot's @cur@
 *		member names the current file descriptor for this file; the
 *		@want@ member is the file descriptor we want to use for it.
 *		if you want to keep a file alive but don't care which
 *		descriptor it ends up with, set @want = -1@.  Several slots
 *		may specify the same @cur@ descriptor; but they all have to
 *		declare different @want@s (except that several slots may have
 *		@want = -1@.
 *
 *		On successful exit, the function will have rearranged the
 *		file descriptors as requested.  To reflect this, the @cur@
 *		members will all be set to match the (non-@-1@) @want@
 *		members.
 *
 *		If there is a failure, then some rearrangement may have been
 *		performed and some not; the @cur@ members are set to reflect
 *		which file descriptors are to be used.  The old file
 *		descriptors are closed.  (This is different from usual @dup@
 *		behaviour, of course, but essential for reliable error
 *		handling.)  If you want to keep a particular source file
 *		descriptor open as well as make a new copy then specify two
 *		slots with the same @cur@, one with @want = cur@ and one with
 *		the desired output descriptor.
 *
 *		This function works correctly even if the desired remappings
 *		contain cycles.
 */

extern int mdup(mdup_fd */*v*/, size_t /*n*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
