/* -*-c-*-
 *
 * Watch a file for changes
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_FWATCH_H
#define MLIB_FWATCH_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <sys/types.h>
#include <sys/stat.h>

/*----- Data structures ---------------------------------------------------*/

typedef struct fwatch {
  int err;
  dev_t dev;
  ino_t ino;
  time_t mtime;
  off_t size;
  mode_t mode;
  uid_t uid;
  gid_t gid;
} fwatch;

/*----- Functions provided ------------------------------------------------*/

/* --- @fwatch_init@, @fwatch_update@, etc --- *
 *
 * Arguments:	@fwatch *f@ = pointer to an @fwatch@ structure
 *		@const char *name@ = name of the file to watch
 *		@int fd@ = a file descriptor to watch
 *
 * Returns:	The @update@ functions return nonzero if the file has
 *		changed.
 *
 * Use:		Stores information about a file which can be used to watch
 *		for changes.  The structures may be freed without telling
 *		anyone.
 */

extern void fwatch_init(fwatch */*f*/, const char */*name*/);
extern void fwatch_initfd(fwatch */*f*/, int /*fd*/);
extern int fwatch_update(fwatch */*f*/, const char */*name*/);
extern int fwatch_updatefd(fwatch */*f*/, int /*fd*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
