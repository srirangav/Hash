/* -*-c-*-
 *
 * Fiddling with environment variables
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "alloc.h"
#include "sym.h"

/*----- Data structures ---------------------------------------------------*/

typedef struct var {
  sym_base _base;
  char *v;
} var;

/*----- Main code ---------------------------------------------------------*/

/* --- @env_get@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to a symbol table
 *		@const char *name@ = pointer to variable name to look up
 *
 * Returns:	Pointer to corresponding value string, or null.
 *
 * Use:		Looks up an environment variable in the table and returns its
 *		value.  If the variable can't be found, a null pointer is
 *		returned.
 */

char *env_get(sym_table *t, const char *name)
{
  var *e = sym_find(t, name, -1, 0, 0);
  return (e ? e->v : 0);
}

/* --- @env_put@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to a symbol table
 *		@const char *name@ = pointer to variable name to set
 *		@const char *value@ = pointer to value string to assign
 *
 * Returns:	---
 *
 * Use:		Assigns a value to a variable.  If the @name@ contains an
 *		equals character, then it's assumed to be of the form
 *		`VAR=VALUE' and @value@ argument is ignored.  Otherwise, if
 *		@value@ is null, the variable is deleted.  Finally, the
 *		normal case: @name@ is a plain name, and @value@ is a normal
 *		string causes the variable to be assigned the value in the
 *		way you'd expect.
 */

void env_put(sym_table *t, const char *name, const char *value)
{
  char *q = 0;

  /* --- Sort out the mess with `NAME=VALUE' forms --- */

  {
    size_t eq = strcspn(name, "=");
    if (name[eq] == '=') {
      q = x_alloc(t->t.a, eq + 1);
      memcpy(q, name, eq);
      q[eq] = 0;
      value = name + eq + 1;
      name = q;
    }
  }

  /* --- Read the current value --- */

  if (!value) {
    var *v;
    if ((v = sym_find(t, name, -1, 0, 0)) != 0) {
      x_free(t->t.a, v->v);
      sym_remove(t, v);
    }
  } else {
    unsigned found;
    var *v = sym_find(t, name, -1, sizeof(*v), &found);
    if (found)
      x_free(t->t.a, v->v);
    v->v = x_strdup(t->t.a, value);
  }

  /* --- Tidying --- */

  if (q)
    xfree(q);
}

/* --- @env_import@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to a symbol table
 *		@char **env@ = pointer to an environment list
 *
 * Returns:	---
 *
 * Use:		Inserts all of the environment variables listed into a symbol
 *		table for rapid access.  Equivalent to a lot of calls to
 *		@env_put@.
 */

void env_import(sym_table *t, char **env)
{
  while (*env) {
    env_put(t, *env, 0);
    env++;
  }
}

/* --- @env_export@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to a symbol table
 *
 * Returns:	A big environment list.
 *
 * Use:		Extracts an environment table from a symbol table
 *		representation of an environment.  The table and all of the
 *		strings are in one big block allocated from the heap.
 */

char **env_export(sym_table *t)
{
  size_t n = 1;
  size_t sz = 0;
  sym_iter i;
  var *v;
  char **env;
  char *p, **pp;

  /* --- Work out sizes for everything --- */

  for (sym_mkiter(&i, t); (v = sym_next(&i)) != 0; ) {
    n++;
    sz += SYM_LEN(v) + strlen(v->v) + 2;
  }

  /* --- Allocate the big chunk of memory --- */

  env = pp = xmalloc(n * sizeof(char *) + sz);
  p = (char *)(env + n);

  /* --- Dump the output in the big chunk of memory --- */

  for (sym_mkiter(&i, t); (v = sym_next(&i)) != 0; ) {
    const char *name = SYM_NAME(v);
    size_t nlen = strlen(name), vlen = strlen(v->v);
    *pp++ = p;
    memcpy(p, name, nlen); p += nlen;
    *p++ = '=';
    memcpy(p, v->v, vlen); p += vlen;
    *p++ = 0;
  }
  *pp++ = 0;
  return (env);
}

/* --- @env_destroy@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to symbol table
 *
 * Returns:	---
 *
 * Use:		Destroys all the variables in the symbol table.
 */

void env_destroy(sym_table *t)
{
  sym_iter i;
  var *v;

  for (sym_mkiter(&i, t); (v = sym_next(&i)) != 0; )
    x_free(t->t.a, v->v);
  sym_destroy(t);
}

/*----- That's all, folks -------------------------------------------------*/
