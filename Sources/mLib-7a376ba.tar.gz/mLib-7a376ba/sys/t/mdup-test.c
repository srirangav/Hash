#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "mdup.h"

#define MAXFD 256

static void fail(const char *what) { perror(what); exit(1); }

int main(int argc, char *argv[])
{
  int i, n;
  int fd, fd2;
  struct stat st;
  int ino[MAXFD];
  int flag[MAXFD];
  mdup_fd fds[MAXFD];
  int win = 1;

  for (i = 0; i < argc - 1; i++) {
    if (i >= MAXFD) {
      fprintf(stderr, "too many\n");
      exit(1);
    }
    if (sscanf(argv[i + 1], "%d:%d", &fds[i].cur, &fds[i].want) < 2 ||
        fds[i].cur >= MAXFD) {
      fprintf(stderr, "bad syntax\n");
      exit(1);
    }
  }
  n = argc - 1;
  for (i = 0; i < MAXFD; i++) flag[i] = -1;
  for (i = 0; i < n; i++) {
    fd = fds[i].cur;
    if (flag[fd] >= 0)
      ino[i] = ino[flag[fd]];
    else {
      flag[fd] = i;
      if ((fd2 = open(",delete-me",
		      O_WRONLY | O_CREAT | O_EXCL,
		      0700)) < 0)
	fail("creat");
      unlink(",delete-me");
      if (fd2 != fd) {
	if (dup2(fd2, fd) < 0) fail("dup2");
	close(fd2);
      }
      if (fstat(fd, &st)) fail("fstat");
      ino[i] = st.st_ino;
    }
  }

  if (mdup(fds, n)) fail("mdup");

  for (i = 0; i < n; i++) {
    fd = fds[i].cur;
    if (fds[i].want != -1 && fds[i].want != fd) {
      printf("fd %d[%d] != %d\n", fd, i, fds[i].want);
      win = 0;
    } else if (fstat(fd, &st)) {
      printf("fstat %d[%d] failed: %s\n", fd, i, strerror(errno));
      win = 0;
    } else if (st.st_ino != ino[i]) {
      printf("ino %d[%d] wrong\n", fd, i);
      win = 0;
    }
  }

  return (!win);
}
