/* -*-c-*-
 *
 * Simplified POSIX locking interface
 *
 * (c) 1997 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <errno.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>

#include "lock.h"

/*----- Tunable constants -------------------------------------------------*/

#define LOCK_TIMEOUT 10			/* Maximum time in seconds to wait */

/*----- Static variables --------------------------------------------------*/

static jmp_buf jmp;			/* Jump here to interrup @fcntl@ */

/*----- Main code ---------------------------------------------------------*/

/* --- @sigalrm@ --- *
 *
 * Arguments:	@int sig@ = signal number
 *
 * Returns:	---
 *
 * Use:		Makes sure that a @SIGALRM@ signal interrupts system calls.
 */

static void sigalrm(int sig) { longjmp(jmp, 1); }

/* --- @lock_file@ --- *
 *
 * Arguments:	@int fd@ = file descriptor to lock
 *		@unsigned how@ = type of lock required
 *
 * Returns:	0 if OK, -1 if it failed.
 *
 * Use:		Acquires a lock on the given file.  The value @how@
 *		specifies the type of lock to acquire: @LOCK_EXCL@ gets
 *		an exclusive (write) lock; @LOCK_NONEXCL@ gets a non-
 *		exclusive (read) lock and @LOCK_UNLOCK@ releases any locks.
 *		Acquiring a lock gets timed out after a while with an
 *		error.
 */

int lock_file(int fd, unsigned how)
{
  struct flock fk;
  struct sigaction sa, osa;
  sigset_t ss, oss;
  int e;
  int al, d, left;

  /* --- Fill in the easy bits --- */

  fk.l_whence = SEEK_SET;
  fk.l_start = 0;
  fk.l_len = 0;

  /* --- Unlocking is really easy --- */

  if (how == LOCK_UNLOCK) {
    fk.l_type = F_UNLCK;
    return (fcntl(fd, F_SETLK, &fk));
  }

  /* --- Decide how to do the locking --- */

  if (how == LOCK_EXCL)
    fk.l_type = F_WRLCK;
  else if (how == LOCK_NONEXCL)
    fk.l_type = F_RDLCK;
  else {
    errno = EINVAL;
    return (-1);
  }

  /* --- Block @SIGALRM@ for a while --- *
   *
   * I don't want stray alarms going off while I'm busy here.
   */

  sigemptyset(&ss);
  sigaddset(&ss, SIGALRM);
  if (sigprocmask(SIG_BLOCK, &ss, &oss))
    return (-1);

  /* --- Set up the signal handler --- */

  sa.sa_handler = sigalrm;
  sa.sa_flags = 0;
#ifdef SA_INTERRUPT
  sa.sa_flags |= SA_INTERRUPT;
#endif
  sigemptyset(&sa.sa_mask);
  if (sigaction(SIGALRM, &sa, &osa))
    return (-1);

  /* --- Set up the alarm, remembering when it's meant to go off --- */

  al = alarm(0);
  if (al && al < LOCK_TIMEOUT)
    d = al;
  else
    d = LOCK_TIMEOUT;
  alarm(d);

  /* --- Set up the return context for the signal handler --- */

  if (setjmp(jmp)) {
    sigprocmask(SIG_SETMASK, &oss, 0);
    errno = EINTR;
    e = -1;
    goto done;
  }

  /* --- Unblock the signal and we're ready --- */

  if (sigprocmask(SIG_SETMASK, &oss, 0)) {
    alarm(al);
    e = -1;
    goto done;
  }

  /* --- Do it --- */

  e = fcntl(fd, F_SETLKW, &fk);

  /* --- Tidy up the mess I left --- */

  left = alarm(0);
  if (al)
    alarm(al - d + left);
done:
  sigaction(SIGALRM, &osa, 0);
  return (e);
}

/*----- That's all, fokls -------------------------------------------------*/
