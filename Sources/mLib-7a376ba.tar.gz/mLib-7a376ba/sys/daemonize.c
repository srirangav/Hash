/* -*-c-*-
 *
 * Become a daemon, detaching from terminals
 *
 * (c) 2007 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#include "daemonize.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @detachtty@ --- *
 *
 * Arguments:	---
 *
 * Returns:	---
 *
 * Use:		Detaches from the current terminal and ensures it can never
 *		acquire a new one.  Calls @fork@.
 */

void detachtty(void)
{
#ifdef TIOCNOTTY
  {
    int fd;
    if ((fd = open("/dev/tty", O_RDONLY)) >= 0) {
      ioctl(fd, TIOCNOTTY);
      close(fd);
    }
  }
#endif
  setsid();
  if (fork() > 0)
    _exit(0);
}

/* --- @daemonize@ --- *
 *
 * Arguments:	---
 *
 * Returns:	Zero if OK, nonzero on failure.
 *
 * Use:		Becomes a daemon.
 */

int daemonize(void)
{
  pid_t kid;

  if ((kid = fork()) < 0)
    return (-1);
  if (kid)
    _exit(0);
  detachtty();
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
