/* -*-c-*-
 *
 * Manipulates flags on file descriptors
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <fcntl.h>

#include "fdflags.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @fdflags@ --- *
 *
 * Arguments:	@int fd@ = file descriptor to fiddle with
 *		@unsigned fbic, fxor@ = file flags to set and clear
 *		@unsigned fdbic, fdxor@ = descriptor flags to set and clear
 *
 * Returns:	Zero if successful, @-1@ if not.
 *
 * Use:		Sets file descriptor flags in what is, I hope, an obvious
 *		way.
 */

int fdflags(int fd, unsigned fbic, unsigned fxor,
	    unsigned fdbic, unsigned fdxor)
{
  int f, ff;

  if (fbic || fxor) {
    if ((f = fcntl(fd, F_GETFL)) == -1)
      return (-1);
    ff = (f & ~fbic) ^ fxor;
    if (f != ff && fcntl(fd, F_SETFL, ff) == -1)
      return (-1);
  }
  if (fdbic || fdxor) {
    if ((f = fcntl(fd, F_GETFD)) == -1)
      return (-1);
    ff = (f & ~fdbic) ^ fdxor;
    if (f != ff && fcntl(fd, F_SETFD, ff) == -1)
      return (-1);
  }
  return (0);
}

/*----- That's all, folks -------------------------------------------------*/
