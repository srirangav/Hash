/* -*-c-*-
 *
 * File descriptor passing
 *
 * (c) 2003 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_FDPASS_H
#define MLIB_FDPASS_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <sys/types.h>
#include <unistd.h>

/*----- Functions provided ------------------------------------------------*/

/* --- @fdpass_send@ --- *
 *
 * Arguments:	@int sock@ = socket to send over
 *		@int fd@ = file descriptor to send
 *		@const void *p@ = pointer to data to send
 *		@size_t sz@ = size of buffer to send
 *
 * Returns:	On error, @-1@, otherwise number of bytes transferred from
 *		@p@.
 *
 * Use:		Sends a copy of file descriptor @fd@ to the other end of
 *		@sock@.
 */

extern ssize_t fdpass_send(int /*sock*/, int /*fd*/,
			   const void */*p*/, size_t /*sz*/);

/* --- @fdpass_recv@ --- *
 *
 * Arguments:	@int sock@ = socket to send over
 *		@int *fd@ = where to put received descriptor
 *		@void *p@ = pointer to where to put data
 *		@size_t sz@ = size of buffer
 *
 * Returns:	On error, @-1@, otherwise number of bytes transferred.
 *
 * Use:		Receives a file descriptor.  If the call succeeds, and there
 *		was a file descriptor, then @fd@ won't be @-1@ on exit;
 *		otherwise it will.  At most one descriptor will be collected.
 */

extern ssize_t fdpass_recv(int /*sock*/, int */*fd*/,
			   void */*p*/, size_t /*sz*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
