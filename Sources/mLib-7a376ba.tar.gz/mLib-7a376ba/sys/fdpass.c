/* -*-c-*-
 *
 * File descriptor passing
 *
 * (c) 2003 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "config.h"

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <sys/types.h>
#include <sys/time.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/uio.h>
#include <sys/un.h>

#include "fdpass.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @fdpass_send@ --- *
 *
 * Arguments:	@int sock@ = socket to send over
 *		@int fd@ = file descriptor to send
 *		@const void *p@ = pointer to data to send
 *		@size_t sz@ = size of buffer to send
 *
 * Returns:	On error, @-1@, otherwise number of bytes transferred from
 *		@p@.
 *
 * Use:		Sends a copy of file descriptor @fd@ to the other end of
 *		@sock@.
 */

ssize_t fdpass_send(int sock, int fd, const void *p, size_t sz)
{
  struct iovec iov;
  struct msghdr msg;
#ifndef HAVE_MSG_ACCRIGHTS
  char buf[CMSG_SPACE(sizeof(fd))];
  struct cmsghdr *cmsg;
#endif

  iov.iov_base = (/*unconst*/ void *)p;
  iov.iov_len = sz;
  msg.msg_name = 0;
  msg.msg_namelen = 0;
  msg.msg_iov = &iov;
  msg.msg_iovlen = 1;
#ifdef HAVE_MSG_ACCRIGHTS
  msg.msg_accrights = &fd;
  msg.msg_accrightslen = sizeof(fd);
#else
  msg.msg_flags = 0;
  msg.msg_control = buf;
  msg.msg_controllen = sizeof(buf);
  cmsg = CMSG_FIRSTHDR(&msg);
  cmsg->cmsg_len = CMSG_LEN(sizeof(fd));
  cmsg->cmsg_level = SOL_SOCKET;
  cmsg->cmsg_type = SCM_RIGHTS;
  memcpy(CMSG_DATA(cmsg), &fd, sizeof(fd));
#endif
  return (sendmsg(sock, &msg, 0));
}

/* --- @fdpass_recv@ --- *
 *
 * Arguments:	@int sock@ = socket to send over
 *		@int *fd@ = where to put received descriptor
 *		@void *p@ = pointer to where to put data
 *		@size_t sz@ = size of buffer
 *
 * Returns:	On error, @-1@, otherwise number of bytes transferred.
 *
 * Use:		Receives a file descriptor.  If the call succeeds, and there
 *		was a file descriptor, then @fd@ won't be @-1@ on exit;
 *		otherwise it will.  At most one descriptor will be collected.
 */

ssize_t fdpass_recv(int sock, int *fd, void *p, size_t sz)
{
  struct iovec iov;
  struct msghdr msg;
  ssize_t rc;
#ifndef HAVE_MSG_ACCRIGHTS
  char buf[CMSG_SPACE(sizeof(fd))];
  struct cmsghdr *cmsg;
  int fdtmp;
#endif

  *fd = -1;
  iov.iov_base = p;
  iov.iov_len = sz;
  msg.msg_name = 0;
  msg.msg_namelen = 0;
  msg.msg_iov = &iov;
  msg.msg_iovlen = 1;
#ifdef HAVE_MSG_ACCRIGHTS
  msg.msg_accrights = fd;
  msg.msg_accrightslen = sizeof(*fd);
#else
  msg.msg_flags = 0;
  msg.msg_control = buf;
  msg.msg_controllen = sizeof(buf);
#endif
  if ((rc = recvmsg(sock, &msg, 0)) < 0)
    return (rc);
#ifdef HAVE_MSG_ACCRIGHTS
  if (msg.msg_accrightslen < sizeof(*fd))
    *fd = -1;
#else
  for (cmsg = CMSG_FIRSTHDR(&msg); cmsg; cmsg = CMSG_NXTHDR(&msg, cmsg)) {
    if (cmsg->cmsg_level == SOL_SOCKET &&
	cmsg->cmsg_type == SCM_RIGHTS &&
	cmsg->cmsg_len >= CMSG_LEN(sizeof(fd))) {
      memcpy(&fdtmp, CMSG_DATA(cmsg), sizeof(fdtmp));
      if (*fd == -1)
	*fd = fdtmp;
      else
	close(fdtmp);
    }
  }
#endif
  return (rc);
}

/*----- That's all, folks -------------------------------------------------*/
