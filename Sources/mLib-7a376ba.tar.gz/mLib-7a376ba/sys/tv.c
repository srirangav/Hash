/* -*-c-*-
 *
 * Manipulation of timeval structures
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <sys/time.h>
#include "tv.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @tv_add@ --- *
 *
 * Arguments:	@struct timeval *dst@ = destination block
 *		@const struct timeval *a, *b@ = source blocks
 *
 * Returns:	---
 *
 * Use:		Adds two timevals.
 */

void tv_add(struct timeval *dst,
	    const struct timeval *a, const struct timeval *b)
{
  TV_ADD(dst, a, b);
}

/* --- @tv_addl@ --- *
 *
 * Arguments:	@struct timeval *dst@ = destination block
 *		@const struct timeval *a@ = source blocks
 *		@time_t sec@, @unsigned long usec@ = time to add
 *
 * Returns:	---
 *
 * Use:		Adds a literal time in seconds and microseconds.
 */

void tv_addl(struct timeval *dst, const struct timeval *a,
	     time_t sec, unsigned long usec)
{
  TV_ADDL(dst, a, sec, usec);
}

/* --- @tv_sub@ --- *
 *
 * Arguments:	@struct timeval *dst@ = destination block
 *		@const struct timeval *a, *b@ = source blocks
 *
 * Returns:	---
 *
 * Use:		Subtracts two timevals.
 */

void tv_sub(struct timeval *dst,
	    const struct timeval *a, const struct timeval *b)
{
  TV_SUB(dst, a, b);
}

/* --- @tv_subl@ --- *
 *
 * Arguments:	@struct timeval *dst@ = destination block
 *		@const struct timeval *a@ = source blocks
 *		@time_t sec@, @unsigned long usec@ = time to subtract
 *
 * Returns:	---
 *
 * Use:		Subtracts a literal time in seconds and microseconds.
 */

void tv_subl(struct timeval *dst, const struct timeval *a,
		    time_t sec, unsigned long usec)
{
  TV_SUBL(dst, a, sec, usec);
}

/* --- @tv_cmp@ --- *
 *
 * Arguments:	@const struct timeval *a, *b@ = source blocks
 *
 * Returns:	Less than, equal to, or greater than zero.
 *
 * Use:		Compares two timevals.
 */

int tv_cmp(const struct timeval *a, const struct timeval *b)
{
  /* --- This is more awkward than the case the macro deals with --- */

  if (a->tv_sec > b->tv_sec)
    return (1);
  else if (a->tv_sec < b->tv_sec)
    return (-1);
  else if (a->tv_usec > b->tv_usec)
    return (1);
  else if (a->tv_usec < b->tv_usec)
    return (-1);
  else
    return (0);
}

/*----- That's all, folks -------------------------------------------------*/
