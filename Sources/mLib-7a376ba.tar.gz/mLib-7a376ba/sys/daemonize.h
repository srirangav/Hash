/* -*-c-*-
 *
 * Become a daemon, detaching from terminals
 *
 * (c) 2007 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_DAEMONIZE_H
#define MLIB_DAEMONIZE_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Functions provided ------------------------------------------------*/

/* --- @detachtty@ --- *
 *
 * Arguments:	---
 *
 * Returns:	---
 *
 * Use:		Detaches from the current terminal and ensures it can never
 *		acquire a new one.  Calls @fork@.
 */

extern void detachtty(void);

/* --- @daemonize@ --- *
 *
 * Arguments:	---
 *
 * Returns:	Zero if OK, nonzero on failure.
 *
 * Use:		Becomes a daemon.
 */

extern int daemonize(void);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
