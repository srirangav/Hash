/* -*-c-*-
 *
 * Manipulation of timeval structures
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_TV_H
#define MLIB_TV_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <sys/time.h>

/*----- A macro to make reading easier ------------------------------------*/

#define MILLION 1000000

/*----- Functions provided ------------------------------------------------*/

/* --- @tv_add@ --- *
 *
 * Arguments:	@struct timeval *dst@ = destination block
 *		@const struct timeval *a, *b@ = source blocks
 *
 * Returns:	---
 *
 * Use:		Adds two timevals.
 */

extern void tv_add(struct timeval */*dst*/,
		   const struct timeval */*a*/,
		   const struct timeval */*b*/);

#define TV_ADD(dst, a, b) TV_ADDL(dst, a, (b)->tv_sec, (b)->tv_usec)

/* --- @tv_addl@ --- *
 *
 * Arguments:	@struct timeval *dst@ = destination block
 *		@const struct timeval *a@ = source blocks
 *		@time_t sec@, @unsigned long usec@ = time to add
 *
 * Returns:	---
 *
 * Use:		Adds a literal time in seconds and microseconds.
 */

extern void tv_addl(struct timeval */*dst*/,
		    const struct timeval */*a*/,
		    time_t /*sec*/, unsigned long /*usec*/);

#define TV_ADDL(dst, a, sec, usec) do {					\
  (dst)->tv_sec = (a)->tv_sec + (sec);					\
  (dst)->tv_usec = (a)->tv_usec + (usec);				\
  if ((dst)->tv_usec >= MILLION) {					\
    (dst)->tv_usec -= MILLION;						\
    (dst)->tv_sec++;							\
  }									\
} while (0)

/* --- @tv_sub@ --- *
 *
 * Arguments:	@struct timeval *dst@ = destination block
 *		@const struct timeval *a, *b@ = source blocks
 *
 * Returns:	---
 *
 * Use:		Subtracts two timevals.
 */

extern void tv_sub(struct timeval */*dst*/,
		   const struct timeval */*a*/,
		   const struct timeval */*b*/);

#define TV_SUB(dst, a, b) TV_SUBL(dst, a, (b)->tv_sec, (b)->tv_usec)

/* --- @tv_subl@ --- *
 *
 * Arguments:	@struct timeval *dst@ = destination block
 *		@const struct timeval *a@ = source blocks
 *		@time_t sec@, @unsigned long usec@ = time to subtract
 *
 * Returns:	---
 *
 * Use:		Subtracts a literal time in seconds and microseconds.
 */

extern void tv_subl(struct timeval */*dst*/,
		    const struct timeval */*a*/,
		    time_t /*sec*/, unsigned long /*usec*/);

#define TV_SUBL(dst, a, sec, usec) do {					\
  (dst)->tv_sec = (a)->tv_sec - (sec);					\
  if ((a)->tv_usec >= (usec))						\
    (dst)->tv_usec = (a)->tv_usec - (usec);				\
  else {								\
    (dst)->tv_usec = (a)->tv_usec + MILLION - (usec);			\
    (dst)->tv_sec--;							\
  }									\
} while (0)

/* --- @tv_cmp@ --- *
 *
 * Arguments:	@const struct timeval *a, *b@ = source blocks
 *
 * Returns:	Less than, equal to, or greater than zero.
 *
 * Use:		Compares two timevals.
 */

extern int tv_cmp(const struct timeval */*a*/,
		  const struct timeval */*b*/);

#define TV_CMP(a, op, b) ((a)->tv_sec == (b)->tv_sec ?			\
			    (a)->tv_usec op (b)->tv_usec :		\
			    (a)->tv_sec op (b)->tv_sec)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
