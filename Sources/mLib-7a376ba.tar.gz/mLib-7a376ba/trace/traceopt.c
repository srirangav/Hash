/* -*-c-*-
 *
 * Parsing tracing options
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "report.h"
#include "trace.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @traceopt@ --- *
 *
 * Arguments:	@const trace_opt *t@ = pointer to trace options table
 *		@const char *p@ = option string supplied by user
 *		@unsigned f@ = initial tracing flags
 *		@unsigned bad@ = forbidden tracing flags
 *
 * Returns:	Trace flags as set by user.
 *
 * Use:		Parses an option string from the user and sets the
 *		appropriate trace flags.  If the argument is null or a single
 *		`?' character, a help message is displayed.
 */

unsigned traceopt(const trace_opt *t, const char *p,
		  unsigned f, unsigned bad)
{
  unsigned sense = 1;

  /* --- Dump out help text --- */

  if (!p || !strcmp(p, "?")) {
    const trace_opt *tt;
    puts("Trace options:");
    for (tt = t; tt->ch; tt++) {
      if (!(tt->f & ~bad) || !tt->help)
	continue;
      printf("	`%c': %s\n", tt->ch, tt->help);
    }
    return (f);
  }

  /* --- Parse the string properly --- */

  f = 0;
  while (*p) {
    switch (*p) {
      case '+':
	sense = 1;
	break;
      case '-':
	sense = 0;
	break;
      default: {
	const trace_opt *tt;
	for (tt = t; tt->ch; tt++) {
	  if (!(tt->f & ~bad))
	    continue;
	  if (tt->ch == *p) {
	    if (sense)
	      f |= (tt->f & ~bad);
	    else
	      f &= ~(tt->f & ~bad);
	    goto ok;
	  }
	}
	moan("unknown trace option `%c'", *p);
      ok:;
      } break;
    }
    p++;
  }

  return (f);
}

/*----- That's all, folks -------------------------------------------------*/
