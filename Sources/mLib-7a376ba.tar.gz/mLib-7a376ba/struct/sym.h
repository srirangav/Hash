/* -*-c-*-
 *
 * Symbol table management
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_SYM_H
#define MLIB_SYM_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Required headers --------------------------------------------------*/

#include <stddef.h>

#ifndef MLIB_BITS_H
#  include "bits.h"
#endif

#ifndef MLIB_HASH_H
#  include "hash.h"
#endif

#ifndef MLIB_SUB_H
#  include "sub.h"
#endif

/*----- Tuning parameters -------------------------------------------------*/

/* --- Initial hash table size --- *
 *
 * This is the initial @mask@ value.  It must be of the form %$2^n - 1$%,
 * so that it can be used to mask of the bottom bits of a hash value.
 */

#define SYM_INITSZ 32			/* Size of a new hash table */

/* --- Maximum load factor --- *
 *
 * This parameter controls how much the table has to be loaded before the
 * table is extended.  The number of elements %$n$%, the number of bins %$b$%
 * and the limit %$l$% satisfy the relation %$n < bl$%; if a new item is
 * added to the table and this relation is found to be false, the table is
 * doubled in size.
 */

#define SYM_LIMIT(n) ((n) * 2)		/* Load factor for growing table */

/*----- Type definitions --------------------------------------------------*/

/* --- Symbol table --- *
 *
 * A @sym_table@ contains the information needed to manage a symbol table.
 * Users shouldn't fiddle with this information directly, but it needs to be
 * here so that objects of the correct type can be created.
 */

typedef struct sym_table {
  hash_table t;
  subarena *s;
  size_t load;
} sym_table;

/* --- A symbol table entry --- *
 *
 * I don't care what actually gets stored in symbol entries because I don't
 * create them: that's the responsibility of my client.  All I care about
 * here is that whatever gets passed to me is a structure whose first member
 * is a @sym_base@.  The ANSI guarantees about structure layout are
 * sufficient to allow me to manipulate such objects.
 */

typedef struct sym_base {
  hash_base b;				/* Base structure */
  char *name;				/* Pointer to name string */
  size_t len;				/* Length of the symbol's name */
} sym_base;

/* --- Macros for picking out useful information --- *
 *
 * Note that @SYM_LEN@ returns the size of the symbol key.  For textual keys,
 * this will include the terminating null.
 */

#define SYM_NAME(sy) ((const char *)(((sym_base *)(sy))->name))
#define SYM_LEN(sy) (((sym_base *)(sy))->len + 0)
#define SYM_HASH(sy) (((sym_base *)(sy))->b.hash + 0)

/* --- An iterator block --- */

typedef struct { hash_iter i; } sym_iter;

/*----- External functions ------------------------------------------------*/

/* --- @sym_create@ --- *
 *
 * Arguments:	@sym_table *t@ = symbol table to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes the given symbol table.  Raises @EXC_NOMEM@ if
 *		there isn't enough memory.
 */

extern void sym_create(sym_table */*t*/);

/* --- @sym_destroy@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to symbol table in question
 *
 * Returns:	---
 *
 * Use:		Destroys a symbol table, freeing all the memory it used to
 *		occupy.
 */

extern void sym_destroy(sym_table */*t*/);

/* --- @sym_find@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to symbol table in question
 *		@const char *n@ = pointer to symbol name to look up
 *		@long l@ = length of the name string or negative to measure
 *		@size_t sz@ = size of desired symbol object, or zero
 *		@unsigned *f@ = pointer to a flag, or null.
 *
 * Returns:	The address of a @sym_base@ structure, or null if not found
 *		and @sz@ is zero.
 *
 * Use:		Looks up a symbol in a given symbol table.  The name is
 *		passed by the address of its first character.  The length
 *		may be given, in which case the name may contain arbitrary
 *		binary data, or it may be given as a negative number, in
 *		which case the length of the name is calculated as
 *		@strlen(n) + 1@.
 *
 *		The return value is the address of a pointer to a @sym_base@
 *		block (which may have other things on the end, as above).  If
 *		the symbol could be found, the return value points to the
 *		symbol block.  If the symbol wasn't there, then if @sz@ is
 *		nonzero, a new symbol is created and its address is returned;
 *		otherwise a null pointer is returned.  The exception
 *		@EXC_NOMEM@ is raised if the block can't be allocated.
 *
 *		The value of @*f@ indicates whether a new symbol entry was
 *		created: a nonzero value indicates that an old value was
 *		found.
 */

extern void *sym_find(sym_table */*t*/, const char */*n*/, long /*l*/,
		      size_t /*sz*/, unsigned */*f*/);

/* --- @sym_remove@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to a symbol table object
 *		@void *b@ = pointer to symbol table entry
 *
 * Returns:	---
 *
 * Use:		Removes the object from the symbol table.  The space occupied
 *		by the object and its name is freed; anything else attached
 *		to the entry should already be gone by this point.
 */

extern void sym_remove(sym_table */*t*/, void */*b*/);

/* --- @sym_mkiter@ --- *
 *
 * Arguments:	@sym_iter *i@ = pointer to an iterator object
 *		@sym_table *t@ = pointer to a symbol table object
 *
 * Returns:	---
 *
 * Use:		Creates a new symbol table iterator which may be used to
 *		iterate through a symbol table.
 */

#define SYM_MKITER(i_, t_) HASH_MKITER(&(i_)->i, &(t_)->t)

extern void sym_mkiter(sym_iter */*i*/, sym_table */*t*/);

/* --- @sym_next@ --- *
 *
 * Arguments:	@sym_iter *i@ = pointer to iterator object
 *
 * Returns:	Pointer to the next symbol found, or null when finished.
 *
 * Use:		Returns the next symbol from the table.  Symbols are not
 *		returned in any particular order.
 */

#define SYM_NEXT(i_, p) do {						\
  hash_base *_q;							\
  HASH_NEXT(&(i_)->i, _q);						\
  (p) = (void *)_q;							\
} while (0)

extern void *sym_next(sym_iter */*i*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
