/* -*-c-*-
 *
 * Handle dynamically growing strings
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_DSTR_H
#define MLIB_DSTR_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Rationale ---------------------------------------------------------*
 *
 * This file declares what is hopefully a fairly useful collection of
 * primitive string handling functions.  The idea is that the strings
 * allocate memory for themselves as required.  The @dstr@ routines don't
 * assume any sort of terminator character, so arbitrary binary data can
 * be stored in a dynamic string.  With luck, this should put a stop to
 * any buffer overflow problems.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#ifndef MLIB_ALLOC_H
#  include "alloc.h"
#endif

#ifndef MLIB_ARENA_H
#  include "arena.h"
#endif

#ifndef MLIB_MACROS_H
#  include "macros.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct dstr {
  char *buf;				/* Pointer to string buffer */
  size_t sz;				/* Size of the buffer */
  size_t len;				/* Length of the string */
  arena *a;				/* Pointer to arena */
} dstr;

#define DSTR_INIT { 0, 0, 0, &arena_stdlib } /* How to initialize one */

/*----- Functions provided ------------------------------------------------*/

/* --- @dstr_create@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Initializes a dynamic string.
 */

extern void dstr_create(dstr */*d*/);

#define DCREATE(d) do {							\
  dstr *_dd = (d);							\
  _dd->buf = 0;								\
  _dd->sz = 0;								\
  _dd->len = 0;								\
  _dd->a = &arena_stdlib;						\
} while (0)

/* --- @dstr_destroy@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Reclaims the space used by a dynamic string.
 */

extern void dstr_destroy(dstr */*d*/);

#define DDESTROY(d) do {						\
  dstr *_d = (d);							\
  if (_d->buf)								\
    x_free(_d->a, _d->buf);						\
  DCREATE(_d);								\
} while (0)

/* --- @dstr_reset@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Resets a string so that new data gets put at the beginning.
 */

extern void dstr_reset(dstr */*d*/);

#define DRESET(d) ((d)->len = 0)

/* --- @dstr_ensure@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@size_t sz@ = amount of free space to ensure
 *
 * Returns:	---
 *
 * Use:		Ensures that at least @sz@ bytes are available in the
 *		given string.
 */

extern void dstr_ensure(dstr */*d*/, size_t /*sz*/);

#define DENSURE(d, rq) do {						\
  dstr *_dd = (d);							\
  size_t _rq = (rq);							\
  if (_dd->len + _rq > _dd->sz) dstr_ensure(_dd, _rq);			\
} while (0)

/* --- @dstr_putc@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@int ch@ = character to append
 *
 * Returns:	---
 *
 * Use:		Appends a character to a string.
 */

extern void dstr_putc(dstr */*d*/, int /*ch*/);

#define DPUTC(d, ch) do {						\
  dstr *_d = (d);							\
  DENSURE(_d, 1);							\
  *((unsigned char *)_d->buf + _d->len++) = (ch);			\
} while (0)

/* --- @dstr_putz@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Appends a null byte to a string.  The null byte does not
 *		contribute to the string's length, and will be overwritten
 *		by subsequent `put' operations.
 */

extern void dstr_putz(dstr */*d*/);

#define DPUTZ(d) do {							\
  dstr *_d = (d);							\
  DENSURE(_d, 1);							\
  _d->buf[_d->len] = 0;						\
} while (0)

/* --- @dstr_puts@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@const char *s@ = pointer to string to append
 *
 * Returns:	---
 *
 * Use:		Appends a character string to a string.  A trailing null
 *		byte is added, as for @dstr_putz@.
 */

extern void dstr_puts(dstr */*d*/, const char */*s*/);

#define DPUTS(d, s) do {						\
  dstr *_d = (d);							\
  const char *_s = (s);							\
  size_t _sz = strlen(_s);						\
  DENSURE(_d, _sz + 1);							\
  memcpy(_d->buf + _d->len, _s, _sz + 1);				\
  _d->len += _sz;							\
} while (0)

/* --- @dstr_vputf@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@const char *p@ = pointer to @printf@-style format string
 *		@va_list *ap@ = argument handle
 *
 * Returns:	The number of characters written to the string.
 *
 * Use:		As for @dstr_putf@, but may be used as a back-end to user-
 *		supplied functions with @printf@-style interfaces.
 */

extern int dstr_vputf(dstr */*d*/, const char */*p*/, va_list */*ap*/);

/* --- @dstr_putf@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@const char *p@ = pointer to @printf@-style format string
 *		@...@ = argument handle
 *
 * Returns:	The number of characters written to the string.
 *
 * Use:		Writes a piece of text to a dynamic string, doing @printf@-
 *		style substitutions as it goes.  Intended to be robust if
 *		faced with malicious arguments, but not if the format string
 *		itself is malicious.
 */

extern int PRINTF_LIKE(2, 3)
  dstr_putf(dstr */*d*/, const char */*p*/, ...);

/* --- @dstr_putd@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@const dstr *s@ = pointer to a dynamic string to append
 *
 * Returns:	---
 *
 * Use:		Appends a dynamic string to a string.  A trailing null
 *		byte is added, as for @dstr_putz@.
 */

extern void dstr_putd(dstr */*d*/, const dstr */*s*/);

#define DPUTD(d, s) do {						\
  dstr *_d = (d);							\
  const dstr *_s = (s);							\
  DENSURE(_d, _s->len + 1);						\
  memcpy(_d->buf + _d->len, _s->buf, _s->len);				\
  _d->len += _s->len;							\
  _d->buf[_d->len] = 0;							\
} while (0)

/* --- @dstr_putm@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@const void *p@ = pointer to a block to append
 *		@size_t sz@ = size of the block
 *
 * Returns:	Appends an arbitrary data block to a string.  No trailing
 *		null is appended.
 */

extern void dstr_putm(dstr */*d*/, const void */*p*/, size_t /*sz*/);

#define DPUTM(d, p, sz) do {						\
  dstr *_d = (d);							\
  size_t _sz = (sz);							\
  DENSURE(_d, _sz);							\
  memcpy(_d->buf + _d->len, (p), _sz);					\
  _d->len += _sz;							\
} while (0)

/* --- @dstr_tidy@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Reduces the amount of memory used by a string.  A trailing
 *		null byte is added, as for @dstr_putz@.
 */

extern void dstr_tidy(dstr */*d*/);

/* --- @dstr_putline@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@FILE *fp@ = a stream to read from
 *
 * Returns:	The number of characters read into the buffer, or @EOF@ if
 *		end-of-file was reached before any characters were read.
 *
 * Use:		Appends the next line from the given input stream to the
 *		string.  A trailing newline is not added; a trailing null
 *		byte is appended, as for @dstr_putz@.
 */

extern int dstr_putline(dstr */*d*/, FILE */*fp*/);

/* --- @dstr_write@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@FILE *fp@ = a stream to write on
 *
 * Returns:	The number of bytes written (as for @fwrite@).
 *
 * Use:		Writes a dynamic string to a file.
 */

extern size_t dstr_write(const dstr */*d*/, FILE */*fp*/);

#define DWRITE(d, fp) fwrite((d)->buf, 1, (d)->len, (fp))

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
