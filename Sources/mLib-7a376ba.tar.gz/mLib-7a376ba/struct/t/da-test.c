/* -*-c-*-
 *
 * Test driver for darray.
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "darray.h"
#include "exc.h"

DA_DECL(vec, int);

#ifdef notdef

static void dump(vec *v)
{
  printf("# len = %lu, sz = %lu, off = %lu; push = %u, unshift = %u\n",
	 (unsigned long)v->b.len,
	 (unsigned long)v->b.sz,
	 (unsigned long)v->b.off,
	 v->b.push, v->b.unshift);
  printf("# {");
  if (DA_LEN(v)) {
    size_t i;
    printf(" %i", DA(v)[0]);
    for (i = 1; i < DA_LEN(v); i++)
      printf(", %i", DA(v)[i]);
  }
  puts(" }");
  assert(v->b.sz + v->b.off == 128);
}

#endif

int main(void)
{
  char buf[1024];
  char *p;
  vec v = DA_INIT;

/*   setvbuf(stdout, 0, _IOLBF, BUFSIZ); */

  while (fgets(buf, sizeof(buf), stdin)) {
    buf[strlen(buf) - 1] = 0;
/*     printf("# %s\n", buf); */
    p = strtok(buf, " ");

    TRY {
      if (strcmp(p, "push") == 0) {
	int n = atoi(strtok(0, " "));
	DA_PUSH(&v, n);
      } else if (strcmp(p, "unshift") == 0) {
	int n = atoi(strtok(0, " "));
	DA_UNSHIFT(&v, n);
      } else if (strcmp(p, "pop") == 0) {
	printf("%i\n", DA_POP(&v));
      } else if (strcmp(p, "shift") == 0) {
	printf("%i\n", DA_SHIFT(&v));
      } else if (strcmp(p, "insert") == 0 ||
		 strcmp(p, "append") == 0) {
	vec vv;
	char *q = p;
	DA_CREATE(&vv);
/*	putchar('#'); */
	while ((p = strtok(0, " ")) != 0) {
	  int n = atoi(p);
	  DA_PUSH(&vv, n);
	}
	if (strcmp(q, "insert") == 0) {
	  DA_SHUNT(&v, DA_LEN(&vv));
	  DA_SLIDE(&v, DA_LEN(&vv));
	  memcpy(DA(&v), DA(&vv), DA_LEN(&vv) * sizeof(int));
	} else {
	  size_t l = DA_LEN(&v);
	  DA_ENSURE(&v, DA_LEN(&vv));
	  DA_EXTEND(&v, DA_LEN(&vv));
	  memcpy(DA(&v) + l, DA(&vv), DA_LEN(&vv) * sizeof(int));
	}
	DA_DESTROY(&vv);
      } else if (strcmp(p, "delete") == 0) {
	int n = atoi(strtok(0, " "));
	DA_UNSLIDE(&v, n);
      } else if (strcmp(p, "reduce") == 0) {
	int n = atoi(strtok(0, " "));
	DA_SHRINK(&v, n);
      } else if (strcmp(p, "set") == 0) {
	size_t i = atoi(strtok(0, " "));
	int n = atoi(strtok(0, " "));
	size_t l = DA_LEN(&v);
	DA_INCLUDE(&v, i);
	if (i >= l) {
	  size_t j;
	  for (j = l; j < i; j++)
	    DA(&v)[j] = -1;
	}
	DA(&v)[i] = n;
      } else if (strcmp(p, "get") == 0) {
	size_t i = atoi(strtok(0, " "));
	if (i >= DA_LEN(&v))
	  puts("*RANGE*");
	else
	  printf("%i\n", DA(&v)[i]);
      } else if (strcmp(p, "first") == 0) {
	if (DA_LEN(&v))
	  printf("%i\n", DA_FIRST(&v));
	else
	  puts("*RANGE*");
      } else if (strcmp(p, "last") == 0) {
	if (DA_LEN(&v))
	  printf("%i\n", DA_LAST(&v));
	else
	  puts("*RANGE*");
      } else if (strcmp(p, "show") == 0) {
	if (DA_LEN(&v) == 0)
	  puts("*EMPTY*");
	else {
	  size_t i;
	  printf("%i", DA(&v)[0]);
	  for (i = 1; i < DA_LEN(&v); i++)
	    printf(" %i", DA(&v)[i]);
	  putchar('\n');
	}
      } else
	puts("*BAD*");
    } CATCH switch (exc_type) {
      case DAEXC_UFLOW:
	puts("*UFLOW*");
	break;
      case DAEXC_OFLOW:
	puts("*OFLOW*");
	break;
      case EXC_NOMEM:
	puts("*NOMEM*");
	break;
      default:
	puts("*UNKNOWN-EXCEPTION*");
	break;
    } END_TRY;
/*     dump(&v); */
  }

  DA_DESTROY(&v);
  return (0);
}
