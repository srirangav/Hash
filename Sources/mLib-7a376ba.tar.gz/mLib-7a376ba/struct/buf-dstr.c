/* -*-c-*-
 *
 * Buffers and dynamic strings
 *
 * (c) 2005 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <string.h>

#include "buf.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @buf_getdstr{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@dstr *d@ = where to put the result
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Gets a block of data from a buffer, and writes its contents
 *		to a string.
 */

#define BUF_GETDSTR_(n, W, w)						\
  int buf_getdstr##w(buf *b, dstr *d)					\
  {									\
    void *p;								\
    size_t sz;								\
									\
    if ((p = buf_getmem##w(b, &sz)) == 0)				\
      return (-1);							\
    DPUTM(d, p, sz);							\
    return (0);								\
  }
BUF_DOSUFFIXES(BUF_GETDSTR_)

/* --- @buf_putdstr{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@dstr *d@ = string to write
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts a dynamic string to a buffer.
 */

#define BUF_PUTDSTR_(n, W, w)						\
  int buf_putdstr##w(buf *b, dstr *d)					\
    { return (buf_putmem##w(b, d->buf, d->len)); }
BUF_DOSUFFIXES(BUF_PUTDSTR_)

/*----- That's all, folks -------------------------------------------------*/
