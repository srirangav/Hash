/* -*-c-*-
 *
 * Buffer handling
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <assert.h>
#include <string.h>

#include "buf.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @buf_init@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@void *p@ = pointer to a buffer
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	---
 *
 * Use:		Initializes the buffer block appropriately.
 */

void buf_init(buf *b, void *p, size_t sz)
{
  b->base = b->p = p;
  b->limit = b->p + sz;
  b->f = 0;
}

/* --- @buf_break@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *
 * Returns:	Some negative value.
 *
 * Use:		Marks a buffer as broken.
 */

int buf_break(buf *b) { b->f |= BF_BROKEN; return (-1); }

/* --- @buf_flip@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *
 * Returns:	---
 *
 * Use:		Flips a buffer so that if you've just been writing to it,
 *		you can now read from the bit you've written.
 */

void buf_flip(buf *b)
{
  b->limit = b->p;
  b->p = b->base;
}

/* --- @buf_ensure@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@size_t sz@ = size of data wanted
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Ensures that there are @sz@ bytes still in the buffer.
 */

int buf_ensure(buf *b, size_t sz) { return (BENSURE(b, sz)); }

/* --- @buf_get@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	Pointer to the place in the buffer.
 *
 * Use:		Reserves a space in the buffer of the requested size, and
 *		returns its start address.
 */

void *buf_get(buf *b, size_t sz)
{
  void *p;
  if (BENSURE(b, sz))
    return (0);
  p = BCUR(b);
  BSTEP(b, sz);
  return (p);
}

/* --- @buf_put@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@const void *p@ = pointer to a buffer
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Fetches data from some place and puts it in the buffer
 */

int buf_put(buf *b, const void *p, size_t sz)
{
  if (BENSURE(b, sz))
    return (-1);
  memcpy(BCUR(b), p, sz);
  BSTEP(b, sz);
  return (0);
}

/* --- @buf_getbyte@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *
 * Returns:	A byte, or less than zero if there wasn't a byte there.
 *
 * Use:		Gets a single byte from a buffer.
 */

int buf_getbyte(buf *b)
{
  if (BENSURE(b, 1))
    return (-1);
  return (*b->p++);
}

/* --- @buf_putbyte@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@int ch@ = byte to write
 *
 * Returns:	Zero if OK, nonzero if there wasn't enough space.
 *
 * Use:		Puts a single byte in a buffer.
 */

int buf_putbyte(buf *b, int ch)
{
  if (BENSURE(b, 1))
    return (-1);
  *b->p++ = ch;
  return (0);
}

/* --- @buf_getu{8,{16,24,32,64}{,l,b}}@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@uintSZ *w@ = where to put the word
 *
 * Returns:	Zero if OK, or nonzero if there wasn't a word there.
 *
 * Use:		Gets a word of appropriate size and order from a buffer.
 */

#define BUF_GETU_(n, W, w)						\
  int buf_getu##w(buf *b, uint##n *ww)					\
  {									\
    if (BENSURE(b, SZ_##W)) return (-1);				\
    *ww = LOAD##W(b->p);						\
    BSTEP(b, SZ_##W);							\
    return (0);								\
  }
DOUINTCONV(BUF_GETU_)

/* --- @buf_putu{8,{16,24,32,64}{,l,b}}@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@uintSZ w@ = word to write
 *
 * Returns:	Zero if OK, or nonzero if there wasn't enough space
 *
 * Use:		Puts a word into a buffer with appropriate size and order.
 */

#define BUF_PUTU_(n, W, w)						\
  int buf_putu##w(buf *b, uint##n ww)					\
  {									\
    if (BENSURE(b, SZ_##W)) return (-1);				\
    STORE##W(b->p, ww);							\
    BSTEP(b, SZ_##W);							\
    return (0);								\
  }
DOUINTCONV(BUF_PUTU_)

/* --- @findz@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@size_t *nn@ = where to put the length
 *
 * Returns:	Zero if OK, nonzero if there wasn't a null byte to be found.
 *
 * Use:		Finds a terminating null byte.  The length includes this
 *		terminator.
 */

static int findz(buf *b, size_t *nn)
{
  octet *p;

  if ((p = memchr(BCUR(b), 0, BLEFT(b))) == 0) {
    buf_break(b);
    return (-1);
  }
  *nn = p - BCUR(b) + 1;
  return (0);
}

/* --- @buf_getmem{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@size_t *nn@ = where to put the length
 *
 * Returns:	Pointer to the buffer data, or null.
 *
 * Use:		Gets a chunk of memory from a buffer.  The suffix is the
 *		width and byte order of the length; @z@ means null-
 *		terminated.
 */

#define BUF_GETMEM_(n, W, w)						\
  void *buf_getmem##w(buf *b, size_t *nn)				\
  {									\
    uint##n sz;								\
    if (buf_getu##w(b, &sz)) return (0);				\
    *nn = sz;								\
    return (buf_get(b, sz));						\
  }
DOUINTCONV(BUF_GETMEM_)

void *buf_getmemz(buf *b, size_t *nn)
{
  if (findz(b, nn)) return (0);
  return (buf_get(b, *nn));
}

/* --- @buf_putmem{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@const void *p@ = pointer to data to write
 *		@size_t n@ = length to write
 *
 * Returns:	Zero if OK, nonzero if there wasn't enough space.
 *
 * Use:		Writes a chunk of data to a buffer.  The suffix is the
 *		width and byte order of the length; @z@ means null-
 *		terminated.
 */

#define BUF_PUTMEM_(n, W, w)						\
  int buf_putmem##w(buf *b, const void *p, size_t sz)			\
  {									\
    assert(sz <= MASK##W);						\
    if (buf_putu##w(b, sz) || buf_put(b, p, sz))			\
      return (-1);							\
    return (0);								\
  }
DOUINTCONV(BUF_PUTMEM_)

int buf_putmemz(buf *b, const void *p, size_t n)
{
  octet *q;

  assert(!memchr(p, 0, n));
  if ((q = buf_get(b, n + 1)) == 0)
    return (-1);
  memcpy(q, p, n);
  q[n] = 0;
  return (0);
}

/* --- @buf_getbuf{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@buf *bb@ = where to put the result
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Gets a block of data from a buffer, and writes its bounds to
 *		another buffer.
 */

#define BUF_GETBUF_(n, W, w)						\
  int buf_getbuf##w(buf *b, buf *bb)					\
  {									\
    void *p;								\
    size_t sz;								\
									\
    if ((p = buf_getmem##w(b, &sz)) == 0)				\
      return (-1);							\
    buf_init(bb, p, sz);						\
    return (0);								\
  }
BUF_DOSUFFIXES(BUF_GETBUF_)

/* --- @buf_putbuf{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@buf *bb@ = buffer to write
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts the contents of a buffer to a buffer.
 */

#define BUF_PUTBUF_(n, W, w)						\
  int buf_putbuf##w(buf *b, buf *bb)					\
    { return (buf_putmem##w(b, BBASE(bb), BLEN(bb))); }
BUF_DOSUFFIXES(BUF_PUTBUF_)

/* --- @buf_putstr{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@const char *p@ = string to write
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts a null-terminated string to a buffer.
 */

#define BUF_PUTSTR_(n, W, w)						\
  int buf_putstr##w(buf *b, const char *p)				\
    { return (buf_putmem##w(b, p, strlen(p))); }
BUF_DOSUFFIXES(BUF_PUTSTR_)

/*----- That's all, folks -------------------------------------------------*/
