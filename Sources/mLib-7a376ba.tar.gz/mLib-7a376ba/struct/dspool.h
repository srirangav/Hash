/* -*-c-*-
 *
 * Provide pools of strings
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#ifndef MLIB_DSPOOL_H
#define MLIB_DSPOOL_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_DSTR_H
#  include "dstr.h"
#endif

#ifndef MLIB_SUB_H
#  include "sub.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct dspoolstr {
  dstr ds;
  struct dspoolstr *next;
} dspoolstr;

typedef struct dspool {
  dspoolstr *free;
  size_t isz;
} dspool;

/*----- Functions provided ------------------------------------------------*/

/* --- @dspool_create@ --- *
 *
 * Arguments:	@dspool *p@ = address of pool to create
 *		@size_t isz@ = initial size of new strings
 *
 * Returns:	---
 *
 * Use:		Initializes a dynamic string pool.
 */

extern void dspool_create(dspool */*p*/, size_t /*isz*/);

/* --- @dspool_destroy@ --- *
 *
 * Arguments:	@dspool *p@ = pool to destroy
 *
 * Returns:	---
 *
 * Use:		Releases all of the strings left in the pool.  Any strings
 *		not put back into the pool aren't freed.  However, the pool
 *		is still valid, and the active strings can be put back and
 *		released later.
 */

extern void dspool_destroy(dspool */*p*/);

/* --- @dspool_get@ --- *
 *
 * Arguments:	@dspool *p@ = pointer to a string pool
 *
 * Returns:	Pointer to a dynamic string.
 *
 * Use:		Fetches a string from the pool.  The string has space for at
 *		least @isz@ characters (where @isz@ is the size passed to
 *		@dspool_create@ for the pool).
 */

extern dstr *dspool_get(dspool */*p*/);

#define DSGET(p, d) do {						\
  dspoolstr *_s;							\
  dspool *_p = (p);							\
  if (_p->free) {							\
    _s = _p->free;							\
    _p->free = _s->next;						\
  } else {								\
    _s = CREATE(dspoolstr);						\
    DCREATE(&_s->ds);							\
    if (_p->isz)							\
      DENSURE(&_s->ds, _p->isz);					\
  }									\
  d = &_s->ds;								\
} while (0)

/* --- @dspool_put@ --- *
 *
 * Arguments:	@dspool *p@ = pointer to a string pool
 *		@dstr *d@ = pointer to a dynamic string from a string pool
 *
 * Returns:	---
 *
 * Use:		Releases a dynamic string back into a string pool.  It
 *		doesn't have to be the same pool the string actually came
 *		from, although it does have to have come from some string
 *		pool.
 */

extern void dspool_put(dspool */*p*/, dstr */*d*/);

#define DSPUT(p, d) do {						\
  dspool *_p = (p);							\
  dspoolstr *_s = (dspoolstr *)(d);					\
  DRESET(d);								\
  _s->next = _p->free;							\
  _p->free = _s;							\
} while (0)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
