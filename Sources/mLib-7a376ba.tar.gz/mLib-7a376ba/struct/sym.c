/* -*-c-*-
 *
 * Symbol table management
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

/* --- ANSI headers --- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* --- Local headers --- */

#include "alloc.h"
#include "arena.h"
#include "bits.h"
#include "exc.h"
#include "hash.h"
#include "sub.h"
#include "sym.h"
#include "unihash.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @sym_create@ --- *
 *
 * Arguments:	@sym_table *t@ = symbol table to initialize
 *
 * Returns:	---
 *
 * Use:		Initializes the given symbol table.  Raises @EXC_NOMEM@ if
 *		there isn't enough memory.
 */

void sym_create(sym_table *t)
{
  hash_create(&t->t, SYM_INITSZ);
  t->s = &sub_global;
  t->load = SYM_LIMIT(SYM_INITSZ);
}

/* --- @sym_destroy@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to symbol table in question
 *
 * Returns:	---
 *
 * Use:		Destroys a symbol table, freeing all the memory it used to
 *		occupy.
 */

void sym_destroy(sym_table *t)
{
  sym_iter i;

  SYM_MKITER(&i, t);
  for (;;) {
    sym_base *p;
    SYM_NEXT(&i, p);
    if (!p)
      break;
    x_free(t->t.a, p);
  }
  hash_destroy(&t->t);
}

/* --- @sym_find@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to symbol table in question
 *		@const char *n@ = pointer to symbol name to look up
 *		@long l@ = length of the name string or negative to measure
 *		@size_t sz@ = size of desired symbol object, or zero
 *		@unsigned *f@ = pointer to a flag, or null.
 *
 * Returns:	The address of a @sym_base@ structure, or null if not found
 *		and @sz@ is zero.
 *
 * Use:		Looks up a symbol in a given symbol table.  The name is
 *		passed by the address of its first character.  The length
 *		may be given, in which case the name may contain arbitrary
 *		binary data, or it may be given as a negative number, in
 *		which case the length of the name is calculated as
 *		@strlen(n) + 1@.
 *
 *		The return value is the address of a pointer to a @sym_base@
 *		block (which may have other things on the end, as above).  If
 *		the symbol could be found, the return value points to the
 *		symbol block.  If the symbol wasn't there, then if @sz@ is
 *		nonzero, a new symbol is created and its address is returned;
 *		otherwise a null pointer is returned.  The exception
 *		@EXC_NOMEM@ is raised if the block can't be allocated.
 *
 *		The value of @*f@ indicates whether a new symbol entry was
 *		created: a nonzero value indicates that an old value was
 *		found.
 */

void *sym_find(sym_table *t, const char *n, long l, size_t sz, unsigned *f)
{
  uint32 hash;
  size_t len = 0;
  hash_base **bin, **p;
  sym_base *q;

  /* --- Find the correct bin --- */

  len = l < 0 ? strlen(n) : l;
  hash = UNIHASH(&unihash_global, n, len);
  bin = HASH_BIN(&t->t, hash);

  /* --- Search the bin list --- */

  for (p = bin; *p; p = &(*p)->next) {
    q = (sym_base *)*p;
    if (hash == q->b.hash && len == q->len && !memcmp(n, SYM_NAME(q), len)) {

      /* --- Found a match --- *
       *
       * As a minor, and probably pointless, tweak, move the item to the
       * front of its bin list.
       */

      (*p) = q->b.next;
      q->b.next = *bin;
      *bin = &q->b;

      /* --- Return the block --- */

      if (f) *f = 1;
      return (q);
    }
  }

  /* --- Couldn't find the item there --- */

  if (f) *f = 0;
  if (!sz) return (0);

  /* --- Create a new symbol block and initialize it --- *
   *
   * The name is attached to the end of the symbol block.
   */

  q = x_alloc(t->t.a, sz + len + 1);
  q->b.next = *bin;
  q->b.hash = hash;
  q->name = (char *)q + sz;
  memcpy(q->name, n, len);
  q->name[len] = 0;
  q->len = len;
  *bin = &q->b;

  /* --- Consider growing the array --- */

  if (t->load)
    t->load--;
  if (!t->load && hash_extend(&t->t))
    t->load = SYM_LIMIT(t->t.mask + 1);

  /* --- Finished that, so return the new symbol block --- */

  return (q);
}

/* --- @sym_remove@ --- *
 *
 * Arguments:	@sym_table *t@ = pointer to a symbol table object
 *		@void *p@ = pointer to symbol table entry
 *
 * Returns:	---
 *
 * Use:		Removes the object from the symbol table.  The space occupied
 *		by the object and its name is freed; anything else attached
 *		to the entry should already be gone by this point.
 */

void sym_remove(sym_table *t, void *p)
{
  sym_base *q = p;
  hash_remove(&t->t, &q->b);
  xfree(q);
  t->load++;
}

/* --- @sym_mkiter@ --- *
 *
 * Arguments:	@sym_iter *i@ = pointer to an iterator object
 *		@sym_table *t@ = pointer to a symbol table object
 *
 * Returns:	---
 *
 * Use:		Creates a new symbol table iterator which may be used to
 *		iterate through a symbol table.
 */

void sym_mkiter(sym_iter *i, sym_table *t) { SYM_MKITER(i, t); }

/* --- @sym_next@ --- *
 *
 * Arguments:	@sym_iter *i@ = pointer to iterator object
 *
 * Returns:	Pointer to the next symbol found, or null when finished.
 *
 * Use:		Returns the next symbol from the table.  Symbols are not
 *		returned in any particular order.
 */

void *sym_next(sym_iter *i)
{
  void *p;
  SYM_NEXT(i, p);
  return (p);
}

/*----- That's all, folks -------------------------------------------------*/
