/* -*-c-*-
 *
 * Handle dynamically growing strings
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "alloc.h"
#include "dstr.h"

/*----- Tunable constants -------------------------------------------------*/

/*
 * If the buffer is empty, it is set to @DSTR_INITSZ@ bytes in size.
 * Otherwise, it's set to the next power of two that's large enough.  This is
 * memory-hungry, but efficient.
 */

#define DSTR_INITSZ 64			/* Initial buffer size */

/*----- Main code ---------------------------------------------------------*/

/* --- @dstr_create@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Initializes a dynamic string.
 */

void dstr_create(dstr *d) { DCREATE(d); }

/* --- @dstr_destroy@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Reclaims the space used by a dynamic string.
 */

void dstr_destroy(dstr *d) { DDESTROY(d); }

/* --- @dstr_reset@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Resets a string so that new data gets put at the beginning.
 */

void dstr_reset(dstr *d) { DRESET(d); }

/* --- @dstr_ensure@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@size_t sz@ = amount of free space to ensure
 *
 * Returns:	---
 *
 * Use:		Ensures that at least @sz@ bytes are available in the
 *		given string.
 */

void dstr_ensure(dstr *d, size_t sz)
{
  size_t rq = d->len + sz;
  size_t nsz;

  /* --- If we have enough space, just leave it --- */

  if (rq <= d->sz)
    return;

  /* --- Grow the buffer --- */

  nsz = d->sz;

  if (nsz == 0)
    nsz = (DSTR_INITSZ >> 1);
  do nsz <<= 1; while (nsz < rq);

  if (d->buf)
    d->buf = x_realloc(d->a, d->buf, nsz, d->sz);
  else
    d->buf = x_alloc(d->a, nsz);
  d->sz = nsz;
}

/* --- @dstr_putc@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@int ch@ = character to append
 *
 * Returns:	---
 *
 * Use:		Appends a character to a string.
 */

void dstr_putc(dstr *d, int ch) { DPUTC(d, ch); }

/* --- @dstr_putz@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Appends a null byte to a string.  The null byte does not
 *		contribute to the string's length, and will be overwritten
 *		by subsequent `put' operations.
 */

void dstr_putz(dstr *d) { DPUTZ(d); }

/* --- @dstr_puts@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@const char *s@ = pointer to string to append
 *
 * Returns:	---
 *
 * Use:		Appends a character string to a string.  A trailing null
 *		byte is added, as for @dstr_putz@.
 */

void dstr_puts(dstr *d, const char *s) { DPUTS(d, s); }

/* --- @dstr_putd@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@const dstr *s@ = pointer to a dynamic string to append
 *
 * Returns:	---
 *
 * Use:		Appends a dynamic string to a string.  A trailing null
 *		byte is added, as for @dstr_putz@.
 */

void dstr_putd(dstr *d, const dstr *s) { DPUTD(d, s); }

/* --- @dstr_putm@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@const void *p@ = pointer to a block to append
 *		@size_t sz@ = size of the block
 *
 * Returns:	Appends an arbitrary data block to a string.  No trailing
 *		null is appended.
 */

void dstr_putm(dstr *d, const void *p, size_t sz) { DPUTM(d, p, sz); }

/* --- @dstr_tidy@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *
 * Returns:	---
 *
 * Use:		Reduces the amount of memory used by a string.  A trailing
 *		null byte is added, as for @dstr_putz@.
 */

void dstr_tidy(dstr *d)
{
  d->buf = x_realloc(d->a, d->buf, d->len + 1, d->sz);
  d->buf[d->len] = 0;
  d->sz = d->len + 1;
}

/* --- @dstr_putline@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@FILE *fp@ = a stream to read from
 *
 * Returns:	The number of characters read into the buffer, or @EOF@ if
 *		end-of-file was reached before any characters were read.
 *
 * Use:		Appends the next line from the given input stream to the
 *		string.  A trailing newline is not added; a trailing null
 *		byte is appended, as for @dstr_putz@.
 */

int dstr_putline(dstr *d, FILE *fp)
{
  size_t left = d->sz - d->len;
  size_t off = d->len;
  int rd = 0;
  int ch;

  for (;;) {

    /* --- Read the next byte --- */

    ch = getc(fp);

    /* --- End-of-file when no characters read is special --- */

    if (ch == EOF && !rd)
      return (EOF);

    /* --- Make sure there's some buffer space --- */

    if (!left) {
      d->len = off;
      dstr_ensure(d, 1);
      left = d->sz - off;
    }

    /* --- End-of-file or newline ends the loop --- */

    if (ch == EOF || ch == '\n') {
      d->buf[off] = 0;
      d->len = off;
      return rd;
    }

    /* --- Append the character and continue --- */

    d->buf[off++] = ch;
    left--; rd++;
  }
}

/* --- @dstr_write@ --- *
 *
 * Arguments:	@dstr *d@ = pointer to a dynamic string block
 *		@FILE *fp@ = a stream to write on
 *
 * Returns:	The number of bytes written (as for @fwrite@).
 *
 * Use:		Writes a dynamic string to a file.
 */

size_t dstr_write(const dstr *d, FILE *fp) { return (DWRITE(d, fp)); }

/*----- That's all, folks -------------------------------------------------*/
