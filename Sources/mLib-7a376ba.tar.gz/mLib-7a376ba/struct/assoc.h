/* -*-c-*-
 *
 * Assocation tables
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_ASSOC_H
#define MLIB_ASSOC_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#ifndef MLIB_ATOM_H
#  include "atom.h"
#endif

#ifndef MLIB_HASH_H
#  include "hash.h"
#endif

/*----- Data structures ---------------------------------------------------*/

typedef struct assoc_table {
  hash_table t;
  size_t load;
} assoc_table;

typedef struct assoc_base {
  hash_base b;
  atom *a;
} assoc_base;

typedef struct { hash_iter i; } assoc_iter;

#define ASSOC_ATOM(p) (((assoc_base *)(p))->a + 0)

/*----- Functions provided ------------------------------------------------*/

/* --- @assoc_create@ --- *
 *
 * Arguments:	@assoc_table *t@ = pointer to an association table
 *
 * Returns:	---
 *
 * Use:		Creates a new association table.
 */

extern void assoc_create(assoc_table */*t*/);

/* --- @assoc_destroy@ --- *
 *
 * Arguments:	@assoc_table *t@ = pointer to an association table
 *
 * Returns:	---
 *
 * Use:		Destroys an association table.
 */

extern void assoc_destroy(assoc_table */*t*/);

/* --- @assoc_find@ --- *
 *
 * Arguments:	@assoc_table *t@ = pointer to an association table
 *		@atom *a@ = an atom to label the item
 *		@size_t sz@ = size of block to allocate
 *		@unsigned *f@ = pointer to `found' flag
 *
 * Returns:	A pointer to the item located or null.
 *
 * Use:		Looks up an atom in an association table.  If the atom is
 *		found, the association is returned.  If not, and @sz@ is
 *		zero, a null pointer is returned.  Otherwise, a block of size
 *		@sz@ is allocated, its @assoc_base@ header is filled in, and
 *		the pointer returned.  The flag @*f@ is cleared if the item
 *		couldn't be found, or set if it was.
 *
 *		All the atoms used in a particular table should
 */

extern void *assoc_find(assoc_table */*t*/, atom */*a*/,
			size_t /*sz*/, unsigned */*f*/);

/* --- @assoc_remove@ --- *
 *
 * Arguments:	@assoc_table *t@ = pointer to an association table
 *		@void *p@ = pointer to a block to remove
 *
 * Returns:	---
 *
 * Use:		Removes an association from a table.
 */

extern void assoc_remove(assoc_table */*t*/, void */*p*/);

/* --- @assoc_mkiter@, @assoc_next@ --- *
 *
 * Arguments:	@assoc_iter *i@ = pointer to an iterator
 *		@assoc_table *t@ = pointer to an association table
 *
 * Returns:	Next association, or null, for @assoc_next@; nothing for
 *		@assoc_mkiter@.
 *
 * Use:		Iterates over the associations in a table.
 */

#define ASSOC_MKITER(i_, t_) HASH_MKITER(&(i_)->i, &(t_)->t)

#define ASSOC_NEXT(i_, p) do {						\
  hash_base *_q;							\
  HASH_NEXT(&(i_)->i, _q);						\
  (p) = (void *)_q;							\
} while (0)

extern void assoc_mkiter(assoc_iter */*i*/, assoc_table */*t*/);
extern void *assoc_next(assoc_iter */*i*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
