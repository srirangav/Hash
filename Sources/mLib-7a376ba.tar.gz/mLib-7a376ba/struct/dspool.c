/* -*-c-*-
 *
 * Provide pools of strings
 *
 * (c) 1999 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>

#include "dspool.h"
#include "dstr.h"
#include "sub.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @dspool_create@ --- *
 *
 * Arguments:	@dspool *p@ = address of pool to create
 *		@size_t isz@ = initial size of new strings
 *
 * Returns:	---
 *
 * Use:		Initializes a dynamic string pool.
 */

void dspool_create(dspool *p, size_t isz)
{
  p->free = 0;
  p->isz = isz;
}

/* --- @dspool_destroy@ --- *
 *
 * Arguments:	@dspool *p@ = pool to destroy
 *
 * Returns:	---
 *
 * Use:		Releases all of the strings left in the pool.  Any strings
 *		not put back into the pool aren't freed.  However, the pool
 *		is still valid, and the active strings can be put back and
 *		released later.
 */

void dspool_destroy(dspool *p)
{
  dspoolstr *s = p->free;
  while (s) {
    dspoolstr *n = s->next;
    DDESTROY(&s->ds);
    DESTROY(s);
    s = n;
  }
  p->free = 0;
}

/* --- @dspool_get@ --- *
 *
 * Arguments:	@dspool *p@ = pointer to a string pool
 *
 * Returns:	Pointer to a dynamic string.
 *
 * Use:		Fetches a string from the pool.  The string has space for at
 *		least @isz@ characters (where @isz@ is the size passed to
 *		@dspool_create@ for the pool).
 */

dstr *dspool_get(dspool *p) { dstr *d; DSGET(p, d); return (d); }

/* --- @dspool_put@ --- *
 *
 * Arguments:	@dspool *p@ = pointer to a string pool
 *		@dstr *d@ = pointer to a dynamic string from a string pool
 *
 * Returns:	---
 *
 * Use:		Releases a dynamic string back into a string pool.  It
 *		doesn't have to be the same pool the string actually came
 *		from, although it does have to have come from some string
 *		pool.
 */

void dspool_put(dspool *p, dstr *d) { DSPUT(p, d); }

/*----- That's all, folks -------------------------------------------------*/
