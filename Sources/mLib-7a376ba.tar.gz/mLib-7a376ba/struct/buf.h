/* -*-c-*-
 *
 * Reading and writing packet buffers
 *
 * (c) 2001 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_BUF_H
#define MLIB_BUF_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stddef.h>

#ifndef MLIB_BITS_H
#  include "bits.h"
#endif

#ifndef MLIB_DSTR_H
#  include "dstr.h"
#endif

/*----- Data structures ---------------------------------------------------*/

/* --- Buffers --- *
 *
 * Buffers provide a simple stream-like interface for building and parsing
 * packets.
 */

typedef struct buf {
  octet *base, *p, *limit;		/* Pointers to the buffer */
  unsigned f;				/* Various flags */
} buf;

#define BF_BROKEN 1u			/* Buffer is broken */

/*----- Useful macros -----------------------------------------------------*/

#define BBASE(b) ((b)->base)
#define BLIM(b) ((b)->limit)
#define BCUR(b) ((b)->p)
#define BSZ(b) ((b)->limit - (b)->base)
#define BLEN(b) ((b)->p - (b)->base)
#define BLEFT(b) ((b)->limit - (b)->p)
#define BSTEP(b, sz) ((b)->p += (sz))
#define BBAD(b) ((b)->f & BF_BROKEN)
#define BOK(b) (!BBAD(b))

#define BENSURE(b, sz)							\
  (BBAD(b) ? -1 : (sz) > BLEFT(b) ? (b)->f |= BF_BROKEN, -1 : 0)

#define BUF_DOSUFFIXES(_) DOUINTCONV(_) _(z, z, z)

/*----- Functions provided ------------------------------------------------*/

/* --- @buf_init@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@void *p@ = pointer to a buffer
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	---
 *
 * Use:		Initializes the buffer block appropriately.
 */

extern void buf_init(buf */*b*/, void */*p*/, size_t /*sz*/);

/* --- @buf_break@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *
 * Returns:	Some negative value.
 *
 * Use:		Marks a buffer as broken.
 */

extern int buf_break(buf */*b*/);

/* --- @buf_flip@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *
 * Returns:	---
 *
 * Use:		Flips a buffer so that if you've just been writing to it,
 *		you can now read from the bit you've written.
 */

extern void buf_flip(buf */*b*/);

/* --- @buf_ensure@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@size_t sz@ = size of data wanted
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Ensures that there are @sz@ bytes still in the buffer.
 */

extern int buf_ensure(buf */*b*/, size_t /*sz*/);

/* --- @buf_get@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	Pointer to the place in the buffer.
 *
 * Use:		Reserves a space in the buffer of the requested size, and
 *		returns its start address.
 */

extern void *buf_get(buf */*b*/, size_t /*sz*/);

/* --- @buf_put@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@const void *p@ = pointer to a buffer
 *		@size_t sz@ = size of the buffer
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Fetches data from some place and puts it in the buffer
 */

extern int buf_put(buf */*b*/, const void */*p*/, size_t /*sz*/);

/* --- @buf_getbyte@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *
 * Returns:	A byte, or less than zero if there wasn't a byte there.
 *
 * Use:		Gets a single byte from a buffer.
 */

extern int buf_getbyte(buf */*b*/);

/* --- @buf_putbyte@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@int ch@ = byte to write
 *
 * Returns:	Zero if OK, nonzero if there wasn't enough space.
 *
 * Use:		Puts a single byte in a buffer.
 */

extern int buf_putbyte(buf */*b*/, int /*ch*/);

/* --- @buf_getu{8,{16,24,32,64}{,l,b}}@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@uintSZ *w@ = where to put the word
 *
 * Returns:	Zero if OK, or nonzero if there wasn't a word there.
 *
 * Use:		Gets a word of appropriate size and order from a buffer.
 */

#define BUF_DECL_GETU_(n, W, w)						\
  extern int buf_getu##w(buf */*b*/, uint##n */*w*/);
DOUINTCONV(BUF_DECL_GETU_)

/* --- @buf_putu{8,{16,24,32,64}{,l,b}}@ --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@uintSZ w@ = word to write
 *
 * Returns:	Zero if OK, or nonzero if there wasn't enough space
 *
 * Use:		Puts a word into a buffer with appropriate size and order.
 */

#define BUF_DECL_PUTU_(n, W, w)						\
  extern int buf_putu##w(buf */*b*/, uint##n /*w*/);
DOUINTCONV(BUF_DECL_PUTU_)

/* --- @buf_getmem{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@size_t *nn@ = where to put the length
 *
 * Returns:	Pointer to the buffer data, or null.
 *
 * Use:		Gets a chunk of memory from a buffer.  The suffix is the
 *		width and byte order of the length; @z@ means null-
 *		terminated.
 */

#define BUF_DECL_GETMEM_(n, W, w)					\
  extern void *buf_getmem##w(buf */*b*/, size_t */*nn*/);
BUF_DOSUFFIXES(BUF_DECL_GETMEM_)

/* --- @buf_putmem{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@const void *p@ = pointer to data to write
 *		@size_t n@ = length to write
 *
 * Returns:	Zero if OK, nonzero if there wasn't enough space.
 *
 * Use:		Writes a chunk of data to a buffer.  The suffix is the
 *		width and byte order of the length; @z@ means null-
 *		terminated.
 */

#define BUF_DECL_PUTMEM_(n, W, w)					\
  extern int buf_putmem##w(buf */*b*/, const void */*p*/, size_t /*nn*/);
BUF_DOSUFFIXES(BUF_DECL_PUTMEM_)

/* --- @buf_getbuf{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@buf *bb@ = where to put the result
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Gets a block of data from a buffer, and writes its bounds to
 *		another buffer.
 */

#define BUF_DECL_GETBUF_(n, W, w)					\
  extern int buf_getbuf##w(buf */*b*/, buf */*bb*/);
BUF_DOSUFFIXES(BUF_DECL_GETBUF_)

/* --- @buf_putbuf{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@buf *bb@ = buffer to write
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts the contents of a buffer to a buffer.
 */

#define BUF_DECL_PUTBUF_(n, W, w)					\
  extern int buf_putbuf##w(buf */*b*/, buf */*bb*/);
BUF_DOSUFFIXES(BUF_DECL_PUTBUF_)

/* --- @buf_getdstr{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@dstr *d@ = where to put the result
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Gets a block of data from a buffer, and writes its contents
 *		to a string.
 */

#define BUF_DECL_GETDSTR_(n, W, w)					\
  extern int buf_getdstr##w(buf */*b*/, dstr */*d*/);
BUF_DOSUFFIXES(BUF_DECL_GETDSTR_)

/* --- @buf_putdstr{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@dstr *d@ = string to write
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts a dynamic string to a buffer.
 */

#define BUF_DECL_PUTDSTR_(n, W, w)					\
  extern int buf_putdstr##w(buf */*b*/, dstr */*d*/);
BUF_DOSUFFIXES(BUF_DECL_PUTDSTR_)

/* --- @buf_putstr{8,{16,24,32,64}{,l,b},z} --- *
 *
 * Arguments:	@buf *b@ = pointer to a buffer block
 *		@const char *p@ = string to write
 *
 * Returns:	Zero if it worked, nonzero if there wasn't enough space.
 *
 * Use:		Puts a null-terminated string to a buffer.
 */

#define BUF_DECL_PUTSTR_(n, W, w)					\
  extern int buf_putstr##w(buf */*b*/, const char */*p*/);
BUF_DOSUFFIXES(BUF_DECL_PUTSTR_)

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
