/* -*-c-*-
 *
 * Abstraction for memory allocation arenas
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_ARENA_H
#define MLIB_ARENA_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Header files ------------------------------------------------------*/

#include <stdlib.h>

/*----- Data structures ---------------------------------------------------*/

/* --- An arena structure --- */

typedef struct arena {
  const struct arena_ops *ops;
} arena;

typedef struct arena_ops {
  void *(*alloc)(arena */*a*/, size_t /*sz*/);
  void *(*realloc)(arena */*a*/, void */*p*/, size_t /*sz*/, size_t /*osz*/);
  void (*free)(arena */*a*/, void */*p*/);
  void (*purge)(arena */*a*/);
} arena_ops;

/*----- Global variables --------------------------------------------------*/

extern arena *arena_global;		/* Standard global arena */
extern arena arena_stdlib;		/* Arena based on @malloc@/@free@ */

/*----- Functions provided ------------------------------------------------*/

/* --- @arena_fakerealloc@ --- *
 *
 * Arguments:	@arena *a@ = pointer to arena block
 *		@void *p@ = pointer to memory block to resize
 *		@size_t sz@ = size desired for the block
 *		@size_t osz@ = size of the old block
 *
 * Returns:	---
 *
 * Use:		Standard fake @realloc@ function, for use if you don't
 *		support @realloc@ properly.
 */

extern void *arena_fakerealloc(arena */*a*/, void */*p*/,
			       size_t /*sz*/, size_t /*osz*/);

/* --- Useful macros --- */

#define A_ALLOC(a, sz) (((a)->ops->alloc)((a), (sz)))
#define A_REALLOC(a, p, sz, osz) (((a)->ops->realloc)((a), (p), (sz), (osz)))
#define A_FREE(a, p) (((a)->ops->free)((a), (p)))

/* --- Simple function equivalents --- */

extern void *a_alloc(arena */*a*/, size_t /*sz*/);
extern void *a_realloc(arena */*a*/, void */*p*/,
		       size_t /*sz*/, size_t /*osz*/);
extern void a_free(arena */*a*/, void */*p*/);

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
