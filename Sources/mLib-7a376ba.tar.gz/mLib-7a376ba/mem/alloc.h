/* -*-c-*-
 *
 * Memory allocation functions
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

#ifndef MLIB_ALLOC_H
#define MLIB_ALLOC_H

#ifdef __cplusplus
  extern "C" {
#endif

/*----- Required header files ---------------------------------------------*/

#include <stddef.h>

#ifndef MLIB_ARENA_H
#  include "arena.h"
#endif

/*----- Functions and macros ----------------------------------------------*/

/* --- @x_alloc@ --- *
 *
 * Arguments:	@arena *a@ = pointer to underlying arena
 *		@size_t sz@ = size of block to allocate
 *
 * Returns:	Pointer to allocated block.
 *
 * Use:		Allocates memory.  If there's not enough memory, the
 *		exception @EXC_NOMEM@ is thrown.
 */

extern void *x_alloc(arena */*a*/, size_t /*sz*/);

/* --- @x_strdup@ --- *
 *
 * Arguments:	@arena *a@ = pointer to underlying arena
 *		@const char *s@ = pointer to a string
 *
 * Returns:	Pointer to a copy of the string.
 *
 * Use:		Copies a string (like @strdup@ would, if it existed).  If
 *		there's not enough memory, the exception @EXC_NOMEM@ is
 *		thrown.
 */

extern char *x_strdup(arena */*a*/, const char */*s*/);

/* --- @x_realloc@ --- *
 *
 * Arguments:	@arena *a@ = pointer to underlying arena
 *		@void *p@ = pointer to a block of memory
 *		@size_t sz@ = new size desired for the block
 *		@size_t osz@ = size of the old block
 *
 * Returns:	Pointer to the resized memory block (which is almost
 *		certainly not in the same place any more).
 *
 * Use:		Resizes a memory block.  If there's not enough memory, the
 *		exception @EXC_NOMEM@ is thrown.
 */

extern void *x_realloc(arena */*a*/, void */*p*/,
		       size_t /*sz*/, size_t /*osz*/);

/* --- @x_free@ --- *
 *
 * Arguments:	@arena *a@ = pointer to underlying arena
 *		@void *p@ = pointer to a block of memory.
 *
 * Returns:	---
 *
 * Use:		Frees a block of memory.
 */

extern void x_free(arena */*a*/, void */*p*/);
#define x_free(a, p) A_FREE(a, p)

/*----- Old functions for the standard arena ------------------------------*/

/* --- @xmalloc@ --- *
 *
 * Arguments:	@size_t sz@ = size of block to allocate
 *
 * Returns:	Pointer to allocated block.
 *
 * Use:		Allocates memory.  If there's not enough memory, the
 *		exception @EXC_NOMEM@ is thrown.
 */

extern void *xmalloc(size_t /*sz*/);
#define xmalloc(sz) x_alloc(arena_global, (sz))

/* --- @xstrdup@ --- *
 *
 * Arguments:	@const char *s@ = pointer to a string
 *
 * Returns:	Pointer to a copy of the string.
 *
 * Use:		Copies a string (like @strdup@ would, if it existed).  If
 *		there's not enough memory, the exception @EXC_NOMEM@ is
 *		thrown.
 */

extern char *xstrdup(const char */*s*/);
#define xstrdup(p) x_strdup(arena_global, (p))

/* --- @xrealloc@ --- *
 *
 * Arguments:	@void *p@ = pointer to a block of memory
 *		@size_t sz@ = new size desired for the block
 *		@size_t osz@ = size of the old block
 *
 * Returns:	Pointer to the resized memory block (which is almost
 *		certainly not in the same place any more).
 *
 * Use:		Resizes a memory block.  If there's not enough memory, the
 *		exception @EXC_NOMEM@ is thrown.
 */

extern void *xrealloc(void */*p*/, size_t /*sz*/, size_t /*osz*/);
#define xrealloc(p, sz, osz) x_realloc(arena_global, (p), (sz), (osz))

/* --- @xfree@ --- *
 *
 * Arguments:	@void *p@ = pointer to a block of memory.
 *
 * Returns:	---
 *
 * Use:		Frees a block of memory.
 */

extern void xfree(void */*p*/);
#define xfree(p) x_free(arena_global, (p))

/*----- That's all, folks -------------------------------------------------*/

#ifdef __cplusplus
  }
#endif

#endif
