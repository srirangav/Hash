/* -*-c-*-
 *
 * Subarenas in resource pools
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include "pool.h"
#include "sub.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @pool_subarena@ --- *
 *
 * Arguments:	@pool *p@ = pointer to the pool
 *
 * Returns:	A subarena built from the pool's memory allocator.
 *
 * Use:		Creates a suballocation arena attached to a pool.  The arena
 *		and all of its memory will be freed when the pool is
 *		destroyed.
 */

subarena *pool_subarena(pool *p)
{
  subarena *sa = pool_alloc(p, sizeof(subarena));
  subarena_create(sa, &p->a);
  return (sa);
}

/*----- That's all, folks -------------------------------------------------*/
