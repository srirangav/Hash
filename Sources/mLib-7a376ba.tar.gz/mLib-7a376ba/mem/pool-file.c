/* -*-c-*-
 *
 * File handles in resource pools
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdio.h>

#include "pool.h"

/*----- Main code ---------------------------------------------------------*/

/* --- @pool_fopen@ --- *
 *
 * Arguments:	@pool *p@ = pointer to a pool
 *		@const char *file@ = name of the file to open
 *		@const char *how@ = string specifying opening parameters
 *
 * Returns:	A pointer to a pool resource containing an open file handle,
 *		or null if the file open filed.
 *
 * Use:		Opens a file so that it will be freed again when a pool is
 *		destroyed.
 */

static void pf_destroy(pool_resource *r) { pool_fclose((pool_file *)r); }

pool_file *pool_fopen(pool *p, const char *file, const char *how)
{
  FILE *fp;
  pool_file *pf;

  if ((fp = fopen(file, how)) == 0)
    return (0);
  pf = pool_alloc(p, sizeof(pool_file));
  POOL_ADD(p, &pf->r, pf_destroy);
  pf->fp = fp;
  return (pf);
}

/* --- @pool_fclose@ --- *
 *
 * Arguments:	@pool_file *pf@ = pointer to a file resource
 *
 * Returns:	The response from the @fclose@ function.
 *
 * Use:		Closes a file.  It is not an error to close a file multiple
 *		times.
 */

int pool_fclose(pool_file *pf)
{
  if (!pf->r.destroy)
    return (0);
  pf->r.destroy = 0;
  return (fclose(pf->fp));
}

/*----- That's all, folks -------------------------------------------------*/
