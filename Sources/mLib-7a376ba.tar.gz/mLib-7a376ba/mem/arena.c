/* -*-c-*-
 *
 * Abstraction for memory allocation arenas
 *
 * (c) 2000 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>

#include "arena.h"

/*----- The standard arena ------------------------------------------------*/

static void *_alloc(arena *a, size_t sz) { return malloc(sz); }
static void *_realloc(arena *a, void *p, size_t sz, size_t osz)
  { return realloc(p, sz); }
static void _free(arena *a, void *p) { free(p); }

static arena_ops stdlib_ops = { _alloc, _realloc, _free, 0 };
arena arena_stdlib = { &stdlib_ops };

/*----- Global variables --------------------------------------------------*/

arena *arena_global = &arena_stdlib;

/*----- Main code ---------------------------------------------------------*/

/* --- @arena_fakerealloc@ --- *
 *
 * Arguments:	@arena *a@ = pointer to arena block
 *		@void *p@ = pointer to memory block to resize
 *		@size_t sz@ = size desired for the block
 *		@size_t osz@ = size of the old block
 *
 * Returns:	---
 *
 * Use:		Standard fake @realloc@ function, for use if you don't
 *		support @realloc@ properly.
 */

void *arena_fakerealloc(arena *a, void *p, size_t sz, size_t osz)
{
  void *q = A_ALLOC(a, sz);
  if (!q)
    return (0);
  memcpy(q, p, sz > osz ? osz : sz);
  A_FREE(a, p);
  return (q);
}

/* --- Function equivalents of the macros --- */

void *a_alloc(arena *a, size_t sz) { return (A_ALLOC(a, sz)); }
void *a_realloc(arena *a, void *p, size_t sz, size_t osz)
{ return A_REALLOC(a, p, sz, osz); }
void a_free(arena *a, void *p) { A_FREE(a, p); }

/*----- That's all, folks -------------------------------------------------*/
