/* -*-c-*-
 *
 * Memory allocation functions
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

/* --- ANSI headers --- */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* --- Local headers --- */

#include "alloc.h"
#include "arena.h"
#include "exc.h"

/*----- Functions and macros ----------------------------------------------*/

/* --- @x_alloc@ --- *
 *
 * Arguments:	@arena *a@ = pointer to underlying arena
 *		@size_t sz@ = size of block to allocate
 *
 * Returns:	Pointer to allocated block.
 *
 * Use:		Allocates memory.  If there's not enough memory, the
 *		exception @EXC_NOMEM@ is thrown.
 */

void *x_alloc(arena *a, size_t sz)
{
  void *p = A_ALLOC(a, sz);
  if (!p)
    THROW(EXC_NOMEM);
  return (p);
}

/* --- @x_strdup@ --- *
 *
 * Arguments:	@arena *a@ = pointer to underlying arena
 *		@const char *s@ = pointer to a string
 *
 * Returns:	Pointer to a copy of the string.
 *
 * Use:		Copies a string (like @strdup@ would, if it existed).  If
 *		there's not enough memory, the exception @EXC_NOMEM@ is
 *		thrown.
 */

char *x_strdup(arena *a, const char *s)
{
  size_t sz = strlen(s) + 1;
  char *p = x_alloc(a, sz);
  memcpy(p, s, sz);
  return (p);
}

/* --- @x_realloc@ --- *
 *
 * Arguments:	@arena *a@ = pointer to underlying arena
 *		@void *p@ = pointer to a block of memory
 *		@size_t sz@ = new size desired for the block
 *		@size_t osz@ = size of the old block
 *
 * Returns:	Pointer to the resized memory block (which is almost
 *		certainly not in the same place any more).
 *
 * Use:		Resizes a memory block.  If there's not enough memory, the
 *		exception @EXC_NOMEM@ is thrown.
 */

void *x_realloc(arena *a, void *p, size_t sz, size_t osz)
{
  p = A_REALLOC(a, p, sz, osz);
  if (!p)
    THROW(EXC_NOMEM);
  return (p);
}

/* --- @x_free@ --- *
 *
 * Arguments:	@arena *a@ = pointer to underlying arena
 *		@void *p@ = pointer to a block of memory.
 *
 * Returns:	---
 *
 * Use:		Frees a block of memory.
 */

void (x_free)(arena *a, void *p) { x_free(a, p); }

/*----- Old functions for the standard arena ------------------------------*/

/* --- @xmalloc@ --- *
 *
 * Arguments:	@size_t sz@ = size of block to allocate
 *
 * Returns:	Pointer to allocated block.
 *
 * Use:		Allocates memory.  If there's not enough memory, the
 *		exception @EXC_NOMEM@ is thrown.
 */

void *(xmalloc)(size_t sz) { return xmalloc(sz); }

/* --- @xstrdup@ --- *
 *
 * Arguments:	@const char *s@ = pointer to a string
 *
 * Returns:	Pointer to a copy of the string.
 *
 * Use:		Copies a string (like @strdup@ would, if it existed).  If
 *		there's not enough memory, the exception @EXC_NOMEM@ is
 *		thrown.
 */

char *(xstrdup)(const char *s) { return xstrdup(s); }

/* --- @xrealloc@ --- *
 *
 * Arguments:	@void *p@ = pointer to a block of memory
 *		@size_t sz@ = new size desired for the block
 *		@size_t osz@ = size of the old block
 *
 * Returns:	Pointer to the resized memory block (which is almost
 *		certainly not in the same place any more).
 *
 * Use:		Resizes a memory block.  If there's not enough memory, the
 *		exception @EXC_NOMEM@ is thrown.
 */

void *(xrealloc)(void *p, size_t sz, size_t osz)
{ return xrealloc(p, sz, osz); }

/* --- @xfree@ --- *
 *
 * Arguments:	@void *p@ = pointer to a block of memory.
 *
 * Returns:	---
 *
 * Use:		Frees a block of memory.
 */

void (xfree)(void *p) { xfree(p); }

/*----- That's all, folks -------------------------------------------------*/
