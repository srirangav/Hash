/* -*-c-*-
 *
 * Tracing functions for debugging
 *
 * (c) 1998 Straylight/Edgeware
 */

/*----- Licensing notice --------------------------------------------------*
 *
 * This file is part of the mLib utilities library.
 *
 * mLib is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Library General Public License as
 * published by the Free Software Foundation; either version 2 of the
 * License, or (at your option) any later version.
 *
 * mLib is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with mLib; if not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA.
 */

/*----- Header files ------------------------------------------------------*/

/* --- ANSI headers --- */

#include <ctype.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* --- Local headers --- */

#include "trace.h"
#include "track.h"

/*----- Type definitions --------------------------------------------------*/

/* --- A track block --- *
 *
 * This gets prefixed to every block I manage.
 */

typedef union block {
  struct {
    union block *next;			/* Link to previous block */
    union block *prev;			/* Link to next block */
    size_t sz;				/* Size of the block */
    const char *ctx;			/* Pointer to allocating context */
  } x;					/* Main data area */
  long double _ld;			/* Long double for alignment */
  void *_p;				/* Void pointer for alignment */
} block;

/*----- Private state -----------------------------------------------------*/

/* --- Tracking memory usage --- */

static unsigned int used = 0;		/* Count of bytes occupied */
static block *list;			/* List of allocated blocks */

/* --- Trace level for verbose messages --- */

static unsigned int vLevel = 0;

/* --- Context tracking --- */

static track_ctx baseContext = {
  0, "[unknown context]"
};

static track_ctx *context = &baseContext;

/*----- Functions provided ------------------------------------------------*/

/* --- @track_setLevel@ --- *
 *
 * Arguments:	@unsigned int l@ = tracing level for allocation messages
 *
 * Returns:	---
 *
 * Use:		Sets the trace level for allocation messages.
 */

void track_setLevel(unsigned int l)
{
  vLevel = l;
}

/* --- @track_pushContext@ --- *
 *
 * Arguments:	@track_ctx *ctx@ = context holder to push
 *
 * Returns:	---
 *
 * Use:		Pushes the given context block onto the stack.
 */

void track_pushContext(track_ctx *ctx)
{
  ctx->next = context;
  context = ctx;
}

/* --- @track_popContext@ --- *
 *
 * Arguments:	@track_ctx *ctx@ = context holder to pop
 *
 * Returns:	---
 *
 * Use:		Removes the given context block from the stack.
 */

void track_popContext(track_ctx *ctx)
{
  context = ctx->next;
}

/* --- @track_malloc@ --- *
 *
 * Arguments:	@size_t sz@ = size requested
 *
 * Returns:	Pointer to allocated space, or null
 *
 * Use:		Allocates memory, and tracks how much is allocated.
 */

void *track_malloc(size_t sz)
{
  block *q = (malloc)(sz + sizeof(block));
  if (q) {
    used += sz;
    if (vLevel) {
      trace(vLevel, "(track) allocated %lu at %p in %s",
	    (unsigned long)sz, (void *)(q + 1), context->s);
    }
    q->x.sz = sz;
    q->x.next = list;
    q->x.prev = 0;
    q->x.ctx = context->s;
    if (q->x.next)
      q->x.next->x.prev = q;
    list = q;
    return (q + 1);
  }
  return (0);
}

/* --- @track_free@ --- *
 *
 * Arguments:	@void *p@ = pointer to an allocated block
 *
 * Returns:	---
 *
 * Use:		Frees memory, and tracks how much is still allocated.
 */

void track_free(void *p)
{
  block *q;

  if (!p)
    return;
  q = (block *)p - 1;
  if (vLevel) {
    trace(vLevel, "(track) freed %lu at %p for %s in %s",
	  (unsigned long)q->x.sz, (void *)(q + 1),
	  q->x.ctx, context->s);
  }
  if (q->x.next)
    q->x.next->x.prev = q->x.prev;
  if (q->x.prev)
    q->x.prev->x.next = q->x.next;
  else
    list = q->x.next;
  used -= q->x.sz;
  (free)(q);
}

/* --- @track_realloc@ --- *
 *
 * Arguments:	@void *p@ = pointer to an allocated block
 *		@size_t sz@ = how big it wants to be
 *
 * Returns:	Pointer to the new block.
 *
 * Use:		Reallocates a block, tracking how much memory is still
 *		available.
 */

void *track_realloc(void *p, size_t sz)
{
  size_t osz;
  block *q, *qq;
  if (p) {
    q = (block *)p - 1;
    osz = q->x.sz;
    if (q->x.next)
      q->x.next->x.prev = q->x.prev;
    if (q->x.prev)
      q->x.prev->x.next = q->x.next;
    else
      list = q->x.next;
  } else {
    q = 0;
    osz = 0;
  }
  qq = (realloc)(q, sz + sizeof(block));
  if (qq) {
    if (vLevel) {
      trace(vLevel,
	    "(track) reallocated %lu at %p to %lu for %s in %s",
	    (unsigned long)osz, (void *)(q + 1),
	    (unsigned long)sz,	(void *)(qq + 1),
	    qq->x.ctx, context->s);
    }
    qq->x.sz = sz;
    qq->x.next = list;
    qq->x.prev = 0;
    if (qq->x.next)
      qq->x.next->x.prev = qq;
    list = qq;
    used += sz - osz;
    qq->x.sz = sz;
    return (qq + 1);
  }
  return (0);
}

/* --- @track_used@ --- *
 *
 * Arguments:	---
 *
 * Returns:	A count of how much memory is used currently.
 *
 * Use:		Returns the amount of memory which the @track_@-functions
 *		above have counted as being currently allocated.
 */

unsigned long track_used(void)
{
  return (used);
}

/* --- @track_list@ --- *
 *
 * Arguments:	@unsigned int l@ = trace level to use
 *
 * Returns:	---
 *
 * Use:		Traces a dump of the currently known blocks.  Combined with
 *		a verbose dump of allocations and deallocations, and a
 *		good idea of which blocks were allocated where, this can
 *		be useful for locating memory leaks.  It's not exactly a
 *		picnic, though.
 */

void track_list(unsigned int l)
{
  block *q = list;

  if (!(tracing() & l))
    return;

  trace(l, "(track dump) Dumping all blocks.  Stand well back...");
  while (q) {
    trace(l, "(track dump) %p: %lu in %s",
	  (void *)(q + 1), (unsigned long)q->x.sz, q->x.ctx);
    q = q->x.next;
  }
}

/*----- That's all, folks -------------------------------------------------*/
