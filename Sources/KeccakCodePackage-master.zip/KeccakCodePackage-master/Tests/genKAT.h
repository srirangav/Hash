int genKAT_main();
