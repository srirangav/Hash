@dir /feature/api
@brief feature/api: In-process interface to starting/stopping Tor.
